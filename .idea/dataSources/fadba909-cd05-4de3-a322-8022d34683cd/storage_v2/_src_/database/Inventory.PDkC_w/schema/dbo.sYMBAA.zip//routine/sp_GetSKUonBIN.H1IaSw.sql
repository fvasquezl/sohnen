-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-08-24
-- Description:	Get SKU on BIN
-- =============================================
CREATE PROCEDURE sp_GetSKUonBIN
	@SKU		INT,
	@QTY		INT,
	@OrderID	NVARCHAR(50),
	@UserID		NVARCHAR(20)
AS
BEGIN
	DECLARE @TOTALQTY		INT,
			@CURSOR_STOCK	CURSOR,
			@Bin_Id			NVARCHAR(8),
			@Counter		INT
	SET NOCOUNT ON;
	DECLARE @TMPBIN	TABLE (BINID NVARCHAR(8), QTY INT)
    
	SET @TOTALQTY = ISNULL(@QTY,0)

	SET @CURSOR_STOCK = CURSOR FOR 
	
	SELECT Bin_Id, Counter FROM Inventory.dbo.Bin_Content WHERE ProductCatalog_Id = @SKU AND Bin_Id LIKE 'SM%' ORDER BY Counter DESC

	OPEN @CURSOR_STOCK 
	FETCH NEXT FROM @CURSOR_STOCK 
	INTO @Bin_Id, @Counter

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		
		IF(ISNULL(@Counter,0) >= ISNULL(@TOTALQTY,0) AND ISNULL(@TOTALQTY,0) > 0)
		BEGIN
			INSERT INTO @TMPBIN VALUES (@Bin_Id, @TOTALQTY)
			EXEC [Inventory].[dbo].[sp_BinInputOutputStock] @Bin_Id, @SKU, @TOTALQTY, @UserID, 2, 'OUT50', @OrderID
			SET @TOTALQTY = @TOTALQTY - @TOTALQTY
		END
		ELSE
		BEGIN
			IF(ISNULL(@TOTALQTY,0) > 0)
			BEGIN
				SET @TOTALQTY = @TOTALQTY - ISNULL(@Counter,0)
				INSERT INTO @TMPBIN VALUES (@Bin_Id, ISNULL(@Counter,0))
				EXEC [Inventory].[dbo].[sp_BinInputOutputStock] @Bin_Id, @SKU, @Counter, @UserID, 2, 'OUT50', @OrderID
			END
		END

		NEXT_FETCH:
		FETCH NEXT FROM @CURSOR_STOCK
		INTO @Bin_Id, @Counter
	END
	CLOSE      @CURSOR_STOCK
	DEALLOCATE @CURSOR_STOCK

	--SELECT * FROM Inventory.dbo.Bin_Content WHERE Bin_Id LIKE 'SM%' AND ProductCatalog_Id = @SKU
	
	--SELECT *, @TOTALQTY FROM @TMPBIN
END
go

