-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-8-2018
-- Description:	ChannelAdvisor Inventory Only Feed
-- =============================================
CREATE PROCEDURE [dbo].[sp_ChannelAdvisorInventoryFeed] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	 UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Quantity] =
	  (CASE 
		  
		  WHEN RIGHT([Attribute1Value],2) = 'CN' THEN [Remotes].[dbo].[fn_GetQtyByScanCode](LEFT([Attribute1Value],9),'CN')
		  WHEN RIGHT([Attribute1Value],3) = 'NEW' THEN [Remotes].[dbo].[fn_GetQtyByScanCode](LEFT([Attribute1Value],9),'NEW')
		  WHEN RIGHT([Attribute1Value],4) = 'USED' THEN [Remotes].[dbo].[fn_GetQtyByScanCode](LEFT([Attribute1Value],9),'USED')
		  WHEN RIGHT([Attribute1Value],2) = 'NC' THEN [Remotes].[dbo].[fn_GetQtyByScanCode](LEFT([Attribute1Value],9),'NC')

		  ELSE '0' END)

	 
		DROP TABLE IF EXISTS [Remotes].[dbo].[ChannelAdvisorInvTemp]

		---FINAL SELECT FOR FEED
		CREATE TABLE [Remotes].[dbo].[ChannelAdvisorInvTemp] ([Inventory Number] nvarchar(max),
		[Quantity Update Type] nvarchar(max),[Quantity] nvarchar(max)
		)

		INSERT INTO [Remotes].[dbo].[ChannelAdvisorInvTemp]
		SELECT DISTINCT
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Inventory Number] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Inventory Number], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Quantity Update Type] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Quantity Update Type], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Quantity] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Quantity]
		FROM [Remotes].[dbo].[ChannelAdvisor]  WITH (NOLOCK)
		WHERE ([MarkedForDeletion] IS NULL OR [MarkedForDeletion] = 0)
		--ORDER BY [ID] ASC

		--ADD CleanLaunch Items - NEW
		INSERT INTO [Remotes].[dbo].[ChannelAdvisorInvTemp]
		SELECT DISTINCT
		'"' + CL.[SKU]+'-'+CAST(CL.[ID] AS NVARCHAR(MAX))+'-NEW"' AS [Inventory Number], 
		'"AVAILABLE"' AS [Quantity Update Type], 
		'"' + CAST([Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'NEW') AS NVARCHAR(MAX)) + '"' AS [Quantity]
		FROM [Remotes].[dbo].[CleanLaunch] AS CL  WITH (NOLOCK)
		WHERE CL.[Condition] = 'New' AND  [Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'NEW') > 0

		--ADD CleanLaunch Items - CN
		INSERT INTO [Remotes].[dbo].[ChannelAdvisorInvTemp]
		SELECT DISTINCT
		'"' + CL.[SKU]+'-'+CAST(CL.[ID] AS NVARCHAR(MAX))+'-CN"' AS [Inventory Number], 
		'"AVAILABLE"' AS [Quantity Update Type], 
		'"' + CAST([Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'CN') AS NVARCHAR(MAX)) + '"' AS [Quantity]
		FROM [Remotes].[dbo].[CleanLaunch] AS CL  WITH (NOLOCK)
		WHERE CL.[Condition] = 'CN' AND  [Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'CN') > 0

		--ADD CleanLaunch Items - USED
		INSERT INTO [Remotes].[dbo].[ChannelAdvisorInvTemp]
		SELECT DISTINCT
		'"' + CL.[SKU]+'-'+CAST(CL.[ID] AS NVARCHAR(MAX))+'-USED"' AS [Inventory Number], 
		'"AVAILABLE"' AS [Quantity Update Type], 
		'"' + CAST([Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'USED') AS NVARCHAR(MAX)) + '"' AS [Quantity]
		FROM [Remotes].[dbo].[CleanLaunch] AS CL  WITH (NOLOCK)
		WHERE CL.[Condition] = 'Used' AND  [Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'USED') > 0



		--SELECT * FROM [Remotes].[dbo].[ChannelAdvisorInvTemp]

	DECLARE @selectstatement NVARCHAR(3000)
	DECLARE @cmd NVARCHAR(3000)

	--START SELECT STATEMENT
	SET @selectstatement = 'SELECT [Inventory Number], [Quantity], [Quantity Update Type] FROM [Remotes].[dbo].[ChannelAdvisorInvTemp] WITH (NOLOCK)'
	--END SELECT STATEMENT

	SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\BSQLShares\ChannelAdvisor\ca-invbody.csv" -SBSQL -Usa -PZ91bM473 -c -t"," -r"\n"'
	EXEC master..xp_cmdshell @cmd

	EXEC master..xp_cmdshell '"C:\BSQLShares\ChannelAdvisor\cainvfeed.bat"'


END
go

