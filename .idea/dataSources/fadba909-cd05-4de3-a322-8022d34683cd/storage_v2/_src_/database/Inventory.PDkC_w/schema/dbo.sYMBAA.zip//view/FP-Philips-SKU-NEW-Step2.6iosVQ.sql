CREATE VIEW dbo.[FP-Philips-SKU-NEW-Step2]
AS
SELECT        Brand, PartNumber, PartNumberV2, PartNumberV3, ModuleSKU, ModulePrebuilt, ModuleBuildability, BulbSKU, BulbQOH, KitSKU, CAST
                             ((SELECT        TotalStock
                                 FROM            dbo.Global_Stocks AS GS2
                                 WHERE        (FPPSKU.KitSKU = ProductCatalogId)) AS Int) AS KitQOH
FROM            dbo.[FP-Philips-SKU-NEW-Step1] AS FPPSKU
go

