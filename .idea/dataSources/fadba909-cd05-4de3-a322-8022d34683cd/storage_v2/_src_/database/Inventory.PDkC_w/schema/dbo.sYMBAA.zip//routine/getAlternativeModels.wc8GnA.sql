

CREATE FUNCTION [dbo].[getAlternativeModels](@PartNumber nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @myString nVarchar(max);
	DECLARE @Model nVarchar(max);
	DECLARE @AltModels nVarchar(max);
	
	SET @myString = '';
	
	
	
	DECLARE pn_cursor CURSOR 
	FOR 
	SELECT Model from [Inventory].[dbo].[CompatibilityDetails] cd WHERE cd.PartNumber = @PartNumber;
	OPEN pn_cursor; 
	FETCH NEXT FROM pn_cursor INTO @Model;
		
		WHILE @@FETCH_STATUS = 0 
		BEGIN
				DECLARE model_cursor CURSOR 
				FOR 
				SELECT AlternativeModel from Inventory.dbo.CompatibilityAlternativeModels cam where cam.OriginalModel = @Model;
				
				OPEN model_cursor; 
				FETCH NEXT FROM model_cursor INTO @AltModels;
				
				WHILE @@FETCH_STATUS = 0 
				BEGIN
					SET @myString = @myString + @AltModels + ', '
					
				FETCH NEXT FROM model_cursor INTO @AltModels;
				END
				CLOSE model_cursor 
				DEALLOCATE model_cursor 
							
			FETCH NEXT FROM pn_cursor INTO @Model;
		END	
	
	CLOSE pn_cursor 
	DEALLOCATE pn_cursor 
	
	IF @myString  <> '' 
	BEGIN
		SET @myString = LEFT(@myString, LEN(@myString)-1 )
	End
	
	
  RETURN @myString
  
END


go

