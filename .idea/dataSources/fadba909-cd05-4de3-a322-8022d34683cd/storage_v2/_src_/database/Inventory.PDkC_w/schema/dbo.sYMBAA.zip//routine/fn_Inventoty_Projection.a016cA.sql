-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Inventoty_Projection]
(
	@ProductCatalogId as integer, @InitialDate as datetime, @FinalDate as datetime
)
RETURNS real
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar as real
	
	
	DECLARE @days as integer
	DECLARE @mycount as real
	DECLARE @dialyfactor as real
	DECLARE @actualstock as real
	DECLARE @result as real

	-- Add the T-SQL statements to compute the return value here
	SET @resultvar = 0
	
	SET @days  = DATEDIFF(day, @InitialDate, @finalDate)

	

	if @days < 1
		begin
			SET @days = 0
			SET @dialyfactor = 0
			SET @ResultVar = 0
		end
	else
		begin
			SET @mycount = Inventory.dbo.fn_Count_Items_By_AdjustmentType(@ProductCatalogId, @InitialDate, @FinalDate, 2)
			if @days = 0
				begin
					SET @dialyfactor = @mycount
				end
			else
				begin
					SET @dialyfactor = @mycount / @days
					
					if @dialyfactor > 0
						begin
							SET @actualstock = Inventory.dbo.fn_GetProductStock(@ProductCatalogId)
							SET @ResultVar = @actualstock / @dialyfactor
							SET @ResultVar = ceiling(@ResultVar)
						end
					else
						begin
							SET @ResultVar = 0
						end
					
				end
		
		end
	
	
	
	-- Return the result of the function
	RETURN @ResultVar

END
go

