-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-22-2019
-- Description:	Create Sohnen SKU's
-- =============================================
CREATE PROCEDURE [dbo].[sp_CreateSKU] 

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		--CLEAN PURCHASES TABLE
			UPDATE [Sohnen].[dbo].[Purchases] SET
					[Brand] = LTRIM(RTRIM([Brand])),
					[MFGSKU] = LTRIM(RTRIM([MFGSKU]))
					


		  --INSERT NEW SKUS - TV
		  		  INSERT INTO [Sohnen].[dbo].[SKUData](
					 [SKU]
					,[Brand]
					,[Model]
					,[Description]
					,[EstimatedRetail]
					,[AvgCost]
					,[AddedDate]
					,[CategoryID])

			SELECT DISTINCT
			  'SNTV'+  CAST(FORMAT(((SELECT COUNT([SKU]) FROM [Sohnen].[dbo].[SKUData] WHERE [CategoryID] = P.[BTSCategoryID]) + ROW_NUMBER() OVER(ORDER BY [Brand], [MFGSKU] ASC)),'000000') AS NVARCHAR(10)) AS [SKU]
			  ,RTRIM(LTRIM(P.[Brand])) AS [Brand]
			  ,RTRIM(LTRIM(P.[MFGSKU])) AS [Model]
			  ,(SELECT TOP(1) P2.[ItemDescription] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC)  AS [Description]
			  ,CAST(MIN(P.[EstimatedRetail]) AS decimal(10,2)) AS [EstimatedRetail]
			  ,CAST(AVG(P.[Price]) AS decimal(10,2)) AS [AvgCost]
			  ,GETDATE() AS [AddedDate]
			  ,(SELECT TOP(1) P2.[BTSCategoryID] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC) AS [CategoryID]
		  FROM [Sohnen].[dbo].[Purchases] AS P
		  WHERE RTRIM(LTRIM(P.[MFGSKU])) NOT IN (SELECT [Model] FROM [Sohnen].[dbo].[SKUData])
		  AND P.[BTSCategoryID] = 1
		  GROUP BY P.[Brand], P.[MFGSKU], P.[BTSCategoryID]


		  --INSERT NEW SKUS - BLENDERS
		  		  INSERT INTO [Sohnen].[dbo].[SKUData](
					 [SKU]
					,[Brand]
					,[Model]
					,[Description]
					,[EstimatedRetail]
					,[AvgCost]
					,[AddedDate]
					,[CategoryID])

			SELECT DISTINCT
			  'SNBL'+  CAST(FORMAT(((SELECT COUNT([SKU]) FROM [Sohnen].[dbo].[SKUData] WHERE [CategoryID] = P.[BTSCategoryID]) + ROW_NUMBER() OVER(ORDER BY [Brand], [MFGSKU] ASC)),'000000') AS NVARCHAR(10)) AS [SKU]
			  ,RTRIM(LTRIM(P.[Brand])) AS [Brand]
			  ,RTRIM(LTRIM(P.[MFGSKU])) AS [Model]
			  ,(SELECT TOP(1) P2.[ItemDescription] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC)  AS [Description]
			  ,CAST(MIN(P.[EstimatedRetail]) AS decimal(10,2)) AS [EstimatedRetail]
			  ,CAST(AVG(P.[Price]) AS decimal(10,2)) AS [AvgCost]
			  ,GETDATE() AS [AddedDate]
			  ,(SELECT TOP(1) P2.[BTSCategoryID] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC) AS [CategoryID]
		  FROM [Sohnen].[dbo].[Purchases] AS P
		  WHERE RTRIM(LTRIM(P.[MFGSKU])) NOT IN (SELECT [Model] FROM [Sohnen].[dbo].[SKUData])
		  AND P.[BTSCategoryID] = 2
		  GROUP BY P.[Brand], P.[MFGSKU], P.[BTSCategoryID]


		  --INSERT NEW SKUS - COFFEE MAKERS
		  		  INSERT INTO [Sohnen].[dbo].[SKUData](
					 [SKU]
					,[Brand]
					,[Model]
					,[Description]
					,[EstimatedRetail]
					,[AvgCost]
					,[AddedDate]
					,[CategoryID])

			SELECT DISTINCT
			  'SNCF'+  CAST(FORMAT(((SELECT COUNT([SKU]) FROM [Sohnen].[dbo].[SKUData] WHERE [CategoryID] = P.[BTSCategoryID]) + ROW_NUMBER() OVER(ORDER BY [Brand], [MFGSKU] ASC)),'000000') AS NVARCHAR(10)) AS [SKU]
			  ,RTRIM(LTRIM(P.[Brand])) AS [Brand]
			  ,RTRIM(LTRIM(P.[MFGSKU])) AS [Model]
			  ,(SELECT TOP(1) P2.[ItemDescription] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC)  AS [Description]
			  ,CAST(MIN(P.[EstimatedRetail]) AS decimal(10,2)) AS [EstimatedRetail]
			  ,CAST(AVG(P.[Price]) AS decimal(10,2)) AS [AvgCost]
			  ,GETDATE() AS [AddedDate]
			  ,(SELECT TOP(1) P2.[BTSCategoryID] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC) AS [CategoryID]
		  FROM [Sohnen].[dbo].[Purchases] AS P
		  WHERE RTRIM(LTRIM(P.[MFGSKU])) NOT IN (SELECT [Model] FROM [Sohnen].[dbo].[SKUData])
		  AND P.[BTSCategoryID] = 3
		  GROUP BY P.[Brand], P.[MFGSKU], P.[BTSCategoryID]


		  --INSERT NEW SKUS - COOKING POTS
		  		  INSERT INTO [Sohnen].[dbo].[SKUData](
					 [SKU]
					,[Brand]
					,[Model]
					,[Description]
					,[EstimatedRetail]
					,[AvgCost]
					,[AddedDate]
					,[CategoryID])

			SELECT DISTINCT
			  'SNCP'+  CAST(FORMAT(((SELECT COUNT([SKU]) FROM [Sohnen].[dbo].[SKUData] WHERE [CategoryID] = P.[BTSCategoryID]) + ROW_NUMBER() OVER(ORDER BY [Brand], [MFGSKU] ASC)),'000000') AS NVARCHAR(10)) AS [SKU]
			  ,RTRIM(LTRIM(P.[Brand])) AS [Brand]
			  ,RTRIM(LTRIM(P.[MFGSKU])) AS [Model]
			  ,(SELECT TOP(1) P2.[ItemDescription] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC)  AS [Description]
			  ,CAST(MIN(P.[EstimatedRetail]) AS decimal(10,2)) AS [EstimatedRetail]
			  ,CAST(AVG(P.[Price]) AS decimal(10,2)) AS [AvgCost]
			  ,GETDATE() AS [AddedDate]
			  ,(SELECT TOP(1) P2.[BTSCategoryID] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC) AS [CategoryID]
		  FROM [Sohnen].[dbo].[Purchases] AS P
		  WHERE RTRIM(LTRIM(P.[MFGSKU])) NOT IN (SELECT [Model] FROM [Sohnen].[dbo].[SKUData])
		  AND P.[BTSCategoryID] = 4
		  GROUP BY P.[Brand], P.[MFGSKU], P.[BTSCategoryID]

		  --INSERT NEW SKUS - AIR FRYERS
		  		  INSERT INTO [Sohnen].[dbo].[SKUData](
					 [SKU]
					,[Brand]
					,[Model]
					,[Description]
					,[EstimatedRetail]
					,[AvgCost]
					,[AddedDate]
					,[CategoryID])

			SELECT DISTINCT
			  'SNAF'+  CAST(FORMAT(((SELECT COUNT([SKU]) FROM [Sohnen].[dbo].[SKUData] WHERE [CategoryID] = P.[BTSCategoryID]) +  ROW_NUMBER() OVER(ORDER BY [Brand], [MFGSKU] ASC)),'000000') AS NVARCHAR(10)) AS [SKU]
			  ,RTRIM(LTRIM(P.[Brand])) AS [Brand]
			  ,RTRIM(LTRIM(P.[MFGSKU])) AS [Model]
			  ,(SELECT TOP(1) P2.[ItemDescription] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC)  AS [Description]
			  ,CAST(MIN(P.[EstimatedRetail]) AS decimal(10,2)) AS [EstimatedRetail]
			  ,CAST(AVG(P.[Price]) AS decimal(10,2)) AS [AvgCost]
			  ,GETDATE() AS [AddedDate]
			  ,(SELECT TOP(1) P2.[BTSCategoryID] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC) AS [CategoryID]
		  FROM [Sohnen].[dbo].[Purchases] AS P
		  WHERE RTRIM(LTRIM(P.[MFGSKU])) NOT IN (SELECT [Model] FROM [Sohnen].[dbo].[SKUData])
		  AND P.[BTSCategoryID] = 5
		  GROUP BY P.[Brand], P.[MFGSKU], P.[BTSCategoryID]


		  --INSERT NEW SKUS - VACUUM CLEANERS
		  		  INSERT INTO [Sohnen].[dbo].[SKUData](
					 [SKU]
					,[Brand]
					,[Model]
					,[Description]
					,[EstimatedRetail]
					,[AvgCost]
					,[AddedDate]
					,[CategoryID])

			SELECT DISTINCT
			  'SNVC'+  CAST(FORMAT(((SELECT COUNT([SKU]) FROM [Sohnen].[dbo].[SKUData] WHERE [CategoryID] = P.[BTSCategoryID]) + ROW_NUMBER() OVER(ORDER BY [Brand], [MFGSKU] ASC)),'000000') AS NVARCHAR(10)) AS [SKU]
			  ,RTRIM(LTRIM(P.[Brand])) AS [Brand]
			  ,RTRIM(LTRIM(P.[MFGSKU])) AS [Model]
			  ,(SELECT TOP(1) P2.[ItemDescription] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC)  AS [Description]
			  ,CAST(MIN(P.[EstimatedRetail]) AS decimal(10,2)) AS [EstimatedRetail]
			  ,CAST(AVG(P.[Price]) AS decimal(10,2)) AS [AvgCost]
			  ,GETDATE() AS [AddedDate]
			  ,(SELECT TOP(1) P2.[BTSCategoryID] FROM [Sohnen].[dbo].[Purchases] AS P2 WHERE P2.[Brand] = RTRIM(LTRIM(P.[Brand])) AND P2.[MFGSKU] = RTRIM(LTRIM(P.[MFGSKU])) ORDER BY P2.[MFGSKU] ASC) AS [CategoryID]
		  FROM [Sohnen].[dbo].[Purchases] AS P
		  WHERE RTRIM(LTRIM(P.[MFGSKU])) NOT IN (SELECT [Model] FROM [Sohnen].[dbo].[SKUData])
		  AND P.[BTSCategoryID] = 6
		  GROUP BY P.[Brand], P.[MFGSKU], P.[BTSCategoryID]


	--INSERT NEW SKUS into Inventory Table
		INSERT INTO [Sohnen].[dbo].[Inventory] ([SKU])
			SELECT DISTINCT SKUD.[SKU] FROM [Sohnen].[dbo].[SKUData] AS SKUD
			LEFT OUTER JOIN [Sohnen].[dbo].[Inventory] AS INV ON (SKUD.[SKU] = INV.[SKU])
			WHERE INV.[SKU] IS NULL

    --INSERT NEW SKUS into Attributes Table
		INSERT INTO [Sohnen].[dbo].[Attributes] ([SKU])
			SELECT DISTINCT SKUD.[SKU] FROM [Sohnen].[dbo].[SKUData] AS SKUD
			LEFT OUTER JOIN [Sohnen].[dbo].[Attributes] AS ATR ON (SKUD.[SKU] = ATR.[SKU])
			WHERE ATR.[SKU] IS NULL


	--Update AVG Cost and EstimatedRetail based on latest data
		UPDATE SKUD SET 
				SKUD.[AvgCost] = (SELECT CAST(AVG([Price]) AS decimal(10,2)) FROM [Sohnen].[dbo].[Purchases] AS P WHERE RTRIM(LTRIM(P.[MFGSKU])) = SKUD.[Model]), 
				SKUD.[EstimatedRetail] = (SELECT CAST(MIN(P.[EstimatedRetail]) AS decimal(10,2)) FROM [Sohnen].[dbo].[Purchases] AS P WHERE RTRIM(LTRIM(P.[MFGSKU])) = SKUD.[Model]),
				SKUD.[Description] = (SELECT TOP(1) P.[ItemDescription] FROM [Sohnen].[dbo].[Purchases] AS P WHERE RTRIM(LTRIM(P.[Brand])) = SKUD.[Brand] AND RTRIM(LTRIM(P.[MFGSKU])) = SKUD.[Model])
		FROM [Sohnen].[dbo].[SKUData] AS SKUD
		


	--UPDATE SKU in Purchases Table
		UPDATE P SET P.BTSSKU = SKUD.[SKU]
		FROM [Sohnen].[dbo].[Purchases] AS P
		LEFT OUTER JOIN [Sohnen].[dbo].[SKUData] AS SKUD ON (RTRIM(LTRIM(P.[MFGSKU])) = SKUD.[Model])




END
go

