-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_QB_ExpectedDate]
(

	@sku int
)
RETURNS date
AS
BEGIN
	DECLARE @result date;
	set @result = '';
	
	
	SET @result = (
						select top 1 ExpectedDate from
						inventory.dbo.QBPurchaseOrderBackorders
						WHERE  CAST(@sku as nvarchar) = CAST(inventory.dbo.QBPurchaseOrderBackorders.SKU AS nvarchar)
						order by ExpectedDate asc
						
						);
	
/*
	if @result is null
	BEGIN
		SET @result = '//';
	END
*/	
	return @result

END
go

