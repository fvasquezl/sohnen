-- =============================================
-- Author:		Hubet Cárdenas Isla
-- Create date: 2017-07-13
-- Description:	Get Inventory FBA Manage
-- =============================================
CREATE PROCEDURE [dbo].[AmazonAPI_insertInventoryFBAManage]
	-- Add the parameters for the stored procedure here
	@pOption NVARCHAR(50) = NULL,
	@sku NVARCHAR(50) = NULL,
	@fnsku NVARCHAR(50) = NULL,
	@asin NVARCHAR(50) = NULL,
	@product_name NVARCHAR(2500) = NULL,
	@condition NVARCHAR(50) = NULL,
	@your_price NVARCHAR(50) = NULL,
	@mfn_listing_exists NVARCHAR(50) = NULL,
	@mfn_fulfillable_quantity INT = NULL,
	@afn_listing_exists NVARCHAR(50) = NULL,
	@afn_warehouse_quantity INT = NULL,
	@afn_fulfillable_quantity INT = NULL,
	@afn_unsellable_quantity INT = NULL,
	@afn_reserved_quantity INT = NULL,
	@afn_total_quantity INT = NULL,
	@per_unit_volume NVARCHAR(50) = NULL,
	@afn_inbound_working_quantity INT = NULL,
	@afn_inbound_shipped_quantity INT = NULL,
	@afn_inbound_receiving_quantity INT = NULL
AS
	SET @mfn_fulfillable_quantity = ISNULL(@mfn_fulfillable_quantity, 0) 
	SET @afn_warehouse_quantity = ISNULL(@afn_warehouse_quantity, 0)
	SET @afn_fulfillable_quantity = ISNULL(@afn_fulfillable_quantity, 0)
	SET @afn_unsellable_quantity = ISNULL(@afn_unsellable_quantity, 0)
	SET @afn_reserved_quantity = ISNULL(@afn_reserved_quantity, 0)
	SET @afn_total_quantity = ISNULL(@afn_total_quantity, 0)
	SET @afn_inbound_working_quantity = ISNULL(@afn_inbound_working_quantity, 0)
	SET @afn_inbound_shipped_quantity = ISNULL(@afn_inbound_shipped_quantity, 0)
	SET @afn_inbound_receiving_quantity = ISNULL(@afn_inbound_receiving_quantity, 0)
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @pOption = 'DROP'
	BEGIN
		TRUNCATE TABLE [dbo].[AmazonAPI_InventoryFBAManage_SG]
	END
	ELSE IF @pOption = 'INSERT'
	BEGIN
		INSERT INTO [dbo].[AmazonAPI_InventoryFBAManage_SG]([sku],
											   [fnsku],
											   [asin],
											   [product_name],
											   [condition],
											   [your_price],
											   [mfn_listing_exists],
											   [mfn_fulfillable_quantity],
											   [afn_listing_exists],
											   [afn_warehouse_quantity],
											   [afn_fulfillable_quantity],
											   [afn_unsellable_quantity],
											   [afn_reserved_quantity],
											   [afn_total_quantity],
											   [per_unit_volume],
											   [afn_inbound_working_quantity],
											   [afn_inbound_shipped_quantity],
											   [afn_inbound_receiving_quantity])
									    VALUES(@sku,
											   @fnsku,
											   @asin,
											   @product_name,
											   @condition,
											   @your_price,
											   @mfn_listing_exists,
											   @mfn_fulfillable_quantity,
											   @afn_listing_exists,
											   @afn_warehouse_quantity,
											   @afn_fulfillable_quantity,
											   @afn_unsellable_quantity,
											   @afn_reserved_quantity,
											   @afn_total_quantity,
											   @per_unit_volume,
											   @afn_inbound_working_quantity,
											   @afn_inbound_shipped_quantity,
											   @afn_inbound_receiving_quantity)
	END
	ELSE IF @pOption = 'SELECT'
	BEGIN
		SELECT TOP (1000) *
		  FROM [Remotes].[dbo].[AmazonAPI_Orders] WITH(NOLOCK)
	END
	ELSE IF @pOption = 'UPDATE'
	BEGIN
		DECLARE @iQty INT = 0

		SET @iQty = (SELECT COUNT(*) FROM [dbo].[AmazonAPI_InventoryFBAManage_SG] WITH(NOLOCK))
		
		IF @iQty > 0
		BEGIN
			TRUNCATE TABLE [dbo].[AmazonAPI_InventoryFBAManage]

			INSERT INTO [dbo].[AmazonAPI_InventoryFBAManage]
			SELECT * FROM [dbo].[AmazonAPI_InventoryFBAManage_SG] WITH(NOLOCK)
		END
	END
END
/*
	SELECT * FROM [dbo].[AmazonAPI_InventoryFBAManage] WHERE ISNULL(your_price, '') = '' 
	SELECT * FROM [dbo].[AmazonAPI_InventoryFBAManage] WHERE ISNULL(per_unit_volume, '') = ''
*/
go

