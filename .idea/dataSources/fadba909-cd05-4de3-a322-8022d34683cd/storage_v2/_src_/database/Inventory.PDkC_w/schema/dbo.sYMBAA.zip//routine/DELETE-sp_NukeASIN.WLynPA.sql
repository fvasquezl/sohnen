-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 2-17-2016
-- Description:	
-- =============================================
-- Update by:		Eduardo Gutierrez
-- Create date: 2018-08-07
-- Description:	Add UserID
-- =============================================
CREATE PROCEDURE [dbo].[sp_NukeASIN] 
	-- Add the parameters for the stored procedure here
	@pASIN nvarchar(50) = 0, 
	@pCountryCode nvarchar(3) = 0,
	@pUserID	NVARCHAR(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @SellerSKU AS nvarchar(100)

	SET @SellerSKU = (Select TOP(1) DARTFBMSKU FROM Inventory.dbo.AmazonMerchantSKU WHERE [ASIN] = @pASIN)
	--Select TOP(1) DARTFBMSKU FROM Inventory.dbo.AmazonMerchantSKU WHERE [ASIN] = 'B0033IR068'

	--Code for NUKE ASIN

	--WHEN COUNTRYCODE = US
	IF @pCountryCode = 'US'
	BEGIN
	
	DELETE ASKU FROM [OrderManager].[dbo].[AliasSKUs] AS ASKU 
	LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU ON (ASKU.[AliasSKU] = AZMSKU.[DARTFBMSKU])
	WHERE AZMSKU.[ASIN] = @pASIN

	DELETE ASKU FROM [OrderManager].[dbo].[AliasSKUs] AS ASKU 
	LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU ON (ASKU.[AliasSKU] = AZMSKU.[DARTFBMSKU]+'FLX')
	WHERE AZMSKU.[ASIN] = @pASIN

	DELETE ASKU FROM [OrderManager].[dbo].[AliasSKUs] AS ASKU 
	LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU ON (ASKU.[AliasSKU] = AZMSKU.[DARTFBASKU])
	WHERE AZMSKU.[ASIN] = @pASIN

	DELETE ASKU FROM [OrderManager].[dbo].[AliasSKUs] AS ASKU 
	LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU ON (ASKU.[AliasSKU] = AZMSKU.[DARTMFPSKU])
	WHERE AZMSKU.[ASIN] = @pASIN

	DELETE ASKU FROM [OrderManager].[dbo].[AliasSKUs] AS ASKU 
	LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU ON (ASKU.[AliasSKU] = AZMSKU.[ELEMENTARYVISIONFBASKU])
	WHERE AZMSKU.[ASIN] = @pASIN

	DELETE ASKU FROM [OrderManager].[dbo].[AliasSKUs] AS ASKU 
	LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU ON (ASKU.[AliasSKU] = AZMSKU.[ELEMENTARYVISIONFBMSKU])
	WHERE AZMSKU.[ASIN] = @pASIN
	
	--Delete when CountryCode = US
	DELETE FROM AmazonExclusiveBulbs.dbo.All_Listings_Report WHERE product_id = @pASIN 

	PRINT @pASIN + ' DELETED FROM [OrderManager].[dbo].[AliasSKUS] tables with CountryCode: ALL'
	END

	---WHEN COUNTRYCODE = CA

	IF @pCountryCode = 'CA'
	BEGIN
	DELETE ASKU FROM [OrderManager].[dbo].[AliasSKUs] AS ASKU 
	LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU ON (ASKU.[AliasSKU] = AZMSKU.[DARTFBMSKUCA])
	WHERE AZMSKU.[ASIN] = @pASIN

	DELETE ASKU FROM [OrderManager].[dbo].[AliasSKUs] AS ASKU 
	LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU ON (ASKU.[AliasSKU] = AZMSKU.[DARTFBASKUCA])
	WHERE AZMSKU.[ASIN] = @pASIN

	PRINT @pASIN + ' DELETED FROM [OrderManager].[dbo].[AliasSKUS] tables with CountryCode: ALL'
	END


	---OLD DATABASE
	DELETE FROM [Inventory].[dbo].[Amazon] WHERE [ASIN] = @pASIN AND [CountryCode] = @pCountryCode
	PRINT @pASIN + ' DELETED FROM [Inventory].[dbo].[Amazon] TABLES WITH CountryCode: '+@pCountryCode

	DELETE FROM [Inventory].[dbo].[AmazonASINData] WHERE [ASIN] = @pASIN AND [CountryCode] = @pCountryCode
	PRINT @pASIN + ' DELETED FROM [Inventory].[dbo].[AmazonASINData] TABLES WITH CountryCode: '+@pCountryCode
	

	--NEW DATABASE
	DELETE FROM [MiTech].[amz].[Amazon] WHERE [ASIN] = @pASIN AND [CountryCode] = @pCountryCode
	PRINT @pASIN + ' DELETED FROM [MiTech].[amz].[Amazon] TABLES WITH CountryCode: '+@pCountryCode

	DELETE FROM [MiTech].[amzAPI].[ASINDetails] WHERE [ASIN] = @pASIN
	PRINT @pASIN + ' DELETED FROM [MiTech].[amzAPI].[ASINDetails] TABLE'

	DELETE FROM [MiTech].[amzAPI].[ASINDetailsRelationship] WHERE [ASIN] = @pASIN
	PRINT @pASIN + ' DELETED FROM [MiTech].[amzAPI].[ASINDetailsRelationship] TABLE'

	DELETE FROM [MiTech].[amzAPI].[ASINDetailsSalesRanking] WHERE [ASIN] = @pASIN
	PRINT @pASIN + ' DELETED FROM [MiTech].[amzAPI].[ASINDetailsRelationship] TABLE'



	--NOTES: This is ok because it will get replaced if there are other countries with same asin... a cron will reinject this
	DELETE FROM [Inventory].[dbo].[AmazonMerchantSKU] WHERE [ASIN] = @pASIN
	PRINT @pASIN + ' DELETED FROM [Inventory].[dbo].[AmazonMerchantSKU] tables with CountryCode: ALL'

			--NOTES: We delete from AmazonFBA but not AmazonFBAOrders to keep FBA Order History	
	DELETE FROM [Inventory].[dbo].[AmazonFBA] WHERE [ASIN] = @pASIN
	PRINT @pASIN + ' DELETED FROM [Inventory].[dbo].[AmazonFBA] tables with CountryCode: ALL'
	
	INSERT [Inventory].[dbo].[AmazonNukedASINs] ([ASIN],[SellerSKU],[CountryCode],[UserID]) VALUES (@pASIN, @SellerSKU, @pCountryCode,@pUserID)
	PRINT 'Inserted into NukedASIN Table: ' + @pASIN + ' ' + @pCountryCode
	PRINT 'ASIN Nuke Completed'

	DELETE FROM [192.168.0.36].[Amazon].[dbo].[AmazonASINData] WHERE [ASIN] = @pASIN
	PRINT @pASIN + ' DELETED FROM [192.168.0.36].[Amazon].[dbo].[AmazonASINData] TABLES WITH CountryCode: ALL'

END
go

