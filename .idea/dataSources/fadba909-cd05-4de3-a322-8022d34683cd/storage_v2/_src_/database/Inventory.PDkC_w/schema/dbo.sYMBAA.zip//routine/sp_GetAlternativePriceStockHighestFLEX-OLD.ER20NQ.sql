-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-03-30
-- Description:	Get FLEX Alternative Highest Stock and Price
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetAlternativePriceStockHighestFLEX]
	@pSKU INT
AS
BEGIN
	DECLARE @Result				BIT = 0,
			@SKU				INT, 
			@tQOH				INT, 
			@PriceFloorFBA		DECIMAL(10,2), 
			@PriceCeilingFBA	DECIMAL(10,2),
			@CategoryID			INT,
			@CheckAlwaysInStock INT,
			@IsGeneric			BIT
	SET NOCOUNT ON;

	--DECLARE @tmpSKUALTS AS TABLE ([SKU] INT, [tQOH] INT, PriceFloorFBA DECIMAL(10,2), PriceCeilingFBA DECIMAL(10,2))
	DECLARE @tmpSKUALTS AS TABLE ([SKU] INT, [tQOH] INT, PriceFloorFBA DECIMAL(10,2), PriceCeilingFBA DECIMAL(10,2), SEQ INT)

	(SELECT @CategoryID = [CategoryID],  @CheckAlwaysInStock = [AlwaysInStock] FROM [Inventory].[dbo].[ProductCatalog] WITH(NOLOCK) WHERE [ID] = @pSKU)

	--IF ALWAYS IN STOCK
	IF @CheckAlwaysInStock = 1
	BEGIN
		INSERT INTO @tmpSKUALTS ([SKU],[tQOH],[PriceFloorFBA],[PriceCeilingFBA],SEQ)
		SELECT @pSKU, '500', PC.[PriceFloorFBA], PC.[PriceCeilingFBA], 1
		FROM [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK)
		LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] PC WITH(NOLOCK) ON (PC.[ID] = GS.[ProductCatalogId])
		WHERE GS.[ProductCatalogId] = @pSKU
		GOTO ENDALL
	END
	--IF ORIGINAL
	IF @CategoryID IN ('10','11','12','13','20','21','22','23','62','64','14','24')
	BEGIN
	
		--INSERT INTO @tmpSKUALTS ([SKU],[tQOH],[PriceFloorFBA],[PriceCeilingFBA])
		--SELECT PJD.[EncSKU], GS.[TotalStock], PC.[PriceFloorFBA], PC.[PriceCeilingFBA]
		--FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK)
		--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS (NOLOCK) ON (PJD.[EncSKU] = GS.[ProductCatalogId])
		--LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] PC (NOLOCK) ON (PC.[ID] = PJD.[EncSKU])
		--WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
		--OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
		--OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
		--OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
		--OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
		--OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))

		--INSERT INTO @tmpSKUALTS ([SKU],[tQOH],[PriceFloorFBA],[PriceCeilingFBA])
		--SELECT PJD.[EncSKUPH], GS.[TotalStock], PC.[PriceFloorFBA], PC.[PriceCeilingFBA]
		--FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK)
		--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS (NOLOCK) ON (PJD.[EncSKUPH] = GS.[ProductCatalogId])
		--LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] PC (NOLOCK) ON (PC.[ID] = PJD.[EncSKUPH])
		--WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
		--OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
		--OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
		--OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
		--OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
		--OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))
	
		--INSERT INTO @tmpSKUALTS ([SKU],[tQOH],[PriceFloorFBA],[PriceCeilingFBA])
		--SELECT PJD.[EncSKUOS], GS.[TotalStock] , PC.[PriceFloorFBA], PC.[PriceCeilingFBA]
		--FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK)
		--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS (NOLOCK) ON (PJD.[EncSKUOS] = GS.[ProductCatalogId])
		--LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] PC (NOLOCK) ON (PC.[ID] = PJD.[EncSKUOS])
		--WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
		--OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
		--OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
		--OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
		--OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
		--OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))
	
		--INSERT INTO @tmpSKUALTS ([SKU],[tQOH],[PriceFloorFBA],[PriceCeilingFBA])
		--SELECT PJD.[EncSKUPX], GS.[TotalStock], PC.[PriceFloorFBA], PC.[PriceCeilingFBA]
		--FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK)
		--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS (NOLOCK) ON (PJD.[EncSKUPX] = GS.[ProductCatalogId])
		--LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] PC (NOLOCK) ON (PC.[ID] = PJD.[EncSKUPX])
		--WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
		--OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
		--OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
		--OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
		--OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
		--OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))
	
		--INSERT INTO @tmpSKUALTS ([SKU],[tQOH],[PriceFloorFBA],[PriceCeilingFBA])
		--SELECT PJD.[EncSKUUSH], GS.[TotalStock], PC.[PriceFloorFBA], PC.[PriceCeilingFBA]
		--FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK)
		--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS (NOLOCK) ON (PJD.[EncSKUUSH] = GS.[ProductCatalogId])
		--LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] PC (NOLOCK) ON (PC.[ID] = PJD.[EncSKUUSH])
		--WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
		--OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
		--OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
		--OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
		--OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
		--OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))

		--INSERT INTO @tmpSKUALTS ([SKU],[tQOH],[PriceFloorFBA],[PriceCeilingFBA])
		--SELECT PJD.[EncSKUOEM], GS.[TotalStock], PC.[PriceFloorFBA], PC.[PriceCeilingFBA]
		--FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK)
		--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS (NOLOCK) ON (PJD.[EncSKUOEM] = GS.[ProductCatalogId])
		--LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] PC (NOLOCK) ON (PC.[ID] = PJD.[EncSKUOEM])
		--WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
		--OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
		--OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
		--OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
		--OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
		--OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))

		INSERT INTO @tmpSKUALTS ([SKU],[tQOH],[PriceFloorFBA],[PriceCeilingFBA], SEQ)
		SELECT  PC.ID, GS.[TotalStock], PC.[PriceFloorFBA], PC.[PriceCeilingFBA], ROW_NUMBER() OVER(ORDER BY PJD.[EncSKU], PJD.[EncSKUPH], PJD.[EncSKUOS], PJD.[EncSKUPX], PJD.[EncSKUUSH], PJD.[EncSKUOEM]) AS SEQ
		FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
		LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] PC WITH(NOLOCK) ON (PC.[ID] = PJD.[EncSKU]) OR (PC.[ID] = PJD.[EncSKUPH]) OR (PC.[ID] = PJD.[EncSKUOS]) OR (PC.[ID] = PJD.[EncSKUPX]) OR (PC.[ID] = PJD.[EncSKUUSH]) OR (PC.[ID] = PJD.[EncSKUOEM])
		LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) ON (PC.[ID] = GS.[ProductCatalogId])
		WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
		OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
		OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
		OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
		OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
		OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))
		ORDER BY PJD.[EncSKU], PJD.[EncSKUPH], PJD.[EncSKUOS], PJD.[EncSKUPX], PJD.[EncSKUUSH], PJD.[EncSKUOEM]
		
	END

	IF @CategoryID NOT IN ('10','11','12','13','20','21','22','23','62','64','14','24') AND @CheckAlwaysInStock != 1 
	BEGIN
		INSERT INTO @tmpSKUALTS ([SKU],[tQOH],[PriceFloorFBA],[PriceCeilingFBA], SEQ)
		SELECT @pSKU, GS.[TotalStock], PC.[PriceFloorFBA], PC.[PriceCeilingFBA], 1
		FROM [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK)
		LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] PC WITH(NOLOCK) ON (PC.[ID] = GS.[ProductCatalogId])
		WHERE GS.[ProductCatalogId] = @pSKU
	END

	SET @Result = (CASE WHEN ISNULL((SELECT SUM(GS.TotalStock) FROM [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) WHERE GS.ProductCatalogId = @pSKU),0) > 0 AND 
								ISNULL((SELECT SUM(GS.TotalStock) FROM [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) WHERE GS.ProductCatalogId = @pSKU),0) = ISNULL(@tQOH,0) THEN 0 ELSE 1 END)

	--SELECT TOP(1) @SKU = [SKU], @tQOH = [tQOH], @PriceFloorFBA = [PriceFloorFBA], @PriceCeilingFBA = [PriceCeilingFBA]
	--FROM @tmpSKUALTS 
	--WHERE [SKU] != '-' AND [SKU] IS NOT NULL AND [SKU] != 0 ORDER BY [tQOH] DESC
	SELECT TOP(1) @SKU = [SKU], @tQOH = [tQOH], @PriceFloorFBA = [PriceFloorFBA], @PriceCeilingFBA = [PriceCeilingFBA]
	FROM @tmpSKUALTS 
	WHERE [SKU] != '-' AND [SKU] IS NOT NULL AND [SKU] != 0 ORDER BY [tQOH] DESC, SEQ

	SET @IsGeneric = (CASE WHEN EXISTS(SELECT * FROM Inventory.dbo.ProductCatalog PC WITH(NOLOCK) INNER JOIN Inventory.dbo.Categories C WITH(NOLOCK) ON C.ID = PC.CategoryID WHERE PC.ID = @SKU AND C.Name LIKE '%generic%') THEN 1 ELSE 0 END)

	IF(@tQOH IS NOT NULL AND @PriceFloorFBA IS NOT NULL AND @PriceCeilingFBA IS NOT NULL)
	BEGIN
		UPDATE PC SET 
			PC.[TotalStock] = (CASE WHEN @tQOH > 0 THEN @tQOH ELSE PC.[TotalStock] END),
			PC.[PriceFloorFBA] = (CASE WHEN @tQOH > 0 THEN (CASE WHEN ISNULL(@IsGeneric,0) = 0 THEN @PriceFloorFBA ELSE PC.[PriceFloorFBA] END) ELSE PC.PriceFloor END), 
			PC.[PriceCeilingFBA] = (CASE WHEN  @tQOH > 0 THEN (CASE WHEN ISNULL(@IsGeneric,0) = 0 THEN @PriceCeilingFBA ELSE PC.[PriceCeilingFBA] END) ELSE PC.PriceCeiling END), 
			ShipSKUFBA = (CASE WHEN @tQOH > 0 THEN @SKU ELSE PC.ID END), 
			PC.TMPFloorCeilingFBA = ISNULL(@Result,0)
		FROM [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK)
		WHERE PC.ID = @pSKU
	END
	ELSE
	BEGIN
		IF(@tQOH IS NOT NULL)
		BEGIN
			UPDATE [Inventory].[dbo].[ProductCatalog] SET [TotalStock] = (CASE WHEN @tQOH > 0 THEN @tQOH ELSE [TotalStock] END)
			WHERE ID = @pSKU
		END
	END

	ENDALL:
	-- Return the result of the function
	--SELECT ISNULL(@Result,0)
	

	--PRINT(@pSKU)
	--PRINT(@Result)
	--PRINT(@tQOH)
	--PRINT(@PriceFloorFBA)
	--PRINT(@PriceCeilingFBA)
END
go

