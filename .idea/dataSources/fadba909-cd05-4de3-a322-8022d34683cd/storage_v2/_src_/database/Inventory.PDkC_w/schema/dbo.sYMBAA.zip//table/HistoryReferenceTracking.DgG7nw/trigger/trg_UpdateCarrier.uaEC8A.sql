

-- // TRIGGER
-- // ====================================================================
-- //  Author:		Santos Escobar
-- //  Create date: 2016-01-20
-- //  Description:	Update carrier name from tracking number.
-- // ====================================================================

CREATE TRIGGER [dbo].[trg_UpdateCarrier] ON [Inventory].[dbo].[HistoryReferenceTracking] AFTER INSERT
AS
BEGIN
	DECLARE @RefNum VARCHAR(50)
	DECLARE @TrackingNumber VARCHAR(50)
	DECLARE @Carrier VARCHAR(25)

	SELECT @TrackingNumber = TrackingNumber, @RefNum = ReferenceNumber FROM inserted
	IF(LEN(@TrackingNumber) > 20) BEGIN 
		SET @Carrier = 'USPS'
	END
	ELSE BEGIN
		SET @Carrier = 'UPS'
	END

	UPDATE Inventory.dbo.[HistoryReferenceTracking] SET Carrier = @Carrier WHERE ReferenceNumber = @RefNum
END
go

