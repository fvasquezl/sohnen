-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-12-23
-- Description:	Get PricePerUnit by SKU and OrderNumber
-- =============================================
CREATE FUNCTION fn_GetPricePerUnit_OD
(
	@SKU NVARCHAR(50), @OrderNumber INT
)
RETURNS NVARCHAR(100)
AS
BEGIN
	DECLARE @PricePerUnit NVARCHAR(100)
	SET @PricePerUnit = '-';
	
	SET @PricePerUnit = ISNULL(CAST((Select TOP(1) PricePerUnit FROM OrderManager.dbo.[Order Details] WHERE SKU = @SKU AND OrderNumber = @OrderNumber) AS VARCHAR), '-')
	
	RETURN @PricePerUnit
END
go

