CREATE VIEW dbo.[MLMexico-Feed]
AS
SELECT        CAF.FeedID, LEFT(REPLACE(REPLACE(REPLACE(REPLACE(CAF.MLMexicoTitle, CHAR(9), ''), CHAR(10), ''), CHAR(11), ''), CHAR(13), ''), 80) AS Title, 
                         ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE
                             ((SELECT        CAFTEMPLATES5.TemplateContent
                                 FROM            dbo.ChannelAdvisorFeed AS CAF5 LEFT OUTER JOIN
                                                          dbo.ChannelAdvisorTemplates AS CAFTEMPLATES5 ON CAF5.MLMexicoTemplate = CAFTEMPLATES5.TemplateID AND 
                                                          CAFTEMPLATES5.TemplateStoreID = 'MLMexicoTemplate'
                                 WHERE        (CAF5.FeedID = CAF.FeedID)), '[[Manufacturer]]', CAF.Manufacturer), '[[PartNumber]]', CAF.PartNumber), '[[ModelNumber]]', CAF.ModelNumber), 
                         '[[UpsellLink]]', CAF.MLMexicoUpsellLink), '[[COMPATIBILITY]]', CAF.Compatiblity), '[[MLMexicoTitle]]', CAF.MLMexicoTitle), '[[FeedID]]', CAF.FeedID), 'á', '&aacute;'), 
                         'ó', '&oacute;'), 'é', '&eacute;'), 'í', '&iacute;'), CHAR(9), ''), CHAR(10), ''), CHAR(11), ''), CHAR(13), ''), ' ') AS Description, 
                         CAST((CASE WHEN CAF.MarkForDeletion = 1 THEN '0' WHEN (PC.AlwaysInStock = 1 AND CAF.eBay1IsActive = 1) THEN '500' WHEN (PC.AlwaysInStock = '0' OR
                         PC.AlwaysInStock IS NULL) AND CAF.eBay1IsActive = '1' THEN Isnull(GS.TotalStock * .75, 0) ELSE '0' END) AS INT) AS Quantity, ISNULL(PC.AvgWeightPounds, 2.000) 
                         AS Weight, ISNULL(CAF.Manufacturer, 'Other') AS Manufacturer, 
                         REPLACE(REPLACE(REPLACE(REPLACE((CASE WHEN CAF.NoMPNToEbay = 1 THEN ' ' WHEN CAF.ListingType LIKE '%ModelSpecific%' THEN ' ' WHEN CAF.ListingType
                          LIKE '%PartNumberSpecific%' THEN CAF.PartNumber ELSE ' ' END), CHAR(9), ''), CHAR(10), ''), CHAR(11), ''), CHAR(13), '') AS PartNumber, ISNULL(PC.Condition, 
                         'NEW') AS Condition, 
                         (CASE WHEN CAF.ListingType LIKE '%GENERIC%' THEN '90 Days' WHEN CAF.ListingType LIKE '%PHILIPS%' THEN '180 Days' WHEN CAF.ListingType LIKE '%PHOENIX%'
                          THEN '180 Days' WHEN CAF.ListingType LIKE '%OSRAM%' THEN '180 Days' WHEN CAF.ListingType LIKE '%REMOTE%' THEN '1 Year' ELSE '30 Days' END) 
                         AS Warranty, CASE WHEN IsNull(CAF.MLMexicoPrice, '1999') = '-0.01' THEN 1999 ELSE IsNull(CAF.MLMexicoPrice, '1999') END AS Price, 
                         (CASE WHEN Ceiling(IsNull(PC.PriceCeiling, 149) * 1.25) - 0.01 = '-.01' THEN 199 ELSE (Ceiling(IsNull(PC.PriceCeiling, 149) * 1.25) - 0.01) END) * 17 AS [Retail Price], 
                         CAF.ImageURL1 AS Image1, CAF.ImageURL2 AS Image2, CAF.ImageURL3 AS Image3, CAF.ImageURL4 AS Image4, CAF.ImageURL5 AS Image5, 
                         ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(CAF.Compatiblity, CHAR(9), ''), CHAR(10), ''), CHAR(11), ''), CHAR(13), ''), ' ') AS CompatiblityList, 
                         (CASE WHEN CTG.ParentID IN ('1', '3') THEN 'Lamp Bulb' WHEN CTG.ParentID IN ('2', '4') THEN 'Lamp with Housing' ELSE ' ' END) AS LampType, 
                         CAF.MLMexicoIsActive AS IsActive, CAF.MLMexicoMainCategory, CAF.MLMexicoListingID, CAF.MLMexicoListingDate, 
                         CAF.MLMexicoUpdatedDate AS MLMexicoListingUpdatedDate, CAF.MarkForDeletion, CAF.Modified
FROM            dbo.ChannelAdvisorFeed AS CAF LEFT OUTER JOIN
                         dbo.Global_Stocks AS GS ON CAF.MITSKU = GS.ProductCatalogId LEFT OUTER JOIN
                         dbo.ProductCatalog AS PC ON CAF.MITSKU = PC.ID LEFT OUTER JOIN
                         dbo.Categories AS CTG ON PC.CategoryID = CTG.ID
go

