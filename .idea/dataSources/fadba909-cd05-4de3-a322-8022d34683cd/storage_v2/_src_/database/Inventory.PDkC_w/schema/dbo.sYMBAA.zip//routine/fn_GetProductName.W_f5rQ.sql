-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetProductName]
(
	-- Add the parameters for the function here
	@ProductCatalogID int
)
RETURNS varchar(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ProductName varchar(100)

	-- Add the T-SQL statements to compute the return value here
	select @ProductName =  a.name from Inventory.dbo.ProductCatalog a
	where a.ID = @ProductCatalogID

	-- Return the result of the function
	RETURN (@ProductName)

END
go

