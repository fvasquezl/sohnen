-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-04-11
-- Description:	Input and Outpu Bin Stock and History
-- =============================================
CREATE PROCEDURE [dbo].[sp_BinInputOutputStock]
	@BIN_ID		NVARCHAR(10),
	@SKU		NVARCHAR(50),
	@QTY		INT,
	@UserID		NVARCHAR(50),
	@FLOW		INT,
	@ScanCode	NVARCHAR(5),
	@Comment	NVARCHAR(500),
	@TYPE		NVARCHAR(5)
AS
BEGIN
	DECLARE @VALID			INT = 0,
			--@GlobalStock	INT,
			@TransactionID NVARCHAR(200) = CONVERT(NVARCHAR,GETDATE()); 

	SET XACT_ABORT ON;
	SET NOCOUNT ON;

	--Valid User
	IF(NOT EXISTS(SELECT * FROM Remotes.dbo.Account WITH(NOLOCK) WHERE Username = @UserID AND Deleted = 0))
	BEGIN
		SET @VALID = 4
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	--Valid BinID
	IF(NOT EXISTS(SELECT * FROM Remotes.dbo.BinMaster WITH(NOLOCK) WHERE BinID = @BIN_ID AND isActive = 1))
	BEGIN
		SET @VALID = 1
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	--Valid SKU
	IF(NOT EXISTS(SELECT * FROM Remotes.dbo.SKUData WITH(NOLOCK) WHERE SKU = @SKU))
	BEGIN
		SET @VALID = 2
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	--Valid Qty
	IF(ISNULL(@QTY,0) <= 0)
	BEGIN
		SET @VALID = 3
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	BEGIN TRANSACTION @TransactionID
	BEGIN TRY
		--Input Stock
		IF(ISNULL(@FLOW,0) = 1)
		BEGIN
			SET @VALID = 5
			IF(EXISTS(SELECT * FROM Remotes.dbo.BinStock WITH(NOLOCK) WHERE BinID = @BIN_ID AND SKU = @SKU AND ScanCode = @TYPE))
			BEGIN
				UPDATE Remotes.dbo.BinStock SET StockQty = StockQty + @QTY, ChangeDate = GETDATE(), ChangeUser = @UserID WHERE BinID = @BIN_ID AND SKU = @SKU AND ScanCode = @TYPE
			END
			ELSE
			BEGIN
				INSERT INTO Remotes.dbo.BinStock (BinID, SKU, ScanCode, StockQty, CreateUser) VALUES (@BIN_ID, @SKU, @TYPE, @QTY, @UserID)
			END
			SET @VALID = 0
		END	
		--Output Stock
		IF(ISNULL(@FLOW,0) = 2)
		BEGIN
			SET @VALID = 6
			--Valid Qty
			IF((SELECT StockQty FROM Remotes.dbo.BinStock WITH(NOLOCK) WHERE BinID = @BIN_ID AND SKU = @SKU AND ScanCode = @TYPE) >= @QTY)
			BEGIN
				UPDATE Remotes.dbo.BinStock SET StockQty = StockQty - @QTY, ChangeDate = GETDATE(), ChangeUser = @UserID WHERE BinID = @BIN_ID AND SKU = @SKU AND ScanCode = @TYPE
				DELETE FROM Remotes.dbo.BinStock WHERE BinID = @BIN_ID AND SKU = @SKU AND ScanCode = @TYPE AND ISNULL(StockQty,0) <= 0
				SET @VALID = 0
			END
			ELSE
			BEGIN				
				SET @VALID = 3
			END
		END
		--Insert History
		IF(ISNULL(@VALID,-1) = 0)
		BEGIN
			SET @VALID = 7
			INSERT INTO Remotes.dbo.BinHistory (BinID, SKU, Quantity, Flow, ScanCode, CreateUser, Comments, ScanType)
			VALUES (@BIN_ID, @SKU, @QTY, @FLOW, @ScanCode, @UserID, @Comment, @TYPE)
			SET @VALID = 0
		END
	END TRY
	BEGIN CATCH
		SET @VALID = 8
	END CATCH
	
	--RollBack if Error exists
	IF(ISNULL(@VALID,1) > 0)
	BEGIN
		ROLLBACK TRANSACTION @TransactionID
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	COMMIT TRANSACTION @TransactionID
	SELECT @VALID AS RESULT
END
go

