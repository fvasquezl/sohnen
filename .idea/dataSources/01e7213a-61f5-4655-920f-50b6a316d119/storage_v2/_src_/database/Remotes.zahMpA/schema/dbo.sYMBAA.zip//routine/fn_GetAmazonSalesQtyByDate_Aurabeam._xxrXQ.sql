-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 12-17-2017
-- Description:	
-- =============================================
CREATE FUNCTION fn_GetAmazonSalesQtyByDate_Aurabeam
(	
	-- Add the parameters for the function here
	@pSKU NVARCHAR(50), 
	@pDateStart datetime,
	@pDateEnd datetime
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	(SELECT SUM(OD.[QuantityOrdered]) AS [QtySold] 
			FROM [Remotes].[dbo].[AmazonAPI_OrderDetails] AS OD
			LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_Orders] AS O ON (OD.[AmazonOrderId] = O.[AmazonOrderId] AND OD.[Title] LIKE '%Aurabeam%')
			WHERE LEFT([SellerSKU],8) IN (SELECT REPLACE(LEFT(MM.[MerchantSKU],9),'RMTC','SKU') 
			FROM [Remotes].[dbo].[MarketplaceMapping] AS MM
			WHERE [SKU] = @pSKU) AND O.[StampInsert] BETWEEN @pDateStart AND @pDateEnd)
)
go

