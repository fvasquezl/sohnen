-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_warehouse_io]
	-- Add the parameters for the stored procedure here
	@WarehouseID int, @ProductCatalogId int, @date1 date, @date2 date
AS
BEGIN
	
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @i int;
	DECLARE @numrows int;
	DECLARE @currentvalue real;
	DECLARE @qty real;
	DECLARE @flow int;
	DECLARE @destination int;
	DECLARE @origin int;
	DECLARE @inputs real;
	DECLARE @outputs real;
	DECLARE @currdate date;
	DECLARE @exist int;
	DECLARE @lastqty int;
	
	
	DECLARE @history TABLE (id int Primary Key IDENTITY(1,1)
									, adjustmentId int
									, mydate date
									, origin int
									, destination int
									, flow int
									, quantity real
									, inputs real
									, outputs real
									, transfers real
									, globalqty real
									, oname varchar(40)
									, dname varchar(40)
									, comments varchar(250)
									, Userid int
									);
									
		DECLARE @analitic TABLE (id int Primary Key IDENTITY(1,1)
									
									, mydate date
									
									, flow int
									, quantity real
									, inputs real
									, outputs real
									, transfers real
									, globalqty real
									
									);

		
		IF (@WarehouseID = 0) or (@WarehouseID Is Null)
		BEGIN
					INSERT INTO @history (adjustmentId, mydate, origin
											, destination, flow, quantity,  inputs, outputs
											, transfers, comments, userid)
							SELECT a.id
									,a.date as mydate
									,a.origin
									, a.destination
									, a.flow
									, b.quantity
									,CASE a.flow 
										WHEN 1 THEN b.quantity 
										ELSE 0
										END as inputs
									,CASE a.flow 
										WHEN 2 THEN b.quantity 
										ELSE 0
										END as outputs
									,CASE a.flow 
										WHEN 3 THEN b.quantity 
										ELSE 0
										END as transfers
									, a.comments
									, a.userid
							FROM Inventory.dbo.InventoryAdjustments a,
									Inventory.dbo.InventoryAdjustmentDetails b
							WHERE (a.ID = b.InventoryAdjustmentsID)
									and (b.ProductCatalogID = @ProductCatalogId)
							ORDER BY a.date;
		END
		

		IF (@WarehouseID > 0) 
		BEGIN
					INSERT INTO @history (adjustmentId, mydate, origin, destination, flow, quantity,  inputs, outputs, transfers)
							SELECT a.id
									,a.date as mydate
									,a.origin
									, a.destination
									, a.flow
									, b.quantity
									,CASE a.flow 
										WHEN 1 THEN b.quantity 
										ELSE 0
										END as inputs
									,CASE a.flow 
										WHEN 2 THEN b.quantity 
										ELSE 0
										END as outputs
									,CASE a.flow 
										WHEN 3 THEN b.quantity 
										ELSE 0
										END as transfers
							FROM Inventory.dbo.InventoryAdjustments a,
									Inventory.dbo.InventoryAdjustmentDetails b
							WHERE (a.ID = b.InventoryAdjustmentsID)
									and (b.ProductCatalogID = @ProductCatalogId)
									and ((a.origin = @WarehouseID)or(a.destination = @WarehouseID))
							ORDER BY a.date;
		END




		SET @currentvalue = 0;
	

		SET @i = 1;
		SET @numrows = (SELECT COUNT(*) FROM @history);

		IF @numrows > 0

				WHILE (@i <= (SELECT MAX(id) FROM @history))
				BEGIN

						SELECT @origin = origin, @destination = destination, @flow = flow, @qty = quantity 
						FROM @history WHERE id = @i;
        
						IF @flow = 1
						BEGIN
									SET @currentvalue = @currentvalue + @qty;
									SET @inputs = @qty; 
									SET @outputs = 0;
						END
        
						IF @flow = 2
						BEGIN
									SET @currentvalue = @currentvalue - @qty;
									SET @inputs = 0; 
									SET @outputs = @qty;
						END
						
						IF (@flow = 3) AND (@WarehouseID = 0)
						BEGIN
									
									SET @inputs = @qty; 
									SET @outputs = @qty;
						END
    
						
						IF (@Flow = 3) AND (@WarehouseID > 0)
						BEGIN
							IF @WarehouseID = @origin -- Transfer Output
							BEGIN
									SET @currentvalue = @currentvalue - @qty;
									SET @inputs = 0; 
									SET @outputs = @qty;
							END
							
							IF @WarehouseID = @destination  -- Transfer Input
							BEGIN
								SET @currentvalue = @currentvalue + @qty;
								SET @inputs = @qty; 
								SET @outputs = 0;
							END
						END

						UPDATE @history SET globalqty = @currentvalue 
											,inputs = @inputs
											,outputs = @outputs
						where id = @i;
						-- increment counter for next employee
						SET @i = @i + 1
        
        
		END /* If num rows > 0*/

		
		
		
		/*Analitic Procees*/
		 SET @currdate = @date1;
		 SET @lastqty = (SELECT TOP 1 a.globalqty FROM @history a WHERE (mydate < @date1) ORDER BY id DESC );
		 
		 	WHILE (@currdate <= @date2)
				BEGIN
					SET @inputs = 0;
					SET @outputs = 0;
					
				
					
					SELECT  @inputs= sum(a.inputs)
							,@outputs =  sum(a.outputs)
							, @exist = count(id)
					FROM @history a
					WHERE (mydate = @currdate);
					
					IF @inputs is null BEGIN SET @inputs = 0; END
					IF @outputs is null  BEGIN SET @outputs = 0; END
								
					IF  (@exist = 0 )
						BEGIN
								/*No exist*/
								SET @qty = @lastqty;
						END;
					
					IF  (@exist > 0)
						BEGIN
							SET @qty = 0;
							SET @qty = (SELECT TOP 1 globalqty FROM @history WHERE (mydate = @currdate) ORDER BY id DESC);
							
								SET @lastqty = @qty;
							
						
							
						END;
				  
				    
				   
					INSERT INTO @analitic (mydate, inputs, outputs, globalqty) values (@currdate, @inputs, @outputs, @qty);
					
					SET @currdate = DATEADD(day,1,@currdate)
				END /* While*/
				
			SELECT mydate as date,inputs, outputs, globalqty as CurrentStock 
			FROM @analitic;
			
END
go

