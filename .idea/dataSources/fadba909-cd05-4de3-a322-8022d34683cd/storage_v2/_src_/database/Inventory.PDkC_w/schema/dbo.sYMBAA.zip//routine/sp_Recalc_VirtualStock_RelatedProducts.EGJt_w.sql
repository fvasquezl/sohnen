-- =============================================
-- Author:		Luis Alberto for MI Technologies, Inc.
-- Create date: Nov-24-2010
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_Recalc_VirtualStock_RelatedPRoducts]
	-- Add the parameters for the stored procedure here
	@ProductID as int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Declare cursor with ISO Syntax
	DECLARE RelatedProducts_Cursor INSENSITIVE  CURSOR 
     FOR 
		 SELECT ProductCatalogID, SubSKUQTYRequired 
		 FROM Inventory.dbo.AssemblyDetails 
		 WHERE SubSKU = @ProductID 
     FOR READ ONLY 

	-- Declare local variables
	DECLARE @RelatedProductID as int
	DECLARE @CurrentStock as real
	DECLARE @RequiredQty as real
	DECLARE @Projection as real
	
	-- Select Current Stock 
	SELECT @CurrentStock =  CurrentStock FROM ProductCatalog
								WHERE ID = @ProductID
	-- Make a list with Related Products
	
	OPEN RelatedProducts_Cursor;

	FETCH NEXT FROM RelatedProducts_Cursor
	INTO @RelatedProductID, @RequiredQty;

	WHILE @@FETCH_STATUS = 0
	BEGIN
			-- Calculate virtual stock 
				
			SET @Projection = @CurrentStock / @RequiredQty
								
			-- Update Virtual store in product Catalog
			UPDATE ProductCatalog SET VirtualStock = @Projection
			WHERE ID = @RelatedProductID
								
			FETCH NEXT FROM RelatedProducts_Cursor
			INTO @RelatedProductID, @RequiredQty;

	END

	CLOSE RelatedProducts_Cursor;
	DEALLOCATE RelatedProducts_Cursor;
	
	
END
go

