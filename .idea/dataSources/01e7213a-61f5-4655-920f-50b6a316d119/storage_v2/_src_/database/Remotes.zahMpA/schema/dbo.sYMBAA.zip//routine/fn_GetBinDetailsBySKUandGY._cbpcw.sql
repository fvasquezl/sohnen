-- =============================================
-- Author:		<Edgar Guadalupe>
-- Create date: <Nov-07-2018>
-- Description:	<Get Bin Details by SKY and GY>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetBinDetailsBySKUandGY]
(	
	-- Add the parameters for the function here
	@pSKU nvarchar(10)
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
		-- Add the SELECT statement with parameter references here
	SELECT BS.[BinID], BS.[StockQty], BS.[ScanCode] FROM [Remotes].[dbo].[BinStock] AS BS WITH (NOLOCK)
	LEFT OUTER JOIN [Remotes].[dbo].[BinMaster] AS BM WITH(NOLOCK) ON (BS.[BinID] = BM.[BinID])
	WHERE [SKU] = @pSKU AND  BM.[WarehouseID] LIKE '%GY%'
)
go

