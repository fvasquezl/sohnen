-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Analitic_History]
	@ProductCatalogId int, @WarehouseID int, @crop int = 0, @startdate date = '1900-01-01', @enddate date = '1900-01-01'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @i int;
	DECLARE @numrows int;
	DECLARE @currentvalue real;
	DECLARE @qty real;
	DECLARE @flow int;
	DECLARE @destination int;
	DECLARE @origin int;
	DECLARE @inputs real;
	DECLARE @outputs real;
	
	
	DECLARE @history TABLE (id int Primary Key IDENTITY(1,1)
									, adjustmentId int
									, mydate date
									, origin int
									, destination int
									, flow int
									, quantity real
									, inputs real
									, outputs real
									, transfers real
									, globalqty real
									, oname varchar(40)
									, dname varchar(40)
									, comments varchar(250)
									, Userid int
									, po varchar(20)
									);

		
		IF (@WarehouseID = 0) or (@WarehouseID Is Null)
		BEGIN
					INSERT INTO @history (adjustmentId, mydate, origin
											, destination, flow, quantity,  inputs, outputs
											, transfers, comments, userid, po)
							SELECT a.id
									,a.date as mydate
									,a.origin
									, a.destination
									, a.flow
									, b.quantity
									,CASE a.flow 
										WHEN 1 THEN b.quantity 
										ELSE 0
										END as inputs
									,CASE a.flow 
										WHEN 2 THEN b.quantity 
										ELSE 0
										END as outputs
									,CASE a.flow 
										WHEN 3 THEN b.quantity 
										ELSE 0
										END as transfers
									, a.comments
									, a.userid
									, a.po
							FROM Inventory.dbo.InventoryAdjustments a,
									Inventory.dbo.InventoryAdjustmentDetails b
							WHERE (a.ID = b.InventoryAdjustmentsID)
									and (b.ProductCatalogID = @ProductCatalogId)
							ORDER BY a.date ;
		END
		

		IF (@WarehouseID > 0) 
		BEGIN
					INSERT INTO @history (adjustmentId, mydate, origin, destination, flow, quantity,  inputs, outputs, transfers, comments, userid, po)
							SELECT a.id
									,a.date as mydate
									,a.origin
									, a.destination
									, a.flow
									, b.quantity
									,CASE a.flow 
										WHEN 1 THEN b.quantity 
										ELSE 0
										END as inputs
									,CASE a.flow 
										WHEN 2 THEN b.quantity 
										ELSE 0
										END as outputs
									,CASE a.flow 
										WHEN 3 THEN b.quantity 
										ELSE 0
										END as transfers
									, a.comments
									, a.userid
									, a.PO
							FROM Inventory.dbo.InventoryAdjustments a,
									Inventory.dbo.InventoryAdjustmentDetails b
							WHERE (a.ID = b.InventoryAdjustmentsID)
									and (b.ProductCatalogID = @ProductCatalogId)
									and ((a.origin = @WarehouseID)or(a.destination = @WarehouseID))
							ORDER BY a.date ;
		END




		SET @currentvalue = 0;
	

		SET @i = 1;
		SET @numrows = (SELECT COUNT(*) FROM @history);

		IF @numrows > 0

				WHILE (@i <= (SELECT MAX(id) FROM @history))
				BEGIN

						SELECT @origin = origin, @destination = destination, @flow = flow, @qty = quantity 
						FROM @history WHERE id = @i;
        
						IF @flow = 1
						BEGIN
									SET @currentvalue = @currentvalue + @qty;
									SET @inputs = @qty; 
									SET @outputs = 0;
						END
        
						IF @flow = 2
						BEGIN
									SET @currentvalue = @currentvalue - @qty;
									SET @inputs = 0; 
									SET @outputs = @qty;
						END
						
						IF (@flow = 3) AND (@WarehouseID = 0)
						BEGIN
									
									SET @inputs = @qty; 
									SET @outputs = @qty;
						END
    
						
						IF (@Flow = 3) AND (@WarehouseID > 0)
						BEGIN
							IF @WarehouseID = @origin -- Transfer Output
							BEGIN
									SET @currentvalue = @currentvalue - @qty;
									SET @inputs = 0; 
									SET @outputs = @qty;
							END
							
							IF @WarehouseID = @destination  -- Transfer Input
							BEGIN
								SET @currentvalue = @currentvalue + @qty;
								SET @inputs = @qty; 
								SET @outputs = 0;
							END
						END

						UPDATE @history SET globalqty = @currentvalue 
											,inputs = @inputs
											,outputs = @outputs
						where id = @i;
						-- increment counter for next employee
						SET @i = @i + 1
        
        
		END /* If num rows > 0*/

	
		if @crop > 0 
		BEGIN
			SELECT  adjustmentId as Adjustment_Id
							, mydate as Adjustment_Date
							, inventory.dbo.fn_GetAccountName(origin) as Origin
							, inventory.dbo.fn_GetAccountName(destination) as Destination
							, inputs, outputs, globalqty as current_qty
							, comments
							, po 
							, inventory.dbo.fn_GetUserName(userid) as username
							, inventory.dbo.fn_get_audit_comment(adjustmentId) as Audit
							, id
					FROM @history 
					WHERE mydate between @startdate and @enddate
					ORDER By id desc;
		END
		else
		BEGIN
		
			SELECT  adjustmentId as Adjustment_Id
							, mydate as Adjustment_Date
							, inventory.dbo.fn_GetAccountName(origin) as Origin
							, inventory.dbo.fn_GetAccountName(destination) as Destination
							, inputs, outputs, globalqty as current_qty
							, comments
							, po 
							, inventory.dbo.fn_GetUserName(userid) as username
							, inventory.dbo.fn_get_audit_comment(adjustmentId) as Audit
							
					FROM @history 
					ORDER By id desc;
					
		END
						
		
		
    
END
go

