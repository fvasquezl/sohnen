CREATE VIEW dbo.QBProductCatalogBackorders
AS
SELECT        dbo.ProductCatalog.ID AS SKU, dbo.ProductCatalog.Name, SUM(dbo.QBPurchaseOrderBackorders.Backorder) AS Backorders
FROM            dbo.ProductCatalog LEFT OUTER JOIN
                         dbo.QBPurchaseOrderBackorders ON LEFT(CAST(dbo.ProductCatalog.ID AS nvarchar), 6) = LEFT(CAST(dbo.QBPurchaseOrderBackorders.SKU AS nvarchar), 6)
GROUP BY dbo.ProductCatalog.ID, dbo.ProductCatalog.Name
go

