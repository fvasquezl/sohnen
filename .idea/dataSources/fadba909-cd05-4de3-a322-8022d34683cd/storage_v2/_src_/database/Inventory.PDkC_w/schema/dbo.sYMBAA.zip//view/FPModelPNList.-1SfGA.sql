CREATE VIEW dbo.FPModelPNList
AS
SELECT     dbo.FPPartNumberList.Manufacturer, dbo.FPPartNumberList.PartNumber, dbo.CompatibilityDetails.Model
FROM         dbo.FPPartNumberList LEFT OUTER JOIN
                      dbo.CompatibilityDetails ON dbo.FPPartNumberList.Manufacturer = dbo.CompatibilityDetails.OriginalManufacturer AND 
                      dbo.FPPartNumberList.PartNumber = dbo.CompatibilityDetails.PartNumber
go

