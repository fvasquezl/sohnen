-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-08-07
-- Description:	Get Virtual Quantity On Hand Details
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetVQOHDetails]
	@ProductCatalogID INT
AS
BEGIN
	DECLARE @CURSORASSY CURSOR,
			@SKU		INT,
			@SUBSKU		INT
	SET NOCOUNT ON;

    DECLARE @TMPTABLE TABLE (ParentSKU INT, Item NVARCHAR(4000), QOH INT, vQOH INT, tQOH INT)

	INSERT INTO @TMPTABLE
	SELECT AD.ProductCatalogID, PC.Name, CAST(GS.GlobalStock AS INT), CAST(GS.VirtualStock AS INT), CAST(GS.TotalStock AS INT)
    FROM [Inventory].[dbo].AssemblyDetails AS AD WITH(NOLOCK)
    LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK)
	ON (AD.ProductCatalogID = PC.ID)
    LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK)
	ON (AD.ProductCatalogID = GS.ProductCatalogId)
    WHERE AD.SubSKU = @ProductCatalogID
	
	INSERT INTO @TMPTABLE
	SELECT AD.SubSKU, PC.Name, CAST(GS.GlobalStock AS INT), CAST(GS.VirtualStock AS INT), CAST(GS.TotalStock AS INT) FROM AssemblyDetails AD WITH(NOLOCK)
	INNER JOIN Inventory.dbo.Global_Stocks AS GS WITH(NOLOCK)
	ON AD.SubSKU = GS.ProductCatalogId
	INNER JOIN Inventory.dbo.ProductCatalog AS PC WITH(NOLOCK)
	ON AD.SubSKU = PC.[ID]
	WHERE AD.ProductCatalogID = @ProductCatalogID AND PC.[CategoryID] IN ('5','6','7','8','9','15','16','17','18','19','61','63','88','89','90','91')

	SET @CURSORASSY = CURSOR FOR

	SELECT AD.ProductCatalogID, AD.SubSKU
	FROM Inventory.dbo.AssemblyDetails AD WITH(NOLOCK)
	INNER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	ON PC.ID = AD.ProductCatalogID
	WHERE AD.SubSKU IN (
		SELECT PC.ID FROM Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
		LEFT OUTER JOIN Inventory.dbo.AssemblyDetails AD WITH(NOLOCK)
		ON AD.ProductCatalogID = PC.ID
		WHERE AD.ProductCatalogID IS NULL
		AND PC.CategoryID IN ('5','6','7','8','9','15','16','17','18','19','61','63','88','89','90','91')
		AND PC.ID = @ProductCatalogID
	)
	AND PC.Name LIKE '%+%'

	OPEN @CURSORASSY FETCH NEXT FROM @CURSORASSY INTO @SKU, @SUBSKU
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
	
		INSERT INTO @TMPTABLE
		SELECT AD.ProductCatalogID, PC.Name, CAST(GS.GlobalStock AS INT), CAST(GS.VirtualStock AS INT), CAST(GS.TotalStock AS INT)
		FROM Inventory.dbo.AssemblyDetails AD WITH(NOLOCK)
		INNER JOIN Inventory.dbo.Global_Stocks GS WITH(NOLOCK)
		ON GS.ProductCatalogId = AD.ProductCatalogID
		LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
		ON PC.ID = AD.ProductCatalogID
		WHERE AD.SubSKU = @SKU AND ISNULL(GS.GlobalStock,0) > 0
						
		FETCH NEXT FROM @CURSORASSY INTO @SKU, @SUBSKU
	END
	CLOSE @CURSORASSY
	DEALLOCATE @CURSORASSY


	SELECT ParentSKU, Item, QOH, vQOH, tQOH FROM @TMPTABLE
	ORDER BY QOH DESC
END
go

