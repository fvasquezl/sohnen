-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-23-2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonFLEXActivateSPARC-Step1] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


		DECLARE @selectstatement NVARCHAR(2000)
		DECLARE @cmd NVARCHAR(2000)
				  
		DELETE FROM [Inventory].[dbo].[History_AmazonFlexActivateSparc] WHERE [stamp] < GETDATE()-30

		INSERT INTO [Inventory].[dbo].[History_AmazonFlexActivateSparc]
		SELECT [sku], [product-id], [product-id-type], [price], [minimum-seller-allowed-price], [maximum-seller-allowed-price], [item-condition], CASE WHEN [quantity] = 0 AND [add-delete] = 'a' then NULL ELSE [quantity] end AS [quantity], [add-delete], [will-ship-internationally], [expedited-shipping], [standard-plus], [item-note], [fulfillment-center-id], [product-tax-code], [leadtime-to-ship], [merchant_shipping_group_name], [batteries_required], [are_batteries_included], [supplier_declared_dg_hz_regulation1]  
		--History Portion
		,GETDATE() AS [stamp]
		--End History Portion
		FROM [Inventory].[dbo].[AmazonFlexActivateSPARC] AS [AZFLEXCurrentSPARC]
		WHERE [AZFLEXCurrentSPARC].[add-delete] != (SELECT [AZFLEXLastSPARC].[add-delete] FROM [Inventory].[dbo].[LastFlexActivateFeedSPARC] AS [AZFLEXLastSPARC] WHERE [AZFLEXLastSPARC].[sku] = [AZFLEXCurrentSPARC].[sku])


		SET @selectstatement = 'SELECT [sku], [product-id], [product-id-type], [price], [minimum-seller-allowed-price], [maximum-seller-allowed-price], [item-condition], CASE WHEN [quantity] = 0 AND [add-delete] = ''a'' then NULL ELSE [quantity] end AS [quantity], [add-delete], [will-ship-internationally], [expedited-shipping], [standard-plus], [item-note], [fulfillment-center-id], [product-tax-code], [leadtime-to-ship], [merchant_shipping_group_name], [batteries_required], [are_batteries_included], [supplier_declared_dg_hz_regulation1] FROM [Inventory].[dbo].[AmazonFlexActivateSPARC] AS [AZFLEXCurrentSPARC]	WHERE [AZFLEXCurrentSPARC].[add-delete] != (SELECT [AZFLEXLastSPARC].[add-delete] FROM [Inventory].[dbo].[LastFlexActivateFeedSPARC] AS [AZFLEXLastSPARC] WHERE [AZFLEXLastSPARC].[sku] = [AZFLEXCurrentSPARC].[sku])'

		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\Sparc\spflexactivate-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd

	
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\Sparc\spflexactivate.bat"'
	

		


END
go

