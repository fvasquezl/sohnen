-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trUpdateRmaDetailsIntoRmaData]
   ON  [Inventory].[dbo].[ExclusiveRMADetails] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	DECLARE @top INT = (SELECT QuantityAuthorized FROM inserted);
	DECLARE @loop INT = 0;

	DELETE FROM Inventory.dbo.RMAReturnData WHERE RMAnumber = (select RMAnumber from inserted) AND SKU = (select SKU FROM inserted) AND isExclusiveBulbs = 1;

	WHILE @loop < @top
	BEGIN
		DECLARE @sku INT = (SELECT WrongSKU FROM inserted);
		DECLARE @rma INT = (SELECT RMAnumber FROM inserted);
		INSERT INTO Inventory.dbo.RMAReturnData(RMAnumber,SKU) VALUES (@rma,@sku);
		set @loop = @loop + 1;
	END

END
go

