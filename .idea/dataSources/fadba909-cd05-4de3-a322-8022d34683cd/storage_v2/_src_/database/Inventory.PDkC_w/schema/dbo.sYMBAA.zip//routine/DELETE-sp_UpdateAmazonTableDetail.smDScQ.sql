-- =============================================
-- Author:		Eduardo Gutierrez
--- Create date: 2017-06-29
-- Description:	Update Amazon table by ASIN
-- =============================================
CREATE PROCEDURE [dbo].[sp_UpdateAmazonTableDetail]
AS
BEGIN
	DECLARE @CURSOR_ASIN		CURSOR,
			@ASIN				NVARCHAR(50),
			@Brand				NVARCHAR(50),
			@Publisher			NVARCHAR(50),
			@Title				NVARCHAR(250),
			@Feature_A			NVARCHAR(MAX),
			@Feature_B			NVARCHAR(MAX),
			@Feature_C			NVARCHAR(MAX),
			@Feature_D			NVARCHAR(MAX),
			@Feature_E			NVARCHAR(MAX),
			@ProductCategoryId	NVARCHAR(50),
			@Rank				NVARCHAR(50),
			@PartNumber			NVARCHAR(50)
	SET NOCOUNT ON;

	--UPDATE AZ SET AZ.[BrandMentioned] = OD.[Publisher], AZ.[Title] = OD.[Title], AZ.[Bullet1] = OD.[Feature_A], AZ.[Bullet2] = OD.[Feature_B], AZ.[Bullet3] = OD.[Feature_C], AZ.[AZSalesRankCategory] = OD.[ProductCategoryId], 
	--	AZ.[AZSalesRank] = OD.[Rank], AZ.[AZPartNumber] = OD.[PartNumber], AZ.[Stamp] = GETDATE()
	--FROM Inventory.dbo.Amazon AZ
	--INNER JOIN [AmazonExclusiveBulbs].[dbo].[ProductDetails] OD
	--ON OD.ASIN = AZ.ASIN
	--WHERE AZ.[CountryCode] = 'US' 

	SET @CURSOR_ASIN = CURSOR FOR 

	SELECT [ASIN], [Brand], [Publisher], [Title], [Feature_A], [Feature_B], [Feature_C], [Feature_D], [Feature_E], [ProductCategoryId], [Rank], [PartNumber]
	FROM [AmazonExclusiveBulbs].[dbo].[ProductDetails] PD WITH(NOLOCK)
	--WHERE ASIN NOT IN (SELECT ASIN FROM [Inventory].[dbo].[Amazon] WITH(NOLOCK) where countrycode = 'us' AND CONVERT(DATE,Stamp) = '2017-07-18')
--	WHERE ASIN IN (
--	SELECT F.ASIN FROM AmazonExclusiveBulbs.dbo.InventoryFBAManage F WITH(NOLOCK)
--LEFT OUTER JOIN Inventory.dbo.Amazon A WITH(NOLOCK)
--ON A.ASIN = F.asin AND A.CountryCode = 'US'
--WHERE A.IsActive = 1 AND ISNULL(BrandMentioned,'') = ''
--	)
	INNER JOIN [WebStation].[AZ].[tAMWS_Marketplace] M WITH(NOLOCK)
	ON M.ID = PD.MarketplaceId AND M.Abbrevation = 'US'
	WHERE PD.HasError = 0
	GROUP BY [ASIN], [Brand], [Publisher], [Title], [Feature_A], [Feature_B], [Feature_C], [Feature_D], [Feature_E], [ProductCategoryId], [Rank], [PartNumber]
	
	OPEN @CURSOR_ASIN 
		FETCH NEXT FROM @CURSOR_ASIN 
		INTO @ASIN, @Brand, @Publisher, @Title, @Feature_A, @Feature_B, @Feature_C, @Feature_D, @Feature_E, @ProductCategoryId, @Rank, @PartNumber
	   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			BEGIN TRY
				--IF((SELECT COUNT(*) FROM Inventory.dbo.Amazon AZ WITH(NOLOCK) WHERE AZ.[CountryCode] = 'US' AND AZ.[ASIN] = @ASIN) > 0)
				--BEGIN
				UPDATE Inventory.dbo.Amazon SET [BrandMentioned] = @Brand, [manufacturer] = @Publisher, [Title] = @Title, 
					[Bullet1] = (CASE WHEN ISNULL(@Feature_A,'') = '' THEN [Bullet1] ELSE @Feature_A END),
					[Bullet2] = (CASE WHEN ISNULL(@Feature_B,'') = '' THEN [Bullet1] ELSE @Feature_B END),
					[Bullet3] = (CASE WHEN ISNULL(@Feature_C,'') = '' THEN [Bullet1] ELSE @Feature_C END),
					[Bullet4] = (CASE WHEN ISNULL(@Feature_D,'') = '' THEN [Bullet1] ELSE @Feature_D END),
					[Bullet5] = (CASE WHEN ISNULL(@Feature_E,'') = '' THEN [Bullet1] ELSE @Feature_E END), 
					[AZSalesRankCategory] = @ProductCategoryId, 
					[AZSalesRank] = CONVERT(INT,@Rank), 
					[AZPartNumber] = @PartNumber,--(CASE WHEN  ISNULL(@PartNumber,'') = '' THEN [AZPartNumber] ELSE @PartNumber END),
					[Stamp] = GETDATE()
				WHERE [CountryCode] = 'US' AND [ASIN] = @ASIN 
				--END
				--ELSE
				--BEGIN
				--IF Need to Insert 
				--END
			END TRY  
			BEGIN CATCH
				PRINT(@ASIN)
			END CATCH
			NEXT_FETCH:
			FETCH NEXT FROM @CURSOR_ASIN
			INTO @ASIN, @Brand, @Publisher, @Title, @Feature_A, @Feature_B, @Feature_C, @Feature_D, @Feature_E, @ProductCategoryId, @Rank, @PartNumber
		END
	CLOSE      @CURSOR_ASIN
	DEALLOCATE @CURSOR_ASIN

	DELETE FROM [AmazonExclusiveBulbs].[dbo].[ProductDetails] WHERE HasError = 0 AND MarketplaceId = (SELECT TOP 1 M.ID FROM [WebStation].[AZ].[tAMWS_Marketplace] M WITH(NOLOCK) WHERE M.Abbrevation = 'US')
END
go

