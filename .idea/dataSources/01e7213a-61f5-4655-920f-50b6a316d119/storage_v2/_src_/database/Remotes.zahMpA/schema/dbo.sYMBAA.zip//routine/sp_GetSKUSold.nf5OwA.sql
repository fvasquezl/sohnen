-- =============================================
-- Author:		Hubet Cárdenas-Isla
-- Create date: 2017-12-19
-- Description:	Get SKU Sold
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSKUSold]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	--TMP_AmazonAPI_OrderDetails  
	--DROP TABLE #TMP_AmazonAPI_OrderDetails  
	CREATE TABLE #TMP_AmazonAPI_OrderDetails([AmazonOrderId] NVARCHAR(50)
											,[SellerSKU] NVARCHAR(50)
											,[QuantityOrdered] INT)

	CREATE NONCLUSTERED INDEX ix_AmazonAPI_OrderDetails_A ON #TMP_AmazonAPI_OrderDetails ([AmazonOrderId]);
	CREATE CLUSTERED INDEX ix_AmazonAPI_OrderDetails_B ON #TMP_AmazonAPI_OrderDetails ([SellerSKU]);

	INSERT INTO #TMP_AmazonAPI_OrderDetails
	SELECT [AmazonOrderId]
		   ,[SellerSKU]
		   ,SUM([QuantityOrdered]) [QuantityOrdered]
	  FROM (SELECT [AmazonOrderId]
				   ,LEFT([SellerSKU],8) [SellerSKU]
				   ,[QuantityOrdered]
			  FROM [Remotes].[dbo].[AmazonAPI_OrderDetails] WITH(NOLOCK)
			 WHERE [Title] NOT LIKE '%Aurabeam%') [AmazonAPI_OrderDetails]
	 GROUP BY [AmazonOrderId]
			 ,[SellerSKU]

	--TMP_MarketplaceMapping
	--DROP TABLE #TMP_MarketplaceMapping  
	CREATE TABLE #TMP_MarketplaceMapping([MerchantSKU] NVARCHAR(50)
										,[SKU] NVARCHAR(50))  
	CREATE NONCLUSTERED INDEX ix_MarketplaceMapping_A ON #TMP_MarketplaceMapping ([MerchantSKU]);
	CREATE CLUSTERED INDEX ix_MarketplaceMapping_B ON #TMP_MarketplaceMapping ([SKU]);

	INSERT INTO #TMP_MarketplaceMapping
	SELECT REPLACE(LEFT(MM.[MerchantSKU],9),'RMTC','SKU') [MerchantSKU]
		   ,[SKU]
	  FROM [Remotes].[dbo].[MarketplaceMapping] AS MM WITH(NOLOCK)   
  
	--MAIN Query  
	SELECT  MAIN.[SKU]
  		   ,MAIN.[Manufacturer]
		   ,MAIN.[PartNumber]
		   ,MAIN.[QtySold]
	  FROM (SELECT SKUD.[SKU], 
				   SKUD.[Manufacturer], 
				   SKUD.[PartNumber], 
				   (SELECT SUM(OD.[QuantityOrdered]) 
					  FROM #TMP_AmazonAPI_OrderDetails AS OD
					  LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_Orders] AS O WITH(NOLOCK)
						   ON OD.[AmazonOrderId] = O.[AmazonOrderId]
					 WHERE OD.[SellerSKU] IN (SELECT [MerchantSKU]
												FROM #TMP_MarketplaceMapping AS MM 
											   WHERE [SKU] = SKUD.[SKU])
					   AND O.[StampInsert] BETWEEN GETDATE()-1 AND GETDATE()) AS [QtySold]
			  FROM [Remotes].[dbo].[SKUData] AS SKUD WITH(NOLOCK)
			  LEFT OUTER JOIN [Remotes].[dbo].[MarketplaceMapping] AS MM WITH(NOLOCK)
				   ON SKUD.[SKU] = MM.[SKU]
			  LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_OrderDetails] AS OD WITH(NOLOCK)
				   ON MM.[MerchantSKU] = OD.[SellerSKU]
			 GROUP BY SKUD.[SKU], SKUD.[Manufacturer], SKUD.[PartNumber])MAIN
	 ORDER BY MAIN.[QtySold] DESC
			  --,MAIN.[SKU]
END
--EXEC [Remotes].[dbo].[sp_GetSKUSold]
go

