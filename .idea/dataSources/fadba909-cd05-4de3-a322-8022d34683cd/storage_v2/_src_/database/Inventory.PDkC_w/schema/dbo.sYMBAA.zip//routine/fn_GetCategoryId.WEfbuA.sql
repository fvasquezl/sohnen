-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetCategoryId]
(
	@pProductCatalogID varchar(255)
 
)
RETURNS integer
AS
BEGIN
	
	DECLARE @lresult int;
	DECLARE @lsku int;

	SET @lresult = -1;
	
	IF isnumeric(@pProductCatalogID) = 1
	BEGIN
		
			select @lresult =  a.CategoryId from ProductCatalog a
			where a.ID = @pProductCatalogID ;
	
		
			IF  @lresult  is null
			BEGIN
				SET @lresult = -1;
			END
	END

	
	RETURN (@lresult)
END
go

