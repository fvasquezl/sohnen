-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 1-26-2016
-- Description:	Amazon Inventory Feed
-- =============================================
CREATE FUNCTION [dbo].[fn_GetAmazonInventoryFeed] 
(
	-- Add the parameters for the function here
	--@pSKU int
	--@Channel NVARCHAR(500) = NULL
)
RETURNS @Result TABLE (SKU NVARCHAR(MAX),Quantity INT, PriceFloor Decimal(10,2), PriceCeiling Decimal(10,2), Channel NVARCHAR(50), ASIN NVARCHAR(MAX), MITSKU INT, [FloorPriceOverride] BIT, [FloorPriceOverrideValue] Decimal(10,2))
AS
BEGIN


	
INSERT INTO @Result ([SKU],[Quantity],[PriceFloor],[PriceCeiling],[Channel],[ASIN],[MITSKU],[FloorPriceOverride],[FloorPriceOverrideValue])

--ExclusiveBulbs

/**Discontineud FBA 3-31-2018 by amir
--FBA
SELECT DISTINCT AZFBA.[MerchantSKU] AS 'SKU',
		'0' AS 'Quantity',

		IsNull(Cast((
		Case When (PC.DumpFBA = 'True' AND Convert(date,PC.DumpFBAEndDate) > Convert(date,GETDATE())) THEN (PC.PriceFloorFBA*0.60) 
		When AZ.BrandMentioned = 'AuraBeam' THEN  AZ.BuyBoxPrice
		When AZ.FloorPriceOverride = '1' THEN AZ.FloorPriceOverrideValue
		ELSE PC.PriceFloorFBA END) AS Decimal(10,2)),15) AS 'PriceFloor',

		IsNull(Cast((
		Case When AZ.BrandMentioned = 'AuraBeam' THEN AZ.BuyBoxPrice 
		ELSE PC.PriceCeilingFBA END) AS Decimal(10,2)),299) AS 'PriceCeiling',
				
		'ExclusiveBulbsFBA' AS 'Channel',
		AZ.[ASIN] AS 'ASIN',
		AZ.[ProductCatalogID] AS 'MITSKU',
		AZ.[FloorPriceOverride] AS 'FloorOverride',
		AZ.[FloorPriceOverrideValue] AS 'FloorOverrideValue'

FROM [Inventory].[dbo].[AmazonFBA] AS AZFBA WITH(NOLOCK)
LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK) ON (AZFBA.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'US')
LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) ON (AZ.[ProductCatalogID] = GS.[ProductCatalogId])
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (AZ.[ProductCatalogID] = PC.[ID])
WHERE AZFBA.[Channel] = 'Dart' AND AZ.[ASIN] IS NOT NULL AND AZFBA.[MerchantSKU] NOT LIKE '%FLX'

UNION ALL
**/

--FLEX
SELECT DISTINCT AMSKU.[DARTFBMSKU]+'FLX' AS 'SKU',
		IsNULL(AFA.[quantity],0) AS 'Quantity',

		IsNull(Cast((
		Case When (PC.DumpFBA = 'True' AND Convert(date,PC.DumpFBAEndDate) > Convert(date,GETDATE())) THEN (PC.PriceFloorFBA*0.60) 
		When AZ.BrandMentioned = 'AuraBeam' THEN  AZ.BuyBoxPrice
		When AZ.FloorPriceOverride = '1' THEN AZ.FloorPriceOverrideValue
		ELSE PC.PriceFloorFBA END) AS Decimal(10,2)),15) AS 'PriceFloor',

		IsNull(Cast((
		Case When AZ.BrandMentioned = 'AuraBeam' THEN AZ.BuyBoxPrice 
		ELSE PC.PriceCeilingFBA END) AS Decimal(10,2)),299) AS 'PriceCeiling',
				
		'ExclusiveBulbsFLX' AS 'Channel',
		AZ.[ASIN] AS 'ASIN',
		AZ.[ProductCatalogID] AS 'MITSKU',
		AZ.[FloorPriceOverride] AS 'FloorOverride',
		AZ.[FloorPriceOverrideValue] AS 'FloorOverrideValue'

FROM [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK)
LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AMSKU WITH(NOLOCK) ON (AZ.[ASIN] = AMSKU.[ASIN])
--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) ON (AZ.[ProductCatalogID] = GS.[ProductCatalogId])
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (AZ.[ProductCatalogID] = PC.[ID])
LEFT OUTER JOIN [MiTech].[amz].[vw_AmazonFeed] AS AFA WITH(NOLOCK) ON (AMSKU.[DARTFBMSKU]+'FLX' = AFA.[merchantsku])
WHERE AZ.[CountryCode] = 'US' AND AMSKU.[ASIN] IS NOT NULL AND AMSKU.[DARTFBMSKU] IS NOT NULL

UNION ALL


--FLEX LINKED INVENTORY
SELECT DISTINCT AMSKU.[DARTFBMSKU]+'FLX' AS 'SKU',
		CAST(FLOOR(AFA.[quantity]) AS INT) AS 'Quantity',

		IsNull(Cast((
		Case When (PC.DumpFBA = 'True' AND Convert(date,PC.DumpFBAEndDate) > Convert(date,GETDATE())) THEN (PC.PriceFloorFBA*0.60) 
		When AZ.BrandMentioned = 'AuraBeam' THEN  AZ.BuyBoxPrice
		When AZ.FloorPriceOverride = '1' THEN AZ.FloorPriceOverrideValue
		ELSE PC.PriceFloorFBA END) AS Decimal(10,2)),15) AS 'PriceFloor',

		IsNull(Cast((
		Case When AZ.BrandMentioned = 'AuraBeam' THEN AZ.BuyBoxPrice 
		ELSE PC.PriceCeilingFBA END) AS Decimal(10,2)),299) AS 'PriceCeiling',
				
		'ExclusiveBulbsLINK' AS 'Channel',
		AZ.[ASIN] AS 'ASIN',
		AZ.[ProductCatalogID] AS 'MITSKU',
		AZ.[FloorPriceOverride] AS 'FloorOverride',
		AZ.[FloorPriceOverrideValue] AS 'FloorOverrideValue'

FROM [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK)
LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AMSKU WITH(NOLOCK) ON (AZ.[ASIN] = AMSKU.[ASIN])
--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) ON (AZ.[ProductCatalogID] = GS.[ProductCatalogId])
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (AZ.[ProductCatalogID] = PC.[ID])
LEFT OUTER JOIN [MiTech].[amz].[vw_AmazonFeed] AS AFA WITH(NOLOCK) ON (AMSKU.[DARTFBMSKU]+'FLX' = AFA.[merchantsku])
WHERE AZ.[CountryCode] = 'US' AND AZ.[FLXActive] = 1 AND AMSKU.[ASIN] IS NOT NULL AND AMSKU.[DARTFBMSKU] IS NOT NULL

UNION ALL




--MerchantPrime
SELECT DISTINCT AMSKU.[DARTMFPSKU] AS 'SKU'
		--,IsNULL(AZFLXACTIVATE.[add-delete],'d') --This is to test flex Active or Disactive
		,CASE 
		WHEN AZ.[IsActive] = 0 THEN 0

		--In the LEFT JOINS the AZFBA is tied to FBA MerchantSKU through the MerchantPrime SKU .. SO THIS IS TRANSLATED
		--FLEX DISACTIVATE FIX (since we are disactivating flex when inventory falls below 3pcs, we will activate MFP regardless)
		WHEN AZ.[IsActive] = 1 AND PC.[TotalStock] <= 1 THEN 0 --CAST(IsNULL(PC.[TotalStock],0) AS INT)
		
		--IF there is FLEX active then we feed 0 regardless
		WHEN AZ.[IsActive] = 1 AND IsNULL(AZFLXACTIVATE.[add-delete],'d') = 'a' THEN 0

		--Flex Disactivated but AlwaysInStock AND Active we feed 500pcs
		WHEN AZ.[IsActive] = 1 AND IsNULL(AZFLXACTIVATE.[add-delete],'d') = 'd' AND PC.[AlwaysInStock] = 1  THEN 500

		--WHEN AZ.[IsActive] = 1 AND PC.[AlwaysInSTock] = 0 THEN CAST(IsNull(GS.[TotalStock]/1.25,0) AS INT)
		--Above has been replaced by below to check alternative stock for OEM's and fill PC.[TotalStock] field
		
		--Flex Disactivated and IsActive and NotAlwaysInStock THEN we feed actual inventory from PC.TotalStock which is getting alternatestock
		WHEN AZ.[IsActive] = 1 AND PC.[AlwaysInSTock] = 0  AND IsNULL(AZFLXACTIVATE.[add-delete],'d') = 'd' THEN CAST(IsNull(PC.[TotalStock],0) AS INT)
		ELSE 0 END AS 'Quantity',

		IsNull(Cast((
		Case When (PC.DumpFBA = 'True' AND Convert(date,PC.DumpFBAEndDate) > Convert(date,GETDATE())) THEN (PC.PriceFloorFBA*0.80) 
		When AZ.BrandMentioned = 'AuraBeam' THEN 
			(Case When PC.PriceFloorMFP+5 < Floor(AZ.BuyBoxPrice+5)-0.01 THEN Floor(AZ.BuyBoxPrice+5)-0.01 
				When PC.PriceFloorMFP > Floor(AZ.BuyBoxPrice+5)-0.01 THEN Floor(PC.PriceFloorMFP)-0.01 
				ELSE Floor(PC.PriceCeilingMFP)-0.01 END) 
		When AZ.FloorPriceOverride = 1 THEN AZ.FloorPriceOverrideValue+5
		ELSE PC.PriceFloorMFP END) AS Decimal(10,2)),15) AS 'PriceFloor',


		IsNull(Cast((
		Case When AZ.BrandMentioned = 'AuraBeam' THEN 
			(Case When PC.PriceFloorMFP < Floor(AZ.BuyBoxPrice+5)-0.01 THEN Floor(AZ.BuyBoxPrice+5)-0.01 
			When PC.PriceFloorMFP > Floor(AZ.BuyBoxPrice+5)-0.01 THEN Floor(PC.PriceFloorMFP)-0.01 
			ELSE Floor(PC.PriceCeilingMFP)-0.01 END) 
		ELSE PC.PriceCeilingMFP END) AS Decimal(10,2)),299) AS 'PriceCeiling',
		
		'ExclusiveBulbsMFP' AS 'Channel',
		AZ.[ASIN] AS 'ASIN',
		AZ.[ProductCatalogID] AS 'MITSKU',
		AZ.[FloorPriceOverride] AS 'FloorOverride',
		AZ.[FloorPriceOverrideValue]+5 AS 'FloorOverrideValue'

FROM [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK)
LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AMSKU WITH(NOLOCK) ON (AZ.[ASIN] = AMSKU.[ASIN])
--I tied the DartMerchantSKU for PRIME to the DartMerchantSKU for FBA so we can check FBA quantity and disable MFP if FBAQty > 0
LEFT OUTER JOIN [Inventory].[dbo].[AmazonFBA] AS AZFBA WITH(NOLOCK) ON (AMSKU.[DARTFBASKU] = AZFBA.[MerchantSKU] AND AZFBA.[Channel] = 'Dart')
--I tied the DartMerchantSKU for PRIME to the DartMerchantSKU for FLEX so we can check FBA quantity and disable MFP if FBAQty > 0
LEFT OUTER JOIN [Inventory].[dbo].[AmazonFBA] AS AZFLX WITH(NOLOCK) ON (AMSKU.[DARTFBMSKU]+'FLX' = AZFLX.[MerchantSKU] AND AZFLX.[Channel] = 'Dart')
LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) ON (AZ.[ProductCatalogID] = GS.[ProductCatalogId])
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (AZ.[ProductCatalogID] = PC.[ID])
LEFT OUTER JOIN [MiTech].[amz].[vw_AmazonFeed] AS AZFLXACTIVATE WITH(NOLOCK) ON (AMSKU.[DARTFBMSKU]+'FLX' = AZFLXACTIVATE.[merchantsku])
--Added this so we don't list stuff we have switched to 100% flex.
LEFT OUTER JOIN [Inventory].[dbo].[AmazonMFPDeactivate] AS AZDEACTIVATEMFP WITH(NOLOCK) ON (AMSKU.[DARTMFPSKU] = AZDEACTIVATEMFP.[MerchantSKU])
WHERE AZ.[CountryCode] = 'US' AND AMSKU.[DARTMFPSKU] IS NOT NULL 
--Added condition to not feed inventory for items in the table [Inventory].[dbo].[AmazonMFPDeactivate]
AND AZDEACTIVATEMFP.[MerchantSKU] IS NULL


UNION ALL

--ExclusiveBulbs CANADA
--FBM Canada
SELECT DISTINCT AMSKU.[DARTFBMSKUCA] AS 'SKU'
		,CASE 
		WHEN AZ.[IsActive] = 0 THEN 0
		WHEN AZ.[IsActive] = 1 AND PC.[AlwaysInStock] = 1 THEN 500
		WHEN AZ.[IsActive] = 1 AND PC.[AlwaysInSTock] = 0 THEN CAST(IsNull(GS.[TotalStock]/1.25,0) AS INT)
		ELSE 0 END AS 'Quantity',

		IsNull(Cast((
		Case When (PC.DumpFBM = 'True' AND Convert(date,PC.DumpFBMEndDate) > Convert(date,GETDATE())) THEN (IsNull(PC.PriceFloor+10,250)*0.60) 
		When AZ.BrandMentioned = 'AuraBeam' THEN AZ.BuyBoxPrice+12  
		When AZ.FloorPriceOverride = '1' THEN AZ.FloorPriceOverrideValue+10 
		ELSE IsNull(PC.PriceFloor+10,250) END) AS Decimal(10,2)),15) AS 'PriceFloor',

		IsNull(Cast((
		Case When AZ.BrandMentioned = 'AuraBeam' THEN AZ.BuyBoxPrice+12 
		ELSE IsNull(PC.PriceCeilingMFP,350) END) AS Decimal(10,2)),299)  AS 'PriceCeiling',

		
		'ExclusiveBulbsCAMFN' AS 'Channel',
		AZ.[ASIN] AS 'ASIN',
		AZ.[ProductCatalogID] AS 'MITSKU',
		AZ.[FloorPriceOverride] AS 'FloorOverride',
		AZ.[FloorPriceOverrideValue]+10 AS 'FloorOverrideValue'

FROM [Inventory].[dbo].[Amazon]  AS AZ WITH(NOLOCK)
LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AMSKU WITH(NOLOCK) ON (AZ.[ASIN] = AMSKU.[ASIN])
LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) ON (AZ.[ProductCatalogID] = GS.[ProductCatalogId])
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (AZ.[ProductCatalogID] = PC.[ID])
WHERE AZ.[CountryCode] = 'CA' AND AMSKU.[DARTFBMSKUCA] IS NOT NULL

UNION ALL 

--FBA Canada
SELECT DISTINCT AZFBA.[MerchantSKU] AS 'SKU',
		'0' AS 'Quantity',

		IsNull(Cast((
		Case When (PC.DumpFBA = 'True' AND Convert(date,PC.DumpFBAEndDate) > Convert(date,GETDATE())) THEN ((PC.PriceFloorFBA+5)*0.60) 
		When AZ.BrandMentioned = 'AuraBeam' THEN  AZ.BuyBoxPrice+5
		When AZ.FloorPriceOverride = '1' THEN AZ.FloorPriceOverrideValue+5
		ELSE PC.PriceFloorFBA+5 END) AS Decimal(10,2)),15) AS 'PriceFloor',

		IsNull(Cast((
		Case When AZ.BrandMentioned = 'AuraBeam' THEN AZ.BuyBoxPrice+5 
		ELSE PC.PriceCeilingFBA+5 END) AS Decimal(10,2)),299) AS 'PriceCeiling',
		
		'ExclusiveBulbsCAFBA' AS 'Channel',
		AZ.[ASIN] AS 'ASIN',
		AZ.[ProductCatalogID] AS 'MITSKU',
		AZ.[FloorPriceOverride] AS 'FloorOverride',
		AZ.[FloorPriceOverrideValue]+5 AS 'FloorOverrideValue'

FROM [Inventory].[dbo].[AmazonFBA] AS AZFBA WITH(NOLOCK)
LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK) ON (AZFBA.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'CA')
LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) ON (AZ.[ProductCatalogID] = GS.[ProductCatalogId])
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (AZ.[ProductCatalogID] = PC.[ID])
WHERE AZFBA.[Channel] = 'DartCA'
	

UNION ALL

--ExclusiveBulbs UK
--FBM UK
SELECT DISTINCT AMSKU.[DARTFBMSKUUK] AS 'SKU'
		,CASE 
		WHEN AZ.[IsActive] = 0 THEN 0
		WHEN AZ.[IsActive] = 1 AND PC.[AlwaysInStock] = 1 THEN 500
		WHEN AZ.[IsActive] = 1 AND PC.[AlwaysInSTock] = 0 THEN CAST(IsNull(GS.[TotalStock]/1.25,0) AS INT)
		ELSE 0 END AS 'Quantity',

		IsNull(Cast((
		Case When (PC.DumpFBM = 'True' AND Convert(date,PC.DumpFBMEndDate) > Convert(date,GETDATE())) THEN (IsNull(PC.PriceFloor+10,250)*0.60) 
		When AZ.BrandMentioned = 'AuraBeam' THEN AZ.BuyBoxPrice+20  
		When AZ.FloorPriceOverride = '1' THEN AZ.FloorPriceOverrideValue+20 
		ELSE IsNull(PC.PriceFloor+20,250) END) AS Decimal(10,2)),15) AS 'PriceFloor',

		IsNull(Cast((
		Case When AZ.BrandMentioned = 'AuraBeam' THEN AZ.BuyBoxPrice+20 
		ELSE IsNull(PC.PriceCeilingMFP,350) END) AS Decimal(10,2)),299)  AS 'PriceCeiling',

		
		'ExclusiveBulbsUK' AS 'Channel',
		AZ.[ASIN] AS 'ASIN',
		AZ.[ProductCatalogID] AS 'MITSKU',
		AZ.[FloorPriceOverride] AS 'FloorOverride',
		AZ.[FloorPriceOverrideValue]+20 AS 'FloorOverrideValue'

FROM [Inventory].[dbo].[Amazon]  AS AZ WITH(NOLOCK)
LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AMSKU WITH(NOLOCK) ON (AZ.[ASIN] = AMSKU.[ASIN])
LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) ON (AZ.[ProductCatalogID] = GS.[ProductCatalogId])
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (AZ.[ProductCatalogID] = PC.[ID])
WHERE AZ.[CountryCode] = 'UK' AND AMSKU.[DARTFBMSKUUK] IS NOT NULL 


	
	RETURN;

END
go

