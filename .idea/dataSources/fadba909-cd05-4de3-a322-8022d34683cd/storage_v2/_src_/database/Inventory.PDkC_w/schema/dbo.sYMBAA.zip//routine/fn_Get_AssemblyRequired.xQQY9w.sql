-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_Get_AssemblyRequired
(
	-- Add the parameters for the function here
	@ProductCatalogID int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar as integer
	DECLARE @TemVar as Bit

	-- Add the T-SQL statements to compute the return value here
	SELECT @TemVar = AssemblyRequired FROM inventory.dbo.ProductCatalog
			WHERE id = @ProductCatalogID
	-- Return the result of the function
	
	IF @TemVar is null
	BEGIN
		SET @ResultVar = 0
	END
	ELSE
	BEGIN
		IF @TemVar = 0
		begin
			SET @ResultVar = 0
		end
		else
		Begin
			SET @ResultVar = 1		
		End
	
	END
	
	RETURN @ResultVar

END
go

