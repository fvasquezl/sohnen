Create Function [dbo].[fnSplit]
        (
        @List varchar(8000)
        , @Delimiter char(1) = ','
        )
    Returns @Temp1 Table
        (
        ItemId int Identity(1, 1) NOT NULL PRIMARY KEY
        , Item varchar(8000) NULL
        )
    As
    Begin

    Declare
        @item varchar(4000)
        , @iPos int

    Set @Delimiter = ISNULL( @Delimiter, ',' )
    Set @List = RTrim( LTrim( @List ) )

    If (@List <> '' )
        Begin
        -- check for final delimiter
        If Right( @List, 1 ) <> @Delimiter      
            -- append final delimiter
            Select @List = @List + @Delimiter

        -- get position of first element
        Select @iPos = Charindex( @Delimiter, @List, 1 )

        While @iPos > 0
            Begin
            -- get item
            Select @item = LTrim( RTrim( Substring( @List, 1, @iPos -1 ) ) )
            If @@ERROR <> 0 Break
            -- remove item form list
            Select @List =  Substring( @List, @iPos + 1, Len(@List) - @iPos + 1 )
            If @@ERROR <> 0 Break
            -- insert item
            Insert @Temp1 Values( @item )
            If @@ERROR <> 0 Break
            -- get position pf next item
            Select @iPos = Charindex( @Delimiter, @List, 1 )
            If @@ERROR <> 0 Break
            End
        End
    Return
    End
go

