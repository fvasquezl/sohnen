-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-23-2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonFLEXActivateSPARC-Step2] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


		DECLARE @selectstatement NVARCHAR(2000)
		DECLARE @cmd NVARCHAR(2000)


		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'LastFlexActivateFeedSPARC'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[LastFlexActivateFeedSPARC]
			END
			--END CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED
		
		CREATE TABLE [Inventory].[dbo].[LastFlexActivateFeedSPARC] (
				[sku] NVARCHAR(MAX),
				[product-id] NVARCHAR(MAX),
				[product-id-type] NVARCHAR(MAX),
				[price] NVARCHAR(MAX),
				[minimum-seller-allowed-price] NVARCHAR(MAX),
				[maximum-seller-allowed-price] NVARCHAR(MAX),
				[item-condition] NVARCHAR(MAX),
				[quantity] NVARCHAR(MAX),
				[add-delete] NVARCHAR(MAX),
				[will-ship-internationally] NVARCHAR(MAX),
				[expedited-shipping] NVARCHAR(MAX),
				[standard-plus] NVARCHAR(MAX),
				[item-note] NVARCHAR(MAX),
				[fulfillment-center-id] NVARCHAR(MAX),
				[product-tax-code] NVARCHAR(MAX),
				[leadtime-to-ship] NVARCHAR(MAX),
				[merchant_shipping_group_name] NVARCHAR(MAX)
				)



		INSERT INTO [Inventory].[dbo].[LastFlexActivateFeedSPARC]
		SELECT [sku] ,
				[product-id] ,
				[product-id-type] ,
				[price] ,
				[minimum-seller-allowed-price] ,
				[maximum-seller-allowed-price],
				[item-condition],
				[quantity],
				[add-delete] ,
				[will-ship-internationally] ,
				[expedited-shipping] ,
				[standard-plus] ,
				[item-note] ,
				[fulfillment-center-id] ,
				[product-tax-code] ,
				[leadtime-to-ship] ,
				[merchant_shipping_group_name] 
		FROM [Inventory].[dbo].[AmazonFlexActivateSPARC] --This is a VIEW




END
go

