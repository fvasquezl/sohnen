-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-06-09
-- Description:	Get function fn_GetCompatiblityListForEbay 
--	and split then insert in temp table to returned
-- =============================================
CREATE PROCEDURE sp_GetTableCompatiblityListForEbay
	@pManufaturer varchar(50), 
	@pPartNumber varchar(50)
AS
DECLARE 
	@COMP_LIST		NVARCHAR(MAX),
	@CURSOR_PRODUCT	CURSOR,
	@SPLIT_DATA		NVARCHAR(50),
	@TYPE			INT = 0,
	@ID				INT
BEGIN
	SET NOCOUNT ON;

    SET @COMP_LIST = [Inventory].[dbo].[fn_GetCompatiblityListForEbay](@pManufaturer,@pPartNumber,'PartNumberSpecific')

	CREATE TABLE #tmpInfo (ID INT IDENTITY(1,1), PartNumbers varchar(50) DEFAULT '', ModelNumbers varchar(50) DEFAULT '') 

	SET @CURSOR_PRODUCT = CURSOR FOR 
	
	SELECT splitdata FROM Inventory.dbo.fnSplitString(REPLACE(@COMP_LIST,'Numbers:',''),' ')

	OPEN @CURSOR_PRODUCT
		FETCH NEXT FROM @CURSOR_PRODUCT 
		INTO @SPLIT_DATA

		IF @@FETCH_STATUS <> 0 
        BEGIN 
			CLOSE      @CURSOR_PRODUCT 
            DEALLOCATE @CURSOR_PRODUCT
            RETURN
		END
		   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN          
			
			IF(LTRIM(RTRIM(ISNULL(@SPLIT_DATA,''))) = 'Part')
			BEGIN
				SET @TYPE = 1
			END
			IF(LTRIM(RTRIM(ISNULL(@SPLIT_DATA,''))) = 'Model')
		    BEGIN
				SET @TYPE = 2
			END
			
			IF(LTRIM(RTRIM(ISNULL(@SPLIT_DATA,''))) <> '<br><br>' AND LTRIM(RTRIM(ISNULL(@SPLIT_DATA,''))) <> '' 
				AND LTRIM(RTRIM(ISNULL(@SPLIT_DATA,''))) <> 'Part' AND LTRIM(RTRIM(ISNULL(@SPLIT_DATA,''))) <> 'Model')
			BEGIN

				IF(@TYPE = 1)
				BEGIN
					INSERT INTO #tmpInfo (PartNumbers) VALUES (REPLACE(@SPLIT_DATA,',',''))
				END

				IF(@TYPE = 2)
				BEGIN
					IF((SELECT COUNT(*) FROM #tmpInfo WHERE ISNULL(ModelNumbers,'') = '') > 0)
					BEGIN
						SELECT TOP 1 @ID = ID FROM #tmpInfo WHERE ISNULL(ModelNumbers,'') = ''
						UPDATE #tmpInfo SET ModelNumbers = REPLACE(@SPLIT_DATA,',','') WHERE ID = @ID
					END
					ELSE
					BEGIN
						INSERT INTO #tmpInfo (ModelNumbers) VALUES (REPLACE(@SPLIT_DATA,',',''))
					END
				END
			
			END
			 
			FETCH NEXT FROM @CURSOR_PRODUCT 
			INTO @SPLIT_DATA
		END
    CLOSE      @CURSOR_PRODUCT 
    DEALLOCATE @CURSOR_PRODUCT 

	SELECT ID, PartNumbers, ModelNumbers FROM #tmpInfo
END
go

