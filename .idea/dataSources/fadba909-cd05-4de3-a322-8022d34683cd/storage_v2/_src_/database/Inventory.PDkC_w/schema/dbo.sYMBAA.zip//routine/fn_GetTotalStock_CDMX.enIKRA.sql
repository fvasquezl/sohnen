-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2019-06-10
-- Description:	Get CDMX Total Stock by SKU
-- =============================================
CREATE FUNCTION fn_GetTotalStock_CDMX
(
	@SKU INT
)
RETURNS INT
AS
BEGIN
	DECLARE @RETURN INT

	SET @RETURN = ISNULL((
		SELECT SUM(BC.Counter) FROM Inventory.dbo.Bin_Content BC WITH(NOLOCK) 
		INNER JOIN Inventory.dbo.Bins B WITH(NOLOCK)
		ON B.Bin_Id = BC.Bin_Id AND B.Active = 1 AND B.Bin_Id LIKE 'CDM%' AND B.WarehouseID = 'DF'
		WHERE BC.ProductCatalog_Id = @SKU),0)
	
	RETURN @RETURN

END
go

