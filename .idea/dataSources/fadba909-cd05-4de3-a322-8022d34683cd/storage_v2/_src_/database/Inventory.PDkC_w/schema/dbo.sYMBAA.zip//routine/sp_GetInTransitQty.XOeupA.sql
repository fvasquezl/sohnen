-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-04-20
-- Description:	Get In Transit Qty by SKU
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetInTransitQty] 
	@SKU INT
AS
BEGIN
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT PONo, SKU, QtyShipped, ETA, ReleaseDay, TrackingID FROM Inventory.dbo.InTransit WHERE SKU = @SKU
END
go

