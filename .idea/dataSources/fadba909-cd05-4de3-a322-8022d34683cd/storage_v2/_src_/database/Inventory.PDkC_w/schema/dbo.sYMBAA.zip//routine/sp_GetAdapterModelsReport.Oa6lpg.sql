-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2019-02-27
-- Description:	Get Adapter models for apps3 Adapter Models Report
-- =============================================
CREATE PROCEDURE sp_GetAdapterModelsReport
	@SEARCH			NVARCHAR(100),
	@PlugType		NVARCHAR(150),
	@Gender			NVARCHAR(50),
	@Amp			NVARCHAR(50),
	@Wattage		NVARCHAR(50),
	@Voltage		NVARCHAR(50)
AS
BEGIN
	DECLARE @SQL NVARCHAR(MAX)
	SET NOCOUNT ON;

	SET @SQL = ' SELECT A.ModelID, A.ProductType, A.Manufacturer, A.Model, A.Amp, A.Wattage, A.Voltage, A.PlugType, A.Gender, A.AdapterMPN, A.AdapterManufacturer '
	SET @SQL = @SQL + ' FROM Inventory.dbo.AdapterModels A WITH(NOLOCK) WHERE 1 = 1 '
	
	SET @SQL = @SQL + (CASE WHEN ISNULL(@SEARCH,'') <> '' THEN ' AND (A.Model LIKE ''%'+@SEARCH+'%'' OR A.AdapterMPN LIKE ''%'+@SEARCH+'%'') ' ELSE '' END)

	SET @SQL = @SQL + (CASE WHEN ISNULL(@Gender,'') <> '' THEN ' AND A.Gender = ''' + @Gender + ''' ' ELSE '' END)

	SET @SQL = @SQL + (CASE WHEN ISNULL(@PlugType,'') <> '' THEN ' AND A.PlugType = ''' + @PlugType + ''' ' ELSE '' END)

	SET @SQL = @SQL + (CASE WHEN ISNULL(@Amp,'') <> '' THEN ' AND A.Amp ' + @Amp ELSE '' END)

	SET @SQL = @SQL + (CASE WHEN ISNULL(@Wattage,'') <> '' THEN ' AND A.Wattage ' + @Wattage ELSE '' END)
	
	SET @SQL = @SQL + (CASE WHEN ISNULL(@Voltage,'') <> '' THEN ' AND A.Voltage ' + @Voltage ELSE '' END)

	EXECUTE(@SQL)
END
go

