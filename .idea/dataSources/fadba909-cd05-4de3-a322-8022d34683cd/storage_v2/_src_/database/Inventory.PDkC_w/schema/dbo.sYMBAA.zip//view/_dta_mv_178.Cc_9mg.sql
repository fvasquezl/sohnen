CREATE VIEW [dbo]._dta_mv_178 WITH SCHEMABINDING AS SELECT  [dbo].[CompatibilityAlternativeModels].[OriginalManufacturer] as _col_1,  [dbo].[CompatibilityAlternativeModels].[OriginalModel] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[CompatibilityAlternativeModels]  GROUP BY  [dbo].[CompatibilityAlternativeModels].[OriginalManufacturer],  [dbo].[CompatibilityAlternativeModels].[OriginalModel]
go

