CREATE VIEW dbo.BinContentConsignment
AS
SELECT        BCONT.ProductCatalog_Id AS MITSKU, PC.Name, BC.Bin_Id AS BinID, B.WarehouseID AS Location, BCONT.Counter AS BinQty, CAT.Name AS Category, BCONT.LastStamp AS LastModified, 
                         LUSR.fullname AS LastUserName, BC.UserID
FROM            dbo.BinConsignment AS BC LEFT OUTER JOIN
                         dbo.Bin_Content AS BCONT ON BC.Bin_Id = BCONT.Bin_Id LEFT OUTER JOIN
                         dbo.Users AS LUSR ON LUSR.id = BCONT.LastUser_Id LEFT OUTER JOIN
                         dbo.ProductCatalog AS PC ON BCONT.ProductCatalog_Id = PC.ID LEFT OUTER JOIN
                         dbo.Categories AS CAT ON PC.CategoryID = CAT.ID LEFT OUTER JOIN
                         dbo.Bins AS B ON B.Bin_Id = BC.Bin_Id
go

