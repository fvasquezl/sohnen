-- =============================================
-- Author:		Luis Batista
-- Create date: JUL-03 2014
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[fn_Bins_Sum_Qty]
(
	@pSKU integer, @pSC as varchar(10), @pDateStart datetime, @pDateEnd datetime
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar int;

	SELECT @ResultVar = SUM( a.Qty)
	FROM [Inventory].[dbo].[Bins_History] a
	WHERE (a.Product_Catalog_ID = @pSKU)
		AND (a.ScanCode like @pSC)
	
		AND (a.Stamp between @pDateStart and @pDateEnd);

	IF @ResultVar is null
	BEGIN
		set @ResultVar = 0;
	END 
	-- Return the result of the function
	RETURN @ResultVar;

END
go

