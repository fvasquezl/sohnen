-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Bins_Stock_In_WH_At_Date]
(
	@pSKU int, @pDate Datetime,  @pWHID varchar(2)
)
RETURNS int	
AS
BEGIN
DECLARE @ResultVar int;
	DECLARE @ins int;
	DECLARE @outs int;
	

	
	
	 SELECT 
		@outs = SUM(CASE WHEN Flow =2 THEN a.Qty ELSE 0 END	) ,
		@ins = SUM(CASE WHEN Flow =1 THEN a.Qty ELSE 0 END	) 
	FROM Inventory.dbo.Bins_History a 
	 WHERE (a.Product_Catalog_ID = @pSKU) and (a.Stamp <= @pDate)
	 AND (inventory.dbo.fn_Get_Bin_WarehouseID (Bin_Id)  = @pWHID );




	  IF @ins is null
	BEGIN
		SET @ins = 0;
	END


	  IF @outs is null
	BEGIN
		SET @outs = 0;
	END

	SET @ResultVar = @ins - @outs;

	IF @ResultVar is null
	BEGIN
		SET @ResultVar = 0;
	END
	-- Return the result of the function
	RETURN @ResultVar; 

END
go

