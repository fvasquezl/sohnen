
-- =======================================================================================================================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-10-09
-- Description:	Get Invoice By Ship Date 
-- Test script: EXEC Inventory.dbo.sp_GetInvoiceByShipDate 1236925
-- =======================================================================================================================================
CREATE PROCEDURE [dbo].[sp_GetInvoiceByShipDate]
	@CustomerID INT
AS
BEGIN
	DECLARE @FinalGrandTotal DECIMAL(13,4), @INT1 INT, @INT2 INT
	SET NOCOUNT ON;

	IF EXISTS (SELECT 1 FROM tempdb..SYSOBJECTS WHERE name LIKE '#TMP_StatementByShipDate') BEGIN
		DROP TABLE #TMP_StatementByShipDate
	END

	CREATE TABLE #TMP_StatementByShipDate (CustomerID INT, OrderNumber INT, OrderSource NVARCHAR(2), OrderReference NVARCHAR(255), PONumber NVARCHAR(50), ShipDate NVARCHAR(10), OrderDate NVARCHAR(10), SKU NVARCHAR(100), WebSKU NVARCHAR(255), Product NVARCHAR(255), QuantityShipped INT, PricePerUnit DECIMAL(13,2), LineTotal DECIMAL(13,2), STATEMENTDAY INT, FullName NVARCHAR(255), Company NVARCHAR(255), [Address] NVARCHAR(255), Address2 NVARCHAR(255), City NVARCHAR(255), State NVARCHAR(255), Zip NVARCHAR(255), Country NVARCHAR(255), Phone NVARCHAR(50), Phone2 NVARCHAR(50), Email NVARCHAR(255), ShipName NVARCHAR(255), ShipCompany NVARCHAR(255), ShipAddress NVARCHAR(255), ShipAddress2 NVARCHAR(255), ShipCity NVARCHAR(255), ShipState NVARCHAR(255), ShipZip NVARCHAR(255), ShipCountry NVARCHAR(255), ShipPhone NVARCHAR(255), OrderStatus NVARCHAR(50), TrackingNum NVARCHAR(50), [ProductTotal] DECIMAL(13,2), [TaxTotal] DECIMAL(13,2), [ShippingTotal] DECIMAL(13,2), [GrandTotal] DECIMAL(13,2), [NumItems] INT, [Shipping] NVARCHAR(150), [Discount] DECIMAL(13,2), [RevisedDiscount] DECIMAL(13,2), [FinalProductTotal] DECIMAL(13,2), [FinalTaxTotal] DECIMAL(13,2), [FinalShippingTotal] DECIMAL(13,2), [FinalGrandTotal] DECIMAL(13,2),[BalanceDue] DECIMAL(13,2), ItemNumber INT)
	
	SET @INT1 = 0
	SET @INT2 = 30
	WHILE(@INT2 <= 180)
	BEGIN
		INSERT INTO #TMP_StatementByShipDate (CustomerID, OrderNumber, OrderSource, OrderReference, PONumber, ShipDate, OrderDate, SKU, WebSKU, [Product], [QuantityShipped], [PricePerUnit], LineTotal, STATEMENTDAY, FullName, Company, [Address], Address2, City, [State], Zip, Country, Phone, Phone2, Email, ShipName, ShipCompany, ShipAddress, ShipAddress2, ShipCity, ShipState, ShipZip, ShipCountry, ShipPhone, OrderStatus, TrackingNum, ProductTotal, TaxTotal, ShippingTotal, GrandTotal, NumItems, Shipping, Discount, RevisedDiscount, FinalProductTotal, FinalTaxTotal, FinalShippingTotal, FinalGrandTotal, BalanceDue, ItemNumber)
		SELECT O.CustomerID, O.[OrderNumber], O.[OrderSource] , ISNULL(O.[SourceOrderID], ISNULL(CAST(O.[SourceOrderNumber] AS NVARCHAR(MAX)),'')) AS 'OrderReference', ISNULL(O.[PONumber],'') AS 'PONumber',CAST((SELECT TOP(1) TRK2.[DateAdded] FROM [OrderManager].[dbo].[Tracking] AS TRK2 (NOLOCK) WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS DATE) AS 'ShipDate', CAST(O.[OrderDate] AS date) AS 'OrderDate',
		--(CASE WHEN OD.[Option01] IS NOT NULL AND OD.[Option01] != '' THEN OD.[Option01] ELSE OD.[SKU] END) AS 'SKU',
		(CASE WHEN OD.[Option01] IS NOT NULL AND OD.[Option01] != '' THEN OD.[Option01] ELSE OD.[SKU] END) AS 'SKU', 
		 OD.WebSKU, OD.[Product], OD.[QuantityShipped], OD.[PricePerUnit], (OD.[QuantityShipped]*OD.[PricePerUnit]) AS 'LineTotal'
			,@INT2, ISNULL(CUST.[FullName],'') AS [FullName], ISNULL(CUST.[Company],'') AS [Company], ISNULL(CUST.[Address],'') AS [Address], ISNULL(CUST.[Address2],'') AS [Address2], ISNULL(CUST.[City],'') AS [City], 
			ISNULL(CUST.[State],'') AS [State], ISNULL(CUST.[Zip],'') AS [Zip], ISNULL(CUST.[Country],'') AS [Country], ISNULL(CUST.[Phone],'') AS [Phone], ISNULL(CUST.[Phone2],'') AS [Phone2], ISNULL(CUST.[Email],'') AS [Email], 
			O.[ShipName], O.[ShipCompany], O.[ShipAddress], ISNULL(O.[ShipAddress2], '') [ShipAddress2], O.[ShipCity], O.[ShipState], O.[ShipZip], O.[ShipCountry], O.[ShipPhone], O.[OrderStatus], (SELECT TOP(1) TRK2.[TrackingID] FROM [OrderManager].[dbo].[Tracking] AS TRK2 (NOLOCK) WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS [TrackingNum], O.[ProductTotal], O.[TaxTotal], O.[ShippingTotal], O.[GrandTotal], O.[NumItems], O.[Shipping], O.[Discount], O.[RevisedDiscount], O.[FinalProductTotal], O.[FinalTaxTotal], O.[FinalShippingTotal], O.[FinalGrandTotal], O.[BalanceDue], OD.ItemNumber
		FROM [OrderManager].[dbo].[Orders] AS O (NOLOCK)
			--LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] AS TRK ON (O.[OrderNumber] = TRK.[NumericKey])
			LEFT OUTER JOIN [OrderManager].[dbo].[Order Details] AS OD WITH(NOLOCK) ON (O.[OrderNumber] = OD.[OrderNumber])
			LEFT OUTER JOIN [OrderManager].[dbo].[Customers] AS CUST WITH(NOLOCK) ON (O.CustomerID = CUST.[CustomerID])
		WHERE O.[Approved] = '1'
			AND O.[Cancelled] = '0'
			AND O.[BalanceDue] > '1.00'
			AND OD.Adjustment = '0'
			--AND TRK.[TrackingID] IS NOT NULL
			AND O.CustomerID = @CustomerID
			-- AND O.OrderNumber IN ( 6456042 )
			AND (SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 WITH(NOLOCK) WHERE TRK2.NumericKey = O.OrderNumber) BETWEEN GETDATE()-@INT2 AND GETDATE()-@INT1
		ORDER BY 'ShipDate' ASC, O.OrderDate ASC, OD.ItemNumber ASC

		IF(@INT2>=120)
		BEGIN
			SET @INT1 = @INT1 + 30
			SET @INT2 = @INT2 + 60
		END
		ELSE
		BEGIN
			SET @INT1 = @INT1 + 30
			SET @INT2 = @INT2 + 30
		END	  
	END

	INSERT INTO #TMP_StatementByShipDate (CustomerID, OrderNumber, OrderSource, OrderReference, PONumber, ShipDate, OrderDate, SKU, WebSKU, [Product], [QuantityShipped], [PricePerUnit], LineTotal, STATEMENTDAY, FullName, Company, [Address], Address2, City, [State], Zip, Country, Phone, Phone2, Email, ShipName, ShipCompany, ShipAddress, ShipAddress2, ShipCity, ShipState, ShipZip, ShipCountry, ShipPhone, OrderStatus, TrackingNum, ProductTotal, TaxTotal, ShippingTotal, GrandTotal, NumItems, Shipping, Discount, RevisedDiscount, FinalProductTotal, FinalTaxTotal, FinalShippingTotal, FinalGrandTotal, BalanceDue, ItemNumber)
		SELECT O.CustomerID, O.[OrderNumber], O.[OrderSource] , ISNULL(O.[SourceOrderID], ISNULL(CAST(O.[SourceOrderNumber] AS NVARCHAR(MAX)),'')) AS 'OrderReference', ISNULL(O.[PONumber],'') AS 'PONumber',CAST((SELECT TOP(1) TRK2.[DateAdded] FROM [OrderManager].[dbo].[Tracking] AS TRK2 (NOLOCK) WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS DATE) AS 'ShipDate', CAST(O.[OrderDate] AS date) AS 'OrderDate',
		--(CASE WHEN OD.[Option01] IS NOT NULL AND OD.[Option01] != '' THEN OD.[Option01] ELSE OD.[SKU] END) AS 'SKU',
		(CASE WHEN OD.[Option01] IS NOT NULL AND OD.[Option01] != '' THEN OD.[Option01] ELSE OD.[SKU] END) AS 'SKU', 
		 OD.WebSKU, OD.[Product], OD.[QuantityShipped], OD.[PricePerUnit], (OD.[QuantityShipped]*OD.[PricePerUnit]) AS 'LineTotal'
			,@INT2, ISNULL(CUST.[FullName],'') AS [FullName], ISNULL(CUST.[Company],'') AS [Company], ISNULL(CUST.[Address],'') AS [Address], ISNULL(CUST.[Address2],'') AS [Address2], ISNULL(CUST.[City],'') AS [City], 
			ISNULL(CUST.[State],'') AS [State], ISNULL(CUST.[Zip],'') AS [Zip], ISNULL(CUST.[Country],'') AS [Country], ISNULL(CUST.[Phone],'') AS [Phone], ISNULL(CUST.[Phone2],'') AS [Phone2], ISNULL(CUST.[Email],'') AS [Email], 
			O.[ShipName], O.[ShipCompany], O.[ShipAddress], ISNULL(O.[ShipAddress2], '') [ShipAddress2], O.[ShipCity], O.[ShipState], O.[ShipZip], O.[ShipCountry], O.[ShipPhone], O.[OrderStatus], (SELECT TOP(1) TRK2.[TrackingID] FROM [OrderManager].[dbo].[Tracking] AS TRK2 (NOLOCK) WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS [TrackingNum], O.[ProductTotal], O.[TaxTotal], O.[ShippingTotal], O.[GrandTotal], O.[NumItems], O.[Shipping], O.[Discount], O.[RevisedDiscount], O.[FinalProductTotal], O.[FinalTaxTotal], O.[FinalShippingTotal], O.[FinalGrandTotal], O.[BalanceDue], OD.ItemNumber
		FROM [OrderManager].[dbo].[Orders] AS O (NOLOCK)
			--LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] AS TRK ON (O.[OrderNumber] = TRK.[NumericKey])
			LEFT OUTER JOIN [OrderManager].[dbo].[Order Details] AS OD WITH(NOLOCK) ON (O.[OrderNumber] = OD.[OrderNumber])
			LEFT OUTER JOIN [OrderManager].[dbo].[Customers] AS CUST WITH(NOLOCK) ON (O.CustomerID = CUST.[CustomerID])
		WHERE O.[Approved] = '1'
			AND O.[Cancelled] = '0'
			AND O.[BalanceDue] > '1.00'
			AND OD.Adjustment = '0'
			--AND TRK.[TrackingID] IS NOT NULL
			AND O.CustomerID = @CustomerID
			-- AND O.OrderNumber IN ( 6456042 )
			AND (SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 WITH(NOLOCK) WHERE TRK2.NumericKey = O.OrderNumber) BETWEEN '2015-01-01 00:00' AND GETDATE()-181
		ORDER BY 'ShipDate' ASC, O.OrderDate ASC, OD.ItemNumber ASC

	SELECT * FROM #TMP_StatementByShipDate 
	GROUP BY CustomerID,OrderNumber,OrderSource,OrderReference,PONumber,ShipDate,OrderDate,SKU, WebSKU,[Product],[QuantityShipped],[PricePerUnit],LineTotal,STATEMENTDAY,FullName,Company,[Address],Address2,City,[State],Zip,Country,Phone,Phone2,Email,ShipName,ShipCompany,ShipAddress,ShipAddress2,ShipCity,ShipState,ShipZip,ShipCountry,ShipPhone,OrderStatus,TrackingNum,ProductTotal, TaxTotal, ShippingTotal, GrandTotal, NumItems, Shipping, Discount, RevisedDiscount, FinalProductTotal, FinalTaxTotal, FinalShippingTotal, FinalGrandTotal, BalanceDue, ItemNumber
	ORDER BY ShipDate ASC, OrderNumber ASC, ItemNumber ASC

END



go

