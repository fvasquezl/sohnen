-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 3-8-2016
-- Description:	Get SKU from CatalogID
-- =============================================
CREATE FUNCTION [dbo].[fn_GetSKUfromCustomerSpecificMapping] 
(
	-- Add the parameters for the function here
	@pCustomerSKU nvarchar(50),@pCustomerID int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	DECLARE @tmpTableResults TABLE([CatalogID] NVARCHAR(MAX),[MITSKU] INT)

--Generic Housing
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-G', PJD.[EncSKU] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[EncSKU] IS NOT NULL AND PJD.[EncSKU] != '-'

--Philips Housing
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-OP', PJD.[EncSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[EncSKUPH] IS NOT NULL AND PJD.[EncSKUPH] != '-'

--Osram Housing
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-OO', PJD.[EncSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[EncSKUOS] IS NOT NULL AND PJD.[EncSKUOS] != '-'

--PhoenixHousing
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-OX', PJD.[EncSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[EncSKUPX] IS NOT NULL AND PJD.[EncSKUPX] != '-'

--Ushio Housing
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-OU', PJD.[EncSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[EncSKUUSH] IS NOT NULL AND PJD.[EncSKUUSH] != '-'

--OEM Housing
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-OE', PJD.[EncSKUOEM] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[EncSKUOEM] IS NOT NULL AND PJD.[EncSKUOEM] != '-'

--Generic Bare
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-BG', PJD.[BareSKU] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[BareSKU] IS NOT NULL AND PJD.[BareSKU] != '-'

--Philips Bare
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-BOP', PJD.[BareSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[BareSKUPH] IS NOT NULL AND PJD.[BareSKUPH] != '-'

--Osram Bare
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-BOO', PJD.[BareSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[BareSKUOS] IS NOT NULL AND PJD.[BareSKUOS] != '-'

--Phoenix Bare
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-BOX', PJD.[BareSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[BareSKUPX] IS NOT NULL AND PJD.[BareSKUPX] != '-'

--Ushio Bare
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-BOU', PJD.[BareSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[BareSKUUSH] IS NOT NULL AND PJD.[BareSKUUSH] != '-'

--OEM Bare
	INSERT INTO @tmpTableResults ([CatalogID],[MITSKU])
	SELECT PJD.[CatalogID]+'-BOE', PJD.[BareSKUOEM] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[BareSKUOEM] IS NOT NULL AND PJD.[BareSKUOEM] != '-'



	-- Add the T-SQL statements to compute the return value here
	SELECT TOP(1) @Result = (CASE WHEN LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),1) < 4 THEN
						(SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU) 
						
				  WHEN LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),1) > 4 THEN
						
						(SELECT TOP(1) [MITSKU] FROM @tmpTableResults WHERE [CatalogID] = (SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU))

						/**
						(CASE	
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),2) = '-G' THEN (SELECT PJD.[EncSKU] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),3) = '-OP' THEN (SELECT PJD.[EncSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),3) = '-OO' THEN (SELECT PJD.[EncSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),3) = '-OX' THEN (SELECT PJD.[EncSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),3) = '-OU' THEN (SELECT PJD.[EncSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),3) = '-BG' THEN (SELECT PJD.[BareSKU] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),4) = '-BOP' THEN (SELECT PJD.[BareSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),4) = '-BOO' THEN (SELECT PJD.[BareSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),4) = '-BOX' THEN (SELECT PJD.[BareSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								WHEN RIGHT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),4) = '-BOU' THEN (SELECT PJD.[BareSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT((SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU),5))
								ELSE (SELECT TOP(1) CSSKUM.MITSKU FROM Inventory.dbo.CustomerSpecificSKUMapping AS CSSKUM WHERE CSSKUM.CustomerID = @pCustomerID AND CSSKUM.CustomerSKU = @pCustomerSKU) 
						 END)
						 **/
					ELSE 
						'999999'
					END)
	-- Return the result of the function
	RETURN @Result

END
go

