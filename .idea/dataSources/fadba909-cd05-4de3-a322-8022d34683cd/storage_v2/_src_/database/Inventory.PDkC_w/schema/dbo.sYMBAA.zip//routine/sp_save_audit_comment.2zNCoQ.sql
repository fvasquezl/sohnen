-- =============================================
-- Author:		Luis Bautista
-- Create date: 2013-FEB-14
-- Description:	Insert (if not exist) or Update a comment asigned to an adjustment
-- =============================================
CREATE PROCEDURE [dbo].[sp_save_audit_comment]
	@pAdjustmentID INT = 0
	,@pComment varchar(100) = ''
AS
BEGIN
	
	SET NOCOUNT ON;
	DECLARE @lexist INT ;
	SET @lexist = 0;
	
    -- Insert statements for procedure here
	SET @lexist =  (SELECT count(id) FROM InventoryAdjustmentsExtras WHERE InventoryAdjustmentID =  @pAdjustmentID);
	
	IF @lexist > 0
	BEGIN
		UPDATE InventoryAdjustmentsExtras SET Comment = @pComment WHERE InventoryAdjustmentID =  @padjustmentID;
	END 
	ELSE
	BEGIN
		
		INSERT INTO InventoryAdjustmentsExtras(InventoryAdjustmentID, Comment) VALUES (@pAdjustmentID, @pComment);
	END
	
	SELECT * from InventoryAdjustmentsExtras WHERE InventoryAdjustmentID =  @pAdjustmentID;
END
go

