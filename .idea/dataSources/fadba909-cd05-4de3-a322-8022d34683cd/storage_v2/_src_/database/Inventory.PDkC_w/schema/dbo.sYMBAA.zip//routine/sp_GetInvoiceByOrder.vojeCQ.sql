
-- ==========================================================================================
-- Author:		Santos Escobar
-- Create date: 2016-03-14
-- Description:	Retrieves an order detail to generate an invoice.
-- ==========================================================================================
CREATE PROCEDURE [dbo].[sp_GetInvoiceByOrder] @OrderNumber INT
AS
BEGIN
-- START PROCEDURE BODY

	DECLARE @IndexMin INT, @IndexMax INT
	SET NOCOUNT ON;

	DECLARE @TMP_StatementByShipDate TABLE (CustomerID INT,
		OrderNumber			INT,
		OrderSource			NVARCHAR(2),
		OrderReference		NVARCHAR(255),
		PONumber			NVARCHAR(50),
		ShipDate			NVARCHAR(10),
		OrderDate			NVARCHAR(10),
		SKU					NVARCHAR(100),
		WebSKU				NVARCHAR(255),
		Product				NVARCHAR(255),
		QuantityShipped		INT,
		PricePerUnit		DECIMAL(13,2),
		LineTotal			DECIMAL(13,2),
		STATEMENTDAY		INT,
		FullName			NVARCHAR(255),
		Company				NVARCHAR(255),
		Address				NVARCHAR(255),
		Address2			NVARCHAR(255),
		City				NVARCHAR(255),
		State				NVARCHAR(255),
		Zip					NVARCHAR(255),
		Country				NVARCHAR(255),
		Phone				NVARCHAR(50),
		Phone2				NVARCHAR(50),
		Email				NVARCHAR(255),
		ShipName			NVARCHAR(255),
		ShipCompany			NVARCHAR(255),
		ShipAddress			NVARCHAR(255),
		ShipAddress2		NVARCHAR(255),
		ShipCity			NVARCHAR(255),
		ShipState			NVARCHAR(255),
		ShipZip				NVARCHAR(255),
		ShipCountry			NVARCHAR(255),
		ShipPhone			NVARCHAR(255),
		OrderStatus			NVARCHAR(50),
		TrackingNum			NVARCHAR(50),
		[ProductTotal]		DECIMAL(13,2),
		[TaxTotal]			DECIMAL(13,2),
		[ShippingTotal]		DECIMAL(13,2),
		[GrandTotal]		DECIMAL(13,2),
		[NumItems]			INT,
		[Shipping]			NVARCHAR(150),
		[Discount]			DECIMAL(13,2),
		[RevisedDiscount]	DECIMAL(13,2),
		[FinalProductTotal]	DECIMAL(13,2),
		[FinalTaxTotal]		DECIMAL(13,2),
		[FinalShippingTotal]DECIMAL(13,2),
		[FinalGrandTotal]	DECIMAL(13,2),
		[BalanceDue]		DECIMAL(13,2),
		ItemNumber			INT
	)

	SET @IndexMin = 0
	SET @IndexMax = 30
	
	INSERT INTO @TMP_StatementByShipDate (CustomerID,OrderNumber,OrderSource,OrderReference,PONumber,ShipDate,OrderDate,SKU, WebSKU,[Product],[QuantityShipped],[PricePerUnit],LineTotal,STATEMENTDAY,FullName,
			Company,Address,Address2,City,State,Zip,Country,Phone,Phone2,Email,ShipName,ShipCompany,ShipAddress,ShipAddress2,ShipCity,ShipState,ShipZip,ShipCountry,ShipPhone,OrderStatus,TrackingNum,
			ProductTotal, TaxTotal, ShippingTotal, GrandTotal, NumItems, Shipping, Discount, RevisedDiscount, FinalProductTotal, FinalTaxTotal, FinalShippingTotal, FinalGrandTotal, BalanceDue, ItemNumber)
		SELECT O.CustomerID, O.[OrderNumber]
			, O.[OrderSource]
			, (CASE WHEN IsNull(O.[SourceOrderID],'') = '' THEN IsNull(CAST(O.[SourceOrderNumber] AS NVARCHAR(MAX)),'') ELSE IsNull(O.[SourceOrderID],'') END) AS 'OrderReference'
			, IsNull(O.[PONumber],'') AS 'PONumber'
			, CAST((SELECT TOP(1) TRK2.[DateAdded] FROM [OrderManager].[dbo].[Tracking] AS TRK2 WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS DATE) AS 'ShipDate'
			, CAST(O.[OrderDate] AS date) AS 'OrderDate'
			, (CASE WHEN OD.[Option01] IS NOT NULL AND OD.[Option01] != '' THEN OD.[Option01] ELSE OD.[SKU] END) AS 'SKU'
			,  od.WebSKU
			, OD.[Product]
			, OD.[QuantityShipped]
			, OD.[PricePerUnit]
			, (OD.[QuantityShipped]*OD.[PricePerUnit]) AS 'LineTotal'
			, @IndexMax

			, CUST.[FullName] , CUST.[Company], CUST.[Address], CUST.[Address2], CUST.[City], CUST.[State], CUST.[Zip], CUST.[Country], CUST.[Phone], CUST.[Phone2] , CUST.[Email]

			, O.[ShipName]
			, O.[ShipCompany]
			, O.[ShipAddress]
			, ISNULL(O.[ShipAddress2], '') [ShipAddress2]
			, O.[ShipCity]
			, O.[ShipState]
			, O.[ShipZip]
			, O.[ShipCountry]
			, O.[ShipPhone]
			, O.[OrderStatus]
			, (SELECT TOP(1) TRK2.[TrackingID] FROM [OrderManager].[dbo].[Tracking] AS TRK2 WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS [TrackingNum]
			, O.[ProductTotal]
			, O.[TaxTotal]
			, O.[ShippingTotal]
			, O.[GrandTotal]
			, O.[NumItems]
			, O.[Shipping]
			, O.[Discount]
			, O.[RevisedDiscount]
			, O.[FinalProductTotal]
			, O.[FinalTaxTotal]
			, O.[FinalShippingTotal]
			, O.[FinalGrandTotal]
			, O.[BalanceDue]
			, OD.ItemNumber
		FROM [OrderManager].[dbo].[Orders] AS O
		LEFT OUTER JOIN [OrderManager].[dbo].[Order Details] AS OD ON (O.[OrderNumber] = OD.[OrderNumber])
		LEFT OUTER JOIN [OrderManager].[dbo].[Customers] AS CUST ON (O.CustomerID = CUST.[CustomerID])
		WHERE O.[Approved] = '1'
		AND O.[Cancelled] = '0'
		--AND O.[BalanceDue] > '1.00'
		AND OD.Adjustment = '0'
		AND O.OrderNumber = @OrderNumber
		AND (SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 WHERE TRK2.NumericKey = O.OrderNumber) BETWEEN GETDATE() - @IndexMax AND GETDATE() - @IndexMin
		ORDER BY [ShipDate] ASC, O.[OrderNumber] ASC, OD.ItemNumber ASC

	SELECT * 
	FROM @TMP_StatementByShipDate 
	GROUP BY
		CustomerID,OrderNumber,OrderSource,OrderReference,PONumber,ShipDate,OrderDate,SKU, WebSKU,[Product],[QuantityShipped],[PricePerUnit],LineTotal,STATEMENTDAY,FullName,
		Company,[Address],Address2,City,[State],Zip,Country,Phone,Phone2,Email,ShipName,ShipCompany,ShipAddress,ShipAddress2,ShipCity,ShipState,ShipZip,ShipCountry,ShipPhone,OrderStatus,TrackingNum,
		ProductTotal, TaxTotal, ShippingTotal, GrandTotal, NumItems, Shipping, Discount, RevisedDiscount, FinalProductTotal, FinalTaxTotal, FinalShippingTotal, FinalGrandTotal, BalanceDue, ItemNumber
		ORDER BY [ShipDate] ASC, [OrderNumber] ASC, ItemNumber ASC
-- END PROCEDURE BODY
END
go

