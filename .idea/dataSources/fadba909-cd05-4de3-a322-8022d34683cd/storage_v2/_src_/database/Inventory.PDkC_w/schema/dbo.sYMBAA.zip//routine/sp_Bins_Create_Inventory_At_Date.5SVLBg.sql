-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-07-18
-- Description:	Get Min Unit Cost by supplier
-- =============================================
CREATE PROCEDURE [dbo].[sp_Bins_Create_Inventory_At_Date]
@pDate datetime,-- @pStart int, @pEnd int
@SEARCH NVARCHAR(255), @Category INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--DECLARE @Bin_id varchar(10);
--DECLARE @qty int;
--DECLARE @flow int;
--DECLARE @id int;
DECLARE @name varchar(254);
DECLARE	@categoryId int;
DECLARE @categoryName varchar(50);
DECLARE @us_qty_in int;
DECLARE @mx_qty_in int;
DECLARE @df_qty_in int;
DECLARE @tr_qty_in int;
DECLARE @TOTAL_qty_in int;

DECLARE @us_qty_out int;
DECLARE @mx_qty_out int;
DECLARE @df_qty_out int;
DECLARE @tr_qty_out int;
DECLARE @TOTAL_qty_out int;
DECLARE @ProductCatalogId int;

--DECLARE @totalqtyin int;


--DECLARE @start int;
--DECLARE @end int;

CREATE TABLE #InventoryAtDate (--id int
							--, 
							ProductCatalogId INT
							, name varchar(254)
							, categoryId int
							, CategoryName varchar(50)
							, US_Stock int
							, MX_Stock int
							, Defective_Stock int
							, Transit_Stock int
							, Total_Stock int
							, Unique_Cost int
							, Total_Amount int
							);

CREATE CLUSTERED INDEX IDX_InventoryAtDate ON #InventoryAtDate(ProductCatalogId)

--INSERT INTO @InventoryAtDate( id, ProductCatalogId ,name, categoryId) 
--SELECT * FROM (

--					SELECT   ROW_NUMBER() OVER (ORDER BY ID asc) AS RowNumber, id, name,categoryid
							
--                    FROM  [Inventory].[dbo].[ProductCatalog] (NOLOCK)
                                 
       
--                 ) as mytable
--				WHERE mytable.RowNumber between  @pStart and @pEnd;



 
UPDATE Inventory.dbo.Bins_History SET WarehouseID = Inventory.dbo.fn_Get_Bin_WarehouseID(Bin_Id) WHERE WarehouseID is null;


--SELECT ID, Name, CategoryID, inventory.dbo.fn_GetCategoryName(CategoryID) AS CategoryName, US_Stock, MX_Stock, Defective_Stock, Transit_Stock, Total_Stock, Inventory.dbo.fn_GetUnitCostBySupplier(ID) AS UnitCost
--FROM (
	INSERT INTO #InventoryAtDate( ProductCatalogId ,name, categoryId, US_Stock, MX_Stock, Defective_Stock, Transit_Stock, Total_Stock, Unique_Cost, Total_Amount) 
	SELECT PC.ID, PC.Name, PC.CategoryID,
		SUM(CASE WHEN B.WarehouseID = 'US' THEN ISNULL(BC.Counter,0) ELSE 0 END),
		SUM(CASE WHEN B.WarehouseID = 'MX' THEN ISNULL(BC.Counter,0) ELSE 0 END),
		SUM(CASE WHEN B.WarehouseID = 'DF' THEN ISNULL(BC.Counter,0) ELSE 0 END),
		SUM(CASE WHEN B.WarehouseID = 'TR' THEN ISNULL(BC.Counter,0) ELSE 0 END),
		SUM(ISNULL(BC.Counter,0)),
		SUM(ISNULL(BC.Counter,0)),
		SUM(ISNULL(BC.Counter,0))

	FROM Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	LEFT OUTER JOIN Inventory.dbo.Bin_Content BC WITH(NOLOCK)
	ON PC.ID = BC.ProductCatalog_Id
	LEFT OUTER JOIN Inventory.dbo.Bins B WITH(NOLOCK)
	ON B.Bin_Id = BC.Bin_Id AND B.Active = 1
	GROUP BY PC.ID, PC.Name, PC.CategoryID--, inventory.dbo.fn_GetCategoryName(PC.CategoryID)
--) TBL
--ORDER BY ID

DECLARE curhistory CURSOR
	FOR SELECT ProductCatalogId 	, name	, categoryId, inventory.dbo.fn_GetCategoryName(categoryId) FROM #InventoryAtDate;
OPEN curhistory

FETCH NEXT FROM curhistory
INTO  @ProductCatalogId 	, @name	, @categoryId, @categoryname;


WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT(@ProductCatalogId)
		SELECT @us_qty_in =	 SUM(CASE WHEN (Flow =1) AND (WarehouseId = 'US') THEN a.Qty ELSE 0 END	)
			   ,@mx_qty_in = SUM(CASE WHEN (Flow =1) AND (WarehouseId = 'MX') THEN a.Qty ELSE 0 END	)
			   ,@df_qty_in = SUM(CASE WHEN (Flow =1) AND (WarehouseId = 'DF') THEN a.Qty ELSE 0 END	)
			   ,@tr_qty_in = SUM(CASE WHEN (Flow =1) AND (WarehouseId = 'TR') THEN a.Qty ELSE 0 END	)
			   ,@TOTAL_qty_in = SUM(CASE WHEN (Flow =1)  THEN a.Qty ELSE 0 END	)

			   ,@us_qty_out = SUM(CASE WHEN (Flow =2) AND (WarehouseId = 'US') THEN a.Qty ELSE 0 END	)
			   ,@mx_qty_out = SUM(CASE WHEN (Flow =2) AND (WarehouseId = 'MX') THEN a.Qty ELSE 0 END	)
			   ,@df_qty_out = SUM(CASE WHEN (Flow =2) AND (WarehouseId = 'DF') THEN a.Qty ELSE 0 END	)
			   ,@tr_qty_out = SUM(CASE WHEN (Flow =2) AND (WarehouseId = 'TR') THEN a.Qty ELSE 0 END	)
			   ,@TOTAL_qty_out = SUM(CASE WHEN (Flow =2)  THEN a.Qty ELSE 0 END	)
		FROM Bins_History a WITH(NOLOCK)
		 WHERE (Product_Catalog_ID = @ProductCatalogId) AND (stamp <= @pDate) ;


		 IF  @us_qty_in is null SET  @us_qty_in = 0;
		 IF  @mx_qty_in is null SET  @mx_qty_in = 0;
		 IF  @tr_qty_in is null SET  @tr_qty_in = 0;
		 IF  @df_qty_in is null SET  @df_qty_in = 0;
		 IF  @TOTAL_qty_in is null SET  @TOTAL_qty_in = 0;

		 IF  @us_qty_out is null SET  @us_qty_out = 0;
		 IF  @mx_qty_out is null SET  @mx_qty_out = 0;
		 IF  @tr_qty_out is null SET  @tr_qty_out = 0;
		 IF  @df_qty_out is null SET  @df_qty_out = 0;
		 IF  @TOTAL_qty_out is null SET  @TOTAL_qty_out = 0;
  
	     UPDATE  #InventoryAtDate SET 
							CategoryName = @categoryname
							, US_Stock = @us_qty_in - @us_qty_out
							, MX_Stock = @mx_qty_in - @mx_qty_out
							, Defective_Stock = @df_qty_in - @df_qty_out
							, Transit_Stock =@tr_qty_in - @tr_qty_out 
							, Total_Stock = @TOTAL_qty_in - @Total_qty_out 
							, Unique_Cost = @TOTAL_qty_in - @Total_qty_out
							, Total_Amount = @TOTAL_qty_in - @Total_qty_out
			WHERE ProductCatalogId = @ProductCatalogId;
	

		FETCH NEXT FROM curhistory
			INTO  @ProductCatalogId 	, @name	, @categoryId, @categoryname;

END 
CLOSE curhistory;
DEALLOCATE curhistory;


SELECT IAD.ProductCatalogId, IAD.name, IAD.categoryId, IAD.CategoryName, IAD.US_Stock, IAD.MX_Stock, IAD.Defective_Stock, IAD.Transit_Stock, IAD.Total_Stock, Inventory.dbo.fn_GetUnitCostBySupplier(IAD.ProductCatalogId) AS UnitCost, Total_Amount
FROM #InventoryAtDate IAD
WHERE CONVERT(NVARCHAR,IAD.categoryId) LIKE (CASE WHEN @Category = 0 THEN '%' ELSE CONVERT(NVARCHAR,@Category) END)
AND 
( IAD.ProductCatalogId LIKE '%' + @SEARCH + '%' OR IAD.name LIKE '%' + @SEARCH + '%' OR inventory.dbo.fn_GetCategoryName(IAD.categoryId) LIKE '%' + @SEARCH + '%' )
ORDER BY IAD.ProductCatalogId

END
go

