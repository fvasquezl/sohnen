-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-07-18
-- Description:	Get Supplier Lowest Unit Cost by SKU
-- =============================================
CREATE FUNCTION [dbo].[fn_GetUnitCostBySupplier]
(
	@SKU INT
)
RETURNS DECIMAL(13,4)
AS
BEGIN
	DECLARE @UnitCost DECIMAL(13,4)

	SET @UnitCost = ISNULL((SELECT TOP 1 MIN([UnitCost]) FROM [Inventory].[dbo].[Suppliers] WITH(NOLOCK) WHERE ProductCatalogId = @SKU AND [UnitCost] > 0),0)

	-- Return the result of the function
	RETURN @UnitCost

END
go

