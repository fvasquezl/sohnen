-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 5-3-2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonSparcInvFeed] 


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		/*********************************************************************************************************************************/
		/*****************************NOW PROCEEDING TO UPDATE QUANTITIES ON AMAZON FOR ALL LISTINGS**************************************/
		/********************************************************SEPARATE TO DIFFERENT JOB************************************************/
		/*********************************************************************************************************************************/
		DECLARE @selectstatementinv AS NVARCHAR(MAX)
		DECLARE @cmdinv AS VARCHAR(2000)


		/**
		/*************FBM****************/
		--***NEW*** 
		SET @selectstatementinv = 'SELECT row_number() OVER (Order by SPR.[item_sku]) AS MessageID, ''Update'' AS OperationType, SPR.[item_sku] AS ''Inventory/SKU'', FLOOR(IsNull(GS.[TotalStock],0)*0.7) AS ''Inventory/Quantity'', ''1'' AS ''Inventory/FulfillmentLatency'', ''MFN'' AS ''Inventory/SwitchFulfillmentTo'' FROM [Inventory].[dbo].[AmazonSparc] AS SPR LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (SPR.[MITSKU] = GS.[ProductCatalogId]) WHERE SPR.[MITSKU] != '''' OR SPR.[MITSKU] IS NOT NULL FOR XML PATH(''Message'')'
		SET @cmdinv = 'bcp "' + @selectstatementinv + '" queryout "C:\sharedb\AmazonAPI\Sparc\spcbody-inv.xml" -SMITSQL -Usa -PZ91bM473 -c -x -r'
		EXEC master..xp_cmdshell @cmdinv

		EXEC master..xp_CMDShell 'c:\sharedb\AmazonAPI\Sparc\spcsendinv.bat'
		**/


		/**
		----------------------
		/*************FBA CONVERT****************/	
		SET @selectstatementinv = 'SELECT row_number() OVER (Order by SPR.[item_sku]) AS MessageID, ''Update'' AS OperationType, SPR.[item_sku] AS ''Inventory/SKU'', ''AMAZON_NA'' AS ''Inventory/FulfillmentCenterID'',''FulfillmentNetwork'' AS ''Inventory/Lookup'', ''AFN'' AS ''Inventory/SwitchFulfillmentTo'' FROM [Inventory].[dbo].[AmazonSparc] AS SPR FOR XML PATH(''Message'')'
		SET @cmdinv = 'bcp "' + @selectstatementinv + '" queryout "C:\sharedb\AmazonAPI\Sparc\spcbody-inv.xml" -SMITSQL -Usa -PZ91bM473 -c -x -r'
		EXEC master..xp_cmdshell @cmdinv

		EXEC master..xp_CMDShell 'c:\sharedb\AmazonAPI\Sparc\spcsendinv.bat'
		**/


END
go

