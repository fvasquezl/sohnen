-- =============================================
-- Author:		Luis Batista
-- Create date: JUL 14 2014
-- Description:	SKU history in bins
-- =============================================
CREATE PROCEDURE [dbo].[sp_Bins_History]
	 @pSku as Integer, @pDate1 as date = '1900-01-01', @pDate2 as date = '1900-01-01'
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE @i int;
	DECLARE @numrows int;
	DECLARE @maxid int;
	DECLARE @currentvalue real;
	DECLARE @qty int;
	DECLARE @flow int;
	DECLARE @reason varchar(10);
	DECLARE @Bin_Id varchar(10);
	DECLARE @inputs int;
	DECLARE @outputs int;
    
    DECLARE @history TABLE (id int Primary Key IDENTITY(1,1)
									, TransactionId int
									, mydate date
									, Bin_Id varchar(6)
									, Reason varchar(10)
									, flow int
									, quantity int
									, inputs int
									, outputs int
									, globalqty int
									, comments varchar(250)
									, Userid int
									);


INSERT INTO @history (TransactionId, mydate, Bin_Id
											, Reason, flow, quantity,  inputs, outputs
											, comments, userid)
							SELECT a.id
									, a.Stamp as mydate
									, a.Bin_Id
									, a.ScanCode
									, a.flow
									, a.Qty
									,CASE a.flow 
										WHEN 1 THEN a.Qty 
										ELSE 0
										END as inputs
									,CASE a.flow 
										WHEN 2 THEN a.Qty
										ELSE 0
										END as outputs
									, a.comments
									, a.User_Id
									
							FROM Inventory.dbo.Bins_History a (NOLOCK)
								WHERE (a.Product_Catalog_ID = @pSKU)
							ORDER BY a.Stamp ;
							
		-- Make th current qty column
		
		SET @currentvalue = 0;
	

		SET @i = 1;
		SET @numrows = (SELECT COUNT(*) FROM @history);
		SET @maxid =(SELECT MAX(id) FROM @history);
		
		IF @numrows > 0

				WHILE (@i <= @maxid)
				BEGIN

						SELECT @Bin_Id = Bin_Id, @reason = Reason, @flow = flow, @qty = quantity 
						FROM @history WHERE id = @i;
        
						IF @flow = 1
						BEGIN
									SET @currentvalue = @currentvalue + @qty;
									SET @inputs = @qty; 
									SET @outputs = 0;
						END
        
						IF @flow = 2
						BEGIN
									SET @currentvalue = @currentvalue - @qty;
									SET @inputs = 0; 
									SET @outputs = @qty;
						END
						
						
    
											

						UPDATE @history SET globalqty = @currentvalue 
											,inputs = @inputs
											,outputs = @outputs
						where id = @i;
						-- increment counter for next employee
						SET @i = @i + 1
        
        
		END /* If num rows > 0*/
	IF (@pDate1 <> '1900-01-01') and ( @pDate2  <> '1900-01-01') 
		BEGIN
				SELECT id, TransactionId, mydate, Bin_Id
					,Inventory.dbo.fn_All_List_ListDisplay(reason) as Reason
					,  inputs,outputs,globalqty 
					, inventory.dbo.fn_GetUserName(userid) as username
					, comments
				FROM 	@history
				WHERE  mydate between  @pDate1  and  @pDate2 
				ORDER By id desc  ;						

		END
	ELSE
		BEGIN
					SELECT id, TransactionId, mydate, Bin_Id
							,Inventory.dbo.fn_All_List_ListDisplay(reason) as Reason
							,  inputs,outputs,globalqty 
							, inventory.dbo.fn_GetUserName(userid) as username
							, comments
					FROM 	@history
					ORDER By id desc  ;						
		END

	
							

END


go

