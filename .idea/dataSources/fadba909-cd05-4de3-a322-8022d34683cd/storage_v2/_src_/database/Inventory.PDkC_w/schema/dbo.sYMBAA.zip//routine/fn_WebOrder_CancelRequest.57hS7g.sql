-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_WebOrder_CancelRequest]
(
	@pWebOrder nvarchar(50)--int	
)
RETURNS int	
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar int;

	
	SELECT @ResultVar = CancelRequest FROM [Inventory].[dbo].[ResellerPortalOrder] WHERE CONVERT(NVARCHAR,WebOrderNumber) = @pWebOrder;

	
	-- Return the result of the function
	RETURN @ResultVar;

END
go

