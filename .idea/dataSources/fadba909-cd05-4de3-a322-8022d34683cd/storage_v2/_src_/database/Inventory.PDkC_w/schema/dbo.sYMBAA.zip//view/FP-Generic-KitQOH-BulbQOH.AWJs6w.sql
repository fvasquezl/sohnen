/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.[FP-Generic-KitQOH-BulbQOH]
AS
SELECT DISTINCT TOP (100) PERCENT AD.ProductCatalogID, PCMAIN.Name, CAST(GSMAIN.GlobalStock AS INT) AS QOH, CAST(GSMAIN.VirtualStock AS INT) AS vQOH, CAST(GSMAIN.TotalStock AS INT) AS tQOH,
                             (SELECT        TOP (1) ADKIT.SubSKU
                               FROM            dbo.AssemblyDetails AS ADKIT WITH (NOLOCK) LEFT OUTER JOIN
                                                         dbo.ProductCatalog AS PCKIT WITH (NOLOCK) ON ADKIT.SubSKU = PCKIT.ID
                               WHERE        (ADKIT.ProductCatalogID = AD.ProductCatalogID) AND (PCKIT.CategoryID IN ('60'))) AS KITSKU, CAST
                             ((SELECT        TOP (1) GlobalStock
                                 FROM            dbo.Global_Stocks AS GSKIT WITH (NOLOCK)
                                 WHERE        (ProductCatalogId =
                                                              (SELECT        TOP (1) ADKIT.SubSKU
                                                                FROM            dbo.AssemblyDetails AS ADKIT WITH (NOLOCK) LEFT OUTER JOIN
                                                                                          dbo.ProductCatalog AS PCKIT WITH (NOLOCK) ON ADKIT.SubSKU = PCKIT.ID
                                                                WHERE        (ADKIT.ProductCatalogID = AD.ProductCatalogID) AND (PCKIT.CategoryID IN ('60'))))) AS INT) AS KITQOH, CAST
                             ((SELECT        TOP (1) VirtualStock
                                 FROM            dbo.Global_Stocks AS GSKIT WITH (NOLOCK)
                                 WHERE        (ProductCatalogId =
                                                              (SELECT        TOP (1) ADKIT.SubSKU
                                                                FROM            dbo.AssemblyDetails AS ADKIT WITH (NOLOCK) LEFT OUTER JOIN
                                                                                          dbo.ProductCatalog AS PCKIT WITH (NOLOCK) ON ADKIT.SubSKU = PCKIT.ID
                                                                WHERE        (ADKIT.ProductCatalogID = AD.ProductCatalogID) AND (PCKIT.CategoryID IN ('60'))))) AS INT) AS KITvQOH, CAST
                             ((SELECT        TOP (1) TotalStock
                                 FROM            dbo.Global_Stocks AS GSKIT WITH (NOLOCK)
                                 WHERE        (ProductCatalogId =
                                                              (SELECT        TOP (1) ADKIT.SubSKU
                                                                FROM            dbo.AssemblyDetails AS ADKIT WITH (NOLOCK) LEFT OUTER JOIN
                                                                                          dbo.ProductCatalog AS PCKIT WITH (NOLOCK) ON ADKIT.SubSKU = PCKIT.ID
                                                                WHERE        (ADKIT.ProductCatalogID = AD.ProductCatalogID) AND (PCKIT.CategoryID IN ('60'))))) AS INT) AS KITtQOH,
                             (SELECT        TOP (1) ADBULB.SubSKU
                               FROM            dbo.AssemblyDetails AS ADBULB WITH (NOLOCK) LEFT OUTER JOIN
                                                         dbo.ProductCatalog AS PCBULB WITH (NOLOCK) ON ADBULB.SubSKU = PCBULB.ID
                               WHERE        (ADBULB.ProductCatalogID = AD.ProductCatalogID) AND (PCBULB.CategoryID IN ('19'))) AS BULBSKU, CAST
                             ((SELECT        TOP (1) GlobalStock
                                 FROM            dbo.Global_Stocks AS GSBULB WITH (NOLOCK)
                                 WHERE        (ProductCatalogId =
                                                              (SELECT        TOP (1) ADBULB.SubSKU
                                                                FROM            dbo.AssemblyDetails AS ADBULB WITH (NOLOCK) LEFT OUTER JOIN
                                                                                          dbo.ProductCatalog AS PCBULB WITH (NOLOCK) ON ADBULB.SubSKU = PCBULB.ID
                                                                WHERE        (ADBULB.ProductCatalogID = AD.ProductCatalogID) AND (PCBULB.CategoryID IN ('19'))))) AS INT) AS BULBQOH, CAST
                             ((SELECT        TOP (1) VirtualStock
                                 FROM            dbo.Global_Stocks AS GSBULB WITH (NOLOCK)
                                 WHERE        (ProductCatalogId =
                                                              (SELECT        TOP (1) ADBULB.SubSKU
                                                                FROM            dbo.AssemblyDetails AS ADBULB WITH (NOLOCK) LEFT OUTER JOIN
                                                                                          dbo.ProductCatalog AS PCBULB WITH (NOLOCK) ON ADBULB.SubSKU = PCBULB.ID
                                                                WHERE        (ADBULB.ProductCatalogID = AD.ProductCatalogID) AND (PCBULB.CategoryID IN ('19'))))) AS INT) AS BULBvQOH, CAST
                             ((SELECT        TOP (1) TotalStock
                                 FROM            dbo.Global_Stocks AS GSBULB WITH (NOLOCK)
                                 WHERE        (ProductCatalogId =
                                                              (SELECT        TOP (1) ADBULB.SubSKU
                                                                FROM            dbo.AssemblyDetails AS ADBULB WITH (NOLOCK) LEFT OUTER JOIN
                                                                                          dbo.ProductCatalog AS PCBULB WITH (NOLOCK) ON ADBULB.SubSKU = PCBULB.ID
                                                                WHERE        (ADBULB.ProductCatalogID = AD.ProductCatalogID) AND (PCBULB.CategoryID IN ('19'))))) AS INT) AS BULBtQOH
FROM            dbo.AssemblyDetails AS AD WITH (NOLOCK) LEFT OUTER JOIN
                         dbo.ProductCatalog AS PCMAIN WITH (NOLOCK) ON AD.ProductCatalogID = PCMAIN.ID LEFT OUTER JOIN
                         dbo.Global_Stocks AS GSMAIN WITH (NOLOCK) ON AD.ProductCatalogID = GSMAIN.ProductCatalogId
WHERE        (PCMAIN.CategoryID IN ('24'))
ORDER BY AD.ProductCatalogID
go

