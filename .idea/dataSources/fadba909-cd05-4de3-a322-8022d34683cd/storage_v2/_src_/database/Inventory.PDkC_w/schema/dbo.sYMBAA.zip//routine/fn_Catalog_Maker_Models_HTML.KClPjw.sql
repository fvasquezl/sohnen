-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Catalog_Maker_Models_HTML]
(
	@pBrand nvarchar(50), @pPartnumber nvarchar(50)
)
RETURNS varchar(1000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(1000);
	DECLARE @Model varchar(50);
	DECLARE @MaxCols int;
	DECLARE @CurrCol int;
	DECLARE @Exist int;

	DECLARE lcursor CURSOR FOR 
					SELECT CD.[Model]
						FROM [MITDB].[dbo].[ProjectorData] AS PD
						LEFT OUTER JOIN INVENTORY.DBO.CompatibilityDetails AS CD ON (PD.PartNumber = CD.[PartNumber] AND PD.Brand = CD.OriginalManufacturer)
						WHERE (PD.Brand = @pBrand) and (PD.PartNumber = @pPartnumber)
						Order By CD.Model;



	SET @Exist = 0;
	SET @MaxCols = 3;
	SET @CurrCol = 1;
	SET @ResultVar = '';


	SET @ResultVar = @ResultVar + '<TABLE>';
	

	OPEN lcursor
	
	FETCH NEXT FROM lcursor	INTO @Model;



	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Exist = 1;
		IF @CurrCol = 1
		BEGIN
			SET @ResultVar = @ResultVar + '<TR>';
		END
					SET @ResultVar = @ResultVar + '<TD>';
								SET @ResultVar = @ResultVar + @Model;
					SET @ResultVar = @ResultVar + '</TD>';

		SET @CurrCol = @CurrCol + 1;
		IF  @CurrCol > @MaxCols
		BEGIN
			SET @ResultVar = @ResultVar + '</TR>';
			SET @CurrCol = 1;
		END

		FETCH NEXT FROM lcursor	INTO @Model;
	END

	CLOSE lcursor;
	DEALLOCATE lcursor;
	
	IF @Exist = 0
		BEGIN
				SET @ResultVar = @ResultVar + '<TD>Unknowed</TD>';
		END
	ELSE
		BEGIN
				IF @CurrCol <= @MaxCols
					BEGIN
							SET @ResultVar = @ResultVar + '</TR>';
					END
		END

	

	SET @ResultVar = @ResultVar + '</TABLE>';

	-- Return the result of the function
	RETURN @ResultVar;
END
go

