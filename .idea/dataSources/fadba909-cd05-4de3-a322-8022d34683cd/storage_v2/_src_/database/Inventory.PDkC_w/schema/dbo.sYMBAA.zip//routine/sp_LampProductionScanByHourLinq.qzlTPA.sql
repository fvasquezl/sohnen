-- =============================================
-- Author:		Araceli Sánchez
-- Create date: 2016-03-30
-- Description:	Scan By Hour and Between Dates version to linq
-- =============================================
CREATE PROCEDURE [dbo].[sp_LampProductionScanByHourLinq]
	@PROD_DATE	NVARCHAR(8)
AS
BEGIN
	SELECT 
	REPLACE(PROD_LINE,'/','_') LINE
	FROM 
	Inventory.dbo.LampProductionPlan
	WHERE 
	STATUS NOT IN ('F','C') AND 
	PROD_DATE = @PROD_DATE
	GROUP BY PROD_LINE
	ORDER BY PROD_LINE
END
go

