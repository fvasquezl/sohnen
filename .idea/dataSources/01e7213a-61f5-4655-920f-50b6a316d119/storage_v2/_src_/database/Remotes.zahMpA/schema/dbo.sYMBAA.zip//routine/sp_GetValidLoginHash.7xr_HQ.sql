-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-07-18
-- Description:	Valid login by Hash
-- =============================================
CREATE PROCEDURE sp_GetValidLoginHash
	@HASHID NVARCHAR(20)
AS
BEGIN
	DECLARE @SEQ NVARCHAR(3)
	SET NOCOUNT ON;

	SET @SEQ = SUBSTRING(@HASHID,1,3)
	SET @HASHID = SUBSTRING(@HASHID,4,LEN(@HASHID)-2)

    SELECT TOP 1 A.Username, A.Name + ' ' + A.LastName AS UserFullName 
	FROM Remotes.dbo.Account A 
	WHERE (SELECT Item FROM Remotes.dbo.fnSplit(A.Id, '-') WHERE ItemId = 1) = @HASHID AND Deleted = 0 AND Remotes.dbo.fn_Year_Month_Day(DATEPART(YYYY,HashDate),DATEPART(MM,HashDate),DATEPART(DD,HashDate)) = @SEQ
END
go

