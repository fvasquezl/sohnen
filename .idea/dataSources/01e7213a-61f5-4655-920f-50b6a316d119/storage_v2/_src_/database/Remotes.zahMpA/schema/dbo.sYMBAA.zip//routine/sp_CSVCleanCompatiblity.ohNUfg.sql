-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6/5/2018
-- Description:	Clean CSV Compatiblity
-- =============================================
CREATE PROCEDURE [dbo].[sp_CSVCleanCompatiblity] 
	-- Add the parameters for the stored procedure here
	@pList nvarchar(max) = 0, 
	@pCleanType nvarchar(10) = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @tmpListTable TABLE (ID NVARCHAR(MAX), MASTERID NVARCHAR(MAX))
	DECLARE @tmpListTableNoDuplicates TABLE (RESULT NVARCHAR(MAX), MASTERID NVARCHAR(MAX))


	--Will clean also spaces
	IF (@pCleanType = 'CleanType1')
	BEGIN 
	  SET @pList = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@pList,' ',','),'	',','),',,',','),CHAR(00),''),CHAR(01),''),CHAR(02),''),CHAR(03),''),CHAR(04),''),CHAR(05),''),CHAR(09),''),CHAR(10),','),CHAR(13),','),CHAR(20),','), CHAR(31),'')
	  SET @pList = REPLACE(@pLIST,',,',',')

	END;

	--Insert the List into temp table removing duplicates
	--We are using the MASTERID field to fill the items without dash or slash for sorting purposes on the COALESCE return
	INSERT INTO @tmpListTable(ID,MASTERID)
	SELECT DISTINCT LTRIM(RTRIM([Item])), LTRIM(RTRIM(REPLACE(REPLACE([Item],'/',''),'-',''))) FROM [Remotes].[dbo].[fn_SplitItem](@pList)

	--Insert the items with DASHES into the table removing the dashes and duplicates
	INSERT INTO @tmpListTable(ID,MASTERID)
	SELECT DISTINCT LTRIM(RTRIM(REPLACE([Item],'-',''))), LTRIM(RTRIM(REPLACE(REPLACE([Item],'/',''),'-',''))) FROM [Remotes].[dbo].[fn_SplitItem](@pList) WHERE [Item] LIKE '%-%'

	--Insert the items with SLASHES into the table removing the dashes and duplicates
	INSERT INTO @tmpListTable(ID,MASTERID)
	SELECT DISTINCT LTRIM(RTRIM(REPLACE([Item],'/',''))), LTRIM(RTRIM(REPLACE(REPLACE([Item],'/',''),'-',''))) FROM [Remotes].[dbo].[fn_SplitItem](@pList) WHERE [Item] LIKE '%/%'

	--Insert the items with DAHS+SLASHES into the table removing the dashes and duplicates
	INSERT INTO @tmpListTable(ID,MASTERID)
	SELECT DISTINCT LTRIM(RTRIM(REPLACE(REPLACE([Item],'/',''),'-',''))), LTRIM(RTRIM(REPLACE(REPLACE([Item],'/',''),'-',''))) FROM [Remotes].[dbo].[fn_SplitItem](@pList) WHERE [Item] LIKE '%-%' AND [ITEM] LIKE '%/%'

	--Get Distinct List from Table removing duplicates
	INSERT INTO @tmpListTableNoDuplicates ([RESULT],[MASTERID])
	SELECT DISTINCT LTRIM(RTRIM([ID])) AS [RESULT], [MASTERID] FROM @tmpListTable ORDER BY [MASTERID] ASC
	
	--Get Comma Separated Result Nicely Ordered by above query
	DECLARE @List VARCHAR(MAX)
	SELECT @List = COALESCE(@List + ', ','') + CAST(LTRIM(RTRIM([RESULT])) AS VARCHAR)
	FROM   @tmpListTableNoDuplicates ORDER BY [MASTERID] ASC
	
	--RETURN COMMA SEPARATED DATA AND REMOVE BEGININ IF IT STARTS WITH ,
	SELECT 
	CASE WHEN LEFT(@List,1) = ',' THEN
	LTRIM(RTRIM(RIGHT(@List,LEN(@List)-2)))
	ELSE LTRIM(RTRIM(@List)) END AS VARIATIONS,
	COUNT(*) AS TOTAL FROM @tmpListTableNoDuplicates WHERE [RESULT] IS NOT NULL AND [RESULT] != ''
	
	
END
go

