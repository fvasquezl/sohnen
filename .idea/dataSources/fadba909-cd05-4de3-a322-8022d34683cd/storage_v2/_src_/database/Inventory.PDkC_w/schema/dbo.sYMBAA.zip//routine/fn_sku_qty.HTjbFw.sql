-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION fn_sku_qty
(	
	@d1 date, @d2 date, @mtype int
)
RETURNS @temmovs TABLE (sku int, name varchar(100), qty real )
AS
Begin

	insert into @temmovs (sku, qty) 
	Select  b.ProductCatalogID, SUM( b.Quantity)
		fROM Inventory.dbo.InventoryAdjustments a, 
				Inventory.dbo.InventoryAdjustmentDetails b
		Where (a.id = b.InventoryAdjustmentsID)
		and (a.Date between @d1 and @d2)
		and (a.Flow = @mtype)
		group by (b.ProductCatalogID)
		
		update  @temmovs SET name = Inventory.dbo.fn_GetProductName(sku) Where sku > 0
		
	RETURN		

END
go

