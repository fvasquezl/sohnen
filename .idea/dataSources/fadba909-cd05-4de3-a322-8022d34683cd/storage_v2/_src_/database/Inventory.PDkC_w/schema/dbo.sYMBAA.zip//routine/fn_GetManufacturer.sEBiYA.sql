-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_GetManufacturer 
(
	-- Add the parameters for the function here
	@ProductCatalogId as int
)
RETURNS  varchar(100)
AS
BEGIN
	declare @MyManufacturer as varchar(100)
	
	select @MyManufacturer =  a.manufacturer from Inventory.dbo.ProductCatalog a
	where a.ID = @ProductCatalogId
	
	return @MyManufacturer
END
go

