CREATE VIEW dbo.[FP-SKU-Data]
AS
SELECT     dbo.FPPartNumberList.Manufacturer, dbo.FPPartNumberList.PartNumber, dbo.[FP-Philips-SKU].ID AS [PH-EN], 
                      dbo.[FP-COMPATIBLE-SKU].ID AS [AM-EN], dbo.[FP-OSRAM-SKU].ID AS [OS-EN]
FROM         dbo.[FP-OSRAM-SKU] RIGHT OUTER JOIN
                      dbo.FPPartNumberList LEFT OUTER JOIN
                      dbo.ProductCatalog ON dbo.FPPartNumberList.PartNumber = dbo.ProductCatalog.ManufacturerPN LEFT OUTER JOIN
                      dbo.[FP-Philips-SKU] ON dbo.FPPartNumberList.Manufacturer = dbo.[FP-Philips-SKU].Manufacturer AND 
                      dbo.FPPartNumberList.PartNumber = dbo.[FP-Philips-SKU].PartNumber ON 
                      dbo.[FP-OSRAM-SKU].Manufacturer = dbo.FPPartNumberList.Manufacturer AND 
                      dbo.[FP-OSRAM-SKU].PartNumber = dbo.FPPartNumberList.PartNumber LEFT OUTER JOIN
                      dbo.[FP-COMPATIBLE-SKU] ON dbo.FPPartNumberList.Manufacturer = dbo.[FP-COMPATIBLE-SKU].Manufacturer AND 
                      dbo.FPPartNumberList.PartNumber = dbo.[FP-COMPATIBLE-SKU].PartNumber
WHERE     (dbo.ProductCatalog.ProductLineID = 36)
go

