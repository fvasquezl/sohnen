-- =============================================
-- Author:		Luis Batista
-- Create date: JUL 14 2014
-- Description:	SKU history in bins
-- Author:      Hubet Cárdenas Isla
-- Modify date: 2016-06-12
-- Description: Change format date
-- =============================================
CREATE PROCEDURE [dbo].[sp_Bins_History_RPT08]
	 @pSku AS INTEGER,
	 @pDate1 AS DATE = '1900-01-01',
	 @pDate2 AS DATE = '1900-01-01'
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE @i INT;
	DECLARE @numrows INT;
	DECLARE @maxid INT;
	DECLARE @currentvalue real;
	DECLARE @qty INT;
	DECLARE @flow INT;
	DECLARE @reason VARCHAR(10);
	DECLARE @Bin_Id VARCHAR(10);
	DECLARE @inputs INT;
	DECLARE @outputs INT;
    
    DECLARE @history TABLE (id INT PRIMARY KEY IDENTITY(1,1)
					   	   ,TransactionId INT
						   ,mydate DATE
						   ,Bin_Id VARCHAR(6)
						   ,Reason VARCHAR(10)
						   ,flow INT
						   ,quantity INT
						   ,inputs INT
						   ,outputs INT
						   ,globalqty INT
						   ,comments VARCHAR(250)
						   ,Userid INT
						   );

	INSERT INTO @history (TransactionId
						 ,mydate
						 ,Bin_Id
						 ,Reason
						 ,flow
						 ,quantity
						 ,inputs
						 ,outputs
						 ,comments
						 ,userid)
			       SELECT a.id
						 ,a.Stamp AS mydate
						 ,a.Bin_Id
						 ,a.ScanCode
						 ,a.flow
						 ,a.Qty
						 ,CASE a.flow WHEN 1 THEN a.Qty 
							  ELSE 0
						  END AS inputs
						 ,CASE a.flow WHEN 2 THEN a.Qty
							  ELSE 0
						  END AS outputs
						 ,a.comments
						 ,a.User_Id
					 FROM [Inventory].[dbo].[Bins_History] a WITH (NOLOCK)
					WHERE a.Product_Catalog_ID = @pSKU
				    ORDER BY a.Stamp ;
							
	-- Make th current qty column
	SET @currentvalue = 0;
	
	SET @i = 1;
	SET @numrows = (SELECT COUNT(*)
					  FROM @history);
	SET @maxid = (SELECT MAX(id)
				    FROM @history);
	
	IF @numrows > 0
		WHILE (@i <= @maxid)
		BEGIN
			SELECT @Bin_Id = Bin_Id
				  ,@reason = Reason
				  ,@flow = flow
				  ,@qty = quantity 
			  FROM @history
			 WHERE id = @i;
        
			IF @flow = 1
			BEGIN
				SET @currentvalue = @currentvalue + @qty;
				SET @inputs = @qty; 
				SET @outputs = 0;
			END
        
			IF @flow = 2
			BEGIN
				SET @currentvalue = @currentvalue - @qty;
				SET @inputs = 0; 
				SET @outputs = @qty;
			END
						
			UPDATE @history
			   SET globalqty = @currentvalue 
				  ,inputs = @inputs
				  ,outputs = @outputs
			 WHERE id = @i;
			-- increment counter for next employee
			SET @i = @i + 1
		END /* If num rows > 0*/
	
	IF (@pDate1 <> '1900-01-01') AND
	   (@pDate2 <> '1900-01-01') 
	BEGIN
		SELECT id
			  ,TransactionId
			  ,CONVERT(VARCHAR(33), CONVERT(DATETIME, mydate),126) [mydate]
			  ,Bin_Id
			  ,[Inventory].[dbo].[fn_All_List_ListDisplay](reason) AS Reason
			  ,inputs
			  ,outputs
			  ,globalqty 
			  ,[Inventory].[dbo].[fn_GetUserName](userid) AS username
			  ,comments
		  FROM @history
		 WHERE mydate BETWEEN @pDate1 AND @pDate2 
		 ORDER By id DESC;						
	END
	ELSE
	BEGIN
		SELECT id
			  ,TransactionId
			  ,CONVERT(VARCHAR(33), CONVERT(DATETIME, mydate),126) [mydate]
			  ,Bin_Id
			  ,[Inventory].[dbo].[fn_All_List_ListDisplay](reason) AS Reason
			  ,inputs
			  ,outputs
			  ,globalqty 
			  ,[Inventory].[dbo].[fn_GetUserName](userid) AS username
			  ,comments
		  FROM @history
		 ORDER By id DESC;						
	END
END
go

