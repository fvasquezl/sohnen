-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_AmazonAccount_GetName
(
	@pID int
)
RETURNS varchar(50)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(50);

	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = name FROM AmazonAccounts WHERE ID = @pID;

	-- Return the result of the function
	RETURN @ResultVar

END
go

