-- =============================================
-- Author:		Luis Bautista
-- Create date: Jul-01-2014
-- Description:	Run scripst inside a safe transaction
-- =============================================
CREATE PROCEDURE [dbo].[sp_run_script]
	@script as varchar(8000)
AS
BEGIN
	
	DECLARE @lresult int;
	SET NOCOUNT ON;
	
	SET @lresult = 0;


	BEGIN TRY
			EXEC (@script);
			 select 1;
	END TRY
	BEGIN CATCH
    
        IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
	END CATCH;

	IF @@TRANCOUNT > 0
    COMMIT TRANSACTION;
    
   
END
go

