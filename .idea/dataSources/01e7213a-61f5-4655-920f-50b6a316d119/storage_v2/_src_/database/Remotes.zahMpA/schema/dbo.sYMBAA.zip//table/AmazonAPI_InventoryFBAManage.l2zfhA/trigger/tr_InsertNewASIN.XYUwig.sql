-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-07-18
-- Description:	Insert into Inventory ASIN
-- =============================================
CREATE TRIGGER [dbo].[tr_InsertNewASIN]
   ON  [Remotes].[dbo].[AmazonAPI_InventoryFBAManage]
   AFTER INSERT
AS 
BEGIN
	DECLARE @MerchantSKU	NVARCHAR(50),
			@FNSKU			NVARCHAR(50),
			@ASIN			NVARCHAR(50),
			@Title			NVARCHAR(MAX)
	SET NOCOUNT ON;

	SELECT  @MerchantSKU = [sku]
		   ,@FNSKU = [fnsku]
		   ,@ASIN = [asin]
		   ,@Title = [product_name]
	  FROM inserted

	IF(NOT EXISTS(SELECT [ASIN]
				    FROM [Remotes].[dbo].[AmazonAPI_InventoryASIN] WITH(NOLOCK)
				   WHERE [ASIN] = @ASIN
				     AND [MerchantSKU] = @MerchantSKU
					 AND [FNSKU] = @FNSKU))
	BEGIN
		INSERT INTO [Remotes].[dbo].[AmazonAPI_InventoryASIN]([ASIN], [MerchantSKU], [FNSKU], [Title], [ChannelName])
												     VALUES(@ASIN, @MerchantSKU, @FNSKU, @Title, 'Remotes')
	END
	ELSE
	BEGIN
		UPDATE [Remotes].[dbo].[AmazonAPI_InventoryASIN]
		   SET  [isActive] = 1
		       ,[ChannelName] = 'Remotes'
	     WHERE [ASIN] = @ASIN
		   AND [MerchantSKU] = @MerchantSKU
		   AND [FNSKU] = @FNSKU
	END

	--IF(NOT EXISTS(SELECT ASIN FROM [192.168.0.226].[AmazonExclusiveBulbs].[dbo].[InventoryASIN] WITH(NOLOCK) WHERE ASIN = @ASIN AND MerchantSKU = @MerchantSKU AND FNSKU = @FNSKU))
	--BEGIN
	--	INSERT INTO [192.168.0.226].[AmazonExclusiveBulbs].[dbo].[InventoryASIN] (ASIN, MerchantSKU, FNSKU, Title, ChannelName) VALUES (@ASIN, @MerchantSKU, @FNSKU, @Title, 'Remotes')
	--END
	--ELSE
	--BEGIN
	--	UPDATE [192.168.0.226].[AmazonExclusiveBulbs].[dbo].[InventoryASIN] SET isActive = 1, ChannelName = 'Remotes' WHERE ASIN = @ASIN AND MerchantSKU = @MerchantSKU AND FNSKU = @FNSKU
	--END
END
go

