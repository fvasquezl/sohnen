-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-10-2018
-- Description:	Get BoughtsSKU from FNSKU
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSKUFromFNSKU] 
	-- Add the parameters for the stored procedure here
	@pFNSKU NVARCHAR(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	--CLEAN FNSKU
	SET @pFNSKU = REPLACE(REPLACE(REPLACE(REPLACE(@pFNSKU ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'')

	--DECLARE @pFNSKU AS NVARCHAR(MAX)
	--SET @pFNSKU = 'X001P2GSWR'

	DECLARE @SKU NVARCHAR(50)
	DECLARE @TYPE NVARCHAR(10)
	
	SET @SKU = (SELECT MM.[SKU] FROM [Remotes].[dbo].[AmazonAPI_InventoryASIN] AS AZFBA
	LEFT OUTER JOIN [Remotes].[dbo].[MarketplaceMapping] AS MM ON (REPLACE(REPLACE(AZFBA.[MerchantSKU],'RMTC','SKU'),'-CN','') = REPLACE(REPLACE(MM.[merchantsku],'RMTC','SKU'),'-CN',''))
	WHERE AZFBA.[fnsku] = @pFNSKU)

	SET @TYPE = (SELECT (CASE WHEN MM.[IsCN] = 1 AND MM.[Condition] = 'New' THEN 'CN'
		WHEN MM.[IsCN] = 0 AND MM.[Condition] = 'New' THEN 'NEW'
		WHEN MM.[IsCN] = 0 AND MM.[Condition] LIKE '%USED%' THEN 'USED'
		ELSE 'No_Mapping' END) FROM [Remotes].[dbo].[AmazonAPI_InventoryASIN] AS AZFBA
	LEFT OUTER JOIN [Remotes].[dbo].[MarketplaceMapping] AS MM ON (REPLACE(REPLACE(AZFBA.MerchantSKU,'RMTC','SKU'),'-CN','') = REPLACE(REPLACE(MM.[merchantsku],'RMTC','SKU'),'-CN',''))
	WHERE AZFBA.[fnsku] = @pFNSKU)


    SELECT AZFBA.[fnsku] AS [FNSKU]
		,AZFBA.MerchantSKU AS [MerchantSKU]
		,AZFBA.[asin] AS [ASIN]
		,AZFBA.Title AS [Title]
		
		,(CASE WHEN MM.[IsCN] = 1 AND MM.[Condition] = 'New' THEN MM.[SKU]+'-CN'
		WHEN MM.[IsCN] = 0 AND MM.[Condition] = 'New' THEN MM.[SKU]+'-NEW'
		WHEN MM.[IsCN] = 0 AND MM.[Condition] LIKE '%USED%' THEN MM.[SKU]+'-USED'
		ELSE 'No_Mapping' END) AS [SCANSKU]
	  
		,(CASE WHEN @TYPE = 'CN' THEN (SELECT IMG.[URL] FROM [Remotes].[dbo].[Image] AS IMG WHERE IMG.[SKU] = @SKU AND IMG.[name] LIKE '%007.jpg')
		WHEN @TYPE = 'NEW' OR @TYPE = 'USED' THEN (SELECT IMG.[URL] FROM [Remotes].[dbo].[Image] AS IMG WHERE IMG.[SKU] = @SKU AND IMG.[name] LIKE '%001.jpg')
		ELSE (SELECT TOP(1) IMG.[URL] FROM [Remotes].[dbo].[Image] AS IMG WHERE IMG.[SKU] = @SKU ORDER BY [Name] ASC)
		END) AS [Image1]

		,@TYPE AS [Type]

		,IsNull((SELECT stuff((SELECT ', ' + cast([BinID] as varchar(max)) + ' ' + cast([StockQty] as varchar(max)) + ' ' + cast(@TYPE as varchar(max)) FROM [Remotes].[dbo].[BinStock] WHERE [SKU] = @SKU AND [ScanCode] = @TYPE	FOR XML PATH('')), 1, 2, '')),'') AS [BinLocations]
			

	  FROM [Remotes].[dbo].[AmazonAPI_InventoryASIN] AS AZFBA
	LEFT OUTER JOIN [Remotes].[dbo].[MarketplaceMapping] AS MM ON (REPLACE(REPLACE(AZFBA.MerchantSKU,'RMTC','SKU'),'-CN','') = REPLACE(REPLACE(MM.[merchantsku],'RMTC','SKU'),'-CN',''))
	WHERE AZFBA.[fnsku] = @pFNSKU




END

go

