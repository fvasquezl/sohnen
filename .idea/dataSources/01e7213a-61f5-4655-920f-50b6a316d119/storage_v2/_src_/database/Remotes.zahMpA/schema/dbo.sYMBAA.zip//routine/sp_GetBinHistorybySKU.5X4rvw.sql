-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-05-14
-- Description:	Get History SKU
-- =============================================
CREATE PROCEDURE sp_GetBinHistorybySKU
	@SKU NVARCHAR(50),
	@WarehouseID NVARCHAR(2),
	@Search NVARCHAR(200)
AS
BEGIN
	SET NOCOUNT ON;

	SET @Search = '%' + @Search + '%'

    SELECT B.idx, A.Name + ' ' + A.LastName AS UserName, (CASE B.Flow WHEN 1 THEN 'Added' WHEN 2 THEN 'Removed' ELSE '' END) AS Movement, 
		B.SKU, B.Quantity, B.BinID, BC.ScanName AS ScanType, C.ScanName AS Reason, B.Comments, B.CreateDate, M.WarehouseID, M.Location
	FROM Remotes.dbo.BinHistory B WITH(NOLOCK)
	LEFT OUTER JOIN Remotes.dbo.BinCode C WITH(NOLOCK)
	ON C.ScanCode = B.ScanCode
	LEFT OUTER JOIN Remotes.dbo.Account A WITH(NOLOCK)
	ON A.Username = B.CreateUser
	LEFT OUTER JOIN Remotes.dbo.BinMaster M WITH(NOLOCK)
	ON M.BinID = B.BinID
	LEFT OUTER JOIN Remotes.dbo.BinCode BC
	ON BC.ScanCode = B.ScanType
	WHERE B.SKU = @SKU AND ISNULL(M.WarehouseID,'') LIKE @WarehouseID 
	AND (ISNULL(A.Name,'') + ' ' + ISNULL(A.LastName,'') LIKE @Search OR (CASE B.Flow WHEN 1 THEN 'Added' WHEN 2 THEN 'Removed' ELSE '' END) LIKE @Search OR B.BinID LIKE @Search 
		OR ISNULL(C.ScanName,'') LIKE @Search OR B.Comments LIKE @Search OR ISNULL(M.Location,'') LIKE @Search OR ISNULL(BC.ScanName,'') LIKE @Search)
	ORDER BY B.idx DESC
END
go

