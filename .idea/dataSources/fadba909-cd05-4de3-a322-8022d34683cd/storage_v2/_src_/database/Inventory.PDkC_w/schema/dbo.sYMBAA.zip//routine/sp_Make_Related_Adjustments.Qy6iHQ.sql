-- =============================================
-- Author:	Luis Bautista
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE sp_Make_Related_Adjustments
	@pOrigin int, @pDestination int, @pUserid int, @pFlow int, @pOriginalid Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @thisId int;

    -- Insert statements for procedure here
	 INSERT INTO InventoryAdjustments (date, Origin, Destination, UserId, flow, type, Comments, reference ) 
					values (getdate(),@pOrigin, @pDestination, @pUserId, @pFlow,1,'Original id->', @pOriginalid);
                  
     SELECT @thisId=SCOPE_IDENTITY() FROM InventoryAdjustments ;
     
END

go

