-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[UpdateInventoryDataOnInsert]
   ON dbo.SKUData
   AFTER INSERT
AS 
BEGIN

	SET NOCOUNT ON;

    EXECUTE [Remotes].[dbo].[sp_UpdateRemotesDB]

END
go

disable trigger UpdateInventoryDataOnInsert on SKUData
go

