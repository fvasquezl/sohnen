-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_QB_PO]
(
	@sku int
)
RETURNS int
AS
BEGIN
	DECLARE @result int;
	SET @result = 0
	
	SET @result = (select backorders from
						inventory.dbo.QBProductCatalogBackorders
						WHERE  CAST(@sku as nvarchar) = CAST(inventory.dbo.QBProductCatalogBackorders.SKU AS nvarchar));
	

	if @result is null
	BEGIN
		SET @result = 0;
	END
	
	return @result
END
go

