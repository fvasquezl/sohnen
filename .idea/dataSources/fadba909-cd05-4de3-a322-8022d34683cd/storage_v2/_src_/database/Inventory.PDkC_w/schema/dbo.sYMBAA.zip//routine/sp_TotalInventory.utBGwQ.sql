-- =============================================
-- Author:		MI Technologies, Inc. By Luis Alberto Bautista Gallardo
-- Create date:  11/06/2010
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_TotalInventory]
AS
	SELECT a.ProductCatalogID as SKU, Inventory.dbo.fn_GetProductName(a.ProductCatalogID) as ProductName, 
		sum(a.Quantity) as CurrentStock, 
		Inventory.dbo.fn_GetProductMin(a.ProductCatalogID) as StockMin,
		Inventory.dbo.fn_GetProductMax(a.ProductCatalogID) as StockMax
  FROM [Inventory].[dbo].[Inventory] a
  group by ProductCatalogID

go

