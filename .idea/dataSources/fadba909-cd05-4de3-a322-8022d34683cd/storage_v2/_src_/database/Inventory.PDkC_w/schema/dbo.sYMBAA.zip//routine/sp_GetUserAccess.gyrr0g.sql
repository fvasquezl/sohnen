-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-08-14
-- Description:	Get User Access by Page
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetUserAccess]
	@UserID NVARCHAR(20),
	@PageID	NVARCHAR(5),
	@ConnID	INT
AS
BEGIN
	DECLARE @UserType	NVARCHAR(30),
			@COUNT		INT
	SET NOCOUNT ON;

	SELECT @COUNT = COUNT(C.PAGE_ID), @UserType = user_type
	--SELECT COUNT(C.PAGE_ID), user_type
    FROM Inventory.dbo.Users A
    LEFT OUTER JOIN Inventory.dbo.SYS_USERROLE B
    ON B.USER_ID = A.usr AND B.ACTIVE = 'A'
    LEFT OUTER JOIN Inventory.dbo.SYS_PAGEROLE C
    ON C.ROLE_ID = B.ROLE_ID AND C.ACTIVE = 'A' AND C.PAGE_ID = @PageID
    WHERE A.usr = @UserID
	GROUP BY user_type

	IF(ISNULL(@UserType,'') IN ('admin','ADM') OR @COUNT > 0)
	BEGIN
		INSERT INTO Inventory.dbo.SYS_LOGRECORD (CONN_ID,PAGE_ID,CREATE_DATE,CREATE_TIME) 
		VALUES (@ConnID,@PageID,CONVERT(NVARCHAR(8),GETDATE(),112),REPLACE(CONVERT(NVARCHAR(8),GETDATE(),114),':',''))
	END

	SELECT CONVERT(BIT,(CASE WHEN ISNULL(@UserType,'') IN ('admin','ADM') OR @COUNT > 0 THEN 1 ELSE 0 END)) AS isValid
END
go

