-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 8-24-2018
-- Description:	All Channel Run Rates
-- =============================================
-- Modify by:	Eduardo Gutierrez
-- Create date: 2018-08-27
-- Description:	query optimization
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetRunRates] 
	-- Add the parameters for the stored procedure here
	@pDays int = 0,
	@pType NVARCHAR(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	CREATE TABLE #RunRates ([ID] NVARCHAR(MAX), [SKU] NVARCHAR(50), [Quantity] INT, [UnitPrice] Decimal(10,2), [PurchaseDate] DATETIME, [Channel] NVARCHAR(MAX))
	CREATE INDEX IDX_TRunRates ON #RunRates([SKU])

	INSERT INTO #RunRates
		--RUNRATES 8-24-2018
		--LPD Trading
		SELECT [LineItemKey] AS [ID],
		(CASE WHEN [Sku] LIKE 'USED%' THEN LEFT(REPLACE([Sku],'USED','RMTC'),9)+'-USED'
		WHEN [Sku] LIKE 'CN%' THEN LEFT(REPLACE([sku],'CN','RMTC'),9)+'-CN'
		WHEN [Sku] LIKE '%USED' THEN LEFT([sku],9)+'-USED'
		WHEN [Sku] LIKE '%NEW' THEN LEFT([sku],9)+'-NEW'
		WHEN [SKU] LIKE '%-CN' THEN LEFT([sku],9)+'-CN'
		ELSE LEFT([sku],9)+'-NEW' END) AS [SKU]        
		,[Quantity]
		,[UnitPrice]
		,[CreateDate] AS [PurchaseDate]
		,'LPDTrading' AS [Channel]
		FROM [SS1].[orders].[Item] WITH(NOLOCK)
		WHERE [CreateDate] BETWEEN GETDATE()-@pDays AND GETDATE()

		INSERT INTO #RunRates

		--MerchantKing
		SELECT [LineItemKey] AS [ID],
		(CASE WHEN [Sku] LIKE 'USED%' THEN LEFT(REPLACE([Sku],'USED','RMTC'),9)+'-USED'
		WHEN [Sku] LIKE 'CN%' THEN LEFT(REPLACE([sku],'CN','RMTC'),9)+'-CN'
		WHEN [Sku] LIKE '%USED' THEN LEFT([sku],9)+'-USED'
		WHEN [Sku] LIKE '%NEW' THEN LEFT([sku],9)+'-NEW'
		WHEN [SKU] LIKE '%-CN' THEN LEFT([sku],9)+'-CN'
		ELSE LEFT([sku],9)+'-NEW' END) AS [SKU]    
		,[Quantity]
		,[UnitPrice]
		,[CreateDate] AS [PurchaseDate]
		,'MerchantKing' AS [Channel]
		FROM [SS2].[orders].[Item] WITH(NOLOCK)
		WHERE [CreateDate] BETWEEN GETDATE()-@pDays AND GETDATE()

		INSERT INTO #RunRates

		--DEHA US Commerce
		SELECT [LineItemKey] AS [ID],
		(CASE WHEN [Sku] LIKE '%USED' THEN LEFT(REPLACE([sku],'DEHA','RMTC'),9)+'-USED'
		WHEN [Sku] LIKE '%NEW' THEN LEFT(REPLACE([sku],'DEHA','RMTC'),9)+'-NEW'
		WHEN [SKU] LIKE '%-CN' THEN LEFT(REPLACE([sku],'DEHA','RMTC'),9)+'-CN'
		ELSE LEFT(REPLACE([sku],'DEHA','RMTC'),9)+'-NEW' END) AS [SKU]    
		,[Quantity]
		,[UnitPrice]
		,[CreateDate] AS [PurchaseDate]
		,'USCommerce' AS [Channel]
		FROM [SS4].[orders].[Item] WITH(NOLOCK)
		WHERE [CreateDate] BETWEEN GETDATE()-@pDays AND GETDATE()


		INSERT INTO #RunRates

		--PriceWatchers FBM
SELECT ITM.[LineItemKey] AS [ID]
		,(CASE 
		WHEN ITM.[Sku] LIKE '%SKU%' AND MM.[Condition] LIKE '%Used%' THEN MM.[SKU]+'-USED'
		WHEN ITM.[Sku] LIKE '%SKU%' AND MM.[Condition] LIKE '%New%' AND MM.[IsCN] != '1' THEN MM.[SKU]+'-NEW'
		WHEN ITM.[Sku] LIKE '%SKU%' AND MM.[IsCN] = 1 THEN MM.[SKU]+'-CN'
		WHEN ITM.[Sku] LIKE '%RMTC%' AND ITM.[Sku] LIKE '%NEW' THEN LEFT(ITM.[SKU],9)+'-NEW'
		WHEN ITM.[Sku] LIKE '%RMTC%' AND ITM.[Sku] LIKE '%USED' THEN LEFT(ITM.[SKU],9)+'-USED'
		WHEN ITM.[Sku] LIKE '%RMTC%' AND ITM.[Sku] LIKE '%CN' THEN LEFT(ITM.[SKU],9)+'-CN'
		ELSE ITM.[Sku]+'XXX' END) AS [SKU]
		,ITM.[Quantity] AS [Quantity]
		,ITM.[UnitPrice] AS [UnitPrice]
		,ITM.[CreateDate] AS [PurchaseDate]
		,'PriceWatchers' AS [Channel]
		FROM [SS3].[orders].[Item] AS ITM WITH(NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[MarketplaceMapping] AS MM WITH(NOLOCK) ON (REPLACE(ITM.[sku],'SKU','RMTC') = (CASE WHEN MM.[IsCN] = 1 THEN MM.[MerchantSKU]+'-CN'
																															WHEN MM.[Condition] = 'New' AND MM.[IsCN] = 0 THEN MM.[MerchantSKU]
																															WHEN MM.[Condition] = 'Used' AND MM.[IsCN] = 0 THEN MM.[MerchantSKU]+'-USED'
																															ELSE MM.[MerchantSKU] END) )
		WHERE [CreateDate] BETWEEN GETDATE()-@pDays AND GETDATE()

		INSERT INTO #RunRates

		SELECT AZOD.[OrderItemId] AS [LineItemKey]
		,(CASE 
		WHEN AZOD.[SellerSKU] LIKE '%SKU%' AND MM.[Condition] LIKE '%Used%' THEN MM.[SKU]+'-USED'
		WHEN AZOD.[SellerSKU] LIKE '%SKU%' AND MM.[Condition] LIKE '%New%' AND MM.[IsCN] != '1' THEN MM.[SKU]+'-NEW'
		WHEN AZOD.[SellerSKU] LIKE '%SKU%' AND RIGHT(AZOD.[SellerSKU],2) = 'CN' THEN LEFT(REPLACE(AZOD.[SellerSKU],'SKU','RMTC'),9)+'-CN'
		WHEN AZOD.[SellerSKU] LIKE '%RMTC%' AND AZOD.[SellerSKU] LIKE '%NEW' THEN LEFT(AZOD.[SellerSKU],9)+'-NEW'
		WHEN AZOD.[SellerSKU] LIKE '%RMTC%' AND AZOD.[SellerSKU] LIKE '%USED' THEN LEFT(AZOD.[SellerSKU],9)+'-USED'
		WHEN AZOD.[SellerSKU] LIKE '%RMTC%' AND AZOD.[SellerSKU] LIKE '%CN' THEN LEFT(AZOD.[SellerSKU],9)+'-CN'
		ELSE AZOD.[SellerSKU] END) AS [SKU]
		,AZOD.[QuantityOrdered] AS [Quantity]
		,CAST((CONVERT(decimal(10,2), AZOD.[ItemPrice])/AZOD.[QuantityOrdered]) AS decimal(10,2)) AS [UnitPrice]
		,AZO.[PurchaseDate] AS [PurchaseDate]
		,'PriceWatchers' AS [Channel]
		FROM [Remotes].[dbo].[AmazonAPI_OrderDetails] AS AZOD WITH(NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_Orders] AS AZO WITH(NOLOCK) ON (AZOD.[AmazonOrderID] = AZO.[AmazonOrderID])
		LEFT OUTER JOIN [Remotes].[dbo].[MarketplaceMapping] AS MM WITH(NOLOCK) ON (REPLACE(AZOD.[SellerSKU],'SKU','RMTC') = MM.[MerchantSKU])
		WHERE AZO.[FulfillmentChannel] = 'AFN'
		AND ISNUMERIC(AZOD.[ItemPrice]) = 1 
		AND AZOD.[QuantityOrdered] > 0
		AND AZO.[PurchaseDate] BETWEEN GETDATE()-@pDays AND GETDATE()
		ORDER BY [PurchaseDate] ASC


    DECLARE @RightVariable NVARCHAR(20)
	SET @RightVariable = (CASE	WHEN @pType = 'CN' THEN '-CN'
								WHEN @pType = 'USED' THEN 'SED'
								WHEN @pType = 'NEW' THEN 'NEW'
								WHEN @pType = 'ALL' THEN 'RMTC'
								ELSE @pType
								END)
	
	SELECT RR.[SKU], 
			SKUD.[Manufacturer],
			SKUD.[PartNumber],
			SUM(RR.[Quantity]) AS [QtySold], 
			CAST(SUM(RR.[Quantity]*RR.[UnitPrice])/SUM(RR.[Quantity]) AS decimal(10,2)) AS [AvsSalesPrice],
			[Remotes].[dbo].[fn_GetQtyByScanCode](LEFT(RR.[SKU],9),@pType) AS [Qty],
			CAT.[CategoryName]
	FROM #RunRates AS RR
	LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD WITH(NOLOCK) ON (LEFT(RR.[SKU],9) = SKUD.[SKU])
	LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT WITH(NOLOCK) ON (SKUD.[CategoryID] = CAT.[CategoryID])
	WHERE [Quantity] > 0 
	AND RR.[SKU] LIKE '%RMTC%'
	--AND RR.[PurchaseDate] BETWEEN GETDATE()-@pDays AND GETDATE()
	AND (@RightVariable = RIGHT(RR.[SKU],3) OR @RightVariable = LEFT(RR.[SKU],4))

	GROUP BY RR.[SKU], SKUD.[Manufacturer], SKUD.[PartNumber], CAT.[CategoryName]
	ORDER BY [QtySold] DESC

	--DROP TABLE #RunRates

END
go

