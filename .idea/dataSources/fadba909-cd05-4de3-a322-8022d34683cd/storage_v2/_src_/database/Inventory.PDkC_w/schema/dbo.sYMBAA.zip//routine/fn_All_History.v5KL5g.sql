-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION fn_All_History
(
	@pProductCatalogId as INT
)
RETURNS 
@History TABLE 
(
	AjustmentId  int,
	TimePrint  datetime,
	flow int,
	AdjustmenType  varchar(15),
	location  int,
	locationname varchar(50),
	destination int,
	destinationname  varchar(50),
	qty  real,
	remaning  real,
	comments varchar(250),
	userid  int,
	username  varchar(50)
)
AS
BEGIN
	
	INSERT INTO @History 
	(AjustmentId, TimePrint, Flow, AdjustmenType, location,locationname, destination,destinationname,qty, remaning, comments, userid, username )
	SELECT a.id,
	 a.Date
		,flow
		,case
			when flow = 1 then 'Added'
			when flow = 2 then 'Removed'
			when flow = 3 then 'Transfered'
			else 'UnknowAdjustment'
		end as "AdjustmentType"
		, a.Origin, 
		Inventory.dbo.fn_GetAccountName(a.origin),
		a.Destination,
		Inventory.dbo.fn_GetAccountName(a.Destination),
   	    b.Quantity,
   	     0000000000.00 as remaning,
   	    a.Comments,
   	     a.userid, 
   	     Inventory.dbo.fn_GetUserName(a.UserID)
	 FROM Inventory.dbo.InventoryAdjustments a,
	      Inventory.dbo.InventoryAdjustmentDetails b
	 WHERE (a.ID = b.InventoryAdjustmentsID)
			and (b.ProductCatalogID = @pProductCatalogId)
			
	
	RETURN 
END
go

