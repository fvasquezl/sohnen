


CREATE PROCEDURE [dbo].[sp_Update_VirtStock_Kits]

AS 
BEGIN
Declare @MITSKU	       AS Varchar(10)
Declare @VirtualStock  AS INT
Declare @QOH  AS INT

SET @VirtualStock = 0

DECLARE GetItemsInCategory_cursor CURSOR
FOR

SELECT ID FROM Inventory.dbo.ProductCatalog WITH(NOLOCK) WHERE CategoryID IN (
--Kits
'59','60'
)


OPEN GetItemsInCategory_cursor
FETCH NEXT FROM GetItemsInCategory_cursor INTO @MITSKU

WHILE @@FETCH_STATUS = 0
BEGIN
	
			-- Query to check seperable quantity for this SKU in cursor
			SELECT @VirtualStock = SUM(GS.GlobalStock) FROM [Inventory].[dbo].[Global_Stocks] AS GS
			INNER JOIN [Inventory].[dbo].[AssemblyDetails] AS AD ON (GS.ProductCatalogID = AD.ProductCatalogId)	
			WHERE AD.SubSKU = @MITSKU  --AND AD3.IsRequired = '1'

	
	UPDATE Inventory.dbo.Global_Stocks with(UPDLOCK) SET VirtualStock = ISNULL(@VirtualStock, 0) WHERE ProductCatalogId = @MITSKU

	PRINT @MITSKU
	PRINT @VirtualStock

SET @VirtualStock = 0


FETCH NEXT FROM GetItemsInCategory_cursor INTO @MITSKU

END

CLOSE GetItemsInCategory_cursor
DEALLOCATE GetItemsInCategory_cursor

END

go

