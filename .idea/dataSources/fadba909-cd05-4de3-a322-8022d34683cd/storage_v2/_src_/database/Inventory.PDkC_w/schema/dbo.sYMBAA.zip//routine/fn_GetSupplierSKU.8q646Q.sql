-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_GetSupplierSKU
(
	@SKU	INT,
	@ID		INT
)
RETURNS NVARCHAR(250)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @SRESULT NVARCHAR(250)

	-- Add the T-SQL statements to compute the return value here
	SET @SRESULT = IsNull((SELECT TOP(1) SupplierSKU FROM Suppliers WHERE ProductCatalogID = @SKU AND SupplierID = (SELECT SupplierID FROM Users WHERE ID = @ID)),'')

	-- Return the result of the function
	RETURN @SRESULT

END
go

