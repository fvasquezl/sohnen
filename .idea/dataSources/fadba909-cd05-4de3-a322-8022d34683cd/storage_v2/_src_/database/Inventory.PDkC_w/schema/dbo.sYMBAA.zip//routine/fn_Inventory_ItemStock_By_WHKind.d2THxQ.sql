-- =============================================
-- Author:		Luis Bautista
-- Create date: November 27, 2013
-- Description:	Sum the item stock in each warehouse filtered by warehouse type
-- =============================================
CREATE FUNCTION [dbo].[fn_Inventory_ItemStock_By_WHKind]
(
	@pProductID int, @pWarehouseKind varchar(100)
)
RETURNS real
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar real

	
	IF @pWarehouseKind = 'All'
	BEGIN
		SELECT @ResultVar = SUM(a.Quantity) 
					FROM Inventory.dbo.Inventory a 
					WHERE (a.ProductCatalogID = @pProductID)
							AND ( inventory.dbo.fn_Get_Warehouse_Kind(a.AccountID) like '%STORE%');

	END
	
	IF @pWarehouseKind = 'Associated'
	BEGIN
		SELECT @ResultVar = SUM(a.Quantity) 
					FROM Inventory.dbo.Inventory a 
					WHERE (a.ProductCatalogID = @pProductID)
							AND ( inventory.dbo.fn_Get_Warehouse_Kind(a.AccountID) = 'ASSOCIATED STORE');

	END
	
	IF @pWarehouseKind = 'Own'
	BEGIN
		SELECT @ResultVar = SUM(a.Quantity) 
					FROM Inventory.dbo.Inventory a 
					WHERE (a.ProductCatalogID = @pProductID)
							AND ( inventory.dbo.fn_Get_Warehouse_Kind(a.AccountID) = 'STORE');

	END
	
	IF @ResultVar is null
	BEGIN
		SET @ResultVar = 0;
	END
	
	RETURN @ResultVar;

END
go

