-- =============================================
-- Author:		<Amir Tafrehsi>
-- Create date: <4/15/2013>
-- Description:	<Used to import a text file into the AliasSKU table of Order Manager>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ImportSKUAliasToOM]
	-- Add the parameters for the stored procedure here
	/* <@Param1, sysname, @p1> <Datatype_For_Param1, , int> = <Default_Value_For_Param1, , 0>, 
	<@Param2, sysname, @p2> <Datatype_For_Param2, , int> = <Default_Value_For_Param2, , 0> */
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- Insert statements for procedure here
	CREATE TABLE Inventory.dbo.ImportAliasSKUsTEMP
	(	[amazonsku] NVARCHAR(MAX),
		[mappedto] NVARCHAR(MAX)
	)

	/* Insert txt file into the temp table Inventory.dbo.ImportAliasSKUsTEMP */
	BULK INSERT ImportAliasSKUsTEMP FROM 'c:\sharedb\sqlprocessing\ordermanagerskumapping.txt' WITH (FIRSTROW = 2, FIELDTERMINATOR = '\t', ROWTERMINATOR = '\n')

	/* Insert non-existing mappings to OrderManager AliasSKUs */
	INSERT INTO OrderManager.dbo.AliasSKUs (ParentSKU, AliasSKU, CartID)
	SELECT mappedto, amazonsku, '0' FROM Inventory.dbo.ImportAliasSKUsTEMP AS IMASTEMP WITH(NOLOCK)
	LEFT OUTER JOIN OrderManager.dbo.AliasSKUs AS OMAS WITH(NOLOCK) ON (IMASTEMP.amazonsku = OMAS.AliasSKU)
	WHERE OMAS.AliasSKU is null

	/* Update existing mappings in OrderManager AliasSKUs */
	UPDATE OrderManager.dbo.AliasSKUs WITH(UPDLOCK)
	SET ParentSKU = tempTable.mappedto
	FROM Inventory.dbo.ImportAliasSKUsTEMP tempTable 
	WHERE AliasSKU =  tempTable.amazonsku
	

	/* Drop ImportAliasSKUsTEMP */
	DROP TABLE Inventory.dbo.ImportAliasSKUsTEMP

	/* Move TextFile to Imported Folder */
	DECLARE @datetime AS NVARCHAR(MAX)
	DECLARE @cmd AS VARCHAR(2000)

	SET @datetime = (select replace(replace(replace(convert(varchar(19), getdate(), 126),'-',''),'T',''),':',''))

	SET @cmd = 'move c:\sharedb\sqlprocessing\ordermanagerskumapping.txt c:\sharedb\sqlprocessing\imported\ordermanagerskumapping_' + @datetime + '.txt'

	EXEC xp_cmdshell @cmd

END
go

