-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 9-14-2018
-- Description:	Delete from ChannelAdvisor and Tables items that are MarkedForDeletion
-- =============================================
CREATE PROCEDURE [dbo].[sp_ChannelAdvisorDelete] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    --PLACE BULKACTION WITHDRAW AND BULKACTION DELETE IN \\mitnas-mx\public\HTTP\portalfeeds\boughts

	DECLARE @selectstatement NVARCHAR(3000)
	DECLARE @cmd NVARCHAR(3000)

	--START SELECT STATEMENT
	SET @selectstatement = 'SELECT [Inventory Number], ''WITHDRAWSKU'' FROM [Remotes].[dbo].[ChannelAdvisor] WHERE [MarkedForDeletion] = ''1'''
	--END SELECT STATEMENT

	SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\BSQLShares\ChannelAdvisor\ca-bulkactionbody.csv" -SBSQL -Usa -PZ91bM473 -c -t"," -r"\n"'
	EXEC master..xp_cmdshell @cmd

	EXEC master..xp_cmdshell '"C:\BSQLShares\ChannelAdvisor\cabulkactionwithdraw.bat"'


	--START SELECT STATEMENT
	SET @selectstatement = 'SELECT [Inventory Number], ''DELETESKU'' FROM [Remotes].[dbo].[ChannelAdvisor] WHERE [MarkedForDeletion] = ''1'''
	--END SELECT STATEMENT

	SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\BSQLShares\ChannelAdvisor\ca-bulkactionbody.csv" -SBSQL -Usa -PZ91bM473 -c -t"," -r"\n"'
	EXEC master..xp_cmdshell @cmd

	EXEC master..xp_cmdshell '"C:\BSQLShares\ChannelAdvisor\cabulkactiondelete.bat"'

	--CREATE BACKUP BY INSERTING IN THE DELETE TABLE
	INSERT INTO [Remotes].[dbo].[ChannelAdvisorDeleted]
	SELECT * FROM [Remotes].[dbo].[ChannelAdvisor] WHERE [MarkedForDeletion] = '1'
	AND [Inventory Number] NOT IN (SELECT [Inventory Number] FROM [Remotes].[dbo].[ChannelAdvisorDeleted])

	--DELETE FROM CHANNELADVISOR CORE  
	DELETE FROM [Remotes].[dbo].[ChannelAdvisorCore]
	WHERE [Inventory Number] IN (SELECT [Inventory Number] FROM [Remotes].[dbo].[ChannelAdvisor] where MarkedForDeletion = '1')

	--DELETE FROM CHANNELADVISOR
	DELETE FROM [Remotes].[dbo].[ChannelAdvisor]
	WHERE MarkedForDeletion = '1'

	--UPDATE UPC TABLE
	UPDATE [Remotes].[dbo].[UPC] SET [Inventory Number] = NULL WHERE [Inventory Number] LIKE '%Removed%'



END
go

