-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-08-18
-- Description:	Input and Outpu Bin Stock and History
-- =============================================
CREATE PROCEDURE [dbo].[sp_BinInputOutputStock]
	@BIN_ID		NVARCHAR(6),
	@SKU		INT,
	@QTY		INT,
	@UserID		NVARCHAR(20),
	@FLOW		INT,
	@ScanCode	NVARCHAR(5),
	@Comment	NVARCHAR(500)
AS
BEGIN
	DECLARE @VALID			INT = 0,
			@User			INT = 0,
			@WHID			NVARCHAR(2),
			@OrderNumber	INT,
			@GlobalStock	INT,
			@TransactionID NVARCHAR(200) = CONVERT(NVARCHAR,GETDATE());  
	SET XACT_ABORT ON;
	SET NOCOUNT ON;
	--Valid User
	IF(NOT EXISTS(SELECT * FROM Inventory.dbo.Users WITH(NOLOCK) WHERE usr = @UserID AND IsActive = 1))
	BEGIN
		SET @VALID = 4
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	ELSE
	BEGIN
		SET @User = (SELECT ID FROM Inventory.dbo.Users WITH(NOLOCK) WHERE usr = @UserID AND IsActive = 1)
	END
	--Valid BinID
	IF(NOT EXISTS(SELECT * FROM Inventory.dbo.Bins WITH(NOLOCK) WHERE Bin_Id = @BIN_ID AND Active = 1))
	BEGIN
		SET @VALID = 1
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	ELSE
	BEGIN
		SET @WHID = ISNULL((SELECT WarehouseID FROM Inventory.dbo.Bins WHERE Bin_Id = @BIN_ID AND Active = 1),'')
	END
	--Valid SKU
	IF(NOT EXISTS(SELECT * FROM Inventory.dbo.ProductCatalog WITH(NOLOCK) WHERE ID = @SKU))
	BEGIN
		SET @VALID = 2
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	--Valid Qty
	IF(ISNULL(@QTY,0) <= 0)
	BEGIN
		SET @VALID = 3
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	--Transaction
	BEGIN TRANSACTION @TransactionID
	BEGIN TRY
		--Input Stock
		IF(ISNULL(@FLOW,0) = 1)
		BEGIN
			SET @VALID = 5
			IF(EXISTS(SELECT * FROM Inventory.dbo.Bin_Content WITH(NOLOCK) WHERE Bin_Id = @BIN_ID AND ProductCatalog_Id = @SKU))
			BEGIN
				UPDATE Inventory.dbo.Bin_Content SET Counter = Counter + @QTY, LastStamp = GETDATE(), LastUser_Id = @User WHERE Bin_Id = @BIN_ID AND ProductCatalog_Id = @SKU
			END
			ELSE
			BEGIN
				INSERT INTO Inventory.dbo.Bin_Content (Bin_Id, ProductCatalog_Id, Counter, LastStamp, LastUser_Id) VALUES (@BIN_ID,@SKU, @QTY, GETDATE(), @User)
			END
			SET @VALID = 0
		END	
		--Output Stock
		IF(ISNULL(@FLOW,0) = 2)
		BEGIN
			SET @VALID = 6
			--Valid Qty
			IF((SELECT Counter FROM Inventory.dbo.Bin_Content WITH(NOLOCK) WHERE Bin_Id = @BIN_ID AND ProductCatalog_Id = @SKU) >= @QTY)
			BEGIN
				UPDATE Inventory.dbo.Bin_Content SET Counter = Counter - @QTY, LastStamp = GETDATE(), LastUser_Id = @User WHERE Bin_Id = @BIN_ID AND ProductCatalog_Id = @SKU
				SET @VALID = 0
			END
			ELSE
			BEGIN				
				SET @VALID = 3
			END
		END
		--Insert History
		IF(ISNULL(@VALID,-1) = 0)
		BEGIN
			SET @VALID = 7		
			--Get OrderNumber
			SET @OrderNumber = (SELECT OrderNumber FROM OrderManager.dbo.Orders WITH(NOLOCK) WHERE CONVERT(NVARCHAR,OrderNumber) = @Comment)
			INSERT INTO Inventory.dbo.Bins_History (Bin_Id, WarehouseID, Product_Catalog_ID, Qty, Flow, ScanCode, User_Id, Comments, OrderNumber)
			VALUES (@BIN_ID, @WHID, @SKU, @QTY, @FLOW, @ScanCode, @User, @Comment, @OrderNumber);
			SET @VALID = 0
		END
	END TRY
	BEGIN CATCH
		SET @VALID = 8
	END CATCH
	--Update Global Stock and Mercado Libre
	BEGIN TRY
		IF(ISNULL(@VALID,-1) = 0)
		BEGIN
			SELECT @GlobalStock = SUM(BC.Counter) 
			FROM Inventory.dbo.Bin_Content BC 
			WHERE BC.ProductCatalog_Id = @SKU AND Inventory.dbo.fn_Get_Bin_WarehouseID(BC.Bin_Id) <> 'DF'
			GROUP BY BC.ProductCatalog_Id
			
			UPDATE Inventory.dbo.Global_Stocks SET GlobalStock = ISNULL(@GlobalStock,0) WHERE ProductCatalogId = @SKU; 
			UPDATE [Inventory].[dbo].[MercadoLibreListings] SET Stock = ISNULL(@GlobalStock,0) WHERE ProductCatalogId = @SKU; 	
		END
	END TRY		
	BEGIN CATCH
		SET @VALID = 0
	END CATCH

	--RollBack if Error exists
	IF(ISNULL(@VALID,1) > 0)
	BEGIN
		ROLLBACK TRANSACTION @TransactionID
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	COMMIT TRANSACTION @TransactionID
	SELECT @VALID AS RESULT
END
go

