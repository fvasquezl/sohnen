

CREATE VIEW [dbo].[QB_PO_Weighted_Cost_6Mo_per_SKU]
AS
SELECT     PurchaseOrderLineItemRefFullName as ID, SUM(PurchaseOrderLineQuantity * PurchaseOrderLineRate) 
                      / SUM(PurchaseOrderLineQuantity) AS WeightedCost
FROM         dbo.QBPurchaseOrderLine
WHERE     (DATEADD(MM, - 6, GETDATE()) < TimeModified) AND (NOT (PurchaseOrderLineItemRefFullName IS NULL)) AND (PurchaseOrderLineQuantity <> '0') AND
                       (PurchaseOrderLineRate <> '0')
                       --and CONVERT(VARCHAR(8),customfieldpurchaseorderlineother1,1)) <Getdate()
GROUP BY PurchaseOrderLineItemRefFullName

go

