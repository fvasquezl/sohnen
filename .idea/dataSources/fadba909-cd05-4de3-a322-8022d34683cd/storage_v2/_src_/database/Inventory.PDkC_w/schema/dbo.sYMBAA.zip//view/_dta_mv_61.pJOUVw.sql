CREATE VIEW [dbo]._dta_mv_61   AS SELECT  [dbo].[Bins_History].[Product_Catalog_ID] as _col_1,  count_big(*) as _col_2 FROM  [dbo].[Bins_History]  GROUP BY  [dbo].[Bins_History].[Product_Catalog_ID]
go

