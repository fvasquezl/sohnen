-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-06-02
-- Description:	Get Start and End Serial by SKU
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetMIT_LampSerial]
	@SKU			NVARCHAR(10),
	@BurnerSerial	NVARCHAR(50),
	@MITSerial		NVARCHAR(10),
	@Assembler		NVARCHAR(50),
	@Supplier		NVARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;

	IF(ISNULL(@SKU,'') = '' AND ISNULL(@BurnerSerial,'') = '' AND ISNULL(@MITSerial,'') = '' AND ISNULL(@Assembler,'') = '')
	BEGIN
		SELECT TOP 2000 A.ID, A.LotNumber, A.Date, A.ProductCatalogID, A.BurnerSerial, A.MITSerial, A.Assembler, B.filter_label AS Supplier, C.filter_label AS Brand
		FROM Inventory.dbo.LampProduction A
		LEFT OUTER JOIN Inventory.dbo.LampProductionMaster B
		ON B.filter_code = A.Supplier AND B.delete_flag = 0 AND B.filter_id = 'REFLECTOR_SUPPLIER'
		LEFT OUTER JOIN Inventory.dbo.LampProductionMaster C
		ON C.filter_code = A.Brand AND C.delete_flag = 0 AND C.filter_id = 'BRAND_NAME'
		--WHERE A.MITSerial IN (SELECT A.SN AS SerialNumber
		--						FROM Inventory.dbo.Shipped_serialnumbers A	
		--						WHERE A.User_id = 308
		--						GROUP BY A.SN)
		ORDER BY A.Date DESC
	END
	ELSE
	BEGIN
		SELECT A.ID, A.LotNumber, A.Date, A.ProductCatalogID, A.BurnerSerial, A.MITSerial, A.Assembler, B.filter_label AS Supplier, C.filter_label AS Brand
		FROM Inventory.dbo.LampProduction A
		LEFT OUTER JOIN Inventory.dbo.LampProductionMaster B
		ON B.filter_code = A.Supplier AND B.delete_flag = 0 AND B.filter_id = 'REFLECTOR_SUPPLIER'
		LEFT OUTER JOIN Inventory.dbo.LampProductionMaster C
		ON C.filter_code = A.Brand AND C.delete_flag = 0 AND C.filter_id = 'BRAND_NAME'
		WHERE A.ProductCatalogID LIKE @SKU + '%' AND A.BurnerSerial LIKE @BurnerSerial + '%' AND A.Assembler LIKE @Assembler + '%' 
		AND A.MITSerial LIKE '%' + @MITSerial + '%' --AND ISNULL(A.Supplier,'') LIKE @Supplier + '%'
		ORDER BY A.Date DESC
	END
END
go

