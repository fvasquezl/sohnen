CREATE VIEW dbo.QBPurchaseOrderBackorders
AS
SELECT        PurchaseOrderLineItemRefFullName AS SKU, VendorAddressAddr1 AS Vendor, RefNumber AS PO#, PurchaseOrderLineQuantity AS [PO Qty], 
                         PurchaseOrderLineReceivedQuantity AS [PO Received], PurchaseOrderLineQuantity - PurchaseOrderLineReceivedQuantity AS Backorder, TxnDate AS OrderDate, 
                         CustomFieldPurchaseOrderLineOther1 AS ExpectedDate, CustomFieldPurchaseOrderLineOther2 AS [AZ Order#]
FROM            dbo.QBPurchaseOrderLine
WHERE        (PurchaseOrderLineItemRefFullName IS NOT NULL) AND (PurchaseOrderLineReceivedQuantity < PurchaseOrderLineQuantity) AND 
                         (PurchaseOrderLineIsManuallyClosed = 0)
go

