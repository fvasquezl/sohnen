-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2019-03-01
-- Description:	Insert or Update Adapter Model
-- =============================================
CREATE PROCEDURE sp_InsertUpdateAdapterModels
	@ModelID				INT,
	@ProductType			NVARCHAR(150),
    @Manufacturer			NVARCHAR(150),
    @Model					NVARCHAR(250),
    @Amp					DECIMAL(10,1),
    @Voltage				INT,
    @Wattage				INT,
    @AdapterMPN				NVARCHAR(100),
    @AdapterManufacturer	NVARCHAR(100),
    @Region					NVARCHAR(150),
    @PlugType				NVARCHAR(150),
    @Other					NVARCHAR(150),
    @Angle					NVARCHAR(15),
    @Gender					NVARCHAR(50),
    @Polarity				NVARCHAR(255),
    @BarrelLength			DECIMAL(10,1),
    @OuterDiameter			DECIMAL(10,1),
    @InnerDiameter			DECIMAL(10,1),
    @CenterPin				DECIMAL(10,1),
    @PinThickness			DECIMAL(10,1),
    @DataEntryType			INT,
	@UserID					NVARCHAR(20)
AS
BEGIN
	DECLARE @RESULT	NVARCHAR(150),
			@GETID	INT
			
	SET NOCOUNT ON;

	SET @GETID = ISNULL((SELECT TOP 1 ModelID FROM Inventory.dbo.AdapterModels WITH(NOLOCK) WHERE Manufacturer = @Manufacturer AND Model = @Model),0)

	SET @GETID = (CASE WHEN @GETID > 0 THEN @GETID ELSE @ModelID END)

	IF(@ModelID = @GETID)
	BEGIN
		IF(EXISTS(SELECT * FROM Inventory.dbo.AdapterModels WITH(NOLOCK) WHERE ModelID = @ModelID))
		BEGIN
			UPDATE Inventory.dbo.AdapterModels SET [ProductType] = @ProductType, [Manufacturer] = @Manufacturer, [Model] = @Model,[Amp] = @Amp, [Voltage] = @Voltage, [Wattage] = @Wattage, [AdapterMPN] = @AdapterMPN,
				[AdapterManufacturer] = @AdapterManufacturer, [Region] = @Region, [PlugType] = @PlugType, [Other] = @Other, [Angle] = @Angle,	[Gender] = @Gender, 
				[Polarity] = @Polarity, [BarrelLength] = @BarrelLength, [OuterDiameter] = @OuterDiameter, [InnerDiameter] = @InnerDiameter, [CenterPin] = @CenterPin, [PinThickness] = @PinThickness, 
				[DataEntryType] = @DataEntryType, [LastModifiedBy] = @UserID, [LastModifiedDate] = GETDATE()
				WHERE ModelID = @ModelID
		END
		ELSE
		BEGIN
			DECLARE @TMP TABLE ([ModelID] INT)
		
			INSERT INTO Inventory.[dbo].[AdapterModels] ([ProductType],[Manufacturer],[Model],[Amp],[Voltage],[Wattage],[AdapterMPN],[AdapterManufacturer],[Region],[PlugType],[Other],[Angle],
				[Gender],[Polarity],[BarrelLength],[OuterDiameter],[InnerDiameter],[CenterPin],[PinThickness],[DataEntryType],[LastModifiedBy],[LastModifiedDate]) OUTPUT inserted.[ModelID] INTO @TMP
			VALUES (@ProductType,@Manufacturer,@Model,@Amp,@Voltage,@Wattage,@AdapterMPN,@AdapterManufacturer,@Region,@PlugType,@Other,@Angle,@Gender,@Polarity,@BarrelLength,@OuterDiameter
				,@InnerDiameter,@CenterPin,@PinThickness,@DataEntryType,@UserID,GETDATE())

		END
	END
END
go

