CREATE procedure [dbo].[spSumaShipppedTotal]
@Anyo int,
@ProductLineId int,
@CartId int
as

	IF @CartId = 0
	Begin
	SELECT  Year(a.OrderDate)as OrderYear,Month(a.OrderDate)as OrderMonth, sum (b.ShippedSubtotal)as SumShippedSubTotal
	FROM OrderManager.dbo.Orders as a , OrderManager.dbo.[Order Details] as b, Inventory.dbo.ProductCatalog as c
	
	WHERE BalanceDue = 0 
	and a.OrderNumber = b.OrderNumber 
	and (ISNUMERIC( b.SKU)<> 0 and b.SKU = c.ID) 
	and c.ProductLineID= @ProductLineId 
	and Year(a.OrderDate)= @Anyo
	group by  Year(a.OrderDate),Month(a.OrderDate),c.ProductLineID
	ORDER BY Year(a.OrderDate),Month(a.OrderDate),c.ProductLineID
    
    End 
    
    IF @CartId <> 0 
    Begin
    SELECT  Year(a.OrderDate)as OrderYear,Month(a.OrderDate)as OrderMonth, sum (b.ShippedSubtotal)as SumShippedSubTotal
	FROM OrderManager.dbo.Orders as a , OrderManager.dbo.[Order Details] as b, Inventory.dbo.ProductCatalog as c
	
	WHERE BalanceDue = 0 
	and a.OrderNumber = b.OrderNumber 
	and (ISNUMERIC( b.SKU)<> 0 
	and b.SKU = c.ID) 
	and c.ProductLineID= @ProductLineId 
	and Year(a.OrderDate)= @Anyo
	and a.CartID = @CartId
	group by  Year(a.OrderDate),Month(a.OrderDate),c.ProductLineID,a.CartId
	ORDER BY Year(a.OrderDate),Month(a.OrderDate),c.ProductLineID
    
    End

go

