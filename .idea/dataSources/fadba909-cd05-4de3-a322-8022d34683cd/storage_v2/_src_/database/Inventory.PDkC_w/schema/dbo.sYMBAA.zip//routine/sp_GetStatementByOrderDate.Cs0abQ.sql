-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-08-24
-- Description:	Get Statement By OrderDate
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetStatementByOrderDate]
	@CustomerID INT,
	@DATE1		NVARCHAR(10),
	@DATE2		NVARCHAR(10)
AS
BEGIN
	SET FMTONLY OFF
	SET NOCOUNT ON;
	
	IF EXISTS (SELECT 1 FROM tempdb..SYSOBJECTS WHERE name LIKE '#TMP_StatementByShipDate')
		DROP   TABLE #TMP_StatementByShipDate
	CREATE TABLE #TMP_StatementByShipDate (CustomerID			INT,
											OrderNumber			INT,
											OrderSource			NVARCHAR(2),
											OrderReference		NVARCHAR(255),
											PONumber			NVARCHAR(50),
											ShipDate			NVARCHAR(10),
											OrderDate			NVARCHAR(10),
											ShipName			NVARCHAR(255),
											ShipCompany			NVARCHAR(255),
											ShipAddress			NVARCHAR(255),
											ShipAddress2		NVARCHAR(255),
											ShipCity			NVARCHAR(255),
											ShipState			NVARCHAR(255),
											ShipZip				NVARCHAR(255),
											ShipCountry			NVARCHAR(255),
											ShipPhone			NVARCHAR(255),
											ProductTotal		DECIMAL(13,2),
											TaxTotal			DECIMAL(13,2),
											ShippingTotal		DECIMAL(13,2),
											GrandTotal			DECIMAL(13,2),
											NumItems			INT,
											Shipping			NVARCHAR(255),
											Discount			DECIMAL(13,2),
											RevisedDiscount		DECIMAL(13,2),
											FinalProductTotal	DECIMAL(13,2),
											FinalTaxTotal		DECIMAL(13,2),
											FinalShippingTotal	DECIMAL(13,2),
											FinalGrandTotal		DECIMAL(13,2),
											BalanceDue			DECIMAL(13,2),
											OrderStatus			NVARCHAR(50),
											TrackingNum			NVARCHAR(50),
											STATEMENTDAY		INT
											)

		INSERT INTO #TMP_StatementByShipDate (CustomerID,OrderNumber,OrderSource,OrderReference,PONumber,ShipDate,OrderDate,ShipName,ShipCompany,ShipAddress,ShipAddress2,ShipCity,ShipState,
												ShipZip,ShipCountry,ShipPhone,ProductTotal,TaxTotal,ShippingTotal,GrandTotal,NumItems,Shipping,Discount,RevisedDiscount,FinalProductTotal,
												FinalTaxTotal,FinalShippingTotal,FinalGrandTotal,BalanceDue,OrderStatus,TrackingNum,STATEMENTDAY)
		SELECT O.CustomerID, OrderNumber
			,O.[OrderSource]
			,(CASE WHEN IsNull(O.[SourceOrderID],'') = '' THEN IsNull(CAST(O.[SourceOrderNumber] AS NVARCHAR(MAX)),'') ELSE IsNull(O.[SourceOrderID],'') END) AS 'OrderReference'
			,IsNull(O.PONumber,'') AS 'PONumber'
			,CAST((SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 WHERE TRK2.NumericKey = O.OrderNumber) AS DATE) AS 'ShipDate'
			,CAST(O.OrderDate AS date) AS 'OrderDate'
			,O.[ShipName]
			,O.[ShipCompany]
			,O.[ShipAddress]
			,ISNULL(O.[ShipAddress2], '') [ShipAddress2]
 			,O.[ShipCity]
			,O.[ShipState]
			,O.[ShipZip]
			,O.[ShipCountry]
			,O.[ShipPhone]
			,O.[ProductTotal]
			,O.[TaxTotal]
			,O.[ShippingTotal]
			,O.[GrandTotal]
			,(
				SELECT SUM(C.QuantityOrdered)
				FROM [OrderManager].[dbo].[Orders] A
				LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] B 
				ON A.[OrderNumber] = B.[NumericKey]
				LEFT OUTER JOIN [OrderManager].[dbo].[Order Details] C 
				ON A.[OrderNumber] = C.[OrderNumber]
				WHERE A.[Approved] = '1' AND A.[Cancelled] = '0' AND A.[BalanceDue] > '1.00' AND C.Adjustment = '0' AND B.[TrackingID] IS NOT NULL AND A.OrderNumber = O.OrderNumber
				GROUP BY A.[OrderNumber]
			) AS NumItems
			,O.[Shipping]
			,O.[Discount]
			,O.[RevisedDiscount]
			,O.[FinalProductTotal]
			,O.[FinalTaxTotal]
			,O.[FinalShippingTotal]
			,O.[FinalGrandTotal]
			,O.[BalanceDue]
			,O.[OrderStatus]
			,(SELECT TOP(1) TRK2.[TrackingID] FROM [OrderManager].[dbo].[Tracking] AS TRK2 WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS 'TrackingNum'
			,0
		FROM OrderManager.dbo.Orders AS O
		--LEFT OUTER JOIN OrderManager.dbo.Tracking AS TRK ON (O.OrderNumber = TRK.NumericKey)
		WHERE O.Approved = '1' 
			AND O.Cancelled = '0' 
			AND O.BalanceDue > '1.00' --AND TRK.TrackingID IS NOT NULL 
			AND O.CustomerID = (@CustomerID) 
			AND CONVERT(DATE,(SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 WHERE TRK2.NumericKey = O.OrderNumber)) BETWEEN @DATE1 AND @DATE2
		ORDER BY 'ShipDate' ASC


	SELECT A.CustomerID, A.FullName, A.Company, A.Address, isnull(A.Address2, '') Address2, A.City, A.State, A.Zip, A.Country, B.OrderNumber, B.OrderSource, B.OrderReference, B.PONumber, B.ShipDate, B.OrderDate, B.ShipName,
		B.ShipCompany, B.ShipAddress, B.ShipAddress2, B.ShipCity, B.ShipState, B.ShipZip, B.ShipCountry, B.ShipPhone, B.ProductTotal, B.TaxTotal, B.ShippingTotal, B.GrandTotal, B.NumItems, 
		B.Shipping, B.Discount, B.RevisedDiscount, B.FinalProductTotal, B.FinalTaxTotal, B.FinalShippingTotal, B.FinalGrandTotal, B.BalanceDue, B.OrderStatus, B.TrackingNum, B.STATEMENTDAY
	FROM OrderManager.dbo.Customers A
	LEFT OUTER JOIN #TMP_StatementByShipDate B	
	ON B.CustomerID = A.CustomerID 
	WHERE A.CustomerID = @CustomerID
	GROUP BY A.CustomerID, A.FullName, A.Company, A.Address, A.Address2, A.City, A.State, A.Zip,A.Country, B.OrderNumber, B.OrderSource, B.OrderReference, B.PONumber, B.ShipDate, B.OrderDate, B.ShipName,
		B.ShipCompany, B.ShipAddress, B.ShipAddress2, B.ShipCity, B.ShipState, B.ShipZip, B.ShipCountry, B.ShipPhone, B.ProductTotal, B.TaxTotal, B.ShippingTotal, B.GrandTotal, B.NumItems, 
		B.Shipping, B.Discount, B.RevisedDiscount, B.FinalProductTotal, B.FinalTaxTotal, B.FinalShippingTotal, B.FinalGrandTotal, B.BalanceDue, B.OrderStatus, B.TrackingNum, B.STATEMENTDAY
	ORDER BY B.STATEMENTDAY ASC, B.ShipDate ASC, B.OrderNumber ASC

END



go

