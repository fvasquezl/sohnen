CREATE VIEW [dbo]._dta_mv_1 WITH SCHEMABINDING AS SELECT  [dbo].[UPC].[Inventory Number] as _col_1,  count_big(*) as _col_2 FROM  [dbo].[UPC]   WHERE ( NOT  [dbo].[UPC].[Inventory Number] like N'%Removed%' ) GROUP BY  [dbo].[UPC].[Inventory Number]
go

