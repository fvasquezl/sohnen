


CREATE PROCEDURE [dbo].[sp_SendInStockNotifications]

AS 
BEGIN
DECLARE @stUserID INT
DECLARE @UserEmail NVARCHAR(MAX)

SET @stUserID = 0
SET @UserEmail = 0

DECLARE SendMail_cursor CURSOR
FOR

	SELECT DISTINCT [UserID] FROM [Inventory].[dbo].[InStockNotification]


OPEN SendMail_cursor
FETCH NEXT FROM SendMail_cursor INTO @stUserID

WHILE @@FETCH_STATUS = 0
BEGIN


		--FOR TESTING
		--DECLARE @stUserID INT
		--DECLARE @UserEmail NVARCHAR(MAX)
		--SET @stUSERID = '19'
		--FOR TESTING


		SELECT @UserEmail = USR.[Email] FROM [Inventory].[dbo].[Users] AS USR WHERE USR.[ID] = @stUserID

		--Print @UserEmail
		
		DECLARE @tmpTable TABLE([SKU] NVARCHAR(20), [Description] NVARCHAR(MAX), [QtyRequested] INT, [QtyAvailable] INT, [Status] NVARCHAR(20), [Notes] NVARCHAR(1000), [UserID] INT)
		DELETE FROM @tmpTable

		INSERT INTO @tmpTable
		SELECT ISN.[ProductCatalogID]
			  ,PC.[Name] AS 'Description'
			  ,ISN.[QtyRequired] AS 'QtyRequested'
			  ,CAST(GS.[TotalStock] AS INT) AS 'QtyAvailable'
			  ,(CASE WHEN GS.[TotalStock] >= ISN.[QtyRequired] THEN 'Fulfillable'
			  ELSE 'Non-Fulfillable' END) AS 'Status'
			  ,ISN.[Notes]
			  ,ISN.[UserID]
		  FROM [Inventory].[dbo].[InStockNotification] AS ISN
		  LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (CAST(ISN.[ProductCatalogID] AS NVARCHAR(20)) = CAST(PC.[ID] AS NVARCHAR(20)))
		  LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (CAST(ISN.[ProductCatalogID] AS NVARCHAR(20)) = CAST(GS.[ProductCatalogId] AS NVARCHAR(20)))
		  WHERE ISN.[UserID] = @stUserID
		  AND CAST(ISN.[ProductCatalogID] AS NVARCHAR(20)) IN (SELECT CAST([ID] AS NVARCHAR(20)) FROM [Inventory].[dbo].[ProductCatalog])

		INSERT INTO @tmpTable
		SELECT ISN.[ProductCatalogID]
			  ,(CASE 
				WHEN RIGHT(ISN.[ProductCatalogID],2) LIKE '%-G%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Generic Module' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OP%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Philips Module' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OO%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Osram Module' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OX%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Phoenix Module' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OU%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Ushio Module' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-BG%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Generic Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOP%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Philips Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOO%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Osram Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOX%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Phoenix Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOU%' THEN (SELECT PJD.[Brand] + ' ' + PJD.[PartNumber] + ' - Ushio Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))			  
			  ELSE '' END) AS 'Description'
			  ,ISN.[QtyRequired] AS 'QtyRequested'
			  ,(CASE 
				WHEN RIGHT(ISN.[ProductCatalogID],2) LIKE '%-G%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKU] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OP%' THEN
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUPH] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OO%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUOS] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OX%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUPX] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OU%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUUSH] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OE%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUOEM] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)

				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-BG%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKU] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOP%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUPH] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOO%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUOS] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOX%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUPX] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOU%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUUSH] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOE%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUOEM] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
			  ELSE '' END) AS 'QtyAvailable'

			  ,(CASE WHEN 
			  (CASE 
				WHEN RIGHT(ISN.[ProductCatalogID],2) LIKE '%-G%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKU] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OP%' THEN
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUPH] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OO%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUOS] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OX%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUPX] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OU%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUUSH] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-OE%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[EncSKUOEM] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				
				WHEN RIGHT(ISN.[ProductCatalogID],3) LIKE '%-BG%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKU] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOP%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUPH] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOO%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUOS] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOX%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUPX] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOU%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUUSH] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
				WHEN RIGHT(ISN.[ProductCatalogID],4) LIKE '%-BOE%' THEN 
				CAST(IsNull((SELECT GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE CAST(GS.[ProductCatalogID] AS NVARCHAR(20)) = 				
				(SELECT CAST(PJD.[BareSKUOEM] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE CAST(PJD.[CatalogID] AS NVARCHAR(20)) = LEFT(ISN.[ProductCatalogID],5))),0) AS INT)
			  ELSE '' END)
			   >= ISN.[QtyRequired] THEN 'Fulfillable'
			  ELSE 'Non-Fulfillable' END) AS 'Status'
			  ,ISN.[Notes]
			  ,ISN.[UserID]
		  FROM [Inventory].[dbo].[InStockNotification] AS ISN
		  WHERE ISN.[UserID] = @stUserID
		  AND CAST(LEFT(ISN.[ProductCatalogID],5) AS NVARCHAR(20)) IN (SELECT CAST([CatalogID] AS NVARCHAR(20)) FROM [MITDB].[dbo].[ProjectorData])


		  --SELECT * FROM @tmpTable
		  
		  
		  ---------Send Email Script--------
		  		 PRINT @stUserID

			DECLARE @xml NVARCHAR(MAX)
			DECLARE @body NVARCHAR(MAX)
			DECLARE @date VARCHAR(12)
			DECLARE @subtext VARCHAR(50)
			DECLARE @subject VARCHAR(62)
			DECLARE @recipients VARCHAR(255)

			SET @xml = ''
			SET @body = ''
			SET @date = ''
			SET @subtext = ''
			SET @subject = ''
			SET @recipients = ''

			
			SET @xml =CAST(( 
			Select [SKU] AS 'td',''
				,[Description] AS 'td',''
				,[QtyRequested] AS 'td',''
				,[QtyAvailable] AS 'td',''
				,[Status] AS 'td',''
				,[Notes] AS 'td',''
				--,[UserID] AS 'td'
			FROM @tmpTable
			ORDER BY [Status], [SKU] FOR XML PATH('tr'), ELEMENTS 
			) AS NVARCHAR(MAX))

			SET @subtext = 'Stock Monitor - '
			SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
			SET @subject = @subtext + @date
			SET @recipients = @UserEmail
			SET @body ='<html><center><H1>Stock Monitor - <br>' + @date + '</H1><br><br> <body bgcolor=yellow><table border = 2><tr><th>SKU</th><th>Description</th><th>QtyRequested</th><th>QtyAvailable</th><th>Status</th><th>Notes</th></tr>' 
			SET @body = @body + @xml +'</center></table><br><br>Regards,<br>AutoBot by MI Technologies, Inc</body></html>'


			If @body is not null BEGIN

			EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',
			@recipients = @recipients,
			@subject = @subject,
			@body = @body,
			@body_format ='HTML'

			END
	
			--ClearTempTable
			DELETE FROM @tmpTable

FETCH NEXT FROM SendMail_cursor INTO @stUserID

END

CLOSE SendMail_cursor
DEALLOCATE SendMail_cursor

END



go

