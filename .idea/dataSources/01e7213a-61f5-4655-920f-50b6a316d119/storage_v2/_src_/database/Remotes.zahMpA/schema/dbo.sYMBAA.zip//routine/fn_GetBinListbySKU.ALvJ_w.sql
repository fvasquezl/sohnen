-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-07-10
-- Description:	Get List Bin by SKU
-- =============================================
CREATE FUNCTION fn_GetBinListbySKU
(	
	@SKUTYPE NVARCHAR(50)
)
RETURNS @TMP TABLE (BinID NVARCHAR(10))
AS
BEGIN 

	DECLARE @SKU		NVARCHAR(50),
			@ScanCode	NVARCHAR(5)

	SET @SKU = (SELECT Item FROM Remotes.dbo.[fnSplit](@SKUTYPE,'-') WHERE ItemId = 1)
	SET @ScanCode = (SELECT Item FROM Remotes.dbo.[fnSplit](@SKUTYPE,'-') WHERE ItemId = 2)

	INSERT INTO @TMP
	SELECT BinID
	FROM Remotes.dbo.BinStock WITH(NOLOCK) WHERE SKU = @SKU AND ScanCode = @ScanCode

	RETURN 
END
go

