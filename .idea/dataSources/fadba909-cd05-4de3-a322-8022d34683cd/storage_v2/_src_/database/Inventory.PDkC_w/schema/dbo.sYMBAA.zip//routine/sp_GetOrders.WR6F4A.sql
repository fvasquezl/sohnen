

-- ============================================================================
-- Author:		Santos Escobar
-- Create date: 01/04/2015
-- Description:	Gets description and detail of a particuar order.
-- ============================================================================
CREATE PROCEDURE [dbo].[sp_GetOrders] 
(
	@OrderNumber INT
)
AS
BEGIN
	SELECT A.OrderNumber, SUM(A.QuantityOrdered) AS TOTAL_QTY 
	FROM OrderManager.dbo.[Order Details] A
	INNER JOIN OrderManager.dbo.Orders B
	ON B.OrderNumber = A.OrderNumber AND ISNULL(B.OrderStatus,'') NOT IN ('Canceled','Drop Shipment Canceled','Drop Shipment Ordered','Item Returned','Refunded','Shipped')
    WHERE A.Adjustment = 0 AND A.OrderNumber = @OrderNumber
	GROUP BY A.OrderNumber
END
go

