-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date,,>
-- Description:	Check for all product under the min. stock
-- =============================================
CREATE PROCEDURE [dbo].[sp_commodities_requirement]
	
AS
BEGIN

	SET NOCOUNT ON;

    -- Insert statements for procedure here
    DECLARE @id INT;
    DECLARE @currentstock INT;
    DECLARE @inventorymin INT;
    DECLARE @inventoryMax INT;
    DECLARE @qtyAuthorized INT;
    DECLARE @exist INT;
    DECLARE @lineid INT;
    DECLARE @POstock INT;
    DECLARE @POmin INT; 
    DECLARE @POmax INT;
    DECLARE @POactive INT;
    DECLARE @Preference BIT;
    
    
    DECLARE requirements_cursor CURSOR
		FOR SELECT Id, currentstock, inventorymin, inventoryMax, ProductLineId 
			FROM ProductCatalog WHERE (inventorymin > 0);
		
		OPEN requirements_cursor;
		
		FETCH NEXT FROM requirements_cursor
				INTO @id, @currentstock, @inventorymin, @inventoryMax, @lineid
		
    
    WHILE @@FETCH_STATUS = 0
	BEGIN
	
				SET @exist = 0;
				SET @POactive = 0;
				SET @POstock = 0;
				
				SELECT @exist = id, @POstock = stock, @POactive = active, @qtyAuthorized = QtyAutorized
				 FROM PO_history WHERE (ProductCatalogId = @id) AND (active > 0) ;
				
				/*Check if ProductCatalog exist in PO_History*/
				IF (@exist < 1) AND (@currentstock <= @inventorymin)
				BEGIN
				
					INSERT INTO PO_history (ProductCatalogId, QtySystem, DateSystem, stock, minstock, maxstock, ProductLineId)
						VALUES (@id, @inventorymax - @currentstock, getdate(), @currentstock, @inventorymin, @inventorymax, @lineid);
						
							
				END
				
				SET @exist = 0;
				SET @POactive = 0;
				SET @POstock = 0;
				SET @Preference = 0;
	
				SELECT @exist = id, @POstock = stock, @POactive = active, @qtyAuthorized = QtyAutorized
						,@Preference = Preferential
						FROM PO_history WHERE (ProductCatalogId = @id) AND (active = 1);
						
				/*Check active or not*/
				IF (@exist > 0)
				BEGIN
					
						IF (@qtyAuthorized = 0)
						BEGIN
						
							
									UPDATE 	PO_history SET stock = @POstock,
														minstock = @inventorymin,
														maxstock = @inventoryMax,
														QtySystem = @inventoryMax - @currentstock
												WHERE id = @exist;
												
													
												
						END
				
				END
										
				FETCH NEXT FROM requirements_cursor
				INTO @id, @currentstock, @inventorymin, @inventoryMax, @lineid;
				
	END
	
	CLOSE requirements_cursor;
	DEALLOCATE requirements_cursor;	
	
END
go

