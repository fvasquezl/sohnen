-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_account_is_in_family] (
	@AccId int, @Family varchar(40)
)
RETURNS int
AS
BEGIN
	
		DECLARE @ResultVar int
	DECLARE @x int;
	
	SET @ResultVar = 0;
	
	SELECT @ResultVar = sum(id) FROM accounts WHERE (id = @AccId ) AND (family = @family);

	-- Return the result of the function
	if @ResultVar Is Null
	BEGIN
		SET @ResultVar = 0
	END
	
	RETURN @ResultVar


END
go

