-- =============================================
-- Author:		Luis Bautista
-- Create date: Jun-9-2014
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_Bin_CRUD]
	@pId int
	,@pBin_Id varchar(10)
	,@pLocation varchar(100)
	,@pActive bit
	,@pAction char(1)
	,@WarehouseID char(2)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Exist int;
	DECLARE @lresult as varchar(100);
	
    -- Insert statements for procedure here
	IF @pAction = 'C' 
	BEGIN
		SELECT @Exist = a.id FROM inventory.dbo.Bins a WHERE (a.Bin_Id = @pBin_Id);
		IF @Exist is null
		BEGIN
			SET @Exist = 0;
		END
		
		IF (@Exist > 0) OR (@pBin_ID = '')
			BEGIN
					SET @lresult = 'Bin ID already exist in databse.';
			END
		ELSE
			BEGIN
					INSERT INTO Bins (Bin_Id, Location, Active, WarehouseID)
					VALUES	 (@pBin_Id, @pLocation, @pActive,@WarehouseID);
					SET @lresult = 'Bin created.';
			END
			
			SELECT @lresult as result;
	END;
	
	
	IF @pAction = 'R' 
	BEGIN
		SELECT * FROM	Inventory.dbo.Bins WHERE Bin_Id = @pBin_Id;
	END;
	
	IF @pAction = 'U' 
	BEGIN
		SELECT @Exist = a.id FROM inventory.dbo.Bins a WHERE (a.Bin_Id = @pBin_Id);
		IF @Exist is null
		BEGIN
			SET @Exist = 0;
		END
		
		IF (@Exist > 0) OR (@pBin_ID = '')
			BEGIN
					UPDATE Bins SET Location = @pLocation
									, Active = @pActive
									WHERE Bin_Id = @pBin_Id;
									
					SET @lresult = 'Bin updated.';
			END
		ELSE
			BEGIN
					SET @lresult = 'Bin ID not exist in databse.';
					
			END
			
			SELECT @lresult as result;
	END;
	
END
go

