-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-31-2018
-- Description:	Current
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonRepricerFeed] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		----------------------------------REPRICING FEED STARTS HERE----------------------------------

		--SET THE SALES RANK BASED ON ORDER HISTORY FOR THIS ACCOUNT
		EXECUTE [Inventory].[dbo].[sp_UpdateEANSalesRankAliasSKU]

		----------------------------------USA----------------------------------
		--Moved USA to NEW SCRIPT - CANADA UNIFIED is disactivated for now and needs to be moved to the new script.


		/**
		------------------------------------CANADA------------------------------------
		------------------------------------CANADA------------------------------------
		------------------------------------CANADA------------------------------------
		--START FBA CANADA - TEMPORARY AURABEAM PRICING REMOVED FLOOR CONSIDERATION
		INSERT INTO @PricingTable
		SELECT 
		AZFBA.[MerchantSKU] AS 'SKU',
		AZFBA.[ASIN] AS 'ASIN',

		(CASE WHEN AZ.[BrandMentioned] = 'Aurabeam' THEN AZ.[BuyBoxPrice]
		ELSE
		Cast(PC.PriceCeilingFBA+10 AS Decimal(10,2)) END) AS 'MaxSellingPrice', 

		Cast((
		Case 
		WHEN AZ.[BrandMentioned] = 'Aurabeam' THEN AZ.[BuyBoxPrice]
		When (PC.DumpFBA = 'True' AND Convert(date,PC.DumpFBAEndDate) > Convert(date,GETDATE())) THEN (PC.PriceFloorFBA*0.60) 
		When AZ.FloorPriceOverride = '1' THEN AZ.FloorPriceOverrideValue+10 
		ELSE PC.PriceFloorFBA+10 END) AS Decimal(10,2)) AS 'MinSellingPrice', 

		'New' AS 'ItemCondition',

		(CASE WHEN AZ.[BrandMentioned] = 'Aurabeam' THEN '0'
		ELSE IsNull(AZFBA.[FBAQty],0) END) AS 'Quantity',

		'AmazonCA' AS 'SellingVenue',
		(CASE WHEN AZ.[BrandMentioned] = 'Aurabeam' THEN '17628' --WE ARE MOVING AURABEAM TO MANUAL REPRICING MODEL
		ELSE '17670' END) AS 'RepricingModelID' 

		FROM [Inventory].[dbo].[AmazonFBA] AS AZFBA WITH(NOLOCK)
		LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (AZFBA.MITSKU = PC.ID) 
		LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK) ON (AZFBA.[ASIN] = AZ.[ASIN]) Where AZFBA.Channel = 'DartCA' AND AZ.CountryCode = 'CA'
		AND AZ.[BrandMentioned] != 'Aurabeam'

		--START FBM CANADA - TEMPORARY AURABEAM PRICING REMOVED FLOOR CONSIDERATION
		INSERT INTO @PricingTable
		SELECT 
		OMAliasSKU.[AliasSKU] AS 'SKU', 
		AZMSKU.[ASIN] AS 'ASIN',

		(CASE WHEN AZ.[BrandMentioned] = 'Aurabeam' THEN CAST(AZ.[BuyBoxPrice]+15 AS Decimal(10,2))
		ELSE
		Cast(IsNull(PC.PriceCeiling+0.01,350)+15 AS Decimal(10,2)) END) AS 'MaxSellingPrice', 

		Cast((
		CASE 
		WHEN AZ.[BrandMentioned] = 'Aurabeam' THEN AZ.[BuyBoxPrice]+15
		When PC.DumpFBM = 'True' AND Convert(date,PC.DumpFBMEndDate) > Convert(date,GETDATE()) THEN (IsNull(PC.PriceFloor,250)*0.60) 
		When AZ.FloorPriceOverride = '1' THEN AZ.FloorPriceOverrideValue+15
		ELSE IsNull(PC.PriceFloor,250)+15 END) AS Decimal(10,2)) AS 'MinSellingPrice', 

		'New' AS 'ItemCondition',

		IsNull(CAST((CASE 
		WHEN AZ.[BrandMentioned] = 'Aurabeam' THEN '0'
		WHEN PC.[AlwaysInStock] = '1' THEN '400'
		ELSE (GS.[TotalStock]*0.8) END) AS INT),0) AS 'Quantity',

		'AmazonCA' AS 'SellingVenue',
		(CASE WHEN AZ.[BrandMentioned] = 'Aurabeam' THEN '17628' --WE ARE MOVING AURABEAM TO MANUAL REPRICING MODEL
		ELSE '17671' END) AS 'RepricingModelID' 

		FROM [OrderManager].[dbo].[AliasSKUs] AS OMAliasSKU WITH(NOLOCK)
		LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (OMAliasSKU.ParentSKU = PC.ID) 
		LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU WITH(NOLOCK) ON (OMAliasSKU.[AliasSKU] = AZMSKU.[DARTFBMSKUCA]) 
		LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK) ON (AZMSKU.[ASIN] = AZ.[ASIN]) 
		LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS WITH(NOLOCK) ON (PC.[ID] = GS.[ProductCatalogID])
		Where OMAliasSKU.[Description] like 'ExclusiveBulbsCA' 
		AND AZ.CountryCode = 'CA'
		AND AZ.[BrandMentioned] != 'Aurabeam'
		AND (CAST(AZ.[MITSalesRank] AS INT) > 7001)



		-----DO CLEANUP TO MAKE SURE MIN is not higher than MAX---
		UPDATE @PricingTable SET [MaxSellingPrice] = [MinSellingPrice] WHERE [MinSellingPrice] > [MaxSellingPrice]


		--CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED
		IF (EXISTS (SELECT * 
						 FROM INFORMATION_SCHEMA.TABLES 
						 WHERE TABLE_CATALOG = 'Inventory' 
						 AND  TABLE_NAME = 'History_AmazonChannelMaxFeed'))
		BEGIN
			DROP TABLE [Inventory].[dbo].[History_AmazonChannelMaxFeed]
		END
		--END CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED

		CREATE TABLE [Inventory].[dbo].[History_AmazonChannelMaxFeed] (
		[SKU] NVARCHAR(MAX), 
		[ASIN] NVARCHAR(MAX), 
		[MaxSellingPrice] Decimal(10,2), 
		[MinSellingPrice] Decimal(10,2), 
		[ItemCondition] NVARCHAR(MAX),
		[Quantity] INT,
		[SellingVenue] NVARCHAR(MAX), 
		[RepricingModelID] INT)

		INSERT INTO [Inventory].[dbo].[History_AmazonChannelMaxFeed]
		SELECT [SKU], [ASIN], [MaxSellingPrice], [MinSellingPrice], [ItemCondition], [Quantity], [SellingVenue], [RepricingModelID] FROM @PricingTable

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[History_AmazonChannelMaxFeed] ORDER BY [SellingVenue] DESC, [SKU] ASC'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\Dart\dartchannelmax-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd

		EXEC master..xp_cmdshell '"C:\sharedb\Dart\senddartfeedchannelmax.bat"'

		
		**/

		-----------------------------------OLD APPEAGLE FEED-------------------------------------
		-----------------------------------OLD APPEAGLE FEED-------------------------------------
		-----------------------------------OLD APPEAGLE FEED-------------------------------------
		-----------------------------------OLD APPEAGLE FEED-------------------------------------
		-----------------------------------OLD APPEAGLE FEED-------------------------------------
		--------------------------STILL USED FOR OLD CANADA ACCOUNT------------------------------

		DECLARE @selectstatement NVARCHAR(2000)
		DECLARE @cmd NVARCHAR(2000)


		--Start FBA CANADA - Added Dump Code 9/22/2014 - Removed DoubleQuotes from ProfileID and ProfileID title - ADDED AURABEAM ALGO 12/5/2014
		SET @selectstatement = 'SELECT AZFBA.[MerchantSKU] AS ''SKU'', ''6109'' AS ''MARKETPLACE_ID'', Cast((Case When (PC.DumpFBA = ''True'' AND Convert(date,PC.DumpFBAEndDate) > Convert(date,GETDATE())) THEN ((PC.PriceFloorFBA+8)*0.60) When AZ.BrandMentioned = ''AuraBeam'' THEN 	(Case When PC.PriceFloorFBA+8 < Floor(AZ.BuyBoxPrice+8)-0.01 THEN Floor(AZ.BuyBoxPrice+8)-0.01 When PC.PriceFloorFBA+8 > Floor(AZ.BuyBoxPrice+8)-0.01 THEN Floor(PC.PriceFloorFBA+8)-0.01 ELSE Floor(PC.PriceCeilingFBA+8)-0.01 END) ELSE PC.PriceFloorFBA+8 END) AS Decimal(10,2)) AS ''MIN_PRICE'', Cast((Case When AZ.BrandMentioned = ''AuraBeam'' THEN (Case When PC.PriceFloorFBA+8 < Floor(AZ.BuyBoxPrice+8)-0.01 THEN Floor(AZ.BuyBoxPrice+8)-0.01 When PC.PriceFloorFBA+8 > Floor(AZ.BuyBoxPrice+8)-0.01 THEN Floor(PC.PriceFloorFBA+8)-0.01 ELSE Floor(PC.PriceCeilingFBA+8)-0.01 END) ELSE PC.PriceCeilingFBA+8 END) AS Decimal(10,2)) AS ''MAX_PRICE'', ''10391'' AS ''PROFILE_ID'' FROM [Inventory].[dbo].[AmazonFBA] AS AZFBA WITH(NOLOCK) LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (AZFBA.MITSKU = PC.ID) LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK) ON (AZFBA.[ASIN] = AZ.[ASIN]) Where AZFBA.Channel = ''DartCA'' AND AZ.CountryCode = ''CA'''
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\Dart\dartCA-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd

		--Start FBM CANADA - Added Dump Code 9/22/2014 - Removed DoubleQuotes from ProfileID and ProfileID title
		SET @selectstatement = 'SELECT OMAliasSKU.AliasSKU AS ''SKU'', ''6109'' AS ''MARKETPLACE_ID'', Cast((Case When PC.DumpFBM = ''True'' AND Convert(date,PC.DumpFBMEndDate) > Convert(date,GETDATE()) THEN (IsNull(PC.PriceFloor+15,250)*0.60) When AZ.BrandMentioned = ''AuraBeam'' THEN (Case 	When PC.PriceFloor+15 < Floor(AZ.BuyBoxPrice+15)-0.01 THEN Floor(AZ.BuyBoxPrice+15)-0.01 When PC.PriceFloor+15 > Floor(AZ.BuyBoxPrice+15)-0.01 THEN Floor(PC.PriceFloor+15)-0.01 ELSE Floor(PC.PriceCeiling+15)-0.01 END) ELSE IsNull(PC.PriceFloor+15,250) END) AS Decimal(10,2)) AS ''MIN_PRICE'', Cast((Case When AZ.BrandMentioned = ''AuraBeam'' THEN (Case When PC.PriceFloor+15 < Floor(AZ.BuyBoxPrice+15)-0.01 THEN Floor(AZ.BuyBoxPrice+15)-0.01 When PC.PriceFloor+15 > Floor(AZ.BuyBoxPrice+15)-0.01 THEN Floor(PC.PriceFloor+15)-0.01 ELSE Floor(PC.PriceCeiling+15)-0.01 END) ELSE IsNull(PC.PriceCeiling+15,350) END) AS Decimal(10,2)) AS ''MAX_PRICE'', ''10387'' AS ''PROFILE_ID'' FROM [OrderManager].[dbo].[AliasSKUs] AS OMAliasSKU WITH(NOLOCK) LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (OMAliasSKU.ParentSKU = PC.ID) LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU WITH(NOLOCK) ON (OMAliasSKU.[AliasSKU] = AZMSKU.[DARTFBMSKUCA]) LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK) ON (AZMSKU.[ASIN] = AZ.[ASIN])  Where OMAliasSKU.[Description] like ''ExclusiveBulbsCA'' AND AZ.CountryCode = ''CA'''
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\Dart\dartCA-body2.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd


		--Start FBM UK Unified - Added Dump Code 9/22/2014 - Removed DoubleQuotes from ProfileID and ProfileID title
		SET @selectstatement = 'SELECT OMAliasSKU.AliasSKU AS ''SKU'', ''8323'' AS ''MARKETPLACE_ID'', Cast((Case When PC.DumpFBM = ''True'' AND Convert(date,PC.DumpFBMEndDate) > Convert(date,GETDATE()) THEN (IsNull(PC.PriceFloor+20,250)*0.60) When AZ.BrandMentioned = ''AuraBeam'' THEN (Case 	When PC.PriceFloor+20 < Floor(AZ.BuyBoxPrice+20)-0.01 THEN Floor(AZ.BuyBoxPrice+20)-0.01 When PC.PriceFloor+20 > Floor(AZ.BuyBoxPrice+20)-0.01 THEN Floor(PC.PriceFloor+20)-0.01 ELSE Floor(PC.PriceCeiling+20)-0.01 END) ELSE IsNull(PC.PriceFloor+20,250) END) AS Decimal(10,2)) AS ''MIN_PRICE'', Cast((Case When AZ.BrandMentioned = ''AuraBeam'' THEN (Case When PC.PriceFloor+20 < Floor(AZ.BuyBoxPrice+20)-0.01 THEN Floor(AZ.BuyBoxPrice+20)-0.01 When PC.PriceFloor+20 > Floor(AZ.BuyBoxPrice+20)-0.01 THEN Floor(PC.PriceFloor+20)-0.01 ELSE Floor(PC.PriceCeiling+20)-0.01 END) ELSE IsNull(PC.PriceCeiling+20,350) END) AS Decimal(10,2)) AS ''MAX_PRICE'', ''19443'' AS ''PROFILE_ID'' FROM [OrderManager].[dbo].[AliasSKUs] AS OMAliasSKU WITH(NOLOCK) LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK) ON (OMAliasSKU.ParentSKU = PC.ID) LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU WITH(NOLOCK) ON (OMAliasSKU.[AliasSKU] = AZMSKU.[DARTFBMSKUUK]) LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK) ON (AZMSKU.[ASIN] = AZ.[ASIN]) Where OMAliasSKU.[Description] like ''ExclusiveBulbsUK'' AND AZ.CountryCode = ''UK'''
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\Dart\dartCA-body2.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd


		EXEC master..xp_cmdshell '"C:\sharedb\Dart\senddartfeed.bat"'


		DECLARE @body NVARCHAR(MAX)
		DECLARE @runquery NVARCHAR(MAX)
		DECLARE @filename NVARCHAR(MAX)
		DECLARE @date VARCHAR(12)
		DECLARE @subtext VARCHAR(50)
		DECLARE @subject VARCHAR(62)
		DECLARE @recipients VARCHAR(255)

 
		SET @subtext = 'Dart Channel Group Repricer Feed - '
		SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
		SET @filename = 'dcgfeed-'+ CONVERT (varchar,CONVERT (date, SYSDATETIME())) +'.csv'
		SET @subject = @subtext + @date
		SET @recipients = 'dcgtechnical@mitechnologiesinc.com'
		--dcgtechnical@mitechnologiesinc.com
		SET @body ='<html>Gentlemen,<br>AutoBot has generated a new repricer feed for Dart Channel Group located at http://exclusivebulbs2.webhop.org/feeds/channelmaxfeed.txt. <br><br><br>Thanks,<br>AutoBot by MI Technologies, Inc.</body></html>'

		--http://photos.discount-merchant.com/Dart/dartfeed.txt

		EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

		@recipients = @recipients,
		@subject = @subject,
		@body = @body,
		@body_format ='HTML'



END
go

