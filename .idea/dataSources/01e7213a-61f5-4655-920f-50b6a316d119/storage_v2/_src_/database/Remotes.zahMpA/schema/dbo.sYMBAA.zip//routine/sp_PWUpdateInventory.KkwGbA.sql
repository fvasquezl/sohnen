-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-14-2018
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_PWUpdateInventory] 


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		--Make sure IsCN bit field is not Null
		UPDATE [Remotes].[dbo].[MarketplaceMapping] SET [IsCN] = 0 WHERE [IsCN] IS NULL

		
		---Start Feed---	
		DECLARE @selectstatement AS NVARCHAR(MAX)
		DECLARE @cmd AS VARCHAR(2000)
	
		SET @selectstatement = 'select * from [Remotes].[dbo].[vw_PWInventoryUpdate]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "\\192.168.0.226\sharedb\AmazonAPI\PriceWatchers\pwbody-addsku.txt" -SBSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd

		EXEC master..xp_cmdshell '"\\192.168.0.226\sharedb\AmazonAPI\PriceWatchers\pwaddsku-txt.bat"'




END
go

