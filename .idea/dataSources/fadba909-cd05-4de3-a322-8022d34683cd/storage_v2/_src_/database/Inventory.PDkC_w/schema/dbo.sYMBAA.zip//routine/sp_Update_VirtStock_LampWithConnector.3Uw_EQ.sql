--This procedure is created to update the Virtual stock and "total stock" in the Global_stocks table
CREATE PROCEDURE [dbo].[sp_Update_VirtStock_LampWithConnector]
AS 
BEGIN
Declare @MITSKU	       AS Varchar(10)
Declare @CategoryCheck AS INT
Declare @UnitCost  AS Float
Declare @VirtualStock  AS INT
Declare @VirtualStockTopLevel AS INT
Declare @VirtualStockLampThenConnector AS INT
Declare @BulbStock AS INT
Declare @ConnectorStock AS INT
Declare @QOH  AS INT
Declare @LampCost    AS Decimal(10,2)
Declare @ConnectorCost    AS Decimal(10,2)
Declare @TotalCost  AS Decimal(10,2)

Declare @SQL1  AS nVArchar(MAX)
Declare @SQL2  AS nVArchar(MAX)

SET @CategoryCheck = 0

SET @UnitCost = 0
SET @VirtualStock = 0
SET @VirtualStockTopLevel = 0
SET @VirtualStockLampThenConnector = 0
SET @BulbStock = 0
SET @ConnectorStock = 0
SET @LampCost = 0
SET @ConnectorCost = 0
SET @TotalCost = 0

DECLARE AssemblyReq_cursor CURSOR
FOR
--Select all of the bare lamp SKUs
SELECT ID, UnitCost FROM Inventory.dbo.ProductCatalog WITH(NOLOCK) WHERE CategoryID IN ('5','6','7','8','9','15','16','17','18','19','61','63','88','89','90','91')--Lamp Categories
--AND ID = '103101'  --Test Condition 

OPEN AssemblyReq_cursor
FETCH NEXT FROM AssemblyReq_cursor INTO @MITSKU,  @UnitCost

WHILE @@FETCH_STATUS = 0
BEGIN
	--Checks to see if Barelamp and Connector are both available in Assembly Details
	SET @CategoryCheck = (
		SELECT COUNT(SubSKU) FROM Inventory.dbo.AssemblyDetails ad 
		INNER JOIN Inventory.dbo.ProductCatalog pc 
		ON ad.ProductCatalogID = pc.ID
		WHERE ad.ProductCatalogID = @MITSKU
		AND ad.SubSKU IN (Select pc.ID FROM Inventory.dbo.ProductCatalog PC  WHERE PC.CategoryID IN (
		--Bare Lamps
		'5','6','7','8','9','15','16','17','18','19','61','63','88','89','90','91',
		--Lamp Connectors
		'33'))
		--AND ad.SubSKU IN (Select pc.ID FROM Inventory.dbo.ProductCatalog pc LEFT JOIN Inventory.dbo.Categories ctg ON pc.CategoryID = Ctg.ID WHERE ctg.ParentID IN ('1', '3') OR ctg.ID IN ('33')) 		
	)	

	--If Lamp Has Connector
	If @CategoryCheck = '2' 
		BEGIN	
			--Get Quantity of Lamp Modules with this Lamp with Connector
			SELECT @VirtualStockTopLevel = SUM(GS.GlobalStock) FROM AssemblyDetails AD WITH(NOLOCK)
			INNER JOIN Inventory.dbo.Global_Stocks AS GS ON (AD.ProductCatalogID = GS.ProductCatalogID)
			WHERE AD.SubSKU = @MITSKU

			--Get Quantity of Bare Lamp then get Quantity of Connector and take the minimum
			SET @BulbStock = 
			--Getting Bare Lamp Quantity
			(SELECT GS.GlobalStock FROM AssemblyDetails AD WITH(NOLOCK)
			INNER JOIN Inventory.dbo.Global_Stocks AS GS ON (AD.SubSKU = GS.ProductCatalogId)
			INNER JOIN Inventory.dbo.ProductCatalog AS PC ON (AD.SubSKU = PC.[ID])
			WHERE AD.ProductCatalogID = @MITSKU AND PC.[CategoryID] IN ('5','6','7','8','9','15','16','17','18','19','61','63','88','89','90','91'))

			SET @ConnectorStock = 
			--Getting Connector Quantity
			(SELECT SUM(GS.GlobalStock) FROM AssemblyDetails AD WITH(NOLOCK)
			INNER JOIN Inventory.dbo.Global_Stocks AS GS ON (AD.SubSKU = GS.ProductCatalogId)
			INNER JOIN Inventory.dbo.ProductCatalog AS PC ON (AD.SubSKU = PC.[ID])
			WHERE AD.ProductCatalogID = @MITSKU AND PC.[CategoryID] IN ('33'))
			
			--Logic to select the smallest quantity of lamp or connector as the @LampThenConnectorStock
				IF @BulbStock < @ConnectorStock 
					BEGIN
						SET @VirtualStockLampThenConnector = @BulbStock
				END

				IF @ConnectorStock < @BulbStock
					BEGIN
						SET @VirtualStockLampThenConnector = @ConnectorStock
				END

			SET @VirtualStock = IsNull(@VirtualStockLampThenConnector,0) + IsNull(@VirtualStockTopLevel,0)
						
			-- Query to Get Lamp Cost
			SELECT @LampCost = CASE WHEN PC.UnitCost = 0 THEN '999' ELSE PC.UnitCost END FROM [Inventory].[dbo].[ProductCatalog] AS PC
			WHERE PC.[ID] = (SELECT AD2.SubSKU FROM AssemblyDetails AS AD2
			LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC2 ON (AD2.SubSKU = PC2.[ID]) 
			WHERE AD2.ProductCatalogID = @MITSKU AND PC2.CategoryID IN ('5','6','7','8','9','15','16','17','18','19','61','63','88','89','90','91') )
			
			-- Query to Get Connector Cost
			SELECT @ConnectorCost = PC.UnitCost FROM [Inventory].[dbo].[ProductCatalog] AS PC
			WHERE PC.[ID] = (SELECT AD2.SubSKU FROM AssemblyDetails AS AD2
			LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC2 ON (AD2.SubSKU = PC2.[ID]) 
			WHERE AD2.ProductCatalogID = @MITSKU AND PC2.CategoryID IN ('33') )
			
			-- Add $1 for connector cost
			SET @TotalCost = @LampCost+@ConnectorCost

			--PRINT @CategoryCheck
			--PRINT @MitSKU
			--PRINT @LampCost
			--PRINT @ConnectorCost
			--PRINT @TotalCost
		END
	ELSE
		BEGIN
			SET @VirtualStock = (SELECT GS4.VirtualStock FROM [Inventory].[dbo].[Global_Stocks] AS GS4 WHERE GS4.ProductCatalogId = @MITSKU)
			SET @TotalCost = (SELECT PC4.UnitCost FROM [Inventory].[dbo].[ProductCatalog] AS PC4 WHERE PC4.[ID] = @MITSKU)
			--PRINT @CategoryCheck
			--IF(ISNULL(@VirtualStock,0)<=0)
			--PRINT (@MitSKU)
			--PRINT @LampCost
			--PRINT @ConnectorCost
			--PRINT @TotalCost
		END
			UPDATE Inventory.dbo.Global_Stocks with(UPDLOCK) SET VirtualStock = ISNULL(@VirtualStock, 0) WHERE ProductCatalogId = @MITSKU
			UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET VirtualStock = ISNULL(@VirtualStock,0), UnitCost = ISNULL(@TotalCost,0)  WHERE ID = @MITSKU
		Print @MITSKU
		PRINT @VirtualStock	
		
--	PRINT @CategoryCheck
--	PRINT @MitSKU
--	PRINT @LampCost
--	PRINT @ConnectorCost
--	PRINT @TotalCost
	
SET @CategoryCheck = 0
SET @VirtualStock = 0
SET @LampCost = 0
SET @ConnectorCost = 0
SET @TotalCost = 0

FETCH NEXT FROM AssemblyReq_cursor INTO @MITSKU, @UnitCost

END

CLOSE AssemblyReq_cursor
DEALLOCATE AssemblyReq_cursor

END
go

