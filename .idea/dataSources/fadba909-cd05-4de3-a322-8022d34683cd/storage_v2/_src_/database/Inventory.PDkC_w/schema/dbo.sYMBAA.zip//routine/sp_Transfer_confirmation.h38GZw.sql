-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Transfer_confirmation]
	@pAdjustmentId as int, @puser as int	
AS
BEGIN

		select * from inventoryadjustments where id = @pAdjustmentId;
		
		
END
go

