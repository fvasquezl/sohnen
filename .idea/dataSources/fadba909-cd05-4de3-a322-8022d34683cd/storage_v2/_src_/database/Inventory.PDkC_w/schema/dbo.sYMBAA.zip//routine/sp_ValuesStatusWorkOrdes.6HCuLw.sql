
CREATE Procedure [dbo].[sp_ValuesStatusWorkOrdes] 

AS
BEGIN

SELECT 
SUM(IIF(OS.OrderStatus IN('Canceled','Drop Shipment Canceled','Drop Shipment Ordered','Item Returned','Refunded','Shipped'), 0,1) ) Pending,
SUM(IIF(OS.OrderStatus = 'Shipped', 1,0)) Finish,
SUM(IIF(OS.OrderStatus IN('Canceled','Drop Shipment Canceled','Drop Shipment Ordered','Item Returned','Refunded'), 1, 0) ) Canceled,
COUNT(*) Total
FROM WebStation.OE.WorkOrders WO
INNER JOIN OrderManager.dbo.Orders OS
ON OS.OrderNumber = WO.WorkOrderID 


END



go

