-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-8-2018
-- Description:	ChannelAdvisor Product Feed
-- =============================================
CREATE PROCEDURE [dbo].[sp_ChannelAdvisorProductFeedEU] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
		IF OBJECT_ID('[Remotes].[dbo].[ChannelAdvisorTempEU]') IS NOT NULL DROP TABLE [Remotes].[dbo].[ChannelAdvisorTempEU]
	
		---FINAL SELECT FOR FEED
		CREATE TABLE [Remotes].[dbo].[ChannelAdvisorTempEU] ([Inventory Number] nvarchar(max),[Auction Title] nvarchar(max)
		,[Quantity Update Type] nvarchar(max),[Quantity] nvarchar(max)
		,[Length] nvarchar(max),[Height] nvarchar(max),[Width] nvarchar(max),[Weight] nvarchar(max)
		,[MPN] nvarchar(max),[Short Description] nvarchar(max),[Description] nvarchar(max)
		,[Manufacturer] nvarchar(max),[Brand] nvarchar(max),[Condition] nvarchar(max),[Warranty] nvarchar(max)
		,[Seller Cost] nvarchar(max),[Buy It Now Price] nvarchar(max),[Retail Price] nvarchar(max)
		,[Picture URLs] nvarchar(max),[Description Template Name] nvarchar(max)
		,[Posting Template Name] nvarchar(max),[Schedule Name] nvarchar(max),[eBay Category List] nvarchar(max)
		,[eBay Store Category Name] nvarchar(max),[Labels] nvarchar(max),[Classification] nvarchar(max)
		,[Attribute1Name] nvarchar(max),[Attribute1Value] nvarchar(max),[Attribute2Name] nvarchar(max)
		,[Attribute2Value] nvarchar(max),[Attribute3Name] nvarchar(max),[Attribute3Value] nvarchar(max)
		,[Attribute4Name] nvarchar(max),[Attribute4Value] nvarchar(max),[Attribute5Name] nvarchar(max)
		,[Attribute5Value] nvarchar(max),[Attribute6Name] nvarchar(max),[Attribute6Value] nvarchar(max)
		,[Attribute7Name] nvarchar(max),[Attribute7Value] nvarchar(max),[Attribute8Name] nvarchar(max)
		,[Attribute8Value] nvarchar(max),[Attribute9Name] nvarchar(max),[Attribute9Value] nvarchar(max)
		,[Attribute10Name] nvarchar(max),[Attribute10Value] nvarchar(max),[Attribute11Name] nvarchar(max)
		,[Attribute11Value] nvarchar(max),[Attribute12Name] nvarchar(max),[Attribute12Value] nvarchar(max)
		,[Attribute13Name] nvarchar(max),[Attribute13Value] nvarchar(max),[Attribute14Name] nvarchar(max)
		,[Attribute14Value] nvarchar(max),[Attribute15Name] nvarchar(max),[Attribute15Value] nvarchar(max))

		INSERT INTO [Remotes].[dbo].[ChannelAdvisorTempEU]
		SELECT  
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Inventory Number] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Inventory Number], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Auction Title] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Auction Title], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Quantity Update Type] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Quantity Update Type], 
		CAST([Remotes].[dbo].[fn_GetQtyByScanCodeGY](LEFT([Attribute1Value],9),REPLACE(REPLACE(RIGHT([Attribute1Value],3),'-CN','CN'),'SED','USED')) AS INT) AS [Quantity], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CAST([Length] as decimal(10,2))*2.54 as decimal(10,2)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Length], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CAST([Height] as decimal(10,2))*2.54 as decimal(10,2)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Height], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CAST([Width] as decimal(10,2))*2.54 as decimal(10,2)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Width], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CAST([Weight] as decimal(10,2))/2.205 as decimal(10,2)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Weight], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([MPN] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [MPN], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Short Description] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Short Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Description] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Manufacturer] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Manufacturer], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Brand] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Brand], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Condition] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Condition], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Warranty] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Warranty], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Seller Cost] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Seller Cost], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute15Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Buy It Now Price],  --This has been changed to CeilingPriceEU
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(CAST((CEILING([Attribute15Value])*2) AS decimal(10,2)),'-0.01','89.99') ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Retail Price],  --This has been changed to CeilingPriceEU*2
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Picture URLs] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Picture URLs],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Description Template Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Description Template Name],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Posting Template Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Posting Template Name],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Schedule Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Schedule Name],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([eBay Category List] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [eBay Category List],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([eBay Store Category Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [eBay Store Category Name], 
		'' AS [Labels], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Classification] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Classification], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute1Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute1Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute1Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute1Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute2Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute2Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute2Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute2Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute3Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute3Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute3Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute3Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute4Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute4Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute4Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute4Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute5Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute5Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute5Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute5Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute6Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute6Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute6Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute6Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute7Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute7Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute7Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute7Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute8Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute8Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Value],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute9Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute2Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute9Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute2Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute10Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute3Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute10Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute3Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute11Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute4Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute11Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute4Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute12Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute5Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute12Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute5Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute13Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute6Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute13Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute6Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute14Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute7Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute14Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute7Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute15Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute15Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Value]

		FROM [Remotes].[dbo].[ChannelAdvisor] WITH (NOLOCK)
		WHERE 
		([Attribute4Value] LIKE '%REMOTE%'
		OR [Attribute4Value] LIKE '%CABLE%')
		--AND [Quantity] > 0
		ORDER BY [ID] ASC

		SELECT * FROM [Remotes].[dbo].[ChannelAdvisorTempEU] WHERE [Quantity] > 0

		DECLARE @selectstatement NVARCHAR(3000)
		DECLARE @cmd NVARCHAR(3000)

		--START SELECT STATEMENT
		SET @selectstatement = 'SELECT * FROM [Remotes].[dbo].[ChannelAdvisorTempEU] WHERE [Quantity] > 0'
		--END SELECT STATEMENT

		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\BSQLShares\ChannelAdvisorEU\ca-body.csv" -SBSQL -Usa -PZ91bM473 -c -C ACP -t"," -r"\n"'
		EXEC master..xp_cmdshell @cmd

		EXEC master..xp_cmdshell '"C:\BSQLShares\ChannelAdvisorEU\cafeed.bat"'


END
go

