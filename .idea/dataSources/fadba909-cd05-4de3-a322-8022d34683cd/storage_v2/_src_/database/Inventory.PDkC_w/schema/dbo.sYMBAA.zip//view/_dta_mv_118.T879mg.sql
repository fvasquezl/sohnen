CREATE VIEW [dbo]._dta_mv_118 WITH SCHEMABINDING AS SELECT  [dbo].[CompatibilityAlternativeModels].[AlternativeModel] as _col_1,  [dbo].[CompatibilityAlternativeModels].[OriginalModel] as _col_2,  [dbo].[CompatibilityAlternativeModels].[OriginalManufacturer] as _col_3,  count_big(*) as _col_4 FROM  [dbo].[CompatibilityAlternativeModels]   GROUP BY  [dbo].[CompatibilityAlternativeModels].[AlternativeModel],  [dbo].[CompatibilityAlternativeModels].[OriginalModel],  [dbo].[CompatibilityAlternativeModels].[OriginalManufacturer]
go

