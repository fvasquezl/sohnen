-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_Warehouse_Kind]
(
	@AccountID int
)
RETURNS varchar(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(100)
	

	-- Add the T-SQL statements to compute the return value here
	
	set  @ResultVar = '';
	
	SELECT @ResultVar  = a.Family FROM Accounts a WHERE ID = @AccountID;

	IF @ResultVar  is null
	BEGIN
			set  @ResultVar = '';
	END
	
	
	RETURN @ResultVar;

END
go

