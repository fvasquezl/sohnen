
-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-04-29
-- Description:	Get Sku top sell qty by Dates
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSKUTopSellbyDate]
	@DATE1		NVARCHAR(8),
	@DATE2		NVARCHAR(8),
	@CATEGORY	NVARCHAR(50),
	@SEARCH		NVARCHAR(150)
AS
BEGIN
	DECLARE @SQL			NVARCHAR(4000),
			@CURSOR_DAYS	CURSOR,
			@SKU			INT,
			@DATE3			NVARCHAR(8),
			@DATE4			NVARCHAR(8),
			@CategoryID		INT
			--@isSearch		BIT
	SET NOCOUNT ON;
	SET ANSI_WARNINGS OFF;
	SET ANSI_WARNINGS ON;

	--SET @isSearch = ISNULL((CASE WHEN LEN(ISNULL(@SEARCH,'')) > 2 THEN 1 ELSE 0 END),0)

	IF(LEN(@SEARCH) > 7)
	BEGIN
		SET @CategoryID = ISNULL((SELECT TOP 1 CategoryID FROM Inventory.dbo.ProductCatalog WITH(NOLOCK) WHERE CONVERT(NVARCHAR,ID) LIKE @SEARCH),0)
		IF(@CategoryID > 0)
		BEGIN
			SET @CATEGORY = (CASE WHEN @CategoryID IN (15,16,17,18,63) THEN 'Original Lamps Bare - FP' 
								WHEN @CategoryID IN (5,6,7,8,61) THEN 'Original Lamps Bare - TV' 
								WHEN @CategoryID IN (88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143) THEN 'Original Lamps Bare - Other' 
								WHEN @CategoryID IN (19) THEN 'Generic Lamps Bare - FP' 
								WHEN @CategoryID IN (9) THEN 'Generic Lamps Bare - TV' 
								WHEN @CategoryID IN (91,114) THEN 'Generic Lamps Bare - Other' 
								WHEN @CategoryID IN (20,21,22,23,64) THEN 'Original Lamps with Housing - FP' 
								WHEN @CategoryID IN (10,11,12,13,62) THEN 'Original Lamps with Housing - TV' 
								WHEN @CategoryID IN (24) THEN 'Generic Lamps with Housing - FP' 
								WHEN @CategoryID IN (14) THEN 'Generic Lamps with Housing - TV' 
								WHEN @CategoryID IN (59) THEN 'Lamp Housing Kits - Rear Projection' 
								WHEN @CategoryID IN (60) THEN 'Lamp Housing Kits - Front Projection' 
								WHEN @CategoryID IN (69) THEN 'Lamp Burner' 
								WHEN @CategoryID IN (70) THEN 'Lamp Reflector' 
								WHEN @CategoryID IN (36) THEN 'Toys' 
								WHEN @CategoryID IN (158) THEN 'Mexican Handcrafted'
								WHEN @CategoryID IN (30) THEN 'TV Parts' 
								ELSE @CATEGORY END)
					
		END
	END

	CREATE TABLE #tmpReturnUpSell (SKU INT, QtyOrdered INT, Name NVARCHAR(500), CategoryID INT, CategoryName NVARCHAR(500), BackOrders INT, QOH INT, vQOH INT, tQOH INT, FBAQty INT, ManufacturerPN NVARCHAR(500))

	CREATE TABLE #tmpExecDays (SKU INT, TOTAL_DAYS INT, STOCK_DAYS INT, STOCK_PERCENT DECIMAL(13,2), VIRTUAL_DAYS INT)
	
	CREATE TABLE #tmpTopSell ( SKU INT, QuantityOrdered INT, Name NVARCHAR(500), CategoryID INT, Seq INT, ManufacturerPN NVARCHAR(500))
	
	--CREATE NONCLUSTERED INDEX IDX_tmpTopSell1 ON #tmpTopSell ([Seq]) INCLUDE ([SKU],[QuantityOrdered])

	--CREATE NONCLUSTERED INDEX IDX_tmpTopSell2 ON #tmpTopSell ([CategoryID]) INCLUDE ([SKU],[QuantityOrdered],[Name])

	CREATE TABLE #tmpFBAOrders ( SKU INT, QuantityOrdered INT, Name NVARCHAR(500), CategoryID INT, Seq INT, ManufacturerPN NVARCHAR(500) )

	CREATE TABLE #tblAssembly (SKU INT, SubSKU1 INT, SubSKU2 INT, SubSKU3 INT, CategoryID INT, QtyOrdered INT, Seq INT)

	CREATE TABLE #TMPTABLE (SKU INT, QtySold_R INT, Description NVARCHAR(4000), Category NVARCHAR(200), ManufacturerPN NVARCHAR(500))
	CREATE CLUSTERED INDEX IDX_TMPSKU ON #TMPTABLE(SKU)

	SET @DATE3 = CONVERT(NVARCHAR,DATEADD(DD,-1,DATEADD(DD,-DATEDIFF(DD,CONVERT(DATE,@DATE1),CONVERT(DATE,@DATE2)),CONVERT(DATE,@DATE1))),112)
	SET @DATE4 = CONVERT(NVARCHAR,DATEADD(DD,-1,CONVERT(DATE,@DATE1)),112)

	INSERT INTO #TMPTABLE
	EXEC Inventory.dbo.sp_GetSKUTopSellbyMonth @DATE3, @DATE4, @CATEGORY, @SEARCH

	INSERT INTO #tmpTopSell (SKU, QuantityOrdered, Name, CategoryID, Seq, ManufacturerPN)
	SELECT OD.SKU, SUM(OD.QuantityOrdered), PC.Name, PC.CategoryID, 0, PC.ManufacturerPN
	FROM OrderManager.dbo.[Order Details] OD WITH(NOLOCK)
	LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	ON CONVERT(NVARCHAR,PC.ID) = OD.SKU
	INNER JOIN OrderManager.dbo.Orders O WITH(NOLOCK)
	ON O.OrderNumber = OD.OrderNumber AND O.Cancelled = 0
	WHERE CONVERT(NVARCHAR,OD.DetailDate,112) BETWEEN @DATE1 AND @DATE2 AND
	--OD.OrderNumber IN (
	--	SELECT OrderNumber 
	--	FROM OrderManager.dbo.Orders (NOLOCK) WHERE CONVERT(NVARCHAR,OrderDate,112) BETWEEN @DATE1 AND @DATE2 --AND OrderStatus IN ('Shipped','Order Approved','Order Received','Payment Received','Pending Shipment')
	--) AND 
	OD.Adjustment = 0 AND PC.CategoryID IN (5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,10,11,12,13,62,20,21,22,23,64,14,24,59,60,69,70, 36 ,101,105,109,123,128,133,138,143,30, 158) --/*-*/--
	GROUP BY OD.SKU, PC.Name, PC.CategoryID, PC.ManufacturerPN
	ORDER BY SUM(OD.QuantityOrdered) DESC
	
	--START FBA INSERT
	--INSERT INTO #tmpFBAOrders (SKU, QuantityOrdered, Name, CategoryID, Seq)
	--SELECT amf.MITSKU, SUM(amfo.OrderQty), PC.Name, PC.CategoryID, 0
	--FROM Inventory.dbo.AmazonFBAOrders amfo WITH(NOLOCK)
	--LEFT JOIN Inventory.dbo.AmazonFBA amf WITH(NOLOCK)
	--ON amf.MerchantSKU = amfo.MerchantSKU AND amf.ASIN = amfo.ASIN
	--LEFT JOIN Inventory.dbo.ProductCatalog pc  WITH(NOLOCK)
	--ON pc.ID = amf.MITSKU
	--WHERE amfo.Completed = 'No' AND CONVERT(NVARCHAR,amfo.OrderDate,112) BETWEEN @DATE1 AND @DATE2 AND PC.CategoryID IN (5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,10,11,12,13,62,20,21,22,23,64,14,24,59,60,69,70, 36 ,101,105,109,123,128,133,138,143,30) --/*-*/--
	--GROUP BY amf.MITSKU, PC.Name, PC.CategoryID
	--END FBA INSERT

	--START BACK ORDER RECURSIVE
	INSERT INTO #tblAssembly (SKU, CategoryID, QtyOrdered, Seq)
	SELECT POD.SKU, PC.CategoryID, SUM(CONVERT(INT,POD.QtyBackOrdered)) AS QtyOrdered, 1
	FROM [Inventory].[dbo].PurchaseOrderData POD WITH(NOLOCK)
	INNER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	ON PC.ID = POD.SKU 
	AND ISNULL(PC.CategoryID,0) IN (5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,10,11,12,13,62,20,21,22,23,64,14,24,59,60,69,70, 36 ,101,105,109,123,128,133,138,143,30, 158) --/*-*/--
	WHERE ISNULL(POD.QtyBackOrdered,0) > 0
	GROUP BY POD.SKU, PC.CategoryID

	INSERT INTO #tblAssembly (SKU, SubSKU1, CategoryID, QtyOrdered, Seq)
	SELECT A.SKU, AD.SubSKU, PC.CategoryID, A.QtyOrdered, 2
	FROM #tblAssembly A
	INNER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
	ON AD.ProductCatalogID = A.SKU
	INNER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	ON PC.ID = AD.SubSKU
	WHERE A.Seq = 1

	INSERT INTO #tblAssembly (SKU, SubSKU1, SubSKU2, CategoryID, QtyOrdered, Seq)
	SELECT A.SKU, A.SubSKU1, AD.SubSKU, PC.CategoryID, A.QtyOrdered, 3
	FROM #tblAssembly A
	INNER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
	ON AD.ProductCatalogID = A.SubSKU1
	INNER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	ON PC.ID = AD.SubSKU
	WHERE A.Seq = 2

	INSERT INTO #tblAssembly (SKU, SubSKU1, SubSKU2, SubSKU3, CategoryID, QtyOrdered, Seq)
	SELECT A.SKU, A.SubSKU1, A.SubSKU2, AD.SubSKU, PC.CategoryID, A.QtyOrdered, 4
	FROM #tblAssembly A
	INNER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
	ON AD.ProductCatalogID = A.SubSKU2
	INNER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	ON PC.ID = AD.SubSKU
	WHERE A.Seq = 3
	--END BACK ORDER RECURSIVE

	IF(ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' OR ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' OR ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' OR ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' 
		OR ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' OR ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' OR ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' 
		OR ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' OR ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector')
	BEGIN
		SET @SQL = ' INSERT INTO #tmpTopSell (SKU, QuantityOrdered, Name, CategoryID, Seq, ManufacturerPN)
					SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 1, PC.ManufacturerPN
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '

		SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
								--WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								ELSE '0' END)

		SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.Name, PC.CategoryID, PC.ManufacturerPN '
		--PRINT(@SQL)
		EXEC(@SQL)
		
		--START V2
		SET @SQL = ' INSERT INTO #tmpTopSell (SKU, QuantityOrdered, Name, CategoryID, Seq, ManufacturerPN)
					SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 2, PC.ManufacturerPN
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC  WITH(NOLOCK)
					ON PC.ID = AD.SubSKU WHERE TTS.Seq = 1 AND PC.CategoryID IN ( '

		SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
								--WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								ELSE '0' END)

		SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.Name, PC.CategoryID, PC.ManufacturerPN '

		EXEC(@SQL)
		--END V2

		--START FBA GET ASSEMBLY
		--SET @SQL = ' INSERT INTO #tmpFBAOrders (SKU, QuantityOrdered, Name, CategoryID, Seq)
		--			SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 1
		--			FROM #tmpFBAOrders TTS
		--			LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
		--			ON AD.ProductCatalogID = TTS.SKU
		--			LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
		--			ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '

		--SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
		--						WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
		--						WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
		--						WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
		--						WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
		--						WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
		--						WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
		--						WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
		--						WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
		--						--WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
		--						ELSE '0' END)

		--SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.Name, PC.CategoryID '

		--EXEC(@SQL)
		--END FBA GET ASSEMBLY

		--START FBA GET ASSEMBLY V2
		--SET @SQL = ' INSERT INTO #tmpFBAOrders (SKU, QuantityOrdered, Name, CategoryID, Seq)
		--			SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 2
		--			FROM #tmpFBAOrders TTS
		--			LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
		--			ON AD.ProductCatalogID = TTS.SKU
		--			LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
		--			ON PC.ID = AD.SubSKU WHERE TTS.Seq = 1 AND PC.CategoryID IN ( '

		--SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
		--						WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
		--						WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
		--						WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
		--						WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
		--						WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
		--						WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
		--						WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
		--						WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
		--						--WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
		--						ELSE '0' END)

		--SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.Name, PC.CategoryID '

		--EXEC(@SQL)
		--END FBA GET ASSEMBLY V2
	END
	--END FIRST
	IF (ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector')
	BEGIN
		SET @SQL = ' INSERT INTO #tmpTopSell (SKU, QuantityOrdered, Name, CategoryID, Seq, ManufacturerPN)
					SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 3, PC.ManufacturerPN
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '
		
		SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' THEN '69' WHEN ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '70' ELSE '0' END)

		SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.Name, PC.CategoryID, PC.ManufacturerPN '

		EXEC(@SQL)
		
		----START FBA GET ASSEMBLY
		--SET @SQL = ' INSERT INTO #tmpFBAOrders (SKU, QuantityOrdered, Name, CategoryID, Seq)
		--			SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 3
		--			FROM #tmpFBAOrders TTS
		--			LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
		--			ON AD.ProductCatalogID = TTS.SKU
		--			LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
		--			ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '
		
		--SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' THEN '69' WHEN ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '70' ELSE '0' END)

		--SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.Name, PC.CategoryID '

		--EXEC(@SQL)
		--END FBA GET ASSEMBLY
	END
	
	SET @SQL = ' INSERT INTO #tmpReturnUpSell (SKU, QtyOrdered, Name, CategoryID, CategoryName, BackOrders, QOH, vQOH, tQOH, FBAQty, ManufacturerPN) 
				SELECT '
	SET @SQL = @SQL + (CASE WHEN ISNULL(@SEARCH,'') = 'TOP' THEN ' TOP 10 ' ELSE '' END)+' TBL.SKU, TBL.QtyOrdered, TBL.Name, TBL.CategoryID, TBL.CategoryName,
					ISNULL((SELECT SUM(Cast(QtyBackordered AS INT)) FROM [Inventory].[dbo].PurchaseOrderData WITH(NOLOCK) WHERE SKU = TBL.SKU),0) AS BackOrders,
					CONVERT(INT,ISNULL(GS.GlobalStock,0)) AS QOH, CONVERT(INT,ISNULL(GS.VirtualStock,0)) AS vQOH, CONVERT(INT,ISNULL(GS.TotalStock,0)) AS tQOH,
					ISNULL((SELECT SUM(QuantityOrdered) FROM #tmpFBAOrders WHERE SKU = TBL.SKU),0) AS FBAQty, TBL.ManufacturerPN
				FROM (
					SELECT TTS.SKU, SUM(TTS.QuantityOrdered) AS QtyOrdered, TTS.Name, TTS.CategoryID, C.Name AS CategoryName, TTS.ManufacturerPN
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN Inventory.dbo.Categories C WITH(NOLOCK)
					ON C.ID = TTS.CategoryID
					WHERE TTS.CategoryID IN ( '
	
	SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'

								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps with Housing - FP' THEN '20,21,22,23,64'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps with Housing - TV' THEN '10,11,12,13,62'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps with Housing - FP' THEN '24'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps with Housing - TV' THEN '14'

								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' THEN '69'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '70'

								WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								WHEN ISNULL(@CATEGORY,'') = 'TV Parts' THEN '30'
								WHEN ISNULL(@CATEGORY,'') = 'Mexican Handcrafted' THEN '158'
								ELSE '0' END)

	SET @SQL = @SQL + ' ) '
	IF(LEN(ISNULL(@SEARCH,'')) > 3)
	BEGIN
		SET @SQL = @SQL + ' AND (TTS.SKU LIKE ''%'+@SEARCH+'%'' OR TTS.Name LIKE ''%'+@SEARCH+'%'' OR TTS.ManufacturerPN LIKE ''%'+@SEARCH+'%'') '
	END

	SET @SQL = @SQL + ' GROUP BY TTS.SKU, TTS.Name, TTS.CategoryID, C.Name, TTS.ManufacturerPN
					) TBL
					LEFT OUTER JOIN Inventory.dbo.Global_Stocks GS WITH(NOLOCK)
					ON GS.ProductCatalogId = TBL.SKU
					ORDER BY TBL.QtyOrdered DESC '
	
	EXEC(@SQL)	
	--SET @CURSOR_DAYS = CURSOR FOR 
	--SELECT SKU FROM #tmpReturnUpSell GROUP BY SKU
	--OPEN @CURSOR_DAYS 
	--	FETCH NEXT FROM @CURSOR_DAYS 
	--	INTO @SKU	   
	--	WHILE (@@FETCH_STATUS = 0)
	--	BEGIN			
	--		SET @SQL=' INSERT INTO #tmpExecDays (SKU, TOTAL_DAYS, STOCK_DAYS, STOCK_PERCENT)
	--					SELECT * 
	--					FROM OPENROWSET(
	--						''SQLNCLI'',
	--						''Server=MITSQL;Database=Inventory;Uid=tempuser;Pwd=pLa13t1B'',
	--						''EXEC Inventory.dbo.sp_GetStockDays '+CONVERT(NVARCHAR,@SKU)+', '''''+@DATE1+''''','''''+@DATE2+''''' '')'
	--		EXEC(@SQL)			
	--		NEXT_FETCH:
	--		FETCH NEXT FROM @CURSOR_DAYS
	--		INTO @SKU
	--	END
	--CLOSE      @CURSOR_DAYS
	--DEALLOCATE @CURSOR_DAYS

	--Get Bin History	
	INSERT INTO #tmpExecDays (SKU, TOTAL_DAYS, STOCK_DAYS, STOCK_PERCENT, VIRTUAL_DAYS)
	SELECT SKU, (DATEDIFF(DD,CONVERT(DATETIME,@DATE1),CONVERT(DATETIME,@DATE2)) + 1) AS TOTAL_DAYS, SUM(CASE WHEN ISNULL(Global_Stock,0) > 0 THEN 1 ELSE 0 END) AS STOCK_DAYS,
		CONVERT(DECIMAL(13,2),((CONVERT(DECIMAL,SUM(CASE WHEN ISNULL(Global_Stock,0) > 0 THEN 1 ELSE 0 END)) / CONVERT(DECIMAL,(DATEDIFF(DD,CONVERT(DATETIME,@DATE1),CONVERT(DATETIME,@DATE2)) + 1))) * 100)) AS STOCK_PERCENT,
		SUM(CASE WHEN (ISNULL(Virtual_Stock,0) + ISNULL(Global_Stock,0)) > 0 THEN 1 ELSE 0 END) AS VIRTUAL_DAYS
	FROM Inventory.dbo.BinMovement (NOLOCK)
	WHERE SKU IN (SELECT SKU FROM #tmpReturnUpSell GROUP BY SKU) AND CONVERT(NVARCHAR,Activity_Date,112) BETWEEN @DATE1 AND @DATE2
	GROUP BY SKU

	IF(ISNULL(@SEARCH,'') = 'TOP')
	BEGIN
		SELECT TOP 10 A.SKU, A.QtyOrdered AS QtySold_R
		FROM #tmpReturnUpSell A
		--LEFT OUTER JOIN #tmpExecDays B
		--ON B.SKU = A.SKU
		ORDER BY A.QtyOrdered DESC
	END
	ELSE
	BEGIN
		SELECT SKU, QtySold_R, TotalDays, StockDays, PercentInStock, Description,  Category, BackOrders, QOH, vQOH, tQOH, PendingFBA_R, DailyRunRate, MonthlyRunRate, MOpt, BackOrdersRecursive, InventoryDays, LastQtySold_R, PercentSellTrend, VirtualDays, RealStockDays,
			CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(RealStockDays,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(QtySold_R,0)) / CONVERT(DECIMAL(13,2),ISNULL(RealStockDays,0))) ELSE 0 END)) AS RDailyRunRate, @CATEGORY AS CategorySelect, ManufacturerPN
		FROM (
			SELECT SKU, QtySold_R, TotalDays, StockDays, PercentInStock, Description,  Category, BackOrders, QOH, vQOH, tQOH, PendingFBA_R, DailyRunRate, MonthlyRunRate, MOpt, BackOrdersRecursive, InventoryDays, LastQtySold_R, PercentSellTrend, VirtualDays, Inventory.dbo.fn_Get_RealStockbyDate(@DATE1, @DATE2, A.SKU,  ROUND(A.DailyRunRate,0)) AS RealStockDays, ManufacturerPN
			FROM (
			SELECT A.SKU, A.QtyOrdered AS QtySold_R, B.TOTAL_DAYS AS TotalDays, B.STOCK_DAYS AS StockDays, CONVERT(INT,B.STOCK_PERCENT) AS 'PercentInStock', A.Name AS Description, A.CategoryName AS Category, A.BackOrders, A.QOH, A.vQOH, A.tQOH, A.FBAQty AS PendingFBA_R,
				CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(B.VIRTUAL_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.VIRTUAL_DAYS,0))) ELSE 0 END)) AS DailyRunRate,
				(CONVERT(INT,(CASE WHEN ISNULL(B.VIRTUAL_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.VIRTUAL_DAYS,0))) ELSE 0 END)) * 30) AS MonthlyRunRate, 
				ISNULL((SELECT SUM(Quantity) FROM Inventory.dbo.MissedOpportunities WHERE SKU = A.SKU AND CONVERT(NVARCHAR,DateRequested,112) BETWEEN @DATE1 AND @DATE2 GROUP BY SKU),0) AS MOpt
				--((CONVERT(INT,(CASE WHEN ISNULL(B.STOCK_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.STOCK_DAYS,0))) ELSE 0 END)) * 30) - A.QtyOrdered) AS LostUnitSalesRecursive, 
				--D.AvgCost, C.UnitCost AS LastCost, C.PODate AS LastOrderDate
				,ISNULL(
				(SELECT SUM(QtyOrdered)
					FROM (
					SELECT SKU, QtyOrdered FROM #tblAssembly
					WHERE SKU = A.SKU OR SubSKU1 = A.SKU OR SubSKU2 = A.SKU OR SubSKU3 = A.SKU
					GROUP BY SKU, QtyOrdered
				) TBL),0) AS BackOrdersRecursive, 
				CONVERT(INT,ROUND((CASE WHEN CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(B.STOCK_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.STOCK_DAYS,0))) ELSE 0 END)) > 0 THEN CONVERT(DECIMAL(13,2),A.tQOH) / CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(B.STOCK_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.STOCK_DAYS,0))) ELSE 0 END)) ELSE 0 END),0)) AS InventoryDays,
				ISNULL(TMP.QtySold_R,0) AS LastQtySold_R,
				(CASE WHEN CONVERT(DECIMAL(13,2),ISNULL(TMP.QtySold_R,0)) > 0 THEN CONVERT(DECIMAL(13,2),((ISNULL(A.QtyOrdered,0) - ISNULL(TMP.QtySold_R,0)) / CONVERT(DECIMAL(13,2),ISNULL(TMP.QtySold_R,0))) * 100.00) ELSE 0 END) AS PercentSellTrend
				,B.VIRTUAL_DAYS AS VirtualDays, A.ManufacturerPN
			FROM #tmpReturnUpSell A
			LEFT OUTER JOIN #tmpExecDays B
			ON B.SKU = A.SKU
			LEFT OUTER JOIN #TMPTABLE TMP
			ON TMP.SKU = A.SKU
			--OUTER APPLY Inventory.dbo.fn_GetLastCostDateBasedOnPO(A.SKU) C
			--OUTER APPLY Inventory.dbo.fn_GetAvgCostBasedOnPO(A.SKU, @DATE2) D
			) A
		) B
		ORDER BY QtySold_R DESC, SKU
	END
END
go

