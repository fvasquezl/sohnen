-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <12-8-2014>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Bins_Email_Inventory_At_Date]
@pDate datetime, @pStart int, @pEnd int, @pEmail NVARCHAR(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


--IF TempReport Exists Delete It First
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Inventory' AND  TABLE_NAME = 'TempReport')
BEGIN
	DROP TABLE [Inventory].[dbo].[TempReport]
END

DECLARE @Bin_id varchar(10);
DECLARE @qty int;
DECLARE @flow int;
DECLARE @id int;
DECLARE @name varchar(254);
DECLARE	@categoryId int;
DECLARE @categoryName varchar(50);
DECLARE @us_qty_in int;
DECLARE @mx_qty_in int;
DECLARE @df_qty_in int;
DECLARE @tr_qty_in int;
DECLARE @TOTAL_qty_in int;

DECLARE @us_qty_out int;
DECLARE @mx_qty_out int;
DECLARE @df_qty_out int;
DECLARE @tr_qty_out int;
DECLARE @TOTAL_qty_out int;
DECLARE @ProductCatalogId int;

DECLARE @totalqtyin int;


DECLARE @start int;
DECLARE @end int;

DECLARE @InventoryAtDate TABLE (id int
							, ProductCatalogId INT
							, name varchar(254)
							, categoryId int
							, CategoryName varchar(50)
							, US_Stock int
							, MX_Stock int
							, Defective_Stock int
							, Transit_Stock int
							, Total_Stock int
							);





INSERT INTO @InventoryAtDate( id, ProductCatalogId ,name, categoryId) 
SELECT * FROM (

					SELECT   ROW_NUMBER() OVER (ORDER BY ID asc) AS RowNumber, id, name,categoryid
							
                    FROM  [Inventory].[dbo].[ProductCatalog] 
                                 
       
                 ) as mytable
				 WHERE mytable.RowNumber between  @pStart and @pEnd;



 
UPDATE Inventory.dbo.Bins_History SET WarehouseID = Inventory.dbo.fn_Get_Bin_WarehouseID(Bin_Id) WHERE WarehouseID is null;

DECLARE curhistory CURSOR
	FOR SELECT ProductCatalogId 	, name	, categoryId, inventory.dbo.fn_GetCategoryName(categoryId) FROM @InventoryAtDate;
OPEN curhistory

FETCH NEXT FROM curhistory
INTO  @ProductCatalogId 	, @name	, @categoryId, @categoryname;


WHILE @@FETCH_STATUS = 0
BEGIN

		SELECT @us_qty_in =	 SUM(CASE WHEN (Flow =1) AND (WarehouseId = 'US') THEN a.Qty ELSE 0 END	)
			   ,@mx_qty_in = SUM(CASE WHEN (Flow =1) AND (WarehouseId = 'MX') THEN a.Qty ELSE 0 END	)
			   ,@df_qty_in = SUM(CASE WHEN (Flow =1) AND (WarehouseId = 'DF') THEN a.Qty ELSE 0 END	)
			   ,@tr_qty_in = SUM(CASE WHEN (Flow =1) AND (WarehouseId = 'TR') THEN a.Qty ELSE 0 END	)
			   ,@TOTAL_qty_in = SUM(CASE WHEN (Flow =1)  THEN a.Qty ELSE 0 END	)

			   ,@us_qty_out = SUM(CASE WHEN (Flow =2) AND (WarehouseId = 'US') THEN a.Qty ELSE 0 END	)
			   ,@mx_qty_out = SUM(CASE WHEN (Flow =2) AND (WarehouseId = 'MX') THEN a.Qty ELSE 0 END	)
			   ,@df_qty_out = SUM(CASE WHEN (Flow =2) AND (WarehouseId = 'DF') THEN a.Qty ELSE 0 END	)
			   ,@tr_qty_out = SUM(CASE WHEN (Flow =2) AND (WarehouseId = 'TR') THEN a.Qty ELSE 0 END	)
			   ,@TOTAL_qty_out = SUM(CASE WHEN (Flow =2)  THEN a.Qty ELSE 0 END	)
		FROM Bins_History a
		 WHERE (Product_Catalog_ID = @ProductCatalogId) AND (stamp <= @pDate) ;


		 IF  @us_qty_in is null SET  @us_qty_in = 0;
		 IF  @mx_qty_in is null SET  @mx_qty_in = 0;
		 IF  @tr_qty_in is null SET  @tr_qty_in = 0;
		 IF  @df_qty_in is null SET  @df_qty_in = 0;
		 IF  @TOTAL_qty_in is null SET  @TOTAL_qty_in = 0;

		 IF  @us_qty_out is null SET  @us_qty_out = 0;
		 IF  @mx_qty_out is null SET  @mx_qty_out = 0;
		 IF  @tr_qty_out is null SET  @tr_qty_out = 0;
		 IF  @df_qty_out is null SET  @df_qty_out = 0;
		 IF  @TOTAL_qty_out is null SET  @TOTAL_qty_out = 0;
  
	     UPDATE  @InventoryAtDate SET 
							CategoryName = @categoryname
							, US_Stock = @us_qty_in - @us_qty_out
							, MX_Stock = @mx_qty_in - @mx_qty_out
							, Defective_Stock = @df_qty_in - @df_qty_out
							, Transit_Stock =@tr_qty_in - @tr_qty_out 
							, Total_Stock =@TOTAL_qty_in - @Total_qty_out 
			WHERE ProductCatalogId = @ProductCatalogId;
	

		FETCH NEXT FROM curhistory
			INTO  @ProductCatalogId 	, @name	, @categoryId, @categoryname;

END 
CLOSE curhistory;
DEALLOCATE curhistory;

DECLARE @sql NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
DECLARE @date VARCHAR(12)
DECLARE @reportdate VARCHAR(MAX)
DECLARE @filename NVARCHAR(MAX)
DECLARE @subtext VARCHAR(50)
DECLARE @subject VARCHAR(62)
DECLARE @recipients VARCHAR(255)

SET @date = @pDate
SET @reportdate = Replace(rtrim(ltrim(@date)),' ','-')

Select * into [Inventory].[dbo].[TempReport]  from @InventoryAtDate


SET @sql = 'SELECT [ProductCatalogId] AS ''sep=,' + CHAR(13) + CHAR(10) + 'SKU''
      ,Replace([name],'','','' '') AS ''Name''
      ,[categoryId] AS ''CategoryID''
      ,[CategoryName] AS ''CategoryName''
      ,[US_Stock] AS ''US_Stock''
      ,[MX_Stock] AS ''MX_Stock''
      ,[Defective_Stock] AS ''Defective_Stock''
      ,[Transit_Stock] AS ''Transit_Stock''
      ,[Total_Stock] 
	  FROM [Inventory].[dbo].[TempReport]'

SET @subtext = 'Inventory Report - '
--SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
SET @filename = 'InventoryReport-'+@reportdate+'.csv'
SET @subject = @subtext + @date
SET @recipients = @pEmail
SET @body ='<html><center><H1>Inventory Report - <br>' + @date + '</H1><br><br> <body bgcolor=yellow><br><br>Regards,<br>AutoBot by MI Technologies, Inc</body></html>'



If @body is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',
@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML',
@query =  @sql,
@query_attachment_filename = @filename,
@query_result_separator = ',',
@query_result_no_padding = 1,
@attach_query_result_as_file = 1


END

--DROP TEMPREPORT TABLE
BEGIN
	DROP TABLE [Inventory].[dbo].[TempReport]
END

END
go

