CREATE PROCEDURE [dbo].[sp_MergeSKU]
@RetainSKU nvarchar(10),
@DeletedSKU nvarchar(10)

AS 

BEGIN
INSERT INTO [Inventory].[dbo].[MergedSKUHistory] ([RetainedSKU],[DeletedSKU],[TimeStamp])
VALUES (@RetainSKU, @DeletedSKU, GetDate())

UPDATE Inventory.[dbo].[ProductCatalog]
SET [Description] = CONCAT([Description],' - MERGED ',@DeletedSKU)
WHERE Cast([ID] AS nvarchar(10)) = @RetainSKU

UPDATE OrderManager.dbo.[Order Details]
SET SKU = @RetainSKU
WHERE SKU = @DeletedSKU

UPDATE [OrderManager].[dbo].[Lists] 
SET Text2 = @RetainSKU
WHERE Text2 = @DeletedSKU

UPDATE [OrderManager].[dbo].[AliasSKUs] 
SET ParentSKU =  @RetainSKU 
WHERE ParentSKU =  @DeletedSKU 

UPDATE Inventory.dbo.AssemblyDetails
SET SubSKU = @RetainSKU
WHERE SubSKU = @DeletedSKU

UPDATE MiTech.amz.Amazon
SET ProductSKU = @RetainSKU
WHERE ProductSKU = @DeletedSKU

UPDATE [Inventory].[dbo].[ChannelManagementDB]
SET [ProductCatalogID] = @RetainSKU
WHERE [ProductCatalogID] = @DeletedSKU

UPDATE [Inventory].[dbo].[Compatibility]
SET [ProductCatalogID] = @RetainSKU
WHERE [ProductCatalogID] = @DeletedSKU

UPDATE MITDB.dbo.ProjectorData
SET EncSKU = @RetainSKU
WHERE EncSKU = @DeletedSKU

UPDATE MITDB.dbo.ProjectorData
SET EncSKUPH = @RetainSKU
WHERE EncSKUPH = @DeletedSKU

UPDATE MITDB.dbo.ProjectorData
SET BareSKU = @RetainSKU
WHERE BareSKU = @DeletedSKU

UPDATE MITDB.dbo.ProjectorData
SET BareSKUPH = @RetainSKU
WHERE BareSKUPH = @DeletedSKU

UPDATE MITDB.dbo.ProjectorData
SET BareSKUOS = @RetainSKU
WHERE BareSKUOS = @DeletedSKU

UPDATE [184.106.104.133].[DiscountTVL9.3.1].[dbo].[Inventory]
SET [VendorFullSKU] = @RetainSKU
WHERE [VendorFullSKU] = @DeletedSKU


DELETE FROM Inventory.dbo.Suppliers
WHERE ProductCatalogId = @DeletedSKU

END
go

