
-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-05-17
-- Description:	Get Sku top sell qty by Dates and SKU
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSKUTopSellbySKU]
	@SKU		INT,
	@DATE1		NVARCHAR(8),
	@DATE2		NVARCHAR(8),
	@CATEGORY	NVARCHAR(50)
AS
BEGIN
	DECLARE @SQL			NVARCHAR(4000),
			@CURSOR_DAYS	CURSOR,
			@SKU_NEW		INT
	SET NOCOUNT ON;
	SET ANSI_WARNINGS OFF;
	SET ANSI_WARNINGS ON;

	CREATE TABLE #tmpReturnUpSell (SKU INT, QtyOrdered INT, CategoryID INT, BackOrders INT, QOH INT, vQOH INT, tQOH INT)

	CREATE TABLE #tmpExecDays (SKU INT, TOTAL_DAYS INT, STOCK_DAYS INT, STOCK_PERCENT DECIMAL(13,2), VIRTUAL_DAYS INT)

	CREATE TABLE #tmpTopSell ( SKU INT, QuantityOrdered INT, CategoryID INT, Seq INT )

	CREATE TABLE #tmpOMPrice ( OrderNumber INT, OrderDate NVARCHAR(10), SKU INT, Product NVARCHAR(500), QuantityOrdered INT, WebSKU NVARCHAR(200), OrderStatus NVARCHAR(50), PricePerUnit DECIMAL(13,2))
	
	INSERT INTO #tmpTopSell (SKU, QuantityOrdered, CategoryID, Seq)
	SELECT OD.SKU, SUM(OD.QuantityOrdered), PC.CategoryID, 0
	FROM OrderManager.dbo.[Order Details] OD WITH(NOLOCK)
	LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	ON CONVERT(NVARCHAR,PC.ID) = OD.SKU
	INNER JOIN OrderManager.dbo.Orders O WITH(NOLOCK)
	ON O.OrderNumber = OD.OrderNumber AND O.Cancelled = 0
	WHERE CONVERT(NVARCHAR,OD.DetailDate,112) BETWEEN @DATE1 AND @DATE2 AND
	--OD.OrderNumber IN (
	--	SELECT OrderNumber 
	--	FROM OrderManager.dbo.Orders (NOLOCK) WHERE CONVERT(NVARCHAR,OrderDate,112) BETWEEN @DATE1 AND @DATE2 --AND OrderStatus IN ('Shipped','Order Approved','Order Received','Payment Received','Pending Shipment')
	--) AND 
	OD.Adjustment = 0 AND PC.CategoryID IN (5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,10,11,12,13,62,20,21,22,23,64,14,24,59,60,69,70, 36 ,101,105,109,123,128,133,138,143,30, 158) --/*-*/--
	GROUP BY OD.SKU, PC.CategoryID
	ORDER BY SUM(OD.QuantityOrdered) DESC
	
	IF(ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' OR ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' OR ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' OR ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' 
		OR ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' OR ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' OR ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' 
		OR ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' OR ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector')
	BEGIN
		SET @SQL = ' INSERT INTO #tmpTopSell (SKU, QuantityOrdered, CategoryID, Seq)
					SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.CategoryID, 1
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '

		SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'								
								WHEN ISNULL(@CATEGORY,'') = 'Mexican Handcrafted' THEN '158'
								ELSE '0' END)

		SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.CategoryID '
		--PRINT(@SQL)
		EXEC(@SQL)
		
		--START V2
		SET @SQL = ' INSERT INTO #tmpTopSell (SKU, QuantityOrdered, CategoryID, Seq)
					SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.CategoryID, 2
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
					ON PC.ID = AD.SubSKU WHERE TTS.Seq = 1 AND PC.CategoryID IN ( '

		SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
								--WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								ELSE '0' END)

		SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.CategoryID '

		EXEC(@SQL)
	END
	
	IF (ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector')
	BEGIN
		SET @SQL = ' INSERT INTO #tmpTopSell (SKU, QuantityOrdered, CategoryID, Seq)
					SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.CategoryID, 3
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '
		
		SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' THEN '69' WHEN ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '70' ELSE '0' END)

		SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.CategoryID '

		EXEC(@SQL)
	END
	
	SET @SQL = ' INSERT INTO #tmpReturnUpSell (SKU, QtyOrdered, CategoryID, BackOrders, QOH, vQOH, tQOH) 
				SELECT TBL.SKU, TBL.QtyOrdered, TBL.CategoryID,
					ISNULL((SELECT SUM(Cast(QtyBackordered AS INT)) FROM [Inventory].[dbo].PurchaseOrderData (NOLOCK) WHERE SKU = TBL.SKU),0) AS BackOrders,
					CONVERT(INT,ISNULL(GS.GlobalStock,0)) AS QOH, CONVERT(INT,ISNULL(GS.VirtualStock,0)) AS vQOH, CONVERT(INT,ISNULL(GS.TotalStock,0)) AS tQOH
				FROM (
					SELECT TTS.SKU, SUM(TTS.QuantityOrdered) AS QtyOrdered, TTS.CategoryID
					FROM #tmpTopSell TTS
					WHERE TTS.CategoryID IN ( '
	
	SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'

								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps with Housing - FP' THEN '20,21,22,23,64'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps with Housing - TV' THEN '10,11,12,13,62'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps with Housing - FP' THEN '24'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps with Housing - TV' THEN '14'

								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' THEN '69'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '70'
								WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								WHEN ISNULL(@CATEGORY,'') = 'TV Parts' THEN '30'
								WHEN ISNULL(@CATEGORY,'') = 'Mexican Handcrafted' THEN '158'
								ELSE '0' END)

	SET @SQL = @SQL + ' )  AND TTS.SKU = '''+CONVERT(NVARCHAR,@SKU)+'''  '

	SET @SQL = @SQL + '	GROUP BY TTS.SKU, TTS.CategoryID
				) TBL
				LEFT OUTER JOIN Inventory.dbo.Global_Stocks GS (NOLOCK)
				ON GS.ProductCatalogId = TBL.SKU
				ORDER BY TBL.QtyOrdered DESC '
	
	EXEC(@SQL)
	
	--SET @CURSOR_DAYS = CURSOR FOR 

	--SELECT SKU FROM #tmpReturnUpSell GROUP BY SKU

	--OPEN @CURSOR_DAYS 
	--	FETCH NEXT FROM @CURSOR_DAYS 
	--	INTO @SKU_NEW
	   
	--	WHILE (@@FETCH_STATUS = 0)
	--	BEGIN
			
	--		SET @SQL=' INSERT INTO #tmpExecDays (SKU, TOTAL_DAYS, STOCK_DAYS, STOCK_PERCENT)
	--					SELECT * 
	--					FROM OPENROWSET(
	--						''SQLNCLI'',
	--						''Server=MITSQL;Database=Inventory;Uid=tempuser;Pwd=pLa13t1B'',
	--						''EXEC Inventory.dbo.sp_GetStockDays '+CONVERT(NVARCHAR,@SKU_NEW)+', '''''+@DATE1+''''','''''+@DATE2+''''' '')'
	--		EXEC(@SQL)
			
	--		NEXT_FETCH:
	--		FETCH NEXT FROM @CURSOR_DAYS
	--		INTO @SKU_NEW
	--	END
	--CLOSE      @CURSOR_DAYS
	--DEALLOCATE @CURSOR_DAYS

	--Get Bin History
	INSERT INTO #tmpExecDays (SKU, TOTAL_DAYS, STOCK_DAYS, STOCK_PERCENT, VIRTUAL_DAYS)
	SELECT SKU, (DATEDIFF(DD,CONVERT(DATETIME,@DATE1),CONVERT(DATETIME,@DATE2)) + 1) AS TOTAL_DAYS, SUM(CASE WHEN ISNULL(Global_Stock,0) > 0 THEN 1 ELSE 0 END) AS STOCK_DAYS,
		CONVERT(DECIMAL(13,2),((CONVERT(DECIMAL,SUM(CASE WHEN ISNULL(Global_Stock,0) > 0 THEN 1 ELSE 0 END)) / CONVERT(DECIMAL,(DATEDIFF(DD,CONVERT(DATETIME,@DATE1),CONVERT(DATETIME,@DATE2)) + 1))) * 100)) AS STOCK_PERCENT,
		SUM(CASE WHEN (ISNULL(Virtual_Stock,0) + ISNULL(Global_Stock,0)) > 0 THEN 1 ELSE 0 END) AS VIRTUAL_DAYS
	FROM Inventory.dbo.BinMovement (NOLOCK)
	WHERE SKU IN (SELECT SKU FROM #tmpReturnUpSell GROUP BY SKU) AND CONVERT(NVARCHAR,Activity_Date,112) BETWEEN @DATE1 AND @DATE2
	GROUP BY SKU

	--Get OM Info
	INSERT INTO #tmpOMPrice ( OrderNumber, OrderDate, SKU, Product, QuantityOrdered, WebSKU, OrderStatus, PricePerUnit)
		EXEC Inventory.dbo.sp_GetOMOredersbySKU @SKU, @DATE1, @DATE2, @CATEGORY

SELECT SKU, QtySold_R, TotalDays, StockDays, PercentInStock, BackOrders, QOH, vQOH, tQOH, 
	CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(RealStockDays,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(QtySold_R,0)) / CONVERT(DECIMAL(13,2),ISNULL(RealStockDays,0))) ELSE 0 END)) AS RDailyRunRate,
MonthlyRunRate, 
CONVERT(DECIMAL(13,2),(TotalDays - RealStockDays)) * CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(RealStockDays,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(QtySold_R,0)) / CONVERT(DECIMAL(13,2),ISNULL(RealStockDays,0))) ELSE 0 END)) AS LostUnitSalesRecursive,
AvgSalesPriceRecursive, 
CONVERT(DECIMAL(13,2),(TotalDays - RealStockDays)) * CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(RealStockDays,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(QtySold_R,0)) / CONVERT(DECIMAL(13,2),ISNULL(RealStockDays,0))) ELSE 0 END)) * 
			CONVERT(DECIMAL(13,2),((SELECT SUM(PricePerUnit * QuantityOrdered) FROM #tmpOMPrice) / QtySold_R)) AS TotalLostRevenueRecursive, 
AvgCost, LastCost, LastOrderDate, RealStockDays
FROM (
	SELECT SKU, QtySold_R, TotalDays, StockDays, PercentInStock, BackOrders, QOH, vQOH, tQOH, 
	--RDailyRunRate, 
	MonthlyRunRate, 
	--LostUnitSalesRecursive, 
	AvgSalesPriceRecursive, 
	--TotalLostRevenueRecursive, 
	AvgCost, LastCost, LastOrderDate,
		Inventory.dbo.fn_Get_RealStockbyDate(@DATE1, @DATE2, A.SKU,  ROUND(A.DailyRunRate,0)) AS RealStockDays
	FROM (

		SELECT A.SKU, 
			A.QtyOrdered AS QtySold_R, 
			B.TOTAL_DAYS AS TotalDays, 
			B.STOCK_DAYS AS StockDays, 
			CONVERT(INT,B.STOCK_PERCENT) AS 'PercentInStock', 
			A.BackOrders, 
			A.QOH, 
			A.vQOH, 
			A.tQOH,

			--CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(B.STOCK_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.STOCK_DAYS,0))) ELSE 0 END)) AS DailyRunRate,
			CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(B.VIRTUAL_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.VIRTUAL_DAYS,0))) ELSE 0 END)) AS DailyRunRate,

			(CONVERT(INT,(CASE WHEN ISNULL(B.STOCK_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.STOCK_DAYS,0))) ELSE 0 END)) * 30) AS MonthlyRunRate,

			--CONVERT(DECIMAL(13,2),(B.TOTAL_DAYS - B.STOCK_DAYS)) * CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(B.STOCK_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.STOCK_DAYS,0))) ELSE 0 END)) AS LostUnitSalesRecursive, 

			CONVERT(DECIMAL(13,2),((SELECT SUM(PricePerUnit * QuantityOrdered) FROM #tmpOMPrice) / A.QtyOrdered)) AS AvgSalesPriceRecursive, 

			--CONVERT(DECIMAL(13,2),(B.TOTAL_DAYS - B.STOCK_DAYS)) * CONVERT(DECIMAL(13,2),(CASE WHEN ISNULL(B.STOCK_DAYS,0) > 0 THEN (CONVERT(DECIMAL(13,2),ISNULL(A.QtyOrdered,0)) / CONVERT(DECIMAL(13,2),ISNULL(B.STOCK_DAYS,0))) ELSE 0 END)) * 
			--CONVERT(DECIMAL(13,2),((SELECT SUM(PricePerUnit * QuantityOrdered) FROM #tmpOMPrice) / A.QtyOrdered)) AS TotalLostRevenueRecursive, 
		
			D.AvgCost, 
			C.UnitCost AS LastCost, 
			CONVERT(NVARCHAR,C.PODate,101) AS LastOrderDate
		FROM #tmpReturnUpSell A
		LEFT OUTER JOIN #tmpExecDays B
		ON B.SKU = A.SKU
		OUTER APPLY Inventory.dbo.fn_GetLastCostDateBasedOnPO(A.SKU) C
		OUTER APPLY Inventory.dbo.fn_GetAvgCostBasedOnPO(A.SKU, @DATE2) D

	) A
) B
ORDER BY B.QtySold_R DESC
END

go

