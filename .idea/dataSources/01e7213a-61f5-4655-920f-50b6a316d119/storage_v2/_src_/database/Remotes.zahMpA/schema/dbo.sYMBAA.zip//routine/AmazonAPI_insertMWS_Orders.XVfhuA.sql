-- =============================================
-- Author:		Hubet Cardenas Isla
-- Create date: 2017-03-24
-- Description:	Insert Amazon Markerplace Web Service
-- Modify date: 2017-06-05
-- Description:	Add new option to get updated orders
-- =============================================
CREATE PROCEDURE [dbo].[AmazonAPI_insertMWS_Orders] 
	-- Add the parameters for the stored procedure here
	@LatestShipDate NVARCHAR(50) = NULL,
	@OrderType NVARCHAR(50) = NULL,
	@PurchaseDate NVARCHAR(50) = NULL,
	@AmazonOrderId NVARCHAR(50) = NULL,
	@LastUpdateDate NVARCHAR(50) = NULL,
	@IsReplacementOrder NVARCHAR(50) = NULL,
	@ShipServiceLevel NVARCHAR(50) = NULL,
	@NumberOfItemsShipped NVARCHAR(50) = NULL,
	@OrderStatus NVARCHAR(50) = NULL,
	@SalesChannel NVARCHAR(50) = NULL,
	@IsBusinessOrder NVARCHAR(50) = NULL,
	@NumberOfItemsUnshipped NVARCHAR(50) = NULL,
	@IsPremiumOrder NVARCHAR(50) = NULL,
	@EarliestShipDate NVARCHAR(50) = NULL,
	@FulfillmentChannel NVARCHAR(50) = NULL,
	@PaymentMethod NVARCHAR(50) = NULL,
	@IsPrime NVARCHAR(50) = NULL,
	@ShipmentServiceLevelCategory NVARCHAR(50) = NULL,
	@SellerOrderId NVARCHAR(50) = NULL,
	@pOption NVARCHAR(50) = NULL
AS
DECLARE @Exist INT,
		@dtLatestShipDate DATETIME,
		@dtPurchaseDate DATETIME,
		@dtLastUpdateDate DATETIME,
		@dtEarliestShipDate DATETIME
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET @pOption = ISNULL(@pOption, '')
	-- Insert statements for procedure here
	IF @pOption = ''
	BEGIN
		SET @dtLatestShipDate = CONVERT(DATETIME, @LatestShipDate)
		SET @dtPurchaseDate = CONVERT(DATETIME, @PurchaseDate)
		SET @dtLastUpdateDate = CONVERT(DATETIME, @LastUpdateDate)
		SET @dtEarliestShipDate = CONVERT(DATETIME, @EarliestShipDate)
	
		SELECT @Exist = COUNT(*)
		  FROM [dbo].[AmazonAPI_Orders] WITH(NOLOCK)
		 WHERE AmazonOrderId = @AmazonOrderId
	 
		IF(@Exist <= 0)
		BEGIN
			INSERT INTO [dbo].[AmazonAPI_Orders] ([LatestShipDate],
														[OrderType],
														[PurchaseDate],
														[AmazonOrderId],
														[LastUpdateDate],
														[IsReplacementOrder],
														[ShipServiceLevel],
														[NumberOfItemsShipped],
														[OrderStatus],
														[SalesChannel],
														[IsBusinessOrder],
														[NumberOfItemsUnshipped],
														[IsPremiumOrder],
														[EarliestShipDate],
														[FulfillmentChannel],
														[PaymentMethod],
														[IsPrime],
														[ShipmentServiceLevelCategory],
														[SellerOrderId])
												 VALUES(@dtLatestShipDate,
														@OrderType,
														@dtPurchaseDate,
														@AmazonOrderId,
														@dtLastUpdateDate,
														@IsReplacementOrder,
														@ShipServiceLevel,
														@NumberOfItemsShipped,
														@OrderStatus,
														@SalesChannel,
														@IsBusinessOrder,
														@NumberOfItemsUnshipped,
														@IsPremiumOrder,
														@dtEarliestShipDate,
														@FulfillmentChannel,
														@PaymentMethod,
														@IsPrime,
														@ShipmentServiceLevelCategory,
														@SellerOrderId)
		END
		ELSE
		BEGIN
			UPDATE [dbo].[AmazonAPI_Orders]
			   SET [LatestShipDate] = @dtLatestShipDate,
				   [OrderType] = @OrderType,
				   [PurchaseDate] = @dtPurchaseDate,
				   [AmazonOrderId] = @AmazonOrderId,
				   [LastUpdateDate] = @dtLastUpdateDate,
				   [IsReplacementOrder] = @IsReplacementOrder,
				   [ShipServiceLevel] = @ShipServiceLevel,
				   [NumberOfItemsShipped] = @NumberOfItemsShipped,
				   [OrderStatus] = @OrderStatus,
				   [SalesChannel] = @SalesChannel,
				   [IsBusinessOrder] = @IsBusinessOrder,
				   [NumberOfItemsUnshipped] = @NumberOfItemsUnshipped,
				   [IsPremiumOrder] = @IsPremiumOrder,
				   [EarliestShipDate] = @dtEarliestShipDate,
				   [FulfillmentChannel] = @FulfillmentChannel,
				   [PaymentMethod] = @PaymentMethod,
				   [IsPrime] = @IsPrime,
				   [ShipmentServiceLevelCategory] = @ShipmentServiceLevelCategory,
				   [SellerOrderId] = @SellerOrderId,
  				   [StampChange] = GETDATE()
			 WHERE [AmazonOrderId] = @AmazonOrderId
		END
	END
	ELSE
	BEGIN
		--SELECT O.[AmazonOrderID]
		--  FROM [AmazonExclusiveBulbs].[dbo].[Orders] AS O WITH(NOLOCK) 
		-- WHERE O.[OrderStatus] NOT IN ('Shipped', 'Canceled')
		-- --AND CONVERT(VARCHAR(8), PurchaseDate, 112) = CONVERT(VARCHAR(8), GETDATE(), 112)
		-- ORDER BY O.FulfillmentChannel ASC, O.[PurchaseDate] ASC
		-- --ORDER BY O.[StampInsert] ASC
		SELECT O.[AmazonOrderID]
		  FROM [dbo].[AmazonAPI_Orders] AS O WITH(NOLOCK) 
		  LEFT OUTER JOIN [dbo].[AmazonAPI_OrderDetails] AS OD WITH(NOLOCK)
		    ON O.[AmazonOrderId] = OD.[AmazonOrderId]
		 WHERE O.[OrderStatus] NOT IN ('Shipped', 'Canceled')
		 GROUP BY O.[AmazonOrderID],
				  O.[FulfillmentChannel],
				  REPLACE(SUBSTRING(OD.[SellerSKU], LEN(OD.[SellerSKU]) - 2, 3), 'FLX', '1'),
				  O.[PurchaseDate]
		 ORDER BY O.[FulfillmentChannel] ASC,
		          REPLACE(SUBSTRING(OD.[SellerSKU], LEN(OD.[SellerSKU]) - 2, 3), 'FLX', '1') ASC,
				  O.[PurchaseDate] ASC
	END
END
go

