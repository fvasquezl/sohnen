-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-2-2016
-- Description:	ADSI Update Order Manager with Tracking Information
-- =============================================
CREATE PROCEDURE [dbo].[sp_ADSIUpdateTracking] 
	-- Add the parameters for the stored procedure here
		@pOrderNumber AS INT,
		@pCost AS DECIMAL(10,2),
		@pCarrier AS NVARCHAR(10),
		@pPounds AS INT,
		@pOunces AS INT,
		@pShippingMethod AS NVARCHAR(50),
		@pDeclaredValue AS DECIMAL(10,2),
		@pTrackingNumber AS NVARCHAR(200)
AS
BEGIN
	DECLARE @COUNT INT = 0
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [Inventory].[dbo].[ADSITrackingHistory] (
	   [OrderNumber]
      ,[Cost]
      ,[Carrier]
      ,[Pounds]
      ,[Ounces]
      ,[ShippingMethod]
      ,[DeclareValue]
      ,[TrackingNumber]) 
	  VALUES 
	  (@pOrderNumber, @pCost, @pCarrier, @pPounds,	@pOunces, @pShippingMethod, @pDeclaredValue, @pTrackingNumber)

	IF ( EXISTS(SELECT 1 FROM [OrderManager].[dbo].[Tracking] WITH(NOLOCK) where [OrderNum] = @pOrderNumber AND [TrackingID] = @pTrackingNumber) )
	BEGIN
	GOTO ENDALL
	END
		--Upload Tracking to Tracking Table
		INSERT INTO [OrderManager].[dbo].[Tracking] 
			([OrderNum]
			  ,[PickupDate]
			  ,[Cost]
			  ,[Carrier]
			  ,[EmailSent]
			  ,[StatusSent]
			  ,[IsVoid]
			  ,[Notes]
			  ,[AZSent]
			  ,[Pounds]
			  ,[Ounces]
			  ,[ShippersMethod]
			  ,[RegisteredMail]
			  ,[InsuredMail]
			  ,[CertifiedMail]
			  ,[RestrictedDelivery]
			  ,[CertificateOfMailing]
			  ,[ReturnReceipt]
			  ,[DeliveryConfirmation]
			  ,[SignatureConfirmation]
			  ,[COD]
			  ,[FlatRate]
			  ,[DazzleInsurance]
			  ,[CODAmount]
			  ,[DeclaredValue]
			  ,[Details]
			  ,[FlatBox]
			  ,[DateAdded]
			  ,[TrackingID]
			  ,[NumericKey]
			  ,[CostCurrencyType]
			  ,[ValueCurrencyType]
			  ,[External])
		VALUES (@pOrderNumber
			  ,CONVERT (NVARCHAR(10), GETDATE(),101) -- [PickupDate]
			  ,@pCost -- [Cost]
			  ,REPLACE(@pCarrier,'OnTrac','ONTRC') -- [Carrier]
			  ,'0' -- [EmailSent]
			  ,'0' -- [StatusSent]
			  ,NULL -- [IsVoid]
			  ,'Processed by ADSI' -- [Notes]
			  ,'0' -- [AZSent]
			  ,@pPounds -- [Pounds]
			  ,@pOunces -- [Ounces]
			  ,@pShippingMethod -- [ShippersMethod]
			  ,'0' -- [RegisteredMail]
			  ,'0' -- [InsuredMail]
			  ,'0' -- [CertifiedMail]
			  ,'0' -- [RestrictedDelivery]
			  ,'0' -- [CertificateOfMailing]
			  ,'0' -- [ReturnReceipt]
			  ,'0' -- [DeliveryConfirmation]
			  ,'0' -- [SignatureConfirmation]
			  ,'0' -- [COD]
			  ,'0' -- [FlatRate]
			  ,NULL -- [DazzleInsurance]
			  ,'0' -- [CODAmount]
			  ,@pDeclaredValue -- [DeclaredValue]
			  ,NULL -- [Details]
			  ,'0' -- [FlatBox]
			  ,GETDATE() -- [DateAdded]
			  ,@pTrackingNumber -- [TrackingID]
			  ,@pOrderNumber -- [NumericKey]
			  ,'USD' -- [CostCurrencyType]
			  ,'USD' -- [ValueCurrencyType]
			  ,'0') -- [External]


	
ENDALL:
		--Set Order as Shipped
		  UPDATE [OrderManager].[dbo].[Orders] SET [OrderStatus] = 'Shipped', [OrderStatusChanged] = '1', [OrdStatDetail] = 'Processed by ADSI: '+CONVERT (NVARCHAR(10), GETDATE(),101) WHERE [OrderNumber] = @pOrderNumber

		--Set Items as Shipped
		  UPDATE [OrderManager].[dbo].[Order Details] SET [Status] = 'Shipped', [DateShipped] = GETDATE(), [StatusChanged] = '1' WHERE [OrderNumber] = @pOrderNumber AND [Adjustment] = 0

		--this WHILE will travel 2 times as long as it has not been inserted
		BEGIN TRY 
		
			--REPEAT AS SOMETIMES IT WONT GO THROUGH DUE TO LOCKS

			WHILE((NOT EXISTS(SELECT * FROM [OrderManager].[dbo].[Orders] WITH(NOLOCK) WHERE [OrderStatus] = 'Shipped' AND [OrderStatusChanged] = '1' AND [OrderNumber] = @pOrderNumber AND [OrdStatDetail] LIKE 'Processed by ADSI:%')) AND @COUNT < 2)
			BEGIN
				--Set Order as Shipped
				UPDATE [OrderManager].[dbo].[Orders] SET [OrderStatus] = 'Shipped', [OrderStatusChanged] = '1', [OrdStatDetail] = 'Processed by ADSI: '+CONVERT (NVARCHAR(10), GETDATE(),101) WHERE [OrderNumber] = @pOrderNumber
				SET @COUNT = @COUNT + 1
			END

			SET @COUNT = 0
		
			WHILE((NOT EXISTS(SELECT * FROM [OrderManager].[dbo].[Order Details] WITH(NOLOCK) WHERE [Status] = 'Shipped' AND [StatusChanged] = '1' AND [OrderNumber] = @pOrderNumber AND [Adjustment] = 0)) AND @COUNT < 2)
			BEGIN
				--Set Items as Shipped
				UPDATE [OrderManager].[dbo].[Order Details] SET [Status] = 'Shipped', [DateShipped] = GETDATE(), [StatusChanged] = '1' WHERE [OrderNumber] = @pOrderNumber AND [Adjustment] = 0
				SET @COUNT = @COUNT + 1
			END

		END TRY  
		BEGIN CATCH
			PRINT('Error to insert or table lock')
		END CATCH

		/* Last Code x2
		--REPEAT AS SOMETIMES IT WONT GO THROUGH DUE TO LOCKS
		--Set Order as Shipped
		UPDATE [OrderManager].[dbo].[Orders] SET [OrderStatus] = 'Shipped', [OrderStatusChanged] = '1', [OrdStatDetail] = 'Processed by ADSI: '+CONVERT (NVARCHAR(10), GETDATE(),101) WHERE [OrderNumber] = @pOrderNumber
		--Set Items as Shipped
		UPDATE [OrderManager].[dbo].[Order Details] SET [Status] = 'Shipped', [DateShipped] = GETDATE(), [StatusChanged] = '1' WHERE [OrderNumber] = @pOrderNumber AND [Adjustment] = 0
		*/
END
go

