








-- ==========================================================================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-02-26
-- Description:	Get WebSKU or Cart ID
-- Test Script: EXEC Inventory.dbo.sp_GetWebSKUCartIDbyOrder 6499298, 107018
-- ==========================================================================================


CREATE PROCEDURE [dbo].[sp_GetWebSKUCartIDbyOrder] (@OrderNumber	INT, @SKU INT)
AS
BEGIN
	DECLARE	@CartID INT, @WebSKU NVARCHAR(150), @RETURN INT = 0, @CustomerID INT, @Product NVARCHAR(400), @PONumber NVARCHAR(255)

	SET NOCOUNT ON;
	SELECT @CartID = ISNULL(CartID, 0), @CustomerID = ISNULL(CustomerID, 0), @PONumber = ISNULL(PONumber, 0) FROM OrderManager.dbo.Orders WHERE OrderNumber = @OrderNumber 
	
	IF(ISNULL(@CartID, 0) = 77) BEGIN
		SET @RETURN = 1
		SET @WebSKU = ISNULL((SELECT TOP 1 CONVERT(NVARCHAR,SUBSTRING(Product,CHARINDEX('{',Product)+1,CHARINDEX('}',Product)-2)) FROM OrderManager.dbo.[Order Details] WHERE OrderNumber = @OrderNumber AND SKU = @SKU AND Adjustment = 0),'')
	END
	ELSE IF(ISNULL(@CartID, 0) = 8) BEGIN
		SET @RETURN = 3
		SET @WebSKU = ISNULL((SELECT TOP 1 WebSKU FROM OrderManager.dbo.[Order Details] WHERE OrderNumber = @OrderNumber AND SKU = @SKU AND Adjustment = 0),'')
	END
	ELSE BEGIN
		SET @WebSKU = ISNULL((SELECT TOP 1 WebSKU FROM ( SELECT A.WebSKU, A.SKU, A.OrderNumber, A.QuantityOrdered, COUNT(B.WebSKU) AS SKUCOUNT
									 FROM OrderManager.dbo.[Order Details] A LEFT OUTER JOIN Inventory.dbo.Shipped_serialnumbers B ON B.ProductCatalogId = A.SKU AND B.WebSKU = A.WebSKU AND B.OrderNumber = A.OrderNumber 
									 WHERE A.OrderNumber = @OrderNumber AND A.SKU = CONVERT(NVARCHAR, @SKU)
									 GROUP BY A.WebSKU, A.SKU, A.OrderNumber, A.QuantityOrdered) C WHERE SKUCOUNT < QuantityOrdered ORDER BY C.WebSKU),'')
		SET @RETURN = 2
		IF((SELECT COUNT(*) FROM Inventory.dbo.Users WHERE customerid = @CustomerID) > 0) BEGIN
			SET @RETURN = 3
		END
	END

	IF((SELECT COUNT(OrderNumber) FROM OrderManager.dbo.Orders WHERE OrderInst LIKE '%<<P>>%' AND OrderNumber = @OrderNumber) > 0) BEGIN
		SET @RETURN = 3
	END
	IF (@CustomerID = 1206686 OR @CustomerID = 618554) BEGIN
		SET @RETURN = 4
	END

	--IF(@RETURN = 3) BEGIN
		SELECT TOP 1 @Product = Product FROM OrderManager.dbo.[Order Details] WHERE OrderNumber = @OrderNumber AND SKU = CONVERT(NVARCHAR,@SKU) AND ISNULL(WebSKU,'') = ISNULL(@WebSKU,'') ORDER BY ItemNumber DESC
	--END
	
	SELECT @CustomerID AS [CustomerID],  @RETURN AS Type, SUBSTRING(@WebSKU,1,16) AS WebSKU, ISNULL(@Product, '') AS Product, ISNULL(@PONumber, '') AS PONumber
	-- SELECT @CustomerID AS [CustomerID],  @RETURN AS Type, '51749-G_5381' AS WebSKU, 'Sanyo POA-LMP100 Compatible Housing (51749-G_5381)' AS Product, ISNULL(@PONumber, '') AS PONumber
END



go

