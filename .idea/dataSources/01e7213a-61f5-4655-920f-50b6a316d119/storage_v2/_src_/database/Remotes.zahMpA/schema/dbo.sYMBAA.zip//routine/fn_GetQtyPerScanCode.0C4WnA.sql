-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-14-2018
-- Description:	Get Bin Breakdown by SKU
-- =============================================
CREATE FUNCTION [dbo].[fn_GetQtyPerScanCode] 
(	
	-- Add the parameters for the function here
	@pSKU nvarchar(10)	 
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT [ScanCode], SUM([StockQty]) AS [Qty] FROM [Remotes].[dbo].[BinStock] AS BS WITH (NOLOCK)
	LEFT OUTER JOIN [Remotes].[dbo].[BinMaster] AS BM WITH(NOLOCK) ON (BS.[BinID] = BM.[BinID])
	WHERE BM.[WarehouseID] NOT LIKE '%GY%'
	AND BS.[SKU] = @pSKU
	GROUP BY [ScanCode]	

)
go

