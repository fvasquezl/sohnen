-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-05-18
-- Description:	Get Bin History Movements by Day
-- =============================================
CREATE PROCEDURE [dbo].[sp_Bin_HistoryMovements]
	--@ROW1			INT,
	--@ROW2			INT
AS
BEGIN
	DECLARE-- @CURSOR_DAYS	CURSOR,
			@CURSOR_SKUS	CURSOR,
			--@NEW_DATE		DATE,
			--@INITIAL_DATE	DATE,
			--@FINAL_DATE		DATE,
			@SKU			INT,
			--@DATES			DATE,
			--@LAST_QTY		INT,
			@NEW_QTY		INT,
			--@DATE1			DATE,
			--@DATE2			DATE
			@DF_QTY			INT,
			@RC_QTY			INT,
			@TM_QTY			INT,
			@VQOH			INT
	SET NOCOUNT ON;

	--DROP TABLE #tmpDays
	CREATE TABLE #tmpDays (Dates DATE)
	CREATE NONCLUSTERED INDEX IDX_tmpDays ON #tmpDays ( Dates )

	--SET @DATE1 = DATEADD(DAY,-1,GETDATE())
	--SET @DATE2 = GETDATE()

	--SET @INITIAL_DATE = GETDATE()
	--SET @NEW_DATE = CONVERT(DATE,'2014-01-01')--DATEADD(YEAR,-6,@INITIAL_DATE)
	--SET @FINAL_DATE = GETDATE()
	--SET @INITIAL_DATE = @NEW_DATE

	--DROP TABLE #tmpSKUHistory
	--CREATE TABLE #tmpSKUHistory (SKU INT, Global_Stock INT, Activity_Date DATE) -- , id INT, TransactionId INT, mydate DATE, Bin_Id NVARCHAR(6), Reason NVARCHAR(2500), inputs INT, outputs INT, globalqty INT, username NVARCHAR(250), comments NVARCHAR(2500))
	--CREATE NONCLUSTERED INDEX IDX_tmpSKUHistory ON #tmpSKUHistory ( SKU )

	--WHILE(@NEW_DATE <= @FINAL_DATE)
	--BEGIN
	--	INSERT INTO #tmpDays (Dates) VALUES (@NEW_DATE)
	--	SET @NEW_DATE = DATEADD(DD,1,@NEW_DATE)
	--END
	
	SET @CURSOR_SKUS = CURSOR FOR 

	--WITH mytable AS (
		SELECT ID --, ROW_NUMBER() OVER (ORDER BY ID ASC) AS RowNumber
		FROM Inventory.dbo.ProductCatalog WITH(NOLOCK)-- where id = 134782
	--where id not in (SELECT SKU FROM Inventory.dbo.BinMovement (NOLOCK) GROUP BY SKU )
	--)
	--SELECT ID
	--FROM mytable
	--WHERE RowNumber BETWEEN @ROW1 AND @ROW2

	OPEN @CURSOR_SKUS 
		FETCH NEXT FROM @CURSOR_SKUS 
		INTO @SKU
	   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--DELETE FROM #tmpSKUHistory
			
			--INSERT INTO #tmpSKUHistory (id, TransactionId, mydate, Bin_Id, Reason, inputs, outputs, globalqty, username, comments)
			--EXEC Inventory.dbo.sp_Bins_History @SKU, @INITIAL_DATE, @FINAL_DATE

			--INSERT INTO #tmpSKUHistory (SKU, Global_Stock, Activity_Date)
			--SELECT SKU, Global_Stock, Activity_Date FROM Inventory.dbo.BinMovement WITH(NOLOCK)
			--WHERE SKU = @SKU AND Activity_Date BETWEEN  @INITIAL_DATE AND @FINAL_DATE
			--ORDER BY Activity_Date ASC

			--UPDATE #tmpSKUHistory SET SKU = @SKU

			--SET @NEW_QTY = 0
			--SET @LAST_QTY = 0

			--SET @CURSOR_DAYS = CURSOR FOR 

			--SELECT Dates FROM #tmpDays

			--OPEN @CURSOR_DAYS 
			--	FETCH NEXT FROM @CURSOR_DAYS 
			--	INTO @DATES
	   
			--	WHILE (@@FETCH_STATUS = 0)
			--	BEGIN
					--SET @NEW_QTY = NULL

					SET @NEW_QTY = ISNULL((SELECT SUM(Counter) FROM Inventory.dbo.Bin_Content WITH(NOLOCK) WHERE ProductCatalog_Id = @SKU AND SUBSTRING(Bin_id,1,2) NOT IN ('CD','DF','RC','TM','PR','RT')),0)

					SET @DF_QTY = ISNULL((SELECT SUM(Counter) FROM Inventory.dbo.Bin_Content WITH(NOLOCK) WHERE ProductCatalog_Id = @SKU AND SUBSTRING(Bin_id,1,2) IN ( 'CD','DF','PR','RT')),0)

					SET @RC_QTY = ISNULL((SELECT SUM(Counter) FROM Inventory.dbo.Bin_Content WITH(NOLOCK) WHERE ProductCatalog_Id = @SKU AND SUBSTRING(Bin_id,1,2) = 'RC'),0)

					SET @TM_QTY = ISNULL((SELECT SUM(Counter) FROM Inventory.dbo.Bin_Content WITH(NOLOCK) WHERE ProductCatalog_Id = @SKU AND SUBSTRING(Bin_id,1,2) = 'TM'),0)

					--SET @VQOH = ISNULL((
					--	SELECT SUM(QOH)
					--	FROM (
					--		SELECT AD.SubSKU, 
					--		ISNULL((
					--			SELECT SUM(Counter) FROM Inventory.dbo.Bin_Content BC WITH(NOLOCK) WHERE BC.ProductCatalog_Id = AD.ProductCatalogID AND SUBSTRING(Bin_id,1,2) NOT IN ('CD','DF','RC','TM','PR','RT')
					--		),0) AS QOH
					--		FROM Inventory.dbo.AssemblyDetails AD WITH(NOLOCK)
					--		WHERE AD.SubSKU = @SKU
					--	) TBL
					--	GROUP BY SubSKU
					--),0)

					SET @VQOH = ISNULL((
						SELECT TOP 1 CONVERT(INT,VirtualStock) FROM Inventory.dbo.Global_Stocks WITH(NOLOCK) WHERE ProductCatalogId = @SKU
					),0)

					--PRINT(@NEW_QTY)
					--(SELECT globalqty FROM #tmpSKUHistory WHERE mydate = @DATES AND SKU = @SKU AND TransactionId = (SELECT MAX(TransactionId) FROM #tmpSKUHistory WHERE mydate = @DATES AND SKU = @SKU))
			
					--IF(@NEW_QTY IS NULL)
					--BEGIN
					--	SET @NEW_QTY = @LAST_QTY
					--END

					--IF(@DATES BETWEEN @DATE1 AND @DATE2)
					--BEGIN
						IF(EXISTS(SELECT * FROM Inventory.dbo.BinMovement WITH(NOLOCK) WHERE SKU = @SKU AND Activity_Date = CONVERT(DATE,GETDATE())))
						BEGIN
							UPDATE Inventory.dbo.BinMovement SET Global_Stock = @NEW_QTY, Virtual_Stock = @VQOH WHERE SKU = @SKU AND Activity_Date = CONVERT(DATE,GETDATE())
						END
						ELSE
						BEGIN
							INSERT INTO Inventory.dbo.BinMovement (SKU,Activity_Date,Global_Stock,Virtual_Stock) VALUES (@SKU,GETDATE(),@NEW_QTY,@VQOH)
						END

						INSERT INTO Inventory.[dbo].[BinTotalMovement] (SKU, Global_Stock) VALUES (@SKU,@NEW_QTY)
					--END
					--UPDATE @tmpDays SET Qty = @NEW_QTY WHERE Dates = @DATES

					--SET @LAST_QTY = @NEW_QTY

					INSERT INTO Inventory.dbo.BinSKUMovement (Bin_Id, SKU, Counter_Stock) 
					SELECT Bin_Id, ProductCatalog_Id, [Counter] FROM Inventory.dbo.Bin_Content WITH(NOLOCK) WHERE ProductCatalog_Id = @SKU

					IF(EXISTS(SELECT * FROM Inventory.dbo.[BinOtherMovement] WITH(NOLOCK) WHERE [SKU] = @SKU AND [Activity_Date] = CONVERT(DATE,GETDATE()) AND [BinType] IN ( 'CD', 'DF','PR','RT')))
					BEGIN
						UPDATE Inventory.dbo.[BinOtherMovement] SET [Global_Stock] = @DF_QTY WHERE SKU = @SKU AND Activity_Date = CONVERT(DATE,GETDATE()) AND [BinType] IN ( 'CD', 'DF','PR','RT')
					END
					ELSE
					BEGIN
						INSERT INTO [Inventory].[dbo].[BinOtherMovement] ([SKU],[Activity_Date],[Global_Stock],[BinType]) VALUES (@SKU,GETDATE(),@DF_QTY,'DF')
					END

					IF(EXISTS(SELECT * FROM Inventory.dbo.[BinOtherMovement] WITH(NOLOCK) WHERE [SKU] = @SKU AND [Activity_Date] = CONVERT(DATE,GETDATE()) AND [BinType] = 'RC'))
					BEGIN
						UPDATE Inventory.dbo.[BinOtherMovement] SET [Global_Stock] = @RC_QTY WHERE SKU = @SKU AND Activity_Date = CONVERT(DATE,GETDATE()) AND [BinType] = 'RC'
					END
					ELSE
					BEGIN
						INSERT INTO [Inventory].[dbo].[BinOtherMovement] ([SKU],[Activity_Date],[Global_Stock],[BinType]) VALUES (@SKU,GETDATE(),@RC_QTY,'RC')
					END

					IF(EXISTS(SELECT * FROM Inventory.dbo.[BinOtherMovement] WITH(NOLOCK) WHERE [SKU] = @SKU AND [Activity_Date] = CONVERT(DATE,GETDATE()) AND [BinType] = 'TM'))
					BEGIN
						UPDATE Inventory.dbo.[BinOtherMovement] SET [Global_Stock] = @TM_QTY WHERE SKU = @SKU AND Activity_Date = CONVERT(DATE,GETDATE()) AND [BinType] = 'TM'
					END
					ELSE
					BEGIN
						INSERT INTO [Inventory].[dbo].[BinOtherMovement] ([SKU],[Activity_Date],[Global_Stock],[BinType]) VALUES (@SKU,GETDATE(),@TM_QTY,'TM')
					END

					--
					--

			--		NEXT_FETCH2:
			--		FETCH NEXT FROM @CURSOR_DAYS
			--		INTO @DATES
			--	END
			--CLOSE      @CURSOR_DAYS
			--DEALLOCATE @CURSOR_DAYS
			
			NEXT_FETCH:
			FETCH NEXT FROM @CURSOR_SKUS
			INTO @SKU
		END
	CLOSE      @CURSOR_SKUS
	DEALLOCATE @CURSOR_SKUS
END
go

