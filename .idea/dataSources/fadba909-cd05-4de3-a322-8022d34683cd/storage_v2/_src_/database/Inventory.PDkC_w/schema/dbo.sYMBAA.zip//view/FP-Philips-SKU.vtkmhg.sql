CREATE VIEW dbo.[FP-Philips-SKU]
AS
SELECT     dbo.Compatibility.PartNumber, dbo.Compatibility.Manufacturer, dbo.ProductCatalog.ID, dbo.ProductCatalog.CustomField04 AS BareLamp
FROM         dbo.Compatibility LEFT OUTER JOIN
                      dbo.ProductCatalog ON dbo.Compatibility.ProductCatalogID = dbo.ProductCatalog.ID LEFT OUTER JOIN
                      dbo.ProductLines ON dbo.ProductCatalog.ProductLineID = dbo.ProductLines.ID
WHERE     (dbo.ProductLines.ID = 36) AND (dbo.ProductCatalog.Name LIKE '%(PHILIPS)%')
go

