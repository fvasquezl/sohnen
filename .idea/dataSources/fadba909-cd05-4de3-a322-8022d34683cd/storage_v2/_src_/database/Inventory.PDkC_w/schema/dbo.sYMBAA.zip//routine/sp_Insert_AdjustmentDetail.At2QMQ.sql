-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Insert_AdjustmentDetail]
	-- Add the parameters for the stored procedure here
	(
		@pAdjustmentId as integer , @pFlow as integer ,  @pOrigin as integer, @pDestination as integer,
		@pProductId as integer, @pQty as real 
		,@pBin_Id as char(6) = ''
	)
AS
BEGIN

-- Reorgnaize Index on ProductCatalog table ----------
--ALTER INDEX ALL ON Inventory.[dbo].[ProductCatalog] REORGANIZE
------------------------------------------------------

	-- requires local variables
	DECLARE @SubSKU int;
	DECLARE @SubSKUQTYRequired real;
	DECLARE @WarehouseID int;
	DECLARE @IsAssamblyRequired bit ;
	DECLARE @IsSerialized bit;
	DECLARE @IsAutoSerial bit;
	DECLARE @i int;
	DECLARE @NextValue int;
	
	--Insert Adjustment Details
	
	INSERT INTO InventoryAdjustmentDetails (InventoryAdjustmentsID, ProductCatalogID, Quantity, Bin_id)
			VALUES (@pAdjustmentId, @pProductId, @pQty, @pBin_Id);
	
		
	IF @pFlow = 1  --Add - INBOUND
	BEGIN
	
		-- update location
		 UPDATE Inventory  SET Quantity = Quantity + @pQty WHERE (ProductCatalogID = @pProductId) AND (AccountID = @pOrigin ) ;
		-- Update Product Catalog
		-- UPDATE ProductCatalog  SET  CurrentStock = CurrentStock + @pQty WHERE (ID = @pProductId) ;
		 
		-- Update Global_Stocks
		--UPDATE Global_Stocks SET GlobalStock = GlobalStock +  @pQty WHERE (ProductCatalogID = @pProductId) ;
		
	END		
	
	IF @pFlow = 2  --Deduction - OUTBOUND
	BEGIN
		-- update location
		UPDATE Inventory  SET Quantity = Quantity - @pQty WHERE (ProductCatalogID = @pProductId) AND (AccountID = @pOrigin ) ;
		--  Update Product Catalog
		--UPDATE ProductCatalog  SET  CurrentStock = CurrentStock - @pQty WHERE (ID = @pProductId) ;
		 
		-- Update Global_Stocks
		--UPDATE Global_Stocks SET GlobalStock = GlobalStock -  @pQty WHERE (ProductCatalogID = @pProductId) ;
	END	
	
	
	IF @pFlow = 3 -- TRANSFER
	BEGIN
		-- update location addition
		 UPDATE Inventory  SET Quantity = Quantity - @pQty WHERE (ProductCatalogID = @pProductId) AND (AccountID = @pOrigin ) ;
		
		-- update location deduction
		 UPDATE Inventory  SET Quantity = Quantity + @pQty WHERE (ProductCatalogID = @pProductId) AND (AccountID = @pDestination ) ;
		 
		-- Update Global_Stocks
		
	END
	
	
	
	-- Recalculate Vitual inventory for related products
	-- just remove the comment and virtual quantity will work in each movement (live mode)
	--exec inventory.dbo.sp_project_virtual_inventory @pProductId;
	
	--- Generate serial numbers if it's required
	SET @IsAutoSerial = 0;
	SET @IsSerialized = 0;
	SET @i = 1;
	
	SELECT @IsSerialized = serialized
			, @IsAutoSerial = AutoSerial
			, @NextValue = NextSerialValue FROM ProductCatalog WHERE id = @pProductId;
	
	IF (@IsAutoSerial = 1) AND ( @IsSerialized = 1)
	BEGIN
			WHILE @i <= @pQty
				BEGIN
				
					INSERT INTO [Inventory].[dbo].[SerialNumbers] (ProductCatalogID, SerialNumber, InventoryAdjustmentID)
					VALUES (@pProductId, @i, @pAdjustmentId);
				
					SET @i = @i +1;
				END
				
			UPDATE ProductCatalog SET NextSerialValue = NextSerialValue + @pQty 
			WHERE ID = @pProductId ;
	
	END
	
	
END
go

