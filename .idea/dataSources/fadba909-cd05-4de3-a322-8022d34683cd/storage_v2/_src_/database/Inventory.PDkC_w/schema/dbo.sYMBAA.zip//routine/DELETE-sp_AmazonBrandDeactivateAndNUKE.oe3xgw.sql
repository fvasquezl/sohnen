-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 8-4-2018
-- Description:	Delete/Nuke Active=0 listings in Amazon
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonBrandDeactivateAndNUKE] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--------------------------------------------------------------------------------
	---------------------Amazon Brand DeActivate Moved Here-------------------------
	--------------------------------------------------------------------------------

	--Begin updating AmazonBrandDeactivate List
	INSERT INTO [Inventory].[dbo].[AmazonBrandDeactivate]([Brand], [Deactivate])
	SELECT distinct AZ.[manufacturer] as [Brand],
					'0' AS [Deactiveate]
	  FROM [Inventory].[dbo].[Amazon] AS AZ
	  WHERE AZ.[manufacturer] NOT IN (SELECT [Brand] FROM [Inventory].[dbo].[AmazonBrandDeactivate] WHERE [Brand] = AZ.[manufacturer])
	  AND AZ.[manufacturer] != '' AND AZ.[manufacturer] IS NOT NULL

	INSERT INTO [Inventory].[dbo].[AmazonBrandDeactivate]([Brand], [Deactivate])
	  SELECT distinct [BrandMentioned] as [Brand],
  					'0' AS [Deactiveate]
	  FROM [Inventory].[dbo].[Amazon] AS AZ
	  WHERE AZ.[BrandMentioned] NOT IN (SELECT [Brand] FROM [Inventory].[dbo].[AmazonBrandDeactivate] WHERE [Brand] = AZ.[BrandMentioned])
	  AND AZ.[BrandMentioned] != '' AND AZ.[BrandMentioned] IS NOT NULL

	---------------------------------------------------------------------------

	--DO A RESET
	--UPDATE [Inventory].[dbo].[Amazon] SET IsActive = '1' WHERE IsActive = '0' OR IsActive IS NULL

	---FORCE DISACTIAVATE LIST (inventory.dbo.AmazonFoceDisactivate)
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 0 WHERE [ASIN] IN (SELECT [ASIN] FROM [Inventory].[dbo].[AmazonForceDisactivate] (NOLOCK) WHERE [CountryCode] = 'US') AND [CountryCode] = 'US'
	
	--DISACTIVATE BASED ON BRANDS
	 UPDATE AZ SET AZ.[IsActive] = 0 FROM [Inventory].[dbo].[Amazon] AS AZ
	  LEFT OUTER JOIN [Inventory].[dbo].[AmazonBrandDeactivate] AS AZBD 
			ON (AZ.[BrandMentioned] = AZBD.[Brand] OR AZ.[manufacturer] = AZBD.[Brand])
	  WHERE AZ.[CountryCode] = 'US' 
	  AND AZBD.[Deactivate] = 1
	  AND AZ.[IsActive] = 1

	--DISACTIVATE BASED ON ALL_LISTING_REPORT TITLE having brand in the BrandDisactivate Table
	IF OBJECT_ID('[Inventory].[dbo].[TempBrands]') IS NOT NULL
	DROP TABLE [Inventory].[dbo].[TempBrands]

	CREATE TABLE [Inventory].[dbo].[TempBrands] ([ASIN] NVARCHAR(MAX), [MerchantSKU] NVARCHAR(MAX), [Title] NVARCHAR(MAX), [Brand] NVARCHAR(MAX))
	
	DECLARE @brand nvarchar(200)

	DECLARE db_cursor CURSOR FOR 
	Select [Brand] from [Inventory].[dbo].[AmazonBrandDeactivate] WHERE [Deactivate] = 1
		--Would remove listings FOR Infocus - ALL REAL BRANDS SHOULD GO HERE
		AND [Brand] NOT LIKE '%InFocus%'
		--Too Short of a Brand
		AND LEN([Brand]) > 3 

		OPEN db_cursor  
		FETCH NEXT FROM db_cursor INTO @brand  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
      
			  INSERT INTO [Inventory].[dbo].[TempBrands] ([ASIN],[MerchantSKU],[Title],[Brand])
			  SELECT [asin1], [seller_sku], [item_name], @brand FROM [AmazonExclusiveBulbs].[dbo].[All_Listings_Report] WHERE [item_name] LIKE '%'+@brand+'%'

			  FETCH NEXT FROM db_cursor INTO @brand 
		END 

		CLOSE db_cursor  
		DEALLOCATE db_cursor 

	--SELECT * FROM [Inventory].[dbo].[TempBrands]

	--UPDATE AMAZON DBO TABLE
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 0 WHERE [ASIN] IN (SELECT [ASIN] FROM [Inventory].[dbo].[TempBrands])

	------------UK-------
	---DISACTIVATE ALL EXCEPT AURABEAM AND GENERIC IN UK----
	UPDATE [Inventory].[dbo].[Amazon] SET IsActive = '0' WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK'
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 1 WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK' AND BrandMentioned like '%aurabeam%'
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 1 WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK' AND BrandMentioned like '%generic%'
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 1 WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK' AND BrandMentioned like '%compatible%'
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 1 WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK' AND BrandMentioned like '%lutema%'
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 1 WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK' AND BrandMentioned like '%philips%'
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 1 WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK' AND BrandMentioned like '%osram%'
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 1 WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK' AND BrandMentioned like '%phoenix%'
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 1 WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK' AND BrandMentioned like '%ushio%'
	UPDATE [Inventory].[dbo].[Amazon] SET [IsActive] = 0 WHERE ChannelName = 'Amazon' AND [CountryCode] = 'UK' AND BrandMentioned like '%Alda PQ%'

	--------------------------------------------------------------------------------------
	---------------------------NEGATIVE KEYWORDS MOVED HERE-------------------------------
	---------------------------------------------------------------------------------------

	UPDATE AZ SET AZ.[IsActive] = '0'
    FROM [Inventory].[dbo].[Amazon] AS AZ
    WHERE (AZ.[Title] LIKE '%HDMI%'
		  OR AZ.[Title] LIKE '%720P%'
		   OR AZ.[Title] LIKE '%Lumens%'
		   OR AZ.[Title] LIKE '%1080P%'
		   OR AZ.[Title] LIKE '%VGA%'
		   OR AZ.[Title] LIKE '%cell%'
		   OR AZ.[Title] LIKE '%phone%'
		   OR AZ.[Title] LIKE '%WXGA%'
		   OR AZ.[Title] LIKE '%portable%'
		   OR AZ.[Title] LIKE '%remote projector%'
		   OR AZ.[Title] LIKE '%contrast%' 
		   OR AZ.[Title] LIKE '%cable%'
		   OR AZ.[Title] Like '%memory%'
		   OR AZ.[Title] LIKE '%laptop%'
		   OR AZ.[Title] LIKE '%2010 model%'  
		   OR AZ.[Title] LIKE '%2011 model%' 
		   OR AZ.[Title] LIKE '%2012 model%' 
		   OR AZ.[Title] LIKE '%2013 model%' 
		   OR AZ.[Title] LIKE '%2014 model%' 
		   OR AZ.[Title] LIKE '%2015 model%'
		   OR AZ.[Title] LIKE '%2016 model%'
		   OR AZ.[Title] LIKE '%Home Theater%'
			OR AZ.[Title] LIKE '%NTSC%'
			OR AZ.[Title] LIKE '%PAL%'
			OR AZ.[Title] LIKE '%HDTV%'
			OR AZ.[Title] LIKE '%Entertainment%'
			OR AZ.[Title] LIKE '%SVGA%'
			OR AZ.[Title] LIKE '%Blu-ray%'
			OR AZ.[Title] LIKE '%Widescreen%'
			OR AZ.[Title] LIKE '%dictionary%'
			OR AZ.[Title] LIKE '%Document%'
			OR AZ.[Title] LIKE '%Core i5%'
			OR AZ.[Title] LIKE '%720i%'
			OR AZ.[Title] LIKE '%ThinkPad%'   
			OR AZ.[Title] LIKE '%cell%' 
			OR AZ.[Title] LIKE '%charger%'
			OR AZ.[Title] LIKE '%inspiron%'
			OR AZ.[Title] LIKE '%travel%'
			OR AZ.[Title] LIKE '%detachable%'
			OR AZ.[Title] LIKE '%Tablet%'
			OR AZ.[Title] LIKE '%fireplace%'
			OR AZ.[Title] like '%Power Cord%' 
			OR AZ.[Title] like '%Blower%' 
			OR AZ.[Title] like '%QuickShip%' 
			OR AZ.[Title] like '%Desktop%'
			OR AZ.[Title] like '%Station%'
			OR AZ.[Title] like '%Toner%'
			OR AZ.[Title] like '%Adapter%'
			OR AZ.[Title] like '%Business Card%'
			OR AZ.[Title] like '%Protector%'
			OR AZ.[Title] like '%iPhone%'
			OR AZ.[Title] like '%Galaxy%'
			OR AZ.[Title] like '%Transceiver%'
			OR AZ.[Title] like '%Headset%' 
			OR AZ.[Title] like '%Telephone%'

		   )
		   
		   AND AZ.[Title] NOT LIKE '%Lamp%' 
		   and AZ.[Title] NOT LIKE '%Bulb%' 
		   and AZ.[Title] NOT LIKE '%replacement%'
		   and AZ.[Title] NOT LIKE '%lutema%'
		   and AZ.[Title] NOT LIKE '%remote%'  

	---------------------------------------------------------------------------------------
	------------------------------END NEGATIVE KEYWORDS-----------------------------------
	---------------------------------------------------------------------------------------


		--REPORT WHAT YOU ARE DELETING
		DECLARE @xml NVARCHAR(MAX)
		DECLARE @body NVARCHAR(MAX)
		DECLARE @date VARCHAR(12)
		DECLARE @subtext VARCHAR(50)
		DECLARE @subject VARCHAR(62)
		DECLARE @recipients VARCHAR(255)

		SET @xml =CAST(( 
				SELECT 
				ALR.[seller_sku] AS 'td',''
				,ALR.[asin1] AS 'td',''
				,AZ.[Title] AS 'td',''
				,ALR.[item_name] AS 'td',''
				,AZ.[BrandSell] AS 'td',''
				,AZ.[BrandMentioned] AS 'td',''
				,IsNull(SUM(OD.[QuantityOrdered]),0) AS 'td'
				FROM [AmazonExclusiveBulbs].[dbo].[All_Listings_Report] AS ALR
				LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ ON (ALR.[asin1] = AZ.[ASIN])
				LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (AZ.[ProductCatalogId] = PC.[ID])
				LEFT OUTER JOIN [OrderManager].[dbo].[Order Details] AS OD ON (ALR.[seller_sku] = OD.[Websku])
				WHERE (AZ.[IsActive] = 0)
				AND az.[CountryCode] = 'US'
				GROUP BY ALR.[seller_sku], ALR.[asin1], AZ.[Title], ALR.[item_name], AZ.[BrandSell], AZ.[BrandMentioned]
				ORDER BY SUM(OD.[QuantityOrdered]) DESC FOR XML PATH('tr'), ELEMENTS 
		) AS NVARCHAR(MAX))

		SET @subtext = 'Amazon ExclusiveBulbs ASIN Nuking - '
		SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
		SET @subject = @subtext + @date
		SET @recipients = 'marketplace@mitechnologiesinc.com'
		SET @body ='<html><center><H1>Amazon ExclusiveBulbs ASIN Nuking - <br>' + @date + '</H1><br><br></Center>Marketplace Team,<br>AutoBot has NUKED the following ASINs from Amazon due to Brand Deactivation / Brand Registry: <br><br><Center><body bgcolor=yellow><table border = 2><tr>
		<th>MerchantSKU</th>
		<th>ASIN</th>
		<th>TitleDataMining</th>
		<th>TitleAmazon</th>
		<th>BrandSell</th>
		<th>BrandMentioned</th>
		<th>TotalSold</th>
		</tr>' 
		SET @body = @body + @xml +'</center></table><br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'

		PRINT @body

		If @body is not null BEGIN

		EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

		@recipients = @recipients,
		@subject = @subject,
		@body = @body,
		@body_format ='HTML'

		END


		--REPORT INACTIVE BRANDS
		SET @xml =CAST(( 
				SELECT [Brand] AS 'td',''
				,'Yes' AS 'td',''
				,IsNull([Regions],'') AS 'td'
				FROM [Inventory].[dbo].[AmazonBrandDeactivate]
				WHERE [Deactivate] = 1
				ORDER BY [Brand] ASC FOR XML PATH('tr'), ELEMENTS 
		) AS NVARCHAR(MAX))

		SET @subtext = 'Amazon ExclusiveBulbs Brand Deactivation - '
		SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
		SET @subject = @subtext + @date
		SET @recipients = 'marketplace@mitechnologiesinc.com'
		SET @body ='<html><center><H1>Amazon ExclusiveBulbs Brand Deactivation - <br>' + @date + '</H1><br><br></Center>Marketplace Team,<br>Below is a list of Brands being Deactivated Automatically: <br><br><Center><body bgcolor=yellow><table border = 2><tr>
		<th>Brand</th>
		<th>Deactivate</th>
		<th>Regions</th>
		</tr>' 
		SET @body = @body + @xml +'</center></table><br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'

		PRINT @body

		If @body is not null BEGIN

		EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

		@recipients = @recipients,
		@subject = @subject,
		@body = @body,
		@body_format ='HTML'

		END



END
go

