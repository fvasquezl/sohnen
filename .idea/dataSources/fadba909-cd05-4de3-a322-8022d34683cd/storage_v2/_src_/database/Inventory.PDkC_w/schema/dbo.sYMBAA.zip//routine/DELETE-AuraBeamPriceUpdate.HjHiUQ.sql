
--EXECUTE [dbo].[AuraBeamPriceUpdate]
--This procedure is created to Update AuraBeam buybox price based on the lowest price on Amazon for corresponding SKU.

CREATE PROCEDURE [dbo].[AuraBeamPriceUpdate]
AS 
BEGIN

DECLARE @MITSKU AS NVARCHAR(MAX)
DECLARE @lowestPrice AS MONEY


DECLARE AuraBeam_cursor CURSOR
FOR
--Select all SKUS for Generic TV Lamps
Select pc.ID FROM Inventory.dbo.ProductCatalog pc 
LEFT JOIN Inventory.dbo.Categories ctg
ON pc.CategoryID = ctg.ID
WHERE ctg.ParentID = '1'  -- TV Lamp Bare
OR ctg.ParentID = '2'  -- TV Lamp with housing
OR ctg.ParentID = '4'  -- FP Lamp with housing

OPEN AuraBeam_cursor
FETCH NEXT FROM AuraBeam_cursor INTO @MITSKU

WHILE @@FETCH_STATUS = 0
BEGIN

--PRINT @MITSKU
--PRINT @lowestprice

--USA
UPDATE AZ SET BuyBoxPrice = (CASE WHEN ISNULL(FixPricing,0) = 1 AND ISNULL(BuyBoxPrice,0) <> 0 THEN BuyBoxPrice ELSE
(CASE WHEN PC.CategoryID IN ('9') AND AZ.ProductCatalogId NOT IN ('122551','142551') THEN '19.99' --Bare Lamp TV GENERIC
WHEN PC.CategoryID IN ('9') AND AZ.ProductCatalogId IN ('122551','142551') THEN '34.99' --Bare Lamp TV GENERIC
WHEN PC.CategoryID IN ('19') THEN CEILING([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PC.[ID])+40)-0.01 --Bare Lamp FP GENERIC
WHEN PC.CategoryID IN ('10') THEN '79.99' --Lamp with Housing TV Philips
WHEN PC.CategoryID IN ('11') THEN '72.99' --Lamp with Housing TV Osram 
WHEN PC.CategoryID IN ('12') THEN '84.99' --Lamp with Housing TV Phoenix
WHEN PC.CategoryID IN ('14') AND AZ.ProductCatalogId NOT IN ('126072','126073','126074','126075','126080') THEN '24.95'  --Lamp with Housing TV
WHEN PC.CategoryID IN ('14') AND AZ.ProductCatalogId IN ('126072','126073','126074','126075','126080') THEN '44.95'  --Lamp with Housing TV
WHEN PC.CategoryID IN ('20','21','22','23','64') THEN CEILING((([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PC.[ID]))*1.4)+10)-0.01 --FP Philips/OSRAM/Phoenix/UShio
WHEN PC.CategoryID IN ('24') THEN CEILING(((Select [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](@MITSKU))*1.8)+6)-0.01 --FP Generic
ELSE '69.99' END)
END)
FROM [Inventory].[dbo].[Amazon] AS AZ
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (AZ.ProductCatalogId = PC.[ID])
WHERE CAST(AZ.ProductCatalogId AS VARCHAR) = @MITSKU
AND CountryCode = 'US' 
AND ChannelName = 'Amazon' 
AND BrandMentioned = 'AuraBeam' 

--CANADA
UPDATE AZ SET BuyBoxPrice = (CASE WHEN ISNULL(FixPricing,0) = 1 AND ISNULL(BuyBoxPrice,0) <> 0 THEN BuyBoxPrice ELSE
(CASE WHEN PC.CategoryID IN ('9') AND AZ.ProductCatalogId NOT IN ('122551','142551') THEN '23.99' --Bare Lamp TV GENERIC
WHEN PC.CategoryID IN ('9') AND AZ.ProductCatalogId IN ('122551','142551') THEN '54.99' --Bare Lamp TV GENERIC
WHEN PC.CategoryID IN ('19') THEN CEILING([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PC.[ID])+30)-0.01 --Bare Lamp FP GENERIC
WHEN PC.CategoryID IN ('10') THEN '89.99' --Lamp with Housing TV Philips
WHEN PC.CategoryID IN ('11') THEN '79.99' --Lamp with Housing TV Osram 
WHEN PC.CategoryID IN ('12') THEN '91.99' --Lamp with Housing TV Phoenix
WHEN PC.CategoryID IN ('14') AND AZ.ProductCatalogId NOT IN ('126072','126073','126074','126075','126080') THEN '29.99'  --Lamp with Housing TV
WHEN PC.CategoryID IN ('14') AND AZ.ProductCatalogId IN ('126072','126073','126074','126075','126080') THEN '54.99'  --Lamp with Housing TV
WHEN PC.CategoryID IN ('20','21','22','23','64') THEN CEILING((([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PC.[ID]))*1.4)+18)-0.01 --FP Philips/OSRAM/Phoenix/UShio
WHEN PC.CategoryID IN ('24') THEN CEILING(((Select [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](@MITSKU))*1.8)+20)-0.01 --FP Generic
ELSE '89.99' END)
END)
FROM [Inventory].[dbo].[Amazon] AS AZ
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (AZ.ProductCatalogId = PC.[ID])
WHERE CAST(AZ.ProductCatalogId AS VARCHAR) = @MITSKU
AND CountryCode = 'CA' 
AND ChannelName = 'Amazon' 
AND BrandMentioned = 'AuraBeam' 

FETCH NEXT FROM AuraBeam_cursor INTO @MITSKU

END

CLOSE AuraBeam_cursor
DEALLOCATE AuraBeam_cursor

END
go

