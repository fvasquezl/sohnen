CREATE VIEW [dbo]._dta_mv_174 WITH SCHEMABINDING AS SELECT  [dbo].[Compatibility].[ProductCatalogID] as _col_1,  [dbo].[Compatibility].[PartNumber] as _col_2,  [dbo].[Compatibility].[Manufacturer] as _col_3,  count_big(*) as _col_4 FROM  [dbo].[Compatibility]   WHERE  [dbo].[Compatibility].[PartNumber] like '%153114%'  GROUP BY  [dbo].[Compatibility].[ProductCatalogID],  [dbo].[Compatibility].[PartNumber],  [dbo].[Compatibility].[Manufacturer]
go

