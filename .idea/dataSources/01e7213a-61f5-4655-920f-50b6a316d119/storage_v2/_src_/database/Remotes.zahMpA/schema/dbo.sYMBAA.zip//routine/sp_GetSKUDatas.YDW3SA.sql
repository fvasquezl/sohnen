-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSKUDatas]
	-- Add the parameters for the stored procedure here
	@compatibility NVARCHAR(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--------------
	-- Temp Table, store final table.
	--------------
	CREATE TABLE #TMP_SKUDATA_WITH_CATEGORY(
											 [ID] int IDENTITY(1,1) PRIMARY KEY
											,[SKU] NVARCHAR(50)
											,[Manufacturer] NVARCHAR(50)
											,[PartNumber] NVARCHAR(250)
											,[Categories] NVARCHAR(50)
											,[WeightOz] decimal(10,2)
											,[FloorPrice] decimal (10,2)
											,[CeilingPrice] decimal (10,2)
											,[UnitCost] decimal (10,2)
											,[FloorPriceCN] decimal (10,2)
											,[CeilingPriceCN] decimal (10,2)
											,[UnitCostCN] decimal (10,2)
											,[FloorPriceUSED] decimal (10,2)
											,[CeilingPriceUSED] decimal (10,2)
											,[UnitCostUSED] decimal (10,2)
											,[Amazon] bit
											,[eBay] bit
											,[HaveCNVariant] bit
											,[Qty] NVARCHAR(50)											
											,[NImages] int)

	CREATE NONCLUSTERED INDEX ix_SKUDATA_SKU ON #TMP_SKUDATA_WITH_CATEGORY ([ID]);

	-----------------
	--- Fill TEMP table with SKU DATA plus Category Names
	--- Filter information by Compatibility if exists. 
	-----------------

	IF(@compatibility ='')
		INSERT INTO #TMP_SKUDATA_WITH_CATEGORY
			SELECT SKUD.SKU, SKUD.Manufacturer, SKUD.PartNumber,CAT.CategoryName, SKUD.WeightOz, SKUD.FloorPrice, SKUD.CeilingPrice,
					SKUD.UnitCost, SKUD.FloorPriceCN, SKUD.CeilingPriceCN, SKUD.UnitCostCN, SKUD.FloorPriceUSED, SKUD.CeilingPriceUSED, 
					SKUD.UnitCostUSED, SKUD.Amazon, SKUD.eBay, SKUD.HaveCNVariant,

			stuff((SELECT CHAR(10) + CHAR(10) + cast([ScanCode] as varchar(max))+': '+cast([Qty] as varchar(max))
			  FROM [Remotes].[dbo].[fn_GetQtyPerScanCode] (SKUD.[SKU]) FOR XML PATH('')), 1, 2, '') AS [Qty],
			(SELECT COUNT (SKU) FROM [Remotes].[dbo].[Image] Image WHERE SKU = SKUD.[SKU] ) AS [NImages]

			FROM SKUData AS SKUD
			INNER JOIN Categories AS CAT ON (SKUD.[CategoryID] = CAT.CategoryID);
	ELSE
		INSERT INTO #TMP_SKUDATA_WITH_CATEGORY
			SELECT SKUD.SKU, SKUD.Manufacturer, SKUD.PartNumber,CAT.CategoryName, SKUD.WeightOz, SKUD.FloorPrice, SKUD.CeilingPrice,
					SKUD.UnitCost, SKUD.FloorPriceCN, SKUD.CeilingPriceCN, SKUD.UnitCostCN, SKUD.FloorPriceUSED, SKUD.CeilingPriceUSED, 
					SKUD.UnitCostUSED, SKUD.HaveCNVariant,

			stuff((SELECT CHAR(10) + CHAR(10) + cast([ScanCode] as varchar(max))+': '+cast([Qty] as varchar(max))
			  FROM [Remotes].[dbo].[fn_GetQtyPerScanCode] (SKUD.[SKU]) FOR XML PATH('')), 1, 2, '') AS [Qty],
			(SELECT COUNT (SKU) FROM [Remotes].[dbo].[Image] Image WHERE SKU = SKUD.[SKU] ) AS [NImages]

			FROM SKUData AS SKUD			
			INNER JOIN Categories AS CAT ON (SKUD.[CategoryID] = CAT.CategoryID)
			WHERE AlsoCompatibleWith LIKE '%'+@compatibility+'%' OR OriginallySuppliedWith LIKE '%'+@compatibility+'%';	

	-- Return Data.
	SELECT SKU, Manufacturer, PartNumber,Categories, WeightOz, FloorPrice, CeilingPrice, UnitCost, FloorPriceCN, CeilingPriceCN, UnitCostCN, 
			FloorPriceUSED, CeilingPriceUSED, UnitCostUSED, Amazon, eBay,HaveCNVariant, CAST(IsNull(Qty,'') AS NVARCHAR(50)) AS [Qty], [NImages]
		 FROM #TMP_SKUDATA_WITH_CATEGORY ORDER BY SKU
END
go

