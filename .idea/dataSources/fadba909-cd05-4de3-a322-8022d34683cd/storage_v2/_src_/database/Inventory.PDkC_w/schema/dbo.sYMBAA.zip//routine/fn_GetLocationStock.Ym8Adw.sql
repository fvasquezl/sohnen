-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_GetLocationStock
(
	@ProductCatalogId as int , @location as int
)
RETURNS real
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar as real

	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = quantity FROM [Inventory].[dbo].[Inventory]
			WHERE (ProductCatalogID = @ProductCatalogId)
					and (AccountID = @location)

	-- Return the result of the function
	RETURN @ResultVar

END
go

