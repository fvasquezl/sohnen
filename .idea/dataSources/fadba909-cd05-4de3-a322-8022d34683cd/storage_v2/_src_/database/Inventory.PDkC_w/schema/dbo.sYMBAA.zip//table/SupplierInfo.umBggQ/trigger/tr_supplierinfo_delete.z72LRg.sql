-- =============================================
-- Author:		Luis Batista
-- Create date: 05/05/2014
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER tr_supplierinfo_delete
   ON  dbo.SupplierInfo
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    DECLARE @pId int;
    SET @pId = (SELECT SupplierId FROM deleted);
	DELETE FROM Suppliers where SupplierID = @pId;
END
go

