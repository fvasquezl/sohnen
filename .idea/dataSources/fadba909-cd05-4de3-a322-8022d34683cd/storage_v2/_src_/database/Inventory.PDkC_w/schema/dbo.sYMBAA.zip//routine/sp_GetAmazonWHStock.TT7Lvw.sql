-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-12-15
-- Description:	Get Channel Data
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetAmazonWHStock]
	@ASIN			NVARCHAR(50),
	@CountryCode	NVARCHAR(3),
	@Category		NVARCHAR(20),
	@ChannelName	NVARCHAR(50),
	@FLXActive		INT,
	@IsActive		INT,
	@FLXInvLinking	INT
AS
BEGIN
	DECLARE @CURSOR_WH	CURSOR,
			@SKU		INT,
			@QTY		INT
	SET NOCOUNT ON;

	CREATE TABLE #tmpInfoAmazon (ASIN NVARCHAR(15),Title NVARCHAR(250), CountryCode NVARCHAR(3), Category NVARCHAR(20), ProductCatalogId INT, GlobalStock DECIMAL(18,4), VirtualStock DECIMAL(18,4),
		TOTAL_MX DECIMAL(18,4), TOTAL_US DECIMAL(18,4), ID INT, DARTFBMSKU NVARCHAR(50), DARTFBASKU NVARCHAR(50), E_FBMSKU NVARCHAR(50), E_FBASKU NVARCHAR(50), Manufacturer NVARCHAR(250), BrandMentioned NVARCHAR(200), 
		DARTFBASKUUK NVARCHAR(50), DARTFBMSKUUK NVARCHAR(50), FLXActive BIT, FLXStamp SMALLDATETIME, FLEXSKU NVARCHAR(50), FLXInvLinking BIT, IsActive BIT)
	CREATE CLUSTERED INDEX IDX_TMPInfoAmazon ON #tmpInfoAmazon(ASIN,ProductCatalogId)

	CREATE TABLE #TMPASIN (ASIN NVARCHAR(50))
	CREATE CLUSTERED INDEX IDX_TMPASIN ON #TMPASIN(ASIN)
	
	IF(LEN(ISNULL(@ASIN,'')) > 2)
	BEGIN
	
		INSERT INTO #TMPASIN
		SELECT ASIN FROM AmazonExclusiveBulbs.dbo.InventoryASIN WITH(NOLOCK) WHERE ChannelName = 'Exclusive' AND isActive = 1 AND MerchantSKU LIKE @ASIN

		INSERT INTO #tmpInfoAmazon (ASIN,Title,CountryCode,Category,ProductCatalogId,GlobalStock,VirtualStock, ID, DARTFBMSKU, DARTFBASKU, E_FBMSKU, E_FBASKU, Manufacturer, BRANDMENTIONED, DARTFBASKUUK, DARTFBMSKUUK, FLXActive, FLXStamp, FLEXSKU, FLXInvLinking, IsActive)
		SELECT A.[ASIN],A.Title, A.[CountryCode], A.[Category], A.[ProductCatalogId], D.[GlobalStock], D.[VirtualStock], A.ID, M.DARTFBMSKU, M.DARTFBASKU, M.ELEMENTARYVISIONFBMSKU, M.ELEMENTARYVISIONFBASKU, 
			A.manufacturer, A.BrandMentioned, M.DARTFBASKUUK, M.DARTFBMSKUUK, ISNULL(A.FLXActive,0), A.FLXStamp, (SELECT TOP 1 MerchantSKU FROM AmazonExclusiveBulbs.dbo.InventoryASIN WITH(NOLOCK) WHERE MerchantSKU LIKE '%FLX' AND ChannelName = 'Exclusive' AND ASIN = A.ASIN AND isActive = 1) AS FLEXSKU, ISNULL(A.FLXInvLinking,0), ISNULL(A.IsActive,0)
		FROM [Inventory].[dbo].[DELETE-Amazon] A WITH(NOLOCK)
		LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] D WITH(NOLOCK)
		ON D.ProductCatalogId = A.[ProductCatalogId] 
		LEFT OUTER JOIN Inventory.dbo.[DELETE-AmazonMerchantSKU] M WITH(NOLOCK)
		ON M.ASIN = A.ASIN
		WHERE A.[CountryCode] = @CountryCode AND A.[ChannelName] = @ChannelName AND ISNULL(A.[Category],'') LIKE @Category AND (ISNULL(A.[ASIN],'') LIKE @ASIN OR ISNULL(CONVERT(NVARCHAR,A.[ProductCatalogId]),'') LIKE @ASIN OR ISNULL(M.DARTFBMSKU,'') LIKE @ASIN OR ISNULL(A.manufacturer,'') LIKE @ASIN OR ISNULL(A.BrandMentioned,'') LIKE @ASIN OR ISNULL(M.DARTFBASKUUK,'') LIKE @ASIN OR ISNULL(M.DARTFBMSKUUK,'') LIKE @ASIN OR ISNULL(A.ASIN,'') IN (SELECT ASIN FROM #TMPASIN GROUP BY ASIN))
		ORDER BY A.[ASIN] DESC
	END
	ELSE
	BEGIN
		INSERT INTO #tmpInfoAmazon (ASIN,Title,CountryCode,Category,ProductCatalogId,GlobalStock,VirtualStock, ID, DARTFBMSKU, DARTFBASKU, E_FBMSKU, E_FBASKU, Manufacturer, BRANDMENTIONED, DARTFBASKUUK, DARTFBMSKUUK, FLXActive, FLXStamp, FLEXSKU, FLXInvLinking, IsActive)
		SELECT TOP 1000 A.[ASIN],A.Title, A.[CountryCode], A.[Category], A.[ProductCatalogId], D.[GlobalStock], D.[VirtualStock], A.ID, M.DARTFBMSKU, M.DARTFBASKU, M.ELEMENTARYVISIONFBMSKU, M.ELEMENTARYVISIONFBASKU, 
			A.manufacturer, A.BrandMentioned, M.DARTFBASKUUK, M.DARTFBMSKUUK, ISNULL(A.FLXActive,0), A.FLXStamp, (SELECT TOP 1 MerchantSKU FROM AmazonExclusiveBulbs.dbo.InventoryASIN WITH(NOLOCK) WHERE MerchantSKU LIKE '%FLX' AND ChannelName = 'Exclusive' AND ASIN = A.ASIN AND isActive = 1) AS FLEXSKU, ISNULL(A.FLXInvLinking,0), ISNULL(A.IsActive,0)
		FROM [Inventory].[dbo].[DELETE-Amazon] A WITH(NOLOCK)
		LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] D WITH(NOLOCK)
		ON D.ProductCatalogId = A.[ProductCatalogId] 
		LEFT OUTER JOIN Inventory.dbo.[DELETE-AmazonMerchantSKU] M WITH(NOLOCK)
		ON M.ASIN = A.ASIN
		WHERE A.[CountryCode] = @CountryCode AND A.[ChannelName] = @ChannelName AND ISNULL(A.[Category],'') LIKE @Category
		ORDER BY A.[ASIN] DESC
	END

	SET @CURSOR_WH = CURSOR FOR 

	SELECT ProductCatalogId
	FROM #tmpInfoAmazon
	GROUP BY ProductCatalogId

	OPEN @CURSOR_WH
		FETCH NEXT FROM @CURSOR_WH 
		INTO @SKU

		IF @@FETCH_STATUS <> 0 
        BEGIN 
			CLOSE      @CURSOR_WH 
            DEALLOCATE @CURSOR_WH
            RETURN
        END

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			SET @QTY = 0

			SELECT @QTY = SUM(A.Counter)
			FROM Inventory.dbo.Bin_Content A WITH(NOLOCK)
			INNER JOIN Inventory.dbo.Bins B WITH(NOLOCK)
			ON B.Bin_id = A.Bin_id
			WHERE A.ProductCatalog_Id = @SKU AND B.WarehouseID = 'US'
			GROUP BY B.WarehouseID

			UPDATE #tmpInfoAmazon SET TOTAL_US = @QTY WHERE ProductCatalogId = @SKU

			SET @QTY = 0

			SELECT @QTY = SUM(A.Counter)
			FROM Inventory.dbo.Bin_Content A WITH(NOLOCK)
			INNER JOIN Inventory.dbo.Bins B WITH(NOLOCK)
			ON B.Bin_id = A.Bin_id
			WHERE A.ProductCatalog_Id = @SKU AND B.WarehouseID = 'MX'
			GROUP BY B.WarehouseID
			
			UPDATE #tmpInfoAmazon SET TOTAL_MX = @QTY WHERE ProductCatalogId = @SKU

			FETCH NEXT FROM @CURSOR_WH 
			INTO @SKU
		END 
	CLOSE      @CURSOR_WH 
	DEALLOCATE @CURSOR_WH  
	
	SELECT * FROM #tmpInfoAmazon
	ORDER BY [ASIN] ASC
END
go

