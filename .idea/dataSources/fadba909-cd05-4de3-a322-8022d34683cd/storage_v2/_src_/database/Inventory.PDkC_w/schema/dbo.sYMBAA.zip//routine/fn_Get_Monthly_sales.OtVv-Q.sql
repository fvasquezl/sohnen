-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_Monthly_sales] (@year int, @CartId int)
RETURNS @Months TABLE (mymonth int, sales  real, name varchar(50) )
AS
BEGIN

		DECLARE @TempTable TABLE ( mymonth int,   sales real,   sku int, ProductLineId int );
		DECLARE @I int;
		DECLARE @Exist int;
		
		IF @CartID = 0
		BEGIN
				INSERT INTO @TempTable (mymonth, sales, sku, ProductLineID) 		
				SELECT avg(month(b.orderdate)) as mymonth
				, sum(a.shippedsubtotal) as sales 
				, avg(cast(a.sku as int))
				, sum(0) as ProductLineID
				FROM orderManager.dbo.[Order Details] a,orderManager.dbo.[Orders] b 
				WHERE (a.ordernumber = b.ordernumber) 
				and (isnumeric(a.sku) = 1) 
				and (b.balancedue = 0) 
				and (year(b.orderdate) = @year) 
				group by month(b.orderdate), a.sku
				order by month(b.orderdate);
		END
		ELSE
		BEGIN
			INSERT INTO @TempTable (mymonth, sales, sku, ProductLineID) 		
				SELECT avg(month(b.orderdate)) as mymonth
				, sum(a.shippedsubtotal) as sales 
				, avg(cast(a.sku as int))
				, sum(0) as ProductLineID
				FROM orderManager.dbo.[Order Details] a,orderManager.dbo.[Orders] b 
				WHERE (a.ordernumber = b.ordernumber) 
						and (isnumeric(a.sku) = 1) 
						and (b.balancedue = 0) 
						and (year(b.orderdate) = @year) 
						and (b.CartId = @CartId)
				group by month(b.orderdate), a.sku
				order by month(b.orderdate);
		END
		
			
		 UPDATE @TempTable SET ProductLineID = inventory.dbo.fn_get_productlineID(sku) WHERE SKU > 0;
		 
		 INSERT INTO @Months (mymonth, sales) 		
			SELECT avg(mymonth), sum(sales) 
			FROM @TempTable
			Where  NOT (ProductLineid is null)
					AND (
							(ProductLineID = 35)OR(	ProductLineID = 36	)
					)
			group by mymonth
			Order by mymonth;
			
			
			SET @I = 1;
			
			 while @I <=12
				begin 
					SET @Exist = 0;
					
					SET @Exist = (SELECT mymonth FROM @Months WHERE mymonth = @I);
					
					IF (@Exist= 0) OR (@Exist is null)
					BEGIN
						INSERT INTO @Months (mymonth, sales) values (@i,0);
					END
					
	                SET @I = @i + 1;
				end  
			
			
			UPDATE 	@Months SET name = 'Jan' WHERE mymonth = 1;	
			UPDATE 	@Months SET name = 'Feb' WHERE mymonth = 2;	
			UPDATE 	@Months SET name = 'Mar' WHERE mymonth = 3;	
			UPDATE 	@Months SET name = 'Apr' WHERE mymonth = 4;	
			UPDATE 	@Months SET name = 'May' WHERE mymonth = 5;	
			UPDATE 	@Months SET name = 'Jun' WHERE mymonth = 6;	
			UPDATE 	@Months SET name = 'Jul' WHERE mymonth = 7;	
			UPDATE 	@Months SET name = 'Aug' WHERE mymonth = 8;	
			UPDATE 	@Months SET name = 'Sep' WHERE mymonth = 9;	
			UPDATE 	@Months SET name = 'Oct' WHERE mymonth = 10;	
			UPDATE 	@Months SET name = 'Nov' WHERE mymonth = 11;	
			UPDATE 	@Months SET name = 'Dec' WHERE mymonth = 12;	
		
	RETURN;
END
go

