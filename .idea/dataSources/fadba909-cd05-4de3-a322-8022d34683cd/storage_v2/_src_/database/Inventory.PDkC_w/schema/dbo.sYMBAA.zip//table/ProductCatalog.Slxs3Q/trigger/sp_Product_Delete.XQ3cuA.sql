-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[sp_Product_Delete]
   ON  dbo.ProductCatalog
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	 DECLARE @id INT;
    
    SET @id = (SELECT id FROM deleted);
    -- INSERT INTO REMOVED

	INSERT INTO inventory.dbo.productcatalogRemoved(
	[ID]
      ,[OldSKU]
      ,[Manufacturer]
      ,[ManufacturerPN]
      ,[CategoryID]
      ,[ProductLineID]
      ,[MeasuringUnitCode]
      ,[AssemblyRequired]
      ,[Serialized]
      ,[AutoSerial]
      ,[NextSerialValue]
      ,[Name]
    
      ,[IsSellable]
      ,[CountryOfOrigin]
      ,[Condition]
      ,[InventoryMin]
      ,[InventoryMax]
      ,[LastModifiedUserID]
   
      ,[UnitCost]
      ,[UnitDim]
      ,[UnitWeight]
      ,[CaseQty]
      ,[CaseDim]
      ,[CaseWeight]
      ,[PalletQty]
      ,[PalletDim]
      ,[PalletWeight]
      ,[RemovedBy]
      ,[TargetInventory]
      ,[QtyOrdered]
      ,[ETA]
      ,[Classification]
      ,[SKUprovider]
      ,[AverageUnitCost]
      ,[PreferredSupplier1]
      ,[PreferredSupplier2]
      ,[AlwaysInStock]
      ,[backunitcost]
      ,[AddToEbayReport]
      ,[UnitCostFBA]
      ,[UnitCostFBM]
      ,[UnitCostFBADateEntered]
      ,[UnitCostFBMDateEntered]
      ,[PriceFloor]
      ,[PriceCeiling]
      ,[PriceFloorFBA]
      ,[PriceCeilingFBA]
  
      ,[serial_prefix]
      ,[Avg1DayShipCost]
      ,[Avg2DayShipCost]
      ,[AvgStandardShipCost]
      ,[AvgIntPriorityShipCost]
      ,[AvgIntEconomyShipCost]
      ,[AvgWeightPounds]
      ,[UPCcode]
      ,[DumpFBM]
      ,[DumpFBA]
      ,[DumpFBMEndDate]
      ,[DumpFBAEndDate]
	) select 
	[ID]
      ,[OldSKU]
      ,[Manufacturer]
      ,[ManufacturerPN]
      ,[CategoryID]
      ,[ProductLineID]
      ,[MeasuringUnitCode]
      ,[AssemblyRequired]
      ,[Serialized]
      ,[AutoSerial]
      ,[NextSerialValue]
      ,[Name]
     
      ,[IsSellable]
      ,[CountryOfOrigin]
      ,[Condition]
      ,[InventoryMin]
      ,[InventoryMax]
      ,[LastModifiedUserID]
   
      ,[UnitCost]
      ,[UnitDim]
      ,[UnitWeight]
      ,[CaseQty]
      ,[CaseDim]
      ,[CaseWeight]
      ,[PalletQty]
      ,[PalletDim]
      ,[PalletWeight]
      ,[RemovedBy]
      ,[TargetInventory]
      ,[QtyOrdered]
      ,[ETA]
      ,[Classification]
      ,[SKUprovider]
      ,[AverageUnitCost]
      ,[PreferredSupplier1]
      ,[PreferredSupplier2]
      ,[AlwaysInStock]
      ,[backunitcost]
      ,[AddToEbayReport]
      ,[UnitCostFBA]
      ,[UnitCostFBM]
      ,[UnitCostFBADateEntered]
      ,[UnitCostFBMDateEntered]
      ,[PriceFloor]
      ,[PriceCeiling]
      ,[PriceFloorFBA]
      ,[PriceCeilingFBA]
   
      ,[serial_prefix]
      ,[Avg1DayShipCost]
      ,[Avg2DayShipCost]
      ,[AvgStandardShipCost]
      ,[AvgIntPriorityShipCost]
      ,[AvgIntEconomyShipCost]
      ,[AvgWeightPounds]
      ,[UPCcode]
      ,[DumpFBM]
      ,[DumpFBA]
      ,[DumpFBMEndDate]
      ,[DumpFBAEndDate]
	 from deleted;

    -- DELETEss all related items in the inventory (warehouses) table
    DELETE FROM inventory WHERE ProductCatalogId = @id;
    
    -- DELETEss from Global_Stock
    DELETE FROM Global_Stocks WHERE ProductCatalogId = @id;
END
go

