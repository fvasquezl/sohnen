-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tr_Product_Insert]
   ON  dbo.ProductCatalog
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    
    DECLARE @whid INT;
    DECLARE @productid INT;
    DECLARE @account_family varchar(100);
    DECLARE @warehouse_type int;
    
    SET @productid = (SELECT ID FROM INSERTED);
    
    DECLARE warehouses_cursor CURSOR FOR 
			SELECT ID, family
			FROM accounts
			WHERE (family = 'STORE') OR (family = 'FOREIGN STORE')
			ORDER BY ID;

	OPEN warehouses_cursor;

	FETCH NEXT FROM warehouses_cursor INTO @whid, @account_family;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN

		IF (@account_family = 'STORE')
				BEGIN
					SET @warehouse_type = 1;
				END
		ELSE
				BEGIN
					SET @warehouse_type = 2;
				END
					
        INSERT INTO inventory (ProductCatalogId, AccountId, ProductCatalogName, Warehouse_type) 
				VALUES (@productid, @whid, inventory.dbo.fn_GetProductName(@productid), @warehouse_type);


		FETCH NEXT FROM warehouses_cursor INTO @whid, @account_family ;		

    END
    
   
    
    CLOSE warehouses_cursor
	DEALLOCATE warehouses_cursor
	
	-- Insert in Global_Stocks Table
    INSERT INTO Global_Stocks (ProductCatalogId) values (@productid);
    
     /* Insert in the suppliers table*/
    INSERT INTO Suppliers (ProductCatalogId, SupplierID, Enabled)
     SELECT @productid, a.SupplierId, 0 FROM SupplierInfo a;

END
go

