-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-03-15
-- Description:	Get All SKU by Model
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSKUbyModel]
	@MODEL NVARCHAR(50)
AS
BEGIN
	SET FMTONLY OFF
	SET NOCOUNT ON;
	
	CREATE TABLE #tmpInfo (SKU INT, Name NVARCHAR(254), typeLamp nvarchar(20))
	SET FMTONLY OFF;
	INSERT INTO #tmpInfo (SKU, Name, typeLamp)
	SELECT p.ID, p.Name,
	CASE 
		WHEN c.Name not like '%generic%'
		THEN 'original'
		ELSE 'generic'
	END AS typeLamp
	FROM Inventory.dbo.ProductCatalog p(NOLOCK)
	INNER JOIN 
	Inventory.dbo.Categories c
	ON c.ID = p.CategoryID
	WHERE ISNULL(CONVERT(NVARCHAR,p.ID),'') + 
		ISNULL(CONVERT(NVARCHAR,OldSKU),'') + 
		ISNULL(CONVERT(NVARCHAR,Manufacturer),'') + 
		ISNULL(CONVERT(NVARCHAR,ManufacturerPN),'') + 
		ISNULL(CONVERT(NVARCHAR,CategoryID),'') + 
		ISNULL(CONVERT(NVARCHAR,ProductLineID),'') + 
		ISNULL(CONVERT(NVARCHAR,MeasuringUnitCode),'') + 
		ISNULL(CONVERT(NVARCHAR,AssemblyRequired),'') + 
		ISNULL(CONVERT(NVARCHAR,Serialized),'') + 
		ISNULL(CONVERT(NVARCHAR,AutoSerial),'') + 
		ISNULL(CONVERT(NVARCHAR,NextSerialValue),'') + 
		ISNULL(CONVERT(NVARCHAR,p.Name),'') + 
		ISNULL(CONVERT(NVARCHAR,p.Description),'') + 
		ISNULL(CONVERT(NVARCHAR,Keywords),'') + 
		ISNULL(CONVERT(NVARCHAR,IsSellable),'') + 
		ISNULL(CONVERT(NVARCHAR,CountryOfOrigin),'') + 
		ISNULL(CONVERT(NVARCHAR,Condition),'') + 
		ISNULL(CONVERT(NVARCHAR,InventoryMin),'') + 
		ISNULL(CONVERT(NVARCHAR,InventoryMax),'') + 
		ISNULL(CONVERT(NVARCHAR,LastModifiedUserID),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField01),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField02),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField03),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField04),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField05),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField06),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField07),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField08),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField09),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField10),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField11),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField12),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField13),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField14),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField15),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField16),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField17),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField18),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField19),'') + 
		ISNULL(CONVERT(NVARCHAR,CustomField20),'') + 
		ISNULL(CONVERT(NVARCHAR,UnitCost),'') + 
		ISNULL(CONVERT(NVARCHAR,UnitDim),'') + 
		ISNULL(CONVERT(NVARCHAR,UnitWeight),'') + 
		ISNULL(CONVERT(NVARCHAR,CaseQty),'') + 
		ISNULL(CONVERT(NVARCHAR,CaseDim),'') + 
		ISNULL(CONVERT(NVARCHAR,CaseWeight),'') + 
		ISNULL(CONVERT(NVARCHAR,PalletQty),'') + 
		ISNULL(CONVERT(NVARCHAR,PalletDim),'') + 
		ISNULL(CONVERT(NVARCHAR,PalletWeight),'') + 
		ISNULL(CONVERT(NVARCHAR,RemovedBy),'') + 
		ISNULL(CONVERT(NVARCHAR,TargetInventory),'') + 
		ISNULL(CONVERT(NVARCHAR,QtyOrdered),'') + 
		ISNULL(CONVERT(NVARCHAR,ETA),'') + 
		ISNULL(CONVERT(NVARCHAR,Classification),'') + 
		ISNULL(CONVERT(NVARCHAR,SKUprovider),'') + 
		ISNULL(CONVERT(NVARCHAR,AverageUnitCost),'') + 
		ISNULL(CONVERT(NVARCHAR,PreferredSupplier1),'') + 
		ISNULL(CONVERT(NVARCHAR,PreferredSupplier2),'') + 
		ISNULL(CONVERT(NVARCHAR,AlwaysInStock),'') + 
		ISNULL(CONVERT(NVARCHAR,backunitcost),'') + 
		ISNULL(CONVERT(NVARCHAR,AddToEbayReport),'') + 
		ISNULL(CONVERT(NVARCHAR,UnitCostFBA),'') + 
		ISNULL(CONVERT(NVARCHAR,UnitCostFBM),'') + 
		ISNULL(CONVERT(NVARCHAR,UnitCostFBADateEntered),'') + 
		ISNULL(CONVERT(NVARCHAR,UnitCostFBMDateEntered),'') + 
		ISNULL(CONVERT(NVARCHAR,PriceFloor),'') + 
		ISNULL(CONVERT(NVARCHAR,PriceCeiling),'') + 
		ISNULL(CONVERT(NVARCHAR,PriceFloorFBA),'') + 
		ISNULL(CONVERT(NVARCHAR,PriceCeilingFBA),'') + 
		ISNULL(CONVERT(NVARCHAR,serial_prefix),'') + 
		ISNULL(CONVERT(NVARCHAR,Avg1DayShipCost),'') + 
		ISNULL(CONVERT(NVARCHAR,Avg2DayShipCost),'') + 
		ISNULL(CONVERT(NVARCHAR,AvgStandardShipCost),'') + 
		ISNULL(CONVERT(NVARCHAR,AvgIntPriorityShipCost),'') + 
		ISNULL(CONVERT(NVARCHAR,AvgIntEconomyShipCost),'') + 
		ISNULL(CONVERT(NVARCHAR,AvgWeightPounds),'') + 
		ISNULL(CONVERT(NVARCHAR,UPCcode),'') + 
		ISNULL(CONVERT(NVARCHAR,DumpFBM),'') + 
		ISNULL(CONVERT(NVARCHAR,DumpFBA),'') + 
		ISNULL(CONVERT(NVARCHAR,DumpFBMEndDate),'') + 
		ISNULL(CONVERT(NVARCHAR,DumpFBAEndDate),'') + 
		ISNULL(CONVERT(NVARCHAR,CurrentStock),'') + 
		ISNULL(CONVERT(NVARCHAR,VirtualStock),'') + 
		ISNULL(CONVERT(NVARCHAR,TotalStock),'') + 
		ISNULL(CONVERT(NVARCHAR,UnitCostAvgPO),'') + 
		ISNULL(CONVERT(NVARCHAR,ProductAlert),'') + 
		ISNULL(CONVERT(NVARCHAR,PriceFloorMFP),'') + 
		ISNULL(CONVERT(NVARCHAR,PriceCeilingMFP),'') like @MODEL

		INSERT INTO #tmpInfo (SKU, Name,typeLamp)
		SELECT CY.ProductCatalogID, PC.Name, 
		CASE 
			WHEN c.Name not like '%generic%'
			THEN 'original'
			ELSE 'generic'
		END AS typeLamp
		FROM Inventory.dbo.Compatibility CY (NOLOCK) 
		INNER JOIN Inventory.dbo.ProductCatalog PC
		ON PC.ID = CY.ProductCatalogID
		INNER JOIN 
		Inventory.dbo.Categories c
		ON c.ID = PC.CategoryID
		WHERE ISNULL(CONVERT(NVARCHAR,CY.Partnumber),'') + ISNULL(CONVERT(NVARCHAR,CY.manufacturer),'') like @MODEL and 
		CategoryID IN 
		(
			select ID from Inventory.dbo.Categories where name LIKE '%Lamps with Housing%' OR name LIKE '%Front Projection%'
		)

		INSERT INTO #tmpInfo (SKU, Name, typeLamp) VALUES (999999, 'No SKU exists', 'z')

		SELECT 
		SKU, 
		(CONVERT(NVARCHAR,SKU) + ' / ' + Name)  AS NAME,
		typeLamp
		FROM #tmpInfo
		GROUP BY typeLamp, SKU, Name

END
go

