-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetUnitCost]
(
 @pProductCatalogID int
 
)
RETURNS Integer
AS
BEGIN
	
	DECLARE @lresult int

	SET @lresult = 0;
	

	
			select @lresult = CEILING(a.UnitCost) from ProductCatalog a
			where  (a.ID = @pProductCatalogID) and (not a.UnitCost is null) ;
	
	-- Return the result of the function
	RETURN (@lresult)
END

go

