CREATE FUNCTION fn_get_CategoryName
(
	@pCategoryId as INT
)
RETURNS varchar(250)
AS
BEGIN

	DECLARE @ResultVar as  VARCHAR(250);

	-- Add the T-SQL statements to compute the return value here
	SET @ResultVar = (SELECT CategoryName FROM Categories WHERE CategoryID = @pCategoryId );

	-- Return the result of the function
	RETURN @ResultVar;

END
go

