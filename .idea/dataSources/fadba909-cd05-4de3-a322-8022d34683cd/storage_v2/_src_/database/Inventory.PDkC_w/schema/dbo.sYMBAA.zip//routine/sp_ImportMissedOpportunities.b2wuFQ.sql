
-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <2-16-2015>
-- Description:	<Import CSV MissedOpportunities>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ImportMissedOpportunities] 
		@FilePath NVARCHAR(2000), @pUserID INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[Inventory].[dbo].[MissedOpportunitiesImport_tmp]') AND type in (N'U'))
DROP TABLE [Inventory].[dbo].[MissedOpportunitiesImport_tmp]


DECLARE @FileLocation VARCHAR(200);
DECLARE @FirstImportRow VARCHAR(200);

--Set File Location and Starting Row
SET @FileLocation = @FilePath
SET @FirstImportRow = '2';

--Create Temp Table
CREATE TABLE [Inventory].[dbo].[MissedOpportunitiesImport_tmp]
(
	[SKU] [int] NULL,
	[AssemblySKUNeeded] [int] NULL,
	[Quantity] [int] NULL,
	[CustomerID] [int] NULL,
	[Notes] nvarchar(MAX) NULL,
	[AddToInStockNotifications] BIT
)

--Insert and Convert the CSV file into temp table
INSERT [Inventory].[dbo].[MissedOpportunitiesImport_tmp]
EXEC [Inventory].[dbo].[SSP_CSVToTable]
     @InputFile = @FileLocation
    ,@FirstLine = @FirstImportRow


--Insert from Temp Table to Final Table - This is where all the translations of SKU and Carrier Happen
INSERT INTO [Inventory].[dbo].[MissedOpportunities] (
	[SKU],
	[AssemblySKUNeeded],
	[Quantity],
	[CustomerID],
	[DateRequested],
	[Notes]   
	    )
SELECT	MOItmp.[SKU] AS 'SKU',
		MOItmp.[AssemblySKUNeeded] AS 'AssemblySKUNeeded',
		MOItmp.[Quantity] AS 'Quantity',
		IsNull(MOItmp.[CustomerID],0) AS 'CustomerID',
		GETDATE() AS 'DateRequested',
		MOItmp.[Notes] AS 'Notes'
FROM [Inventory].[dbo].[MissedOpportunitiesImport_tmp] AS MOItmp
WHERE CAST(MOItmp.[SKU] AS NVARCHAR(MAX)) IN (SELECT CAST([ID] AS NVARCHAR(MAX)) FROM [Inventory].[dbo].[ProductCatalog])
AND (CAST(MOItmp.[CustomerID] AS NVARCHAR(MAX)) IN (SELECT CAST([CustomerID] AS NVARCHAR(MAX)) FROM [OrderManager].[dbo].[Customers]) OR MOItmp.CustomerID = 0)


INSERT INTO [Inventory].[dbo].[InStockNotification] (
	[ProductCatalogID],
	[QtyRequired],
	[Notes],
	[UserID]   
	    )
SELECT	MOItmp.[SKU] AS 'ProductCatalogID',
		MOItmp.[Quantity] AS 'QtyRequired',
		MOItmp.[Notes] AS 'Notes',
		@pUserID AS 'UserID'
FROM [Inventory].[dbo].[MissedOpportunitiesImport_tmp] AS MOItmp
WHERE CAST(MOItmp.[SKU] AS NVARCHAR(MAX)) IN (SELECT CAST([ID] AS NVARCHAR(MAX)) FROM [Inventory].[dbo].[ProductCatalog])
AND CAST(@pUserID AS NVARCHAR(MAX)) IN (SELECT CAST([ID] AS NVARCHAR(MAX)) FROM [Inventory].[dbo].[Users])


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[Inventory].[dbo].[MissedOpportunitiesImport_tmp]') AND type in (N'U'))
DROP TABLE [Inventory].[dbo].[MissedOpportunitiesImport_tmp]

EXEC master..xp_cmdshell 'C:\sharedb\systemimports\archive\archive.bat'

END

go

