

--This procedure is created to insert MITSKU for the following categories in Suppliers table.
-- Category 1 - FP Lamp with Housing Generic 
	-- Supplier 1 = ArcLite (ID = 3)
	-- Supplier 2 = Glory (ID = 5)
	-- Supplier 3 = CLP (ID = 10)
	-- Supplier 4 = GrandBulbs (ID = 11)
	-- Supplier 5 = Leader (ID = 16)
	-- Supplier 6 = YITA (ID = 17)
	-- Supplier 7 = MI Technologies (ID = 14)
	
-- Category 2 - FP Housing Only 
	-- Supplier 1 = MI Technologies (ID = 14)
	-- Supplier 2 = MoldGate (ID = 12)
	-- Supplier 3 = GrandBulbs(ID = 11)
	-- Supplier 4 = SounthernTech (ID = 13)
	-- Supplier 5 = KennedyWebster (ID = 15)
	-- Supplier 6 = Leader (ID = 16)
	-- Supplier 7 = YITA (ID = 17)
	-- Supplier 8 = FYV (ID = 18)
	-- Supplier 9 = FYV (ID = 20)
	-- Supplier 10 = FYV (ID = 21)

-- And delete the MITSKUs that does not exist or merged.

CREATE PROCEDURE [dbo].[SuppliersUpdate]

AS 
BEGIN

-- Delete all the SKUs that have been deleted from ERP.
DELETE FROM Inventory.dbo.Suppliers
WHERE ProductCatalogID NOT IN ( Select ID FROM Inventory.dbo.ProductCatalog )

   
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INSERT MISSING SKUS - FP Lamp With Housing Generic
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Supplier 1 = ArcLite (ID = 3)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '3', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='3')
 AND CategoryID = '24')
 

-- Supplier 2 = Glory (ID = 5)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '5', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='5')
 AND CategoryID = '24')

-- Supplier 3 = CLP (ID = 10)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '10', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='10')
 AND CategoryID = '24')
	
-- Supplier 4 = GrandBulbs (ID = 11)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '11', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='11')
 AND CategoryID = '24')

 -- Supplier 5 = Leader (ID = 16)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '16', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='16')
 AND CategoryID = '24')

 -- Supplier 6 = YITA (ID = 17)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '17', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='17')
 AND CategoryID = '24')


  -- MI Technologies (ID = 14)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '14', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='14')
 AND CategoryID = '24')
------------------------------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INSERT MISSING SKUS - FP Housing Only
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Supplier 1 = MI Technologies (ID = 14)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '14', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='14')
 AND CategoryID = '60')
 

-- Supplier 2 = Moldgate (ID = 12)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '12', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='12')
 AND CategoryID = '60')

-- Supplier 3 = GrandBulbs (ID = 11)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '11', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='11')
 AND CategoryID = '60')
	
-- Supplier 4 = SounthernTech (ID = 13)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '13', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='13')
 AND CategoryID = '60')
 
 -- Supplier 4 = KennedyWebster (ID = 15)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '15', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='15')
 AND CategoryID = '60')

-- Supplier 6 = Leader (ID = 16)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '16', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='16')
 AND CategoryID = '60')

-- Supplier 7 = YITA (ID = 17)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '17', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='17')
 AND CategoryID = '60')
	
-- Supplier 8 = FYV (ID = 18)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '18', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='18')
 AND CategoryID = '60')

 -- Supplier 9 = LampsChoice (ID = 20)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '20', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='20')
 AND CategoryID = '60')

  -- Supplier 10 = LampsChoice (ID = 21)
INSERT INTO Inventory.dbo.Suppliers
(ProductCatalogId, SupplierID, UnitCost, Enabled)
(Select ID, '21', '0', '1' FROM Inventory.dbo.ProductCatalog
 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID ='21')
 AND CategoryID = '60')

------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------

---DELETE DUPLICATES
DELETE FROM [Inventory].[dbo].[Suppliers] 
WHERE (SELECT count(S2.ProductCatalogId) FROM [Inventory].[dbo].[Suppliers] AS S2 WHERE S2.[SupplierID] = Suppliers.[SupplierID] AND S2.[ProductCatalogID] = Suppliers.[ProductCatalogId]) > 1


END


go

