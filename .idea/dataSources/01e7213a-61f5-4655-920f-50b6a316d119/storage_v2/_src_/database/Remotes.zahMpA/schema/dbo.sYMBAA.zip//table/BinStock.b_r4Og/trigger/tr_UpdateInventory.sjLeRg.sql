-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-05-14
-- Description:	Update Inventory
-- =============================================
CREATE TRIGGER [dbo].[tr_UpdateInventory]
   ON  dbo.BinStock
   AFTER INSERT,DELETE,UPDATE
AS 
BEGIN
	DECLARE @SKU	NVARCHAR(50),
			@Qty	INT,
			@New	INT,
			@Used	INT,
			@CN		INT,
			@NC		INT
	SET NOCOUNT ON;

    SELECT @SKU = SKU
	FROM inserted

	--SET @New = ISNULL((SELECT SUM(StockQty) FROM [Remotes].[dbo].[BinStock] WITH(NOLOCK) WHERE ScanCode = 'NEW' AND SKU = @SKU),0)
	--SET @Used = ISNULL((SELECT SUM(StockQty) FROM [Remotes].[dbo].[BinStock] WITH(NOLOCK) WHERE ScanCode = 'USED' AND SKU = @SKU),0)
	--SET @CN = ISNULL((SELECT SUM(StockQty) FROM [Remotes].[dbo].[BinStock] WITH(NOLOCK) WHERE ScanCode = 'CN' AND SKU = @SKU),0)
	--SET @NC = ISNULL((SELECT SUM(StockQty) FROM [Remotes].[dbo].[BinStock] WITH(NOLOCK) WHERE ScanCode = 'NC' AND SKU = @SKU),0)

	--UPDATE Remotes.dbo.Inventory SET QuantityCN = @CN, QuantityMX = @Used, QuantityMXNew = @New, QuantityNoCover = @NC WHERE SKU = @SKU
END
go

disable trigger tr_UpdateInventory on BinStock
go

