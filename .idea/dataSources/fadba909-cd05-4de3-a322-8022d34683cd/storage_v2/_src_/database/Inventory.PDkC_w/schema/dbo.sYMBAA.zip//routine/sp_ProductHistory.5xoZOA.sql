-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ProductHistory]
	-- Add the parameters for the stored procedure here
	@productid int,
	@InitialDate datetime,
	@finalDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT a.Date
		,flow
		,case
			when flow = 1 then 'Added'
			when flow = 2 then 'Removed'
			when flow = 3 then 'Transfered'
			else 'UnknowAdjustment'
		end as "AdjustmentType"
		, a.Origin, 
		Inventory.dbo.fn_GetAccountName(a.origin),
		a.Destination,
		Inventory.dbo.fn_GetAccountName(a.Destination),
   	   b.ProductCatalogID, b.Quantity, 0000000000.00 as remainet, Inventory.dbo.fn_GetUserName(a.UserID),
   	   a.Comments
	 FROM Inventory.dbo.InventoryAdjustments a,
	      Inventory.dbo.InventoryAdjustmentDetails b
	 WHERE (a.ID = b.InventoryAdjustmentsID)
			and (b.ProductCatalogID = @productid)
			and (a.Date between @InitialDate and @finalDate)
			
			
	  
	
END
go

