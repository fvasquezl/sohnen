-- =============================================
-- Author:		Araceli
-- Create date: 3/14/2016
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_check__Order]
	@OrderNumber int
AS
BEGIN
	/****** Script for SelectTopNRows command from SSMS  ******/
with a as 
(
	select CASE WHEN SUM(OD.QuantityOrdered) >=  SUM(BH.Qty) THEN 1 ELSE 0 END as Processed
	from OrderManager.dbo.[Order Details] OD
	left outer join [Inventory].[dbo].[Bins_History] BH
	ON BH.OrderNumber = OD.OrderNumber AND BH.Product_Catalog_ID = OD.SKU
	where OD.OrderNumber = @OrderNumber and OD.Adjustment = 0
	group by OD.SKU, BH.Product_Catalog_ID
  ) 
  select SUM(Processed) as Procesed from a 
END
go

