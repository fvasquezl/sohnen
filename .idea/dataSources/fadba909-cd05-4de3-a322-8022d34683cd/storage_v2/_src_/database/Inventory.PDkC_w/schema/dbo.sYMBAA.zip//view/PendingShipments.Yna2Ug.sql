CREATE VIEW dbo.PendingShipments
AS
SELECT        OrderDate, OrderNumber, WebOrderNumber, ShippingMethod, OrderStatus, Company, Name, Cart, Notes
FROM            dbo.PendingShipmentsTable
go

