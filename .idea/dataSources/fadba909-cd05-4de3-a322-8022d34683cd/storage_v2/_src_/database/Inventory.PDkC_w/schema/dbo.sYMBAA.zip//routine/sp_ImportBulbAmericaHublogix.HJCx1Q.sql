
-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <6-12-2017>
-- Description:	<Import CSV Purchase Order History from Quickbooks>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ImportBulbAmericaHublogix] 
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--	DROP TABLE #BulbAmericaImport_tmp
--	DROP TABLE #BulbAmericaImport

--Set Variables for CustomerID
	DECLARE @ShipFromName			NVARCHAR(255),
			@ShipFromCompany		NVARCHAR(255),
			@ShipFromAddressLine1	NVARCHAR(255),
			@ShipFromAddressLine2	NVARCHAR(255),
			@ShipFromCity			NVARCHAR(255),
			@ShipFromState			NVARCHAR(255),
			@ShipFromZipCode		NVARCHAR(255),
			@ShipFromCountry		NVARCHAR(255),
			@ShipFromPhone			NVARCHAR(255),
			@ShipFromEmail			NVARCHAR(255),
			@countrycode			NVARCHAR(255)
		
	---Get values from order manager	
    SELECT 
		@ShipFromName = OMC.[FullName]
		, @ShipFromCompany = OMC.[Company]
		, @ShipFromAddressLine1 = OMC.[Address]
		, @ShipFromAddressLine2	 = OMC.[Address2]
		, @ShipFromCity = OMC.[City]
		, @ShipFromState = OMC.[State]
		, @ShipFromZipCode = OMC.[Zip]
		, @ShipFromCountry = OMC.[Country]
		, @ShipFromPhone = OMC.[Phone]
		, @ShipFromEmail = OMC.[Email]
	FROM OrderManager.dbo.Customers AS OMC WITH(NOLOCK) 
	WHERE OMC.CustomerID = '1332724';  
		
	-- Get the country code
	SELECT @countrycode = code FROM [OrderManager].[dbo].[Countries] WITH(NOLOCK)
	WHERE  Country =  @ShipFromCountry;
		-- Set default ShippingMethod

--Create Temp Table
CREATE TABLE #BulbAmericaImport_tmp
(
[LineID] [int]					IDENTITY(1,1) NOT NULL,
[Order - Number]				NVARCHAR(MAX),
[Item - Qty]					NVARCHAR(MAX),
[Item - SKU]					NVARCHAR(MAX),
[Ship To - Name]				NVARCHAR(MAX),
[Ship To - Company]				NVARCHAR(MAX),
[Ship To - Address 1]			NVARCHAR(MAX),
[Ship To - Address 2]			NVARCHAR(MAX),
[Ship To - City]				NVARCHAR(MAX),
[Ship To - Country]				NVARCHAR(MAX),
[Ship To - Phone]				NVARCHAR(MAX),
[Ship To - Postal Code]			NVARCHAR(MAX),
[Ship To - State]				NVARCHAR(MAX),
[Carrier - Service Selected]	NVARCHAR(MAX),
)

--Insert and Convert the CSV file into temp table
INSERT INTO #BulbAmericaImport_tmp (
[Order - Number],
[Item - Qty],
[Item - SKU],
[Ship To - Name],
[Ship To - Company],
[Ship To - Address 1],
[Ship To - Address 2],
[Ship To - City],
[Ship To - Country],
[Ship To - Phone],
[Ship To - Postal Code],
[Ship To - State],
[Carrier - Service Selected]
)
SELECT [OrderId] AS [Order - Number]
      ,[Qty] AS [Item - Qty]
	  ,[SKU] AS [Item - SKU]      
      --,[Price]
      ,[ShippingName] AS [Ship To - Name]
	  ,'' AS [Ship To - Company]
      ,[ShippingAddress1] AS [Ship To - Address 1]
	  ,[ShippingAddress2] AS [Ship To - Address 2]
      ,[ShippingCity] AS [Ship To - City]
	  ,[ShippingCountry] AS [Ship To - Country]
	  ,'' AS [Ship To - Phone]
      ,[ShippingZipcode] AS [Ship To - Postal Code]
      ,[ShippingState] AS [Ship To - State]
	  ,RTRIM(LTRIM([ShipVia])) AS [Carrier - Service Selected]
      --,[ShippingEmail]
      
  FROM [Inventory].[dbo].[BulbAmericaOrders]
  --ONLY BRING LAST 7 DAY ORDERS MAX
  WHERE [Stamp] BETWEEN GETDATE()-7 AND GETDATE() AND Imported = 0
  
--CLEAN
DELETE FROM #BulbAmericaImport_tmp WHERE [Item - SKU] = ''

--CREATE IN-MEMORY Table
DECLARE @tmpTableMITSKUTranslations TABLE ([CatalogID] NVARCHAR(MAX), [MITSKU] INT, [NAME] NVARCHAR(MAX))

--Generic Housing
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-G', PJD.[EncSKU], PJD.[Brand]+' '+PJD.[PartNumber]+' Compatible Housing' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[EncSKU] IS NOT NULL AND PJD.[EncSKU] != '-' AND PJD.[CatalogID] IS NOT NULL

--Philips Housing
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-OP', PJD.[EncSKUPH], PJD.[Brand]+' '+PJD.[PartNumber]+' Philips Housing' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[EncSKUPH] IS NOT NULL AND PJD.[EncSKUPH] != '-' AND PJD.[CatalogID] IS NOT NULL

--Osram Housing
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-OO', PJD.[EncSKUOS], PJD.[Brand]+' '+PJD.[PartNumber]+' Osram Housing' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[EncSKUOS] IS NOT NULL AND PJD.[EncSKUOS] != '-' AND PJD.[CatalogID] IS NOT NULL

--PhoenixHousing
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-OX', PJD.[EncSKUPX], PJD.[Brand]+' '+PJD.[PartNumber]+' Phoenix Housing' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[EncSKUPX] IS NOT NULL AND PJD.[EncSKUPX] != '-' AND PJD.[CatalogID] IS NOT NULL

--Ushio Housing
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-OU', PJD.[EncSKUUSH], PJD.[Brand]+' '+PJD.[PartNumber]+' Ushio Housing' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[EncSKUUSH] IS NOT NULL AND PJD.[EncSKUUSH] != '-' AND PJD.[CatalogID] IS NOT NULL

--OEM Housing
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-OE', PJD.[EncSKUOEM], PJD.[Brand]+' '+PJD.[PartNumber]+' OEM Housing' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[EncSKUOEM] IS NOT NULL AND PJD.[EncSKUOEM] != '-' AND PJD.[CatalogID] IS NOT NULL

--Generic Bare
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-BG', PJD.[BareSKU], PJD.[Brand]+' '+PJD.[PartNumber]+' Compatible Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[BareSKU] IS NOT NULL AND PJD.[BareSKU] != '-' AND PJD.[CatalogID] IS NOT NULL

--Philips Bare
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-BOP', PJD.[BareSKUPH], PJD.[Brand]+' '+PJD.[PartNumber]+' Philips Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[BareSKUPH] IS NOT NULL AND PJD.[BareSKUPH] != '-' AND PJD.[CatalogID] IS NOT NULL

--Osram Bare
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-BOO', PJD.[BareSKUOS], PJD.[Brand]+' '+PJD.[PartNumber]+' Osram Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[BareSKUOS] IS NOT NULL AND PJD.[BareSKUOS] != '-' AND PJD.[CatalogID] IS NOT NULL

--Phoenix Bare
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-BOX', PJD.[BareSKUPX], PJD.[Brand]+' '+PJD.[PartNumber]+' Phoenix Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[BareSKUPX] IS NOT NULL AND PJD.[BareSKUPX] != '-' AND PJD.[CatalogID] IS NOT NULL

--Ushio Bare
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-BOU', PJD.[BareSKUUSH], PJD.[Brand]+' '+PJD.[PartNumber]+' Ushio Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[BareSKUUSH] IS NOT NULL AND PJD.[BareSKUUSH] != '-' AND PJD.[CatalogID] IS NOT NULL

--OEM Bare
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PJD.[CatalogID]+'-BOE', PJD.[BareSKUOEM], PJD.[Brand]+' '+PJD.[PartNumber]+' OEM Bare' FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
	WHERE PJD.[BareSKUOEM] IS NOT NULL AND PJD.[BareSKUOEM] != '-' AND PJD.[CatalogID] IS NOT NULL

--ALL REGULAR SKU's
	INSERT INTO @tmpTableMITSKUTranslations ([CatalogID],[MITSKU],[NAME])
	SELECT PC.[ID], PC.[ID], PC.[Name] FROM [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK)
	

--ADD Column for SKU Translation
ALTER TABLE #BulbAmericaImport_tmp ADD [MITSKU_Translated] INT
UPDATE RSSItmp SET 
RSSItmp.[MITSKU_Translated] = (SELECT [MITSKU] FROM @tmpTableMITSKUTranslations WHERE [CatalogID] = RSSItmp.[Item - SKU])
FROM #BulbAmericaImport_tmp AS RSSITmp


--SELECT * FROM #BulbAmericaImport_tmp



----ReCreate Final Table
CREATE TABLE #BulbAmericaImport
(	  
	[CustomerID] [nvarchar](25) NULL,
	[BillToName] [nvarchar](255) NULL,
	[BillToCompany] [nvarchar](255) NULL,
	[BillToEmail] [nvarchar](255) NULL,
	[BillToAddress] [nvarchar](255) NULL,
	[BillToCity] [nvarchar](255) NULL,
	[BillToState] [nvarchar](5) NULL,
	[BillToZip] [nvarchar](15) NULL,
	[BillToCountry] [nvarchar](50) NULL,
	[OrderNumber] [nvarchar](50) NULL,
	[OrderDate] [datetime] NULL,
	[LocalSKU] INT NULL,
	[CustomerSKU] [nvarchar](100) NULL,
	[Title] [nvarchar](255) NULL,
	[LineItem] [nvarchar](5) NULL,
	[ItemUnitPrice] [decimal](19, 4) NULL,
	[ItemUnitShippingCharge] [decimal](19, 4) NULL,
	[QuantityOrdered] [nvarchar](5) NULL,
	[ShippingTotal] [decimal](19, 4) NULL,
	[OrderTotal] [decimal](19, 4) NULL,
	[ShipToName] [nvarchar](255) NULL,
	[ShipToCompany] [nvarchar](255) NULL,
	[ShipToAddressLine1] [nvarchar](255) NULL,
	[ShipToAddressLine2] [nvarchar](255) NULL,
	[ShipToCity] [nvarchar](50) NULL,
	[ShipToState] [nvarchar](25) NULL,
	[ShipToZipCode] [nvarchar](20) NULL,
	[ShipToCountry] [nvarchar](50) NULL,
	[ShipToPhoneNumber] [nvarchar](20) NULL,
	[ShippingMethod] [nvarchar](max) NULL,
	[OMPaymentMethod] [nvarchar](50) NULL,
	[PONumber] [nvarchar](50) NULL,
	[OrderInstructions] [nvarchar](max) NULL,
	[OMComments] [nvarchar](max) NULL
)


--Insert from Temp Table to Final Table - This is where all the translations of SKU and Carrier Happen
INSERT INTO #BulbAmericaImport (
	   [CustomerID]
      ,[BillToName]
      ,[BillToCompany]
      ,[BillToEmail]
      ,[BillToAddress]
      ,[BillToCity]
      ,[BillToState]
      ,[BillToZip]
      ,[BillToCountry]
      ,[OrderNumber]
      ,[OrderDate]
      ,[LocalSKU]
	  ,[CustomerSKU]
      ,[Title]
      ,[LineItem]
      ,[ItemUnitPrice]
      ,[ItemUnitShippingCharge]
      ,[QuantityOrdered]
      ,[ShippingTotal]
      ,[OrderTotal]
      ,[ShipToName]
      ,[ShipToCompany]
      ,[ShipToAddressLine1]
      ,[ShipToAddressLine2]
      ,[ShipToCity]
      ,[ShipToState]
      ,[ShipToZipCode]
      ,[ShipToCountry]
      ,[ShipToPhoneNumber]
      ,[ShippingMethod]
      ,[OMPaymentMethod]
      ,[PONumber]
      ,[OrderInstructions]
      ,[OMComments] )
SELECT 
		 	 '1332724' AS 'CustomerID'
			,@ShipFromName AS 'BillToName'
			,@ShipFromCompany AS 'BillToCompany'
			,@ShipFromEmail AS 'BillToEmail'
			,@ShipFromAddressLine1 AS 'BillToAddress'
			,@ShipFromCity AS 'BillToCity'
			,@ShipFromState AS 'BillToState'
			,@ShipFromZipCode AS 'BillToZip'
			,@ShipFromCountry AS 'BillToCountry'
			,RSSItmp.[Order - Number] AS 'OrderNumber'
			,GETDATE() AS 'OrderDate'
			,RSSItmp.[MITSKU_Translated] AS 'LocalSKU'
			,RSSItmp.[Item - SKU] AS 'CustomerSKU'
			
			,(SELECT [Name] FROM @tmpTableMITSKUTranslations WHERE [CatalogID] = RSSItmp.[Item - SKU]) AS 'Title'


			,ROW_NUMBER() OVER (PARTITION BY [Order - Number] ORDER BY [LineID] ASC) AS 'LineItem'

			,(SELECT CSP.SalePrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WITH(NOLOCK) WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST((SELECT [MITSKU] FROM @tmpTableMITSKUTranslations WHERE [CatalogID] = RSSItmp.[Item - SKU])  AS NVARCHAR(MAX))) 
			AS 'ItemUnitPrice'
			

			,(CASE WHEN RSSItmp.[Carrier - Service Selected] = 'Standard (5-7 Business Days)' THEN (SELECT CSP.DSEconomyPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[MITSKU_Translated] AS NVARCHAR(MAX))) 
			WHEN RSSItmp.[Carrier - Service Selected] = 'Two-Day (No Saturday Delivery)' THEN (SELECT CSP.DS2ndDayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[MITSKU_Translated] AS NVARCHAR(MAX))) 
			WHEN RSSItmp.[Carrier - Service Selected] = 'One-Day (No Saturday Delivery)' THEN (SELECT CSP.DS1DayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[MITSKU_Translated] AS NVARCHAR(MAX))) 
			WHEN RSSItmp.[Carrier - Service Selected] = 'Shipping Label Attached' THEN '0'
			ELSE '0' END)
			AS 'ItemUnitShippingCharge'
			
			,RSSItmp.[Item - Qty] AS 'QuantityOrdered'
			
			,(CASE WHEN RSSItmp.[Carrier - Service Selected] = 'Standard (5-7 Business Days)' THEN (CAST((SELECT CSP.DSEconomyPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[MITSKU_Translated] AS NVARCHAR(MAX))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN RSSItmp.[Carrier - Service Selected] = 'Two-Day (No Saturday Delivery)' THEN (CAST((SELECT CSP.DS2ndDayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[MITSKU_Translated] AS NVARCHAR(MAX))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN RSSItmp.[Carrier - Service Selected] = 'One-Day (No Saturday Delivery)' THEN (CAST((SELECT CSP.DS1DayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[MITSKU_Translated] AS NVARCHAR(MAX))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN RSSItmp.[Carrier - Service Selected] = 'Shipping Label Attached' THEN '0'
			ELSE '0' END)
			AS 'ShippingTotal'
			
			,((SELECT CSP.SalePrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WITH(NOLOCK) WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[Item - SKU] AS NVARCHAR(MAX)))*RSSItmp.[Item - Qty])
			+
			(CASE WHEN RSSItmp.[Carrier - Service Selected] = 'Standard (5-7 Business Days)' THEN (CAST((SELECT CSP.DSEconomyPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[MITSKU_Translated] AS NVARCHAR(MAX))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN RSSItmp.[Carrier - Service Selected] = 'Two-Day (No Saturday Delivery)' THEN (CAST((SELECT CSP.DS2ndDayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[MITSKU_Translated] AS NVARCHAR(MAX))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN RSSItmp.[Carrier - Service Selected] = 'One-Day (No Saturday Delivery)' THEN (CAST((SELECT CSP.DS1DayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = '1332724' AND CAST(CSP.ProductCatalogID AS NVARCHAR(MAX)) = CAST(RSSItmp.[MITSKU_Translated] AS NVARCHAR(MAX))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN RSSItmp.[Carrier - Service Selected] = 'Shipping Label Attached' THEN '0'
			ELSE '0' END)
			AS 'OrderTotal'

			,RSSItmp.[Ship To - Name] AS 'ShipToName'
			,RSSItmp.[Ship To - Company] AS 'ShipToCompany'
			,RSSItmp.[Ship To - Address 1]  AS 'ShipToAddressLine1'
			,RSSItmp.[Ship To - Address 2] AS 'ShipToAddressLine2'
			,RSSItmp.[Ship To - City] AS 'ShipToCity'
			,RSSItmp.[Ship To - State] AS 'ShipToState'
			,RSSItmp.[Ship To - Postal Code] AS 'ShipToZipCode'
			,RSSItmp.[Ship To - Country] AS 'ShipToCountry'
			,RSSItmp.[Ship To - Phone] AS 'ShipToPhoneNumber'
			
			,RSSItmp.[Carrier - Service Selected] AS 'ShippingMethod'
			--(CASE WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WITH(NOLOCK) WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = '1332724'),'N/A') = 'Economy' THEN 'Standard (5-7 Business Days)' 
			--WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WITH(NOLOCK) WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = '1332724'),'N/A') = '2Day' THEN 'Two-Day (No Saturday Delivery)' 
			--WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WITH(NOLOCK) WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = '1332724'),'N/A') = '1Day' THEN 'One-Day (No Saturday Delivery)' 
			--WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WITH(NOLOCK) WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = '1332724'),'N/A') = 'ShippingLabelAttached' THEN 'Shipping Label Attached'
			--ELSE 'Shipping Label Attached' END) AS 'ShippingMethod'

			,'Integration' AS 'OMPaymentMethod'
			,RSSItmp.[Order - Number] AS 'PONumber'
			,RSSItmp.[Order - Number] AS 'OrderInstructions'
			,'' AS 'OMComments'
FROM #BulbAmericaImport_tmp AS RSSItmp WITH(NOLOCK)
--Update WHERE NOT EXISTS INSTEAD OF NOT IN -- sometimes same order number, different skus come on different lines... this was only improting the first line so we made this correction.
WHERE NOT EXISTS (SELECT 1 FROM [Resellers].[dbo].[ResellerOrders] AS RO WITH(NOLOCK) WHERE RSSItmp.[Order - Number] = RO.[OrderNumber] AND RSSItmp.[Item - SKU] = RO.[CustomerSKU])


--Update Shipping Total and Order Total for Order Manager import
--First we set the shipping price for orders with greater than 2 line items and greater than 1 quantity
UPDATE RSSI SET RSSI.[ShippingTotal] = (CASE WHEN RSSI.LineItem > 1 THEN (RSSI.[ItemUnitShippingCharge]/2)
WHEN RSSI.LineItem = 1 AND RSSI.QuantityOrdered > 1 THEN (RSSI.QuantityOrdered*(RSSI.[ItemUnitShippingCharge]/2)) + (RSSI.[ItemUnitShippingCharge]/2)
ELSE RSSI.[ItemUnitShippingCharge] END)
FROM #BulbAmericaImport AS RSSI

--We update the shipping total again to sum up all the shipping totals calculated in previous query.. and injuect this into all the rows for this order
UPDATE RSSI SET RSSI.[ShippingTotal] = (SELECT SUM(RSSI2.[ShippingTotal]) FROM #BulbAmericaImport AS RSSI2 WHERE RSSI2.OrderNumber = RSSI.OrderNumber)
FROM #BulbAmericaImport AS RSSI

--We sum all the item totals for the particular order then we add a single shipping total we received from the previous update.. and inject this into all the rows for this order
UPDATE RSSI SET RSSI.[OrderTotal] = (SELECT SUM(RSSI2.[ItemUnitPrice]*RSSI2.[QuantityOrdered]) FROM #BulbAmericaImport AS RSSI2 WHERE RSSI2.[OrderNumber] = RSSI.[OrderNumber])+RSSI.ShippingTotal
FROM #BulbAmericaImport AS RSSI

--SELECT * FROM #BulbAmericaImport

----
-----

--FINAL IMPORT INTO ResellerOrders Table
INSERT INTO [Resellers].[dbo].[ResellerOrders] (
	   [CustomerID]
      ,[BillToName]
      ,[BillToCompany]
      ,[BillToEmail]
      ,[BillToAddress]
      ,[BillToCity]
      ,[BillToState]
      ,[BillToZip]
      ,[BillToCountry]
      ,[OrderNumber]
      ,[OrderDate]
      ,[LocalSKU]
	  ,[CustomerSKU]
      ,[Title]
      ,[LineItem]
      ,[ItemUnitPrice]
      ,[ItemUnitShippingCharge]
      ,[QuantityOrdered]
      ,[ShippingTotal]
      ,[OrderTotal]
      ,[ShipToName]
      ,[ShipToCompany]
      ,[ShipToAddressLine1]
      ,[ShipToAddressLine2]
      ,[ShipToCity]
      ,[ShipToState]
      ,[ShipToZipCode]
      ,[ShipToCountry]
      ,[ShipToPhoneNumber]
      ,[ShippingMethod]
      ,[OMPaymentMethod]
      ,[PONumber]
      ,[OrderInstructions]
      ,[OMComments] )

SELECT [CustomerID]
      ,[BillToName]
      ,[BillToCompany]
      ,[BillToEmail]
      ,[BillToAddress]
      ,[BillToCity]
      ,[BillToState]
      ,[BillToZip]
      ,[BillToCountry]
      --Changed to SourceOrderID for imports instead of SourceOrderNumber
	  --,CASE WHEN len(CAST([OrderNumber] AS NVARCHAR(50))) - len(replace(CAST([OrderNumber] AS NVARCHAR(50)), '-', '')) > 1  THEN RIGHT(REPLACE(CAST([OrderNumber] AS NVARCHAR(50)),'-',''),7)  ELSE replace(CAST([OrderNumber] AS NVARCHAR(50)),'-','') END AS [OrderNumber]
	  ,[OrderNumber]
      ,[OrderDate]
      ,[LocalSKU]
	  ,[CustomerSKU]
      ,[Title]
      ,[LineItem]
      ,[ItemUnitPrice]
      ,[ItemUnitShippingCharge]
      ,[QuantityOrdered]
      ,[ShippingTotal]
      ,[OrderTotal]
      ,[ShipToName]
      ,[ShipToCompany]
      ,[ShipToAddressLine1]
      ,[ShipToAddressLine2]
      ,[ShipToCity]
      ,[ShipToState]
      ,[ShipToZipCode]
      ,[ShipToCountry]
      ,[ShipToPhoneNumber]
      ,[ShippingMethod]
      ,[OMPaymentMethod]
      ,[PONumber]
      ,[OrderInstructions]
      ,[OMComments]
FROM #BulbAmericaImport

--Import Complete
UPDATE BAO
SET BAO.Imported = 1
FROM Inventory.dbo.BulbAmericaOrders BAO
INNER JOIN #BulbAmericaImport_tmp TMP
ON TMP.[Order - Number] = BAO.[OrderId] AND TMP.[Item - SKU] = BAO.[SKU]

END

go

