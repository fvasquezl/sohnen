CREATE VIEW [dbo]._dta_mv_78 WITH SCHEMABINDING AS SELECT  [dbo].[Compatibility].[PartNumber] as _col_1,  [dbo].[Compatibility].[ProductCatalogID] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[Compatibility]   WHERE  [dbo].[Compatibility].[ProductCatalogID] = 133537  GROUP BY  [dbo].[Compatibility].[PartNumber],  [dbo].[Compatibility].[ProductCatalogID]
go

