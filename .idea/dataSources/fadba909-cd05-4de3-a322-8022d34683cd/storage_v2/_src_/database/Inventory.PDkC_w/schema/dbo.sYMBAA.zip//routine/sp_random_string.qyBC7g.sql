-- =============================================
-- Author:		Luis Bautista
-- Create date: Dec 27, 2013
-- Description:	Generates a random string with a given len and valid characters.
-- =============================================
CREATE PROCEDURE [dbo].[sp_random_string]

AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @Length int;
	DECLARE @CharPool varchar(200);
	DECLARE @PoolLength int;
	DECLARE @RandomString varchar(200);
	DECLARE @LoopCount int;
	DECLARE @CMDstr varchar(200);
	DECLARE @ExistSTR int;
	DECLARE @LockCount int;
	DECLARE @MaxLoops2PreventServerLock int;
	DECLARE @PoolCharIndex int;
	
	
	--  max length  
	SET @Length = 8;
	SET @LockCount = 0;
	SET @MaxLoops2PreventServerLock = 1000;

	
	SET @CharPool = 
				'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
	SET @PoolLength = DataLength(@CharPool)

	SET @ExistSTR = 1;
	SET @RandomString = ''
	
	WHILE (@ExistSTR <> 0) and (@LockCount <  @MaxLoops2PreventServerLock  )
	BEGIN
			SET @LoopCount = 0
			
			WHILE (@LoopCount < @Length) 
			BEGIN
				SET @PoolCharIndex = CONVERT(int, RAND() * @PoolLength);
				IF @PoolCharIndex = 0
				BEGIN
					SET @PoolCharIndex = 1;
				END
				
				SELECT @RandomString = @RandomString + 	SUBSTRING(@Charpool,@PoolCharIndex , 1);
				SET @LoopCount = @LoopCount + 1
			END
	
			SET @ExistSTR = 0;
	
			SET @ExistSTR = (SELECT count(MITSerial)  
								FROM [Inventory].[dbo].[LampProduction]
								WHERE convert(varchar,MITSerial) =  @RandomString 
							);
	
		
			
			IF @ExistSTR is null
			BEGIN
				SET @ExistSTR  = 0;
			END
			
			IF @ExistSTR > 0
			BEGIN
				SET @RandomString = '';
			END

			SET @LockCount = @LockCount + 1;
	END
	
	Select @RandomString as Result;
END
go

