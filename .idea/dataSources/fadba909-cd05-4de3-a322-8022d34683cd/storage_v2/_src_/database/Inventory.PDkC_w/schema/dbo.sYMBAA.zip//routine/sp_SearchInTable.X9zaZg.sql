-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE sp_SearchInTable
	-- Add the parameters for the stored procedure here
	@TableName varchar(100),
	@FieldList varchar(100),
	@WordList varchar(100)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   Declare @SQL VarChar(1000)

	
	SELECT @SQL = 'SELECT * FROM ' 
	SELECT @SQL = @SQL + @TableName

	Exec ( @SQL)

END
go

