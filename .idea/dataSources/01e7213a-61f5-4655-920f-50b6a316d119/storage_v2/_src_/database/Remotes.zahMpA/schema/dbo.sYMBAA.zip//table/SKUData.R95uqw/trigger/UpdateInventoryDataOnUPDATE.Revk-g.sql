-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[UpdateInventoryDataOnUPDATE]
   ON dbo.SKUData
   AFTER UPDATE
AS 
BEGIN

	SET NOCOUNT ON;

    EXECUTE [Remotes].[dbo].[sp_UpdateRemotesDB]

END
go

disable trigger UpdateInventoryDataOnUPDATE on SKUData
go

