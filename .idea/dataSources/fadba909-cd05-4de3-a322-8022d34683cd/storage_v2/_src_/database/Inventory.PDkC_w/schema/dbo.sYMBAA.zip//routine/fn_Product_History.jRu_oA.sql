-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Product_History]
(	
	@pProductCatalogId as Integer,
	@pAccountId  as Integer
)
RETURNS 
@History TABLE 
(
	id int,
	AdjustmentId  int,
	TimePrint  datetime,
	flow int,
	AdjustmentType  varchar(50),
	location  int,
	locationname varchar(50),
	qty  real,
	remaning  real,
	comments varchar(250),
	userid  int,
	username  varchar(50)
)
AS
BEGIN

	DECLARE @ia_ID int
	DECLARE @ia_date datetime
	DECLARE @ia_flow int
	DECLARE @ia_origin int
	DECLARE @ia_destination int
	DECLARE @iad_quantity real
	DECLARE @ia_comments varchar(250)
	DECLARE @ia_userid int
	DECLARE @H_ID int
	DECLARE @AdjustmentName varchar(50)
	DECLARE @location int
	DECLARE @remianing real
	
	
	
	SET @H_ID = 0
	SET @remianing = 0
	--
	
	DECLARE History_Cursor  CURSOR FOR
									SELECT 
											a.id
											,a.Date
											,a.flow
											,a.Origin
											,a.Destination
											,b.Quantity
   											,a.Comments
   											,a.userid
   											,case
													when a.flow = 1 then 'Inbound'
													when a.flow = 2 then 'Outbound'
													when a.flow = 3 AND a.origin = @pAccountID then 'Outbound(TR)'
													when a.flow = 3 AND a.destination = @pAccountID then 'Inbound(TR)'
													else 'UnknowAdjustment'
											end as "AdjustmentName"
											
											, case
													when a.flow = 1 then a.destination
													when a.flow = 2 then a.destination
													when a.flow = 3 AND a.origin = @pAccountID then a.destination
													when a.flow = 3 AND a.destination = @pAccountID then a.origin
													else 0
											end as "Location"
											
   									FROM Inventory.dbo.InventoryAdjustments a,
										 Inventory.dbo.InventoryAdjustmentDetails b
									WHERE (a.ID = b.InventoryAdjustmentsID)
											and (b.ProductCatalogID = @pProductCatalogId)
											and ((a.origin = @pAccountId)OR (a.destination = @pAccountId));

	OPEN History_Cursor;

	-- Fetch the last row in the cursor. and set it the current position.
	FETCH NEXT FROM History_Cursor
	INTO @ia_id, @ia_date, @ia_flow, @ia_origin, @ia_destination, @iad_quantity, @ia_comments, @ia_userid
		,@AdjustmentName, @location;
	

	WHILE @@FETCH_STATUS = 0
	BEGIN
	
		SET @H_ID = @H_ID + 1
		IF (@AdjustmentName = 'Inbound') OR (@AdjustmentName = 'Inbound(TR)')
			BEGIN
				 SET @remianing =   @remianing + @iad_quantity;
			END
			
		IF (@AdjustmentName = 'Outbound') OR (@AdjustmentName = 'Outbound(TR)')
			BEGIN
				SET @remianing =   @remianing - @iad_quantity;
			END
		
		INSERT INTO @History 
		(ID,AdjustmentId, TimePrint, Flow, AdjustmentType, location, locationname, qty, 
							remaning, comments, userid, username )
		values(@H_ID, @ia_id, @ia_date, @ia_flow, @AdjustmentName, @location, dbo.fn_GetAccountName(@location), @iad_quantity, 
							@remianing, @ia_comments, @ia_userid, dbo.fn_GetUserName( @ia_userid))
	
	
		
	
	
	
		FETCH NEXT FROM History_Cursor
		INTO @ia_id, @ia_date, @ia_flow, @ia_origin, @ia_destination, @iad_quantity, @ia_comments, @ia_userid
		,@AdjustmentName, @location;
	
	END
	
	CLOSE History_Cursor;
	DEALLOCATE History_Cursor;	
	
	RETURN 
END

go

