/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.vw_InventoryGlobal
AS
SELECT        SKUD.SKU, SKUD.Manufacturer, SKUD.PartNumber, CAT.CategoryName, dbo.fn_GetQtyByScanCode(SKUD.SKU, N'NEW') AS NewQty, dbo.fn_GetQtyByScanCode(SKUD.SKU, N'USED') AS UsedQty, 
                         dbo.fn_GetQtyByScanCode(SKUD.SKU, N'CN') AS CNQty, dbo.fn_GetQtyByScanCode(SKUD.SKU, N'NC') AS NoCoverQty, dbo.fn_GetQtyByScanCodeGY(SKUD.SKU, N'NEW') AS DENewQty, 
                         dbo.fn_GetQtyByScanCodeGY(SKUD.SKU, N'USED') AS DEUsedQty, dbo.fn_GetQtyByScanCodeGY(SKUD.SKU, N'CN') AS DECNQty
FROM            dbo.SKUData AS SKUD LEFT OUTER JOIN
                         dbo.Categories AS CAT ON SKUD.CategoryID = CAT.CategoryID
go

