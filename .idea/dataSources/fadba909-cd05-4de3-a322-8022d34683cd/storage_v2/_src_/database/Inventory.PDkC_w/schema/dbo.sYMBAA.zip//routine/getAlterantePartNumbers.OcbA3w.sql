

CREATE FUNCTION [dbo].[getAltPNRemotePartNumbers](@PartNumber nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @myString nVarchar(max);
	DECLARE @AltPN nVarchar(max);
	
	SET @myString = '';
	DECLARE AltPN_cursor CURSOR 
	FOR 
	SELECT AlternativePN FROM [Inventory].[dbo].[CompatibilityAlternativePN] WHERE PartNumber = @PartNumber;
	OPEN AltPN_cursor; 
	FETCH NEXT FROM AltPN_cursor INTO @AltPN;
	
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		SET @myString = @myString + @AltPN + ', '
	FETCH NEXT FROM AltPN_cursor INTO @AltPN;
	END
	
	CLOSE AltPN_cursor 	
	DEALLOCATE AltPN_cursor 
	
	
	IF @myString  <> '' 
	BEGIN
		SET @myString = LEFT(@myString, LEN(@myString)-1 )
	End
	
	
  RETURN @myString
  
END



go

