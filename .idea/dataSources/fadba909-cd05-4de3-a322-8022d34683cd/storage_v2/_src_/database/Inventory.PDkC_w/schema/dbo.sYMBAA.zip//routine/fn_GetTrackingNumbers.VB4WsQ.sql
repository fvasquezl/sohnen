-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-03-11
-- Description:	Get Tracking Numbers by Order
-- =============================================
CREATE FUNCTION [dbo].[fn_GetTrackingNumbers]
(
	@OrderNumber	NVARCHAR(50)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @listStr		NVARCHAR(MAX),
			@returnstring	NVARCHAR(MAX)
	
	SET @listStr = NULL

	SELECT @listStr = TrackingID + (CASE WHEN ISNULL(@listStr,'') <> '' THEN ',' ELSE '' END)
	FROM OrderManager.dbo.tracking (NOLOCK) WHERE OrderNum = @OrderNumber
	
	
	SET @returnstring = @listStr
	

	RETURN @returnstring

END
go

