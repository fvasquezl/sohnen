-- =============================================
-- Author: Eduardo Gutierrez
-- Create date: 2015-03-27
-- Description:	Update [ChannelAdvisorFeed] to Modified = 'S' to synchronize with Mercadolibre
-- =============================================
CREATE TRIGGER [dbo].[TRG_ChannelAdvisorTemplates_UPDATE_INSERT]
   ON  ChannelAdvisorTemplates
   AFTER INSERT,UPDATE
AS 
	DECLARE
		@TemplateID			NVARCHAR(50),
		@TemplateStoreID	NVARCHAR(50)
BEGIN
	SET NOCOUNT ON;

	SELECT @TemplateID = TemplateID,
		@TemplateStoreID = TemplateStoreID
	FROM INSERTED

	IF(@TemplateStoreID = 'MLMexicoTemplate')
	BEGIN
		UPDATE Inventory.dbo.ChannelAdvisorFeed SET Modified = 'S'
		WHERE MLMexicoTemplate = @TemplateID 
	END

END
go

