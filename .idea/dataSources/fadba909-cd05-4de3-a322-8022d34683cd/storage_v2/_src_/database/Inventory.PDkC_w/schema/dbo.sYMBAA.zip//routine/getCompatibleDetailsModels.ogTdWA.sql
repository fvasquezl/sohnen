
CREATE FUNCTION [dbo].[getCompatibleDetailsModels](@PartNum nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @myString nVarchar(max);
	DECLARE @CM nVarchar(max);
	
	SET @PartNum = Replace(@PartNum , ' SML', '') 
	
	SET @myString = '';
	DECLARE model_cursor CURSOR 
	FOR 
	SELECT Model FROM [Inventory].[dbo].[CompatibilityDetails] cmd where cmd.PartNumber = @PartNum;
	
	OPEN model_cursor; 
	FETCH NEXT FROM model_cursor INTO @CM;
	
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		SET @myString = @myString + @CM + ', '
		
	FETCH NEXT FROM model_cursor INTO @CM;
	END
	
	CLOSE model_cursor 
	DEALLOCATE model_cursor 
	
	IF @myString  <> '' 
	BEGIN
		SET @myString = LEFT(@myString, LEN(@myString)-1 )
	End
	
	
  RETURN @myString
  
END
go

