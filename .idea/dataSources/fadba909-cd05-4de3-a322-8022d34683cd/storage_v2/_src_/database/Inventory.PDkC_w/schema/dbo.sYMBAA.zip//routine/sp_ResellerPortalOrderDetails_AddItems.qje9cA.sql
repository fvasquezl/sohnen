-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE sp_ResellerPortalOrderDetails_AddItems
	-- Add the parameters for the stored procedure here
	@pWOID int, @pLocalSKU varchar(255), @pQty int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE ResellerPortalOrderDetails 
	SET ItemQuantityOrdered = ItemQuantityOrdered + @pQty
	WHERE  (WebOrderNumber = @pWOID)
			AND (ItemLocalSKU = @pLocalSKU);
			
	execute Inventory.dbo.sp_ResellerPortalOrder_Recal @pWOID;
	
END
go

