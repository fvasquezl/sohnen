-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_tools_mergewhere]
(
	@ptable varchar(100), @pwords varchar(3000), @pfields varchar(3000)
)
RETURNS varchar(3000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar nvarchar(3000) = '';

	Declare @individual nvarchar(3000) = '';
	Declare @FieldToken nvarchar(3000) = '';
	DECLARE @fieldList nvarchar(3000) = '';

	WHILE LEN(@pwords) > 0
	BEGIN
				SET @ResultVar = '(';

				/* Find the word*/
				IF PATINDEX('%*%',@pwords) > 0
				BEGIN
						SET @individual = SUBSTRING(@pwords, 0, PATINDEX('%*%',@pwords));
						SET @pwords = SUBSTRING(@pwords, LEN(@individual + '*') + 1, LEN(@pwords))
				END
				ELSE
				BEGIN
						SET @individual = @pwords;
						SET @pwords ='';
						
				END

				SET @fieldList = @pfields;

				/*Find the field*/
				WHILE LEN( @fieldList) > 0
				BEGIN
						IF PATINDEX('%*%', @fieldList) > 0
							BEGIN
									SET @FieldToken = SUBSTRING( @fieldList, 0, PATINDEX('%*%', @fieldList));
									SET @fieldList = SUBSTRING( @fieldList, LEN(@FieldToken + '*') + 1, LEN( @fieldList))
							END
							ELSE
							BEGIN
									SET @FieldToken =  @fieldList;
									SET  @fieldList ='';
						
							END

							/* Create convert*/
							SET @ResultVar = @ResultVar +  '(  Convert(varchar(254),' +  @FieldToken + ',0) + ' ;
							
				END
				/* delete last + sign*/
				SET  @ResultVar = SUBSTRING( @ResultVar, 1, LEN(@ResultVar)-1)
				SET @ResultVar = @ResultVar +')';
				SET @ResultVar = @ResultVar +' like ''%' +@individual +'%''' ;

				SET @ResultVar = @ResultVar +')';
	END

	
	-- Return the result of the function
	RETURN @ResultVar

END
go

