-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date, ,>
-- Description:	Get the parent id 
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_ParentCategory_Id]
(
	@pCategoryId int
)
RETURNS int
AS
BEGIN
	
	DECLARE @ResultVar int;

	SELECT @ResultVar = a.ParentID FROM Inventory.dbo.Categories a (NOLOCK) WHERE a.ID = @pCategoryId;

	-- Return the result of the function
	RETURN @ResultVar;

END
go

