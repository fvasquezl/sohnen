-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-23-2016
-- Description:	Get CustomerSpecific Data by SKU/CatalogID
-- =============================================
CREATE FUNCTION fn_GetCustomerSpecificData 
(
	-- Add the parameters for the function here
	@pSKU int, @pCustomerID int, @pDATA NVARCHAR(MAX)
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	IF @pDATA = 'Price'
	BEGIN
		SELECT @Result = CSP.[SalePrice] FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.[CustomerID] = @pCustomerID AND CSP.[ProductCatalogID] = @pSKU
	END

	-- Return the result of the function
	RETURN @Result

END
go

