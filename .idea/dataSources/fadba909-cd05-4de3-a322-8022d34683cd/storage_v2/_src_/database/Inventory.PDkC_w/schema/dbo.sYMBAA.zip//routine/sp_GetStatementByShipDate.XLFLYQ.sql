


-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-09-29
-- Description:	Get Statement By Ship Date
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetStatementByShipDate]
	@CustomerID INT
AS
BEGIN
	SET FMTONLY OFF
	DECLARE @FinalGrandTotal	DECIMAL(13,4),
			@INT1				INT,
			@INT2				INT
	SET NOCOUNT ON;
	
	IF EXISTS (SELECT 1 FROM tempdb..SYSOBJECTS WHERE name LIKE '#TMP_StatementByShipDate')
		DROP   TABLE #TMP_StatementByShipDate
	CREATE TABLE #TMP_StatementByShipDate (CustomerID			INT,
											OrderNumber			INT,
											OrderSource			NVARCHAR(2),
											OrderReference		NVARCHAR(255),
											PONumber			NVARCHAR(50),
											ShipDate			NVARCHAR(10),
											OrderDate			NVARCHAR(10),
											ShipName			NVARCHAR(255),
											ShipCompany			NVARCHAR(255),
											ShipAddress			NVARCHAR(255),
											ShipAddress2		NVARCHAR(255),
											ShipCity			NVARCHAR(255),
											ShipState			NVARCHAR(255),
											ShipZip				NVARCHAR(255),
											ShipCountry			NVARCHAR(255),
											ShipPhone			NVARCHAR(255),
											ProductTotal		DECIMAL(13,2),
											TaxTotal			DECIMAL(13,2),
											ShippingTotal		DECIMAL(13,2),
											GrandTotal			DECIMAL(13,2),
											NumItems			INT,
											Shipping			NVARCHAR(255),
											Discount			DECIMAL(13,2),
											RevisedDiscount		DECIMAL(13,2),
											FinalProductTotal	DECIMAL(13,2),
											FinalTaxTotal		DECIMAL(13,2),
											FinalShippingTotal	DECIMAL(13,2),
											FinalGrandTotal		DECIMAL(13,2),
											BalanceDue			DECIMAL(13,2),
											OrderStatus			NVARCHAR(50),
											TrackingNum			NVARCHAR(50),
											STATEMENTDAY		INT
											)
	SET @INT1 = 0
	SET @INT2 = 30
	WHILE(@INT2 <= 180)
	BEGIN
		INSERT INTO #TMP_StatementByShipDate (CustomerID,OrderNumber,OrderSource,OrderReference,PONumber,ShipDate,OrderDate,ShipName,ShipCompany,ShipAddress,ShipAddress2,ShipCity,ShipState,
												ShipZip,ShipCountry,ShipPhone,ProductTotal,TaxTotal,ShippingTotal,GrandTotal,NumItems,Shipping,Discount,RevisedDiscount,FinalProductTotal,
												FinalTaxTotal,FinalShippingTotal,FinalGrandTotal,BalanceDue,OrderStatus,TrackingNum,STATEMENTDAY)
		SELECT O.CustomerID, OrderNumber
			,O.[OrderSource]
			,(CASE WHEN IsNull(O.[SourceOrderID],'') = '' THEN IsNull(CAST(O.[SourceOrderNumber] AS NVARCHAR(MAX)),'') ELSE IsNull(O.[SourceOrderID],'') END) AS 'OrderReference'
			,IsNull(O.PONumber,'') AS 'PONumber'
			,CAST((SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 WITH(NOLOCK) WHERE TRK2.NumericKey = O.OrderNumber) AS DATE) AS 'ShipDate'
			,CAST(O.OrderDate AS date) AS 'OrderDate'
			,ISNULL(O.[ShipName],'') AS [ShipName]
			,ISNULL(O.[ShipCompany],'') AS [ShipCompany]
			,ISNULL(O.[ShipAddress],'') AS [ShipAddress]
			,ISNULL(O.[ShipAddress2],'') AS [ShipAddress2]
 			,ISNULL(O.[ShipCity],'') AS [ShipCity]
			,ISNULL(O.[ShipState],'') AS [ShipState]
			,ISNULL(O.[ShipZip],'') AS [ShipZip]
			,ISNULL(O.[ShipCountry],'') AS [ShipCountry]
			,ISNULL(O.[ShipPhone],'') AS [ShipPhone]
			,O.[ProductTotal]
			,O.[TaxTotal]
			,O.[ShippingTotal]
			,O.[GrandTotal]
			,(
				SELECT SUM(C.QuantityOrdered)
				FROM [OrderManager].[dbo].[Orders] A WITH(NOLOCK)
				LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] B WITH(NOLOCK)
				ON A.[OrderNumber] = B.[NumericKey]
				LEFT OUTER JOIN [OrderManager].[dbo].[Order Details] C WITH(NOLOCK)
				ON A.[OrderNumber] = C.[OrderNumber]
				WHERE A.[Approved] = '1' AND A.[Cancelled] = '0' AND A.[BalanceDue] > '1.00' AND C.Adjustment = '0' AND B.[TrackingID] IS NOT NULL AND A.OrderNumber = O.OrderNumber
				GROUP BY A.[OrderNumber]
			) AS NumItems
			,O.[Shipping]
			,O.[Discount]
			,O.[RevisedDiscount]
			,O.[FinalProductTotal]
			,O.[FinalTaxTotal]
			,O.[FinalShippingTotal]
			,O.[FinalGrandTotal]
			,O.[BalanceDue]
			,O.[OrderStatus]
			,(SELECT TOP(1) TRK2.[TrackingID] FROM [OrderManager].[dbo].[Tracking] AS TRK2 WITH(NOLOCK) WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS 'TrackingNum'
			,@INT2
		FROM OrderManager.dbo.Orders AS O WITH(NOLOCK)
		--LEFT OUTER JOIN OrderManager.dbo.Tracking AS TRK ON (O.OrderNumber = TRK.NumericKey)
		WHERE O.Approved = '1' 
			AND O.Cancelled = '0' 
			AND O.BalanceDue > '1.00' --AND TRK.TrackingID IS NOT NULL 
			AND O.CustomerID = (@CustomerID) 
			AND (SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 WITH(NOLOCK) WHERE TRK2.NumericKey = O.OrderNumber) BETWEEN GETDATE()-@INT2 AND GETDATE()-@INT1
		ORDER BY 'ShipDate' ASC

		--SET @FinalGrandTotal = 0
		--SET @FinalGrandTotal = (SELECT SUM(FinalGrandTotal) FROM #TMP_StatementByShipDate WHERE STATEMENTDAY = @INT2)

		--IF(ISNULL(@FinalGrandTotal,-1) >= 0)
		--BEGIN
		--	INSERT INTO #TMP_StatementByShipDate (CustomerID,FinalGrandTotal,STATEMENTDAY, OrderStatus) VALUES (@CustomerID, @FinalGrandTotal, (@INT2+1), 'AmountDue')
		--END

		IF(@INT2>=120)
		BEGIN
			SET @INT1 = @INT1 + 30
			SET @INT2 = @INT2 + 60
		END
		ELSE
		BEGIN
			SET @INT1 = @INT1 + 30
			SET @INT2 = @INT2 + 30
		END	  
	END

	INSERT INTO #TMP_StatementByShipDate (CustomerID,OrderNumber,OrderSource,OrderReference,PONumber,ShipDate,OrderDate,ShipName,ShipCompany,ShipAddress,ShipAddress2,ShipCity,ShipState, ShipZip,ShipCountry,ShipPhone,ProductTotal,TaxTotal,ShippingTotal,GrandTotal,NumItems,Shipping,Discount,RevisedDiscount,FinalProductTotal,FinalTaxTotal,FinalShippingTotal,FinalGrandTotal,BalanceDue,OrderStatus,TrackingNum,STATEMENTDAY)
	SELECT O.CustomerID, OrderNumber
		,O.[OrderSource]
		,(CASE WHEN IsNull(O.[SourceOrderID],'') = '' THEN IsNull(CAST(O.[SourceOrderNumber] AS NVARCHAR(MAX)),'') ELSE IsNull(O.[SourceOrderID],'') END) AS 'OrderReference'
		,IsNull(O.PONumber,'') AS 'PONumber'
		,CAST((SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 WITH(NOLOCK) WHERE TRK2.NumericKey = O.OrderNumber) AS DATE) AS 'ShipDate'
		,CAST(O.OrderDate AS date) AS 'OrderDate'
		,ISNULL(O.[ShipName],'') AS [ShipName]
		,ISNULL(O.[ShipCompany],'') AS [ShipCompany]
		,ISNULL(O.[ShipAddress],'') AS [ShipAddress]
		,ISNULL(O.[ShipAddress2],'') AS [ShipAddress2]
 		,ISNULL(O.[ShipCity],'') AS [ShipCity]
		,ISNULL(O.[ShipState],'') AS [ShipState]
		,ISNULL(O.[ShipZip],'') AS [ShipZip]
		,ISNULL(O.[ShipCountry],'') AS [ShipCountry]
		,ISNULL(O.[ShipPhone],'') AS [ShipPhone]
		,O.[ProductTotal]
		,O.[TaxTotal]
		,O.[ShippingTotal]
		,O.[GrandTotal]
		,(
			SELECT SUM(C.QuantityOrdered)
			FROM [OrderManager].[dbo].[Orders] A WITH(NOLOCK)
			LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] B WITH(NOLOCK)
			ON A.[OrderNumber] = B.[NumericKey]
			LEFT OUTER JOIN [OrderManager].[dbo].[Order Details] C WITH(NOLOCK)
			ON A.[OrderNumber] = C.[OrderNumber]
			WHERE A.[Approved] = '1' AND A.[Cancelled] = '0' AND A.[BalanceDue] > '1.00' AND C.Adjustment = '0' AND B.[TrackingID] IS NOT NULL AND A.OrderNumber = O.OrderNumber
			GROUP BY A.[OrderNumber]
		) AS NumItems
		,O.[Shipping]
		,O.[Discount]
		,O.[RevisedDiscount]
		,O.[FinalProductTotal]
		,O.[FinalTaxTotal]
		,O.[FinalShippingTotal]
		,O.[FinalGrandTotal]
		,O.[BalanceDue]
		,O.[OrderStatus]
		,(SELECT TOP(1) TRK2.[TrackingID] FROM [OrderManager].[dbo].[Tracking] AS TRK2 WITH(NOLOCK) WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS 'TrackingNum'
		,@INT2
	FROM OrderManager.dbo.Orders AS O WITH(NOLOCK)
	WHERE O.Approved = '1' 
		AND O.Cancelled = '0' 
		AND O.BalanceDue > '1.00'
		AND O.CustomerID = (@CustomerID) 
		AND (SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 WITH(NOLOCK) WHERE TRK2.NumericKey = O.OrderNumber) BETWEEN '2015-01-01 00:00' AND GETDATE()-181
	ORDER BY 'ShipDate' ASC

	SELECT A.CustomerID, ISNULL(A.FullName,'') AS FullName, ISNULL(A.Company,'') AS Company, ISNULL(A.Address,'') AS Address, ISNULL(A.Address2,'') AS Address2, ISNULL(A.City,'') AS City, ISNULL(A.State,'') AS State, 
		ISNULL(A.Zip,'') AS Zip, ISNULL(A.Country,'') AS Country, B.OrderNumber, B.OrderSource, B.OrderReference, B.PONumber, B.ShipDate, B.OrderDate, B.ShipName,
		B.ShipCompany, B.ShipAddress, B.ShipAddress2, B.ShipCity, B.ShipState, B.ShipZip, B.ShipCountry, B.ShipPhone, B.ProductTotal, B.TaxTotal, B.ShippingTotal, B.GrandTotal, B.NumItems, 
		B.Shipping, B.Discount, B.RevisedDiscount, B.FinalProductTotal, B.FinalTaxTotal, B.FinalShippingTotal, B.FinalGrandTotal, B.BalanceDue, B.OrderStatus, B.TrackingNum, B.STATEMENTDAY
	FROM OrderManager.dbo.Customers A WITH(NOLOCK)
	LEFT OUTER JOIN #TMP_StatementByShipDate B	
	ON B.CustomerID = A.CustomerID 
	WHERE A.CustomerID = @CustomerID
	GROUP BY A.CustomerID, A.FullName, A.Company, A.Address, A.Address2, A.City, A.State, A.Zip,A.Country, B.OrderNumber, B.OrderSource, B.OrderReference, B.PONumber, B.ShipDate, B.OrderDate, B.ShipName,
		B.ShipCompany, B.ShipAddress, B.ShipAddress2, B.ShipCity, B.ShipState, B.ShipZip, B.ShipCountry, B.ShipPhone, B.ProductTotal, B.TaxTotal, B.ShippingTotal, B.GrandTotal, B.NumItems, 
		B.Shipping, B.Discount, B.RevisedDiscount, B.FinalProductTotal, B.FinalTaxTotal, B.FinalShippingTotal, B.FinalGrandTotal, B.BalanceDue, B.OrderStatus, B.TrackingNum, B.STATEMENTDAY
	ORDER BY B.STATEMENTDAY ASC, B.ShipDate ASC, B.OrderNumber ASC

END



go

