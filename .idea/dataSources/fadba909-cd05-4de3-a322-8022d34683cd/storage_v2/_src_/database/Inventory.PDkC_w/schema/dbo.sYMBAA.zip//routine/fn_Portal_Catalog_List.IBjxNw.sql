-- =============================================
-- Author:		Luis Batista
-- Create date: Apr -30, 2014
-- Description:	Returns a record set whit especific lists (android catalog project)
-- =============================================
CREATE FUNCTION [dbo].[fn_Portal_Catalog_List]
(	
	@pList int, @pCondition varchar(100)
)
RETURNS @List TABLE 
(
	  Item varchar(255)
	  
)
AS
BEGIN
		IF @pList = 1
		BEGIN
				INSERT INTO @List (Item) SELECT DISTINCT brand
					 FROM [Inventory].[dbo].[Catalog_Pager] ORDER BY Brand;
		END;
	
		IF @pList = 2
		BEGIN
				IF @pCondition = ''
				BEGIN
					INSERT INTO @List (Item) SELECT DISTINCT PartNumber 
					FROM [Inventory].[dbo].[Catalog_Pager] ORDER BY PartNumber ;
				END
				ELSE
				BEGIN
					INSERT INTO @List (Item) SELECT DISTINCT PartNumber 
					FROM [Inventory].[dbo].[Catalog_Pager] 
					WHERE (brand = @pCondition)
					ORDER BY PartNumber ;
				END	
		END;
		
		IF @pList = 3
		BEGIN
				IF @pCondition = ''
				BEGIN
					INSERT INTO @List (Item) SELECT DISTINCT Model 
					FROM [Inventory].[dbo].[CompatibilityDetails] 
					ORDER BY Model ;
				END
				ELSE
				BEGIN
					INSERT INTO @List (Item) SELECT DISTINCT Model
					FROM [Inventory].[dbo].[CompatibilityDetails] 
					WHERE (OriginalManufacturer = @pCondition)
					ORDER BY Model ;
				END	
		END
		
		
		IF @pList = 4
		BEGIN
				INSERT INTO @List (Item) VALUES ('http://www.youtube.com/watch?v=psEWLHEVArA');
				
		END
		
		RETURN;
END
go

