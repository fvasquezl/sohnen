-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_StockAtDate]
(
	-- Add the parameters for the function here
	@sku as int, @MyDate as varchar(50)
)
RETURNS Real
AS
BEGIN
	-- Declare the return variable here
	-- Declare the return variable here
	DECLARE @MyQtty as real
	DECLARE @tins as real
	DECLARE @touts as real

	-- Add the T-SQL statements to compute the return value here
	SELECT @tins =  sum (b.quantity)
		  FROM InventoryAdjustments a,  InventoryAdjustmentDetails b 
             WHERE ( a.ID = b.InventoryAdjustmentsID )	
             AND (Flow = 1)
             AND ( b.ProductCatalogID = @sku)  and (a.date <= @mydate )
            

	SELECT @touts =  sum (b.quantity)
		  FROM InventoryAdjustments a,  InventoryAdjustmentDetails b 
             WHERE ( a.ID = b.InventoryAdjustmentsID )	
             AND (a.flow = 2)
             AND ( b.ProductCatalogID = @sku)  and (a.date <= @mydate )

	-- Return the result of the function
	if @tins is null
	BEGIN
		SET @tins = 0;
	END
	
	if @tOuts is null
	BEGIN
		SET @tOuts = 0;
	END
	
	SET @MyQtty = @tins - @tOuts
	
	if @myqtty is null
	BEGIN
		SET @Myqtty = 0
	END
	
	
	
	RETURN @MyQtty

END
go

