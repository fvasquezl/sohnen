
CREATE PROCEDURE [dbo].[sp_AddInventoryAdjustment] 
	-- Add the parameters for the stored procedure here
	@date datetime, 
	@idorigin int ,
	@iddestination int,
	@iduser int,
	@idproduct int,
	@Productquantity real,
	@idtype int,
	@Comments varchar(250)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    DECLARE @myidentity int
    
	BEGIN TRANSACTION InventoryAdjustment
		-- Step 1.
		-- Insert the adjustment header
        INSERT INTO Inventory.dbo.InventoryAdjustments  (date, Origin, Destination, UserId, Flow, Comments) 
        values (@date, @idorigin, @iddestination, @iduser, @idtype, @Comments)
    
		set @myidentity = SCOPE_IDENTITY() 

		            
		-- Step 2.
		-- Insert the adjustment details
		INSERT INTO Inventory.dbo.InventoryAdjustmentDetails  (InventoryAdjustmentsId, ProductCatalogID, Quantity) 
		values (@myidentity, @idproduct, @Productquantity);
         
		-- Step 3.
		-- Increase or decrease the inventory table
			-- CASE type of adjusmemt
			-- 1 = Adding, 2 = Remove, 3 = Transfer
			IF @idtype = 1 
      			UPDATE [Inventory].[dbo].[Inventory]
				SET Quantity = Quantity + @Productquantity
				WHERE (ProductCatalogID = @idproduct) 
                   AND (AccountID = @idorigin);

      
   
			if @idtype = 2
				UPDATE [Inventory].[dbo].[Inventory]
				SET Quantity = Quantity - @Productquantity
				WHERE (ProductCatalogID = @idproduct) 
                   AND (AccountID = @idorigin);
    
			if @idtype = 3
			BEGIN
			
				UPDATE [Inventory].[dbo].[Inventory]
				SET Quantity = Quantity - @Productquantity
				WHERE (ProductCatalogID = @idproduct) 
                   AND (AccountID = @idorigin);
                   
                   
                UPDATE [Inventory].[dbo].[Inventory]
				SET Quantity = Quantity + @Productquantity
				WHERE (ProductCatalogID = @idproduct) 
                   AND (AccountID = @iddestination);

			END
			
		-- Step 4.
		-- Increase or decrease the ProductCatalog Table
		IF @idtype = 1 
      			UPDATE [Inventory].[dbo].[ProductCatalog]
				SET CurrentStock = CurrentStock + @Productquantity
				WHERE (ID = @idproduct) ;
                 
   
		if @idtype = 2
				UPDATE [Inventory].[dbo].[ProductCatalog]
				SET CurrentStock = CurrentStock - @Productquantity
				WHERE (ID = @idproduct) ;
    
					    
	COMMIT TRANSACTION InventoryAdjustment
	
	--exec sp_Recalc_VirtualStock_RelatedPRoducts @idProduct
	
END
go

