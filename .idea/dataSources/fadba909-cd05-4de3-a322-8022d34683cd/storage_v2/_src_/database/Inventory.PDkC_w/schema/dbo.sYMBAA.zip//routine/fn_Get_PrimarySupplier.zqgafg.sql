-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_PrimarySupplier]
(
	@ProductId int
)
RETURNS varchar(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar as varchar(100)
	DECLARE @ProductCatalogID as Varchar(100)
	
	
	SET @ProductCatalogID  = CAST(@ProductId AS varchar(100))
		
	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = Supplierid FROM OrderManager.dbo.InventorySuppliers
			WHERE (LocalSKU = @ProductCatalogId) AND (PrimarySupplier = 1)

	if @resultvar is null  --there is not a primaru supplier
		BEGIN
			SET @ResultVar = 'Undefined'
		END
	ELSE
		BEGIN
			SELECT @ResultVar = SupplierName FROM [OrderManager].[dbo].[Suppliers]
			WHERE (SupplierID = @ResultVar) 
		END
	
	

	-- Return the result of the function
	RETURN @ResultVar


END
go

