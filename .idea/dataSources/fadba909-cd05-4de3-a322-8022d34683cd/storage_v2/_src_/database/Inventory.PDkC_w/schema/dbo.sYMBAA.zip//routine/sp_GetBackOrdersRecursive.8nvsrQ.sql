
-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-07-02
-- Description:	Get Back Orders Recursive by SKU
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetBackOrdersRecursive]
	@SKU INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @tblAssembly TABLE (SKU INT, SubSKU1 INT, SubSKU2 INT, SubSKU3 INT, CategoryID INT, QtyOrdered INT, Seq INT)

	INSERT INTO @tblAssembly (SKU, CategoryID, QtyOrdered, Seq)
	SELECT POD.SKU, PC.CategoryID, SUM(CONVERT(INT,POD.QtyBackOrdered)) AS QtyOrdered, 1
	FROM [Inventory].[dbo].PurchaseOrderData POD (NOLOCK) 
	INNER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
	ON PC.ID = POD.SKU 
	AND ISNULL(PC.CategoryID,0) IN (5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,10,11,12,13,62,20,21,22,23,64,14,24,59,60,69,70, 36 ,101,105,109,123,128,133,138,143) --/*-*/--
	WHERE ISNULL(POD.QtyBackOrdered,0) > 0
	GROUP BY POD.SKU, PC.CategoryID

	INSERT INTO @tblAssembly (SKU, SubSKU1, CategoryID, QtyOrdered, Seq)
	SELECT A.SKU, AD.SubSKU, PC.CategoryID, A.QtyOrdered, 2
	FROM @tblAssembly A
	INNER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
	ON AD.ProductCatalogID = A.SKU
	INNER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
	ON PC.ID = AD.SubSKU
	WHERE A.Seq = 1

	INSERT INTO @tblAssembly (SKU, SubSKU1, SubSKU2, CategoryID, QtyOrdered, Seq)
	SELECT A.SKU, A.SubSKU1, AD.SubSKU, PC.CategoryID, A.QtyOrdered, 3
	FROM @tblAssembly A
	INNER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
	ON AD.ProductCatalogID = A.SubSKU1
	INNER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
	ON PC.ID = AD.SubSKU
	WHERE A.Seq = 2

	INSERT INTO @tblAssembly (SKU, SubSKU1, SubSKU2, SubSKU3, CategoryID, QtyOrdered, Seq)
	SELECT A.SKU, A.SubSKU1, A.SubSKU2, AD.SubSKU, PC.CategoryID, A.QtyOrdered, 4
	FROM @tblAssembly A
	INNER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
	ON AD.ProductCatalogID = A.SubSKU2
	INNER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
	ON PC.ID = AD.SubSKU
	WHERE A.Seq = 3

	SELECT POD.SKU, POD.PONumber, CONVERT(NVARCHAR,POD.PODate,101) AS PODate, POD.VendorName, POD.ETA, POD.QtyOrdered, POD.QtyReceived, POD.QtyBackOrdered, 
		POD.UnitCost, DATEDIFF(dd,POD.PODate,GETDATE()) AS TargetDays
	FROM [Inventory].[dbo].PurchaseOrderData POD (NOLOCK) 
	WHERE ISNULL(POD.QtyBackOrdered,0) > 0 
	AND POD.SKU IN (
		SELECT SKU FROM @tblAssembly
		WHERE SKU = @SKU OR SubSKU1 = @SKU OR SubSKU2 = @SKU OR SubSKU3 = @SKU
		GROUP BY SKU
	)
END

go

