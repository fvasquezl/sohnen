-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 3-11-2016
-- Description:	PortalUserCreation - Create Inventory.dbo.Users in OM
-- =============================================
CREATE PROCEDURE sp_PortalUserCreation_CreateLogin
	-- Add the parameters for the stored procedure here
	  @pCustomerID INT,
  	   @pPassword NVARCHAR(MAX),
	   @pCartID INT,
	   @pPasswordNet NVARCHAR(MAX), 
	   @pRememberToken NVARCHAR(MAX), 
	   @pCustomerSOI NVARCHAR(MAX), 
	   @pUPSAccount NVARCHAR(MAX),
	   @pFedexAccount NVARCHAR(MAX),
	   @pDHLAccount NVARCHAR(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

Insert Into [Inventory].[dbo].[Users] (
	   [GroupID]
      ,[USR]
      ,[Password]
      ,[Email]
      ,[Name]
      ,[FullName]
      ,[Position]
      ,[IsActive]
      ,[CartId]
      ,[addedby]
      ,[addeddate]
      ,[CustomerID]
      ,[SupplierID]
      ,[PasswordNet]
      ,[Remember_token]
      ,[Created_at]
      ,[Updated_at]
	  ,[CustomerSOI]
      ,[user_type]
      ,[CustomerUPSAccount]
      ,[CustomerFEDEXAccount]
      ,[CustomerDHLAccount]
      ,[CustomerIsMasterShipper]
      ,[CREATE_USER]
      ,[CREATE_DATE]
      ,[CHANGE_USER]
      ,[CHANGE_DATE]
	  )
	  VALUES
	  (
	  '26'
	  ,(SELECT REPLACE(LOWER(RTRIM(LTRIM([FullName]))),' ','.') FROM [OrderManager].[dbo].[Customers] WHERE [CustomerID] = @pCustomerID)
	  ,@pPassword
	  ,(SELECT [Email] FROM [OrderManager].[dbo].[Customers] WHERE [CustomerID] = @pCustomerID)
	  ,''
	  ,(SELECT [FullName] FROM [OrderManager].[dbo].[Customers] WHERE [CustomerID] = @pCustomerID)
	  ,''
	  ,'1'
	  ,@pCartID
	  ,'19'
	  ,GETDATE()
	  ,@pCustomerID
      ,'0'
      ,@pPasswordNet
      ,@pRememberToken
      ,getdate()
      ,getdate()
	  ,@pCustomerSOI
      ,'partner'
      ,@pUPSAccount
      ,@pFedexAccount
      ,@pDHLAccount
      ,'1' -- [CustomerIsMasterShipper]
      ,'19' -- [CREATE_USER]
      ,getdate() -- [CREATE_DATE]
      ,'19' -- [CHANGE_USER]
      ,getdate() -- [CHANGE_DATE]
	  )


END
go

