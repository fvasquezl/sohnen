-- =============================================
-- Author:		Eduardo GUtierrez
-- Create date: 2017-03-30
-- Description:	Update Global Stock
-- =============================================
CREATE PROCEDURE [dbo].[sp_GlobalStockForceUpdate] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @CurrentID INT
	DECLARE @LastGlobalStock DECIMAL(18,6)
	DECLARE @NewGlobalStock DECIMAL(18,6)
	DECLARE @TotalStock INT

	DECLARE db_cursor CURSOR FOR  
	SELECT PC.[ID]
	FROM [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK)

	OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @CurrentID

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
		
		SET @NewGlobalStock = IsNULL((
			SELECT sum(a.Counter) AS [CurrentStock]
			FROM Inventory.dbo.Bin_Content a WITH(NOLOCK)
			WHERE (a.ProductCatalog_Id = @CurrentID)
			AND Inventory.dbo.fn_Get_Bin_WarehouseID(a.Bin_Id) <> 'DF'
		),0)

		SET @LastGlobalStock = ISNULL((SELECT GlobalStock FROM Inventory.dbo.Global_Stocks WITH(NOLOCK) WHERE ProductCatalogId = @CurrentID),0)

		IF(@LastGlobalStock <> @NewGlobalStock)
			INSERT INTO Inventory.dbo.Global_Stock_History (ProductCatalogId, LastGlobalStock, NewGlobalStock) VALUES (@CurrentID, @LastGlobalStock, @NewGlobalStock)
		       
	   		--- update global stocks
		UPDATE [Inventory].[dbo].[Global_Stocks] 
		SET [GlobalStock] = @NewGlobalStock
		WHERE [ProductCatalogId] = @CurrentID

		--SET @TotalStock = ISNULL((SELECT SUM(TotalStock) FROM Inventory.dbo.Global_Stocks WITH(NOLOCK) WHERE ProductCatalogId = @CurrentID),0)

		--UPDATE Inventory.dbo.ProductCatalog SET TotalStock = @TotalStock WHERE ID = @CurrentID
	
		FETCH NEXT FROM db_cursor INTO @CurrentID  
	END  

	CLOSE db_cursor  
	DEALLOCATE db_cursor 
	
END
go

