CREATE VIEW [dbo]._dta_mv_84   AS SELECT  [dbo].[AmazonSearchDATA].[ASIN] as _col_1,  [dbo].[AmazonSearchDATA].[Brand] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[AmazonSearchDATA]  GROUP BY  [dbo].[AmazonSearchDATA].[ASIN],  [dbo].[AmazonSearchDATA].[Brand]
go

