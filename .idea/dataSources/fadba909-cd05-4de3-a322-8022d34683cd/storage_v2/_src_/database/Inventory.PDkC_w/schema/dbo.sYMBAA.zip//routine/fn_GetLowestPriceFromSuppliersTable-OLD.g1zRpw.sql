-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 12-6-2014
-- Description:	Get Lowest Price based on category from the supplier Views
-- =============================================
CREATE FUNCTION [dbo].[fn_GetLowestPriceFromSuppliersTable] 
(
	-- Add the parameters for the function here
	@pSKU int
)
RETURNS decimal(10,2)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result decimal(10,2)

	IF (Select CategoryID FROM [Inventory].[dbo].[ProductCatalog] WHERE ID = @pSKU) = '24' GOTO FPGetLowestPrice
	IF (Select CategoryID FROM [Inventory].[dbo].[ProductCatalog] WHERE ID = @pSKU) = '60' GOTO HousingGetLowestPrice
	IF (Select CategoryID FROM [Inventory].[dbo].[ProductCatalog] WHERE ID = @pSKU) IN ('5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','61','62','63','64') GOTO FPGetUnitCost

HousingGetLowestPrice:
	
	BEGIN
	SET @Result = (Select Min(Cast(LC.LowestCost AS Decimal(10,2))) FROM
	  (SELECT CASE WHEN [MICost] = 0 THEN 29 ELSE Cast([MICost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU UNION ALL
	  SELECT CASE WHEN [MoldGateCost] = 0 THEN 29 ELSE Cast([MoldGateCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU UNION ALL
	  SELECT CASE WHEN [GrandBulbCost] = 0 THEN 29 ELSE Cast([GrandBulbCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU UNION ALL
	  SELECT CASE WHEN [SouthernTechCost] = 0 THEN 29 ELSE Cast([SouthernTechCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU UNION ALL
	  SELECT CASE WHEN [KWCost] = 0 THEN 29 ELSE Cast([KWCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU UNION ALL
	  SELECT CASE WHEN [LeaderCost] = 0 THEN 29 ELSE Cast([LeaderCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU UNION ALL
	  SELECT CASE WHEN [YitaCost] = 0 THEN 29 ELSE Cast([YitaCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU UNION ALL
	  SELECT CASE WHEN [FYVCost] = 0 THEN 29 ELSE Cast([FYVCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU UNION ALL
	  SELECT CASE WHEN [LampsChoiceCost] = 0 THEN 29 ELSE Cast([LampsChoiceCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU UNION ALL
	  SELECT CASE WHEN [OnlyLampCost] = 0 THEN 29 ELSE Cast([OnlyLampCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] WHERE MITSKU = @pSKU
	  )  AS LC) 
	 
	 END
	 GOTO ENDALL

FPGetLowestPrice:
	
	BEGIN
	SET @Result = (Select Min(Cast(LC.LowestCost AS Decimal(10,2)))FROM
	  (SELECT CASE WHEN [MiTechCost] = 0 THEN 999 ELSE Cast([MiTechCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] WHERE [ID] = @pSKU UNION ALL
	  SELECT CASE WHEN [ArcLiteUnitCost] = 0 THEN 999 ELSE Cast([ArcLiteUnitCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] WHERE [ID] = @pSKU UNION ALL
	  SELECT CASE WHEN [GloryUnitCost] = 0 THEN 999 ELSE Cast([GloryUnitCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] WHERE [ID] = @pSKU UNION ALL
	  SELECT CASE WHEN [ClpUnitCost] = 0 THEN 999 ELSE Cast([ClpUnitCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] WHERE [ID] = @pSKU UNION ALL
	  SELECT CASE WHEN [GrandBulbsCost] = 0 THEN 999 ELSE Cast([GrandBulbsCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] WHERE [ID] = @pSKU UNION ALL
	  SELECT CASE WHEN [LeaderCoCost] = 0 THEN 999 ELSE Cast([LeaderCoCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] WHERE [ID] = @pSKU UNION ALL
	  SELECT CASE WHEN [YitaCost] = 0 THEN 999 ELSE Cast([YitaCost] as Decimal(10,2)) END AS 'LowestCost' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] WHERE [ID] = @pSKU)  AS LC)
	END 
	GOTO ENDALL


FPGetUnitCost:
	
	BEGIN
	SET @Result = (Select [UnitCost] FROM [Inventory].[dbo].[ProductCatalog] WHERE [ID] = @pSKU)

	END 
	GOTO ENDALL

EndALL:

	-- Add the T-SQL statements to compute the return value here
--	SELECT @Result = @pSKU

	-- Return the result of the function
	RETURN @Result

END
go

