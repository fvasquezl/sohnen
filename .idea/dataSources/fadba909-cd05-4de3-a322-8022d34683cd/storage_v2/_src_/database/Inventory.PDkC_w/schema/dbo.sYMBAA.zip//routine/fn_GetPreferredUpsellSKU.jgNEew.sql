-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <9-30-2015>
-- Description:	<Get the preferred upsell sku>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetPreferredUpsellSKU] 
(
	
	@pSKU INT
)
RETURNS INT
AS
BEGIN
	-- Declare the return variable here
	DECLARE @UpsellSKU INT

	SET @UpSellSKU = (@pSKU)

--If SKU is not generic then leave it alone
IF (SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('5','6','7','8','10','11','12','13','15','16','17','18','20','21','22','23','61','62','63','64') GOTO ENDALL; 
IF (SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('9','14','19','24') GOTO GetUpsellSKU;

GOTO ENDALL

GetUpsellSKU:
BEGIN
		--Bare Lamp
		IF 
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('9','19')
				AND (SELECT TOP(1) PJD.[BareSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU) != '-'
				BEGIN 
					SET @UpSellSKU = (SELECT TOP(1) PJD.[BareSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU)
					GOTO ENDALL
				END
		IF
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('9','19')
				AND (SELECT TOP(1) PJD.[BareSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU) != '-'
				BEGIN
					SET @UpSellSKU = (SELECT TOP(1) PJD.[BareSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU)
					GOTO ENDALL

				END 
		IF
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('9','19')
				AND (SELECT TOP(1) PJD.[BareSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU) != '-'
				BEGIN
					SET @UpSellSKU = (SELECT PJD.[BareSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU)
					GOTO ENDALL

				END 
		IF
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('9','19')
				AND (SELECT TOP(1) PJD.[BareSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU) != '-'
				BEGIN
					SET @UpSellSKU = (SELECT PJD.[BareSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU)
					GOTO ENDALL

				END 
		IF
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('9','19')
				AND (SELECT TOP(1) PJD.[BareSKUOEM] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU) != '-'
				BEGIN
					SET @UpSellSKU = (SELECT TOP(1) PJD.[BareSKUOEM] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[BareSKU] = @pSKU)
					GOTO ENDALL

				END 
			--With Housing
		IF
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('14','24')
				AND (SELECT TOP(1) PJD.[EncSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU) != '-'
				BEGIN 
					SET @UpSellSKU = (SELECT TOP(1) PJD.[EncSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU)
					GOTO ENDALL
				END
		IF
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('14','24')
				AND (SELECT TOP(1) PJD.[EncSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU) != '-'
				BEGIN
					SET @UpSellSKU = (SELECT TOP(1) PJD.[EncSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU)
					GOTO ENDALL

				END 
		IF
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('14','24')
				AND (SELECT TOP(1) PJD.[EncSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU) != '-'
				BEGIN
					SET @UpSellSKU = (SELECT TOP(1) PJD.[EncSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU)
					GOTO ENDALL

				END 
		IF
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('14','24')
				AND (SELECT TOP(1) PJD.[EncSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU) != '-'
				BEGIN
					SET @UpSellSKU = (SELECT TOP(1) PJD.[EncSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU)
					GOTO ENDALL

				END 
		IF
				(SELECT PC.[CategoryID] FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) WHERE PC.[ID] = @pSKU) IN ('14','24')
				AND (SELECT TOP(1) PJD.[EncSKUOEM] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU) != '-'
				BEGIN
					SET @UpSellSKU = (SELECT TOP(1) PJD.[EncSKUOEM] FROM [MITDB].[dbo].[ProjectorData] AS PJD (NOLOCK) WHERE PJD.[EncSKU] = @pSKU)
					GOTO ENDALL

				END 

	END

GOTO ENDALL
------------------------------------------------------------------------------------------------------


-------------------------------------------------------------------------------------------------------
ENDALL:


	RETURN @UpSellSKU
	
END
go

