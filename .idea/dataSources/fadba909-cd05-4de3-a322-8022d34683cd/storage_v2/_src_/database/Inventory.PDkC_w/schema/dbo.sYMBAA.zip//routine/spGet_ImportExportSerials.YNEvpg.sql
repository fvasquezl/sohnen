
-- =============================================
-- Author:Eduardo Gutierrez
-- Create date: 2016-01-20
-- Description:Get Inport Export Serials
-- =============================================
CREATE PROCEDURE [dbo].[spGet_ImportExportSerials]
	@SerialNumber	NVARCHAR(50),
	@Printed		NVARCHAR(1),
	@DATE1			NVARCHAR(8),
	@DATE2			NVARCHAR(8)
AS
BEGIN
	SET NOCOUNT ON;

--	SELECT A.ProductCatalogId AS SKU, UPPER(A.SN) AS SerialNumber, B.Manufacturer, B.ManufacturerPN, B.Name AS SKU_NAME, CONVERT(NVARCHAR,B.[Description]) AS [DESCRIPTION], C.Name AS CategoryName, ISNULL(A.Printed,0) AS Printed 
--	FROM Inventory.dbo.Shipped_serialnumbers A LEFT OUTER JOIN Inventory.dbo.ProductCatalog B ON B.ID = A.ProductCatalogId LEFT OUTER JOIN Inventory.dbo.Categories C ON C.ID = B.CategoryID
--	WHERE A.User_id = 308 AND ProductCatalogId = 104014 AND A.SN IN ('GBBAD0165','GBBAD0168')
--	GROUP BY A.ProductCatalogId, A.SN, B.Manufacturer, B.ManufacturerPN, B.Name, CONVERT(NVARCHAR,B.Description), C.Name, A.Printed
--UNION ALL
	SELECT A.ProductCatalogId AS SKU, UPPER(A.SN) AS SerialNumber, B.Manufacturer, B.ManufacturerPN, B.Name AS SKU_NAME, CONVERT(NVARCHAR,B.[Description]) AS [DESCRIPTION], C.Name AS CategoryName, ISNULL(A.Printed,0) AS Printed 
	FROM Inventory.dbo.Shipped_serialnumbers A
		LEFT OUTER JOIN Inventory.dbo.ProductCatalog B ON B.ID = A.ProductCatalogId
		LEFT OUTER JOIN Inventory.dbo.Categories C ON C.ID = B.CategoryID
	WHERE 
	 --Comment for custom print---
	A.User_id = 999--999--308
		AND CONVERT(NVARCHAR,mydate,112) BETWEEN @DATE1 AND @DATE2 
		--AND (A.SN LIKE '%'+@SerialNumber + '%' OR A.ProductCatalogId LIKE '%'+@SerialNumber+'%') 
		AND ISNULL(A.Printed,0) LIKE ISNULL(@Printed,'')+'%'

		AND CONVERT(NVARCHAR,ProductCatalogId) LIKE @SerialNumber --101002-101006--101009

	---------------
	-- TO PRINT ---
	--A.User_id = 999
	--------------
--AND 
--A.SN 
--		SUBSTRING(A.SN,3,8)
--IN (
----		'GBB9M0095',

--)
--UPPER(SUBSTRING(SN,3,8))
		-- AND convert(nvarchar,mydate,112) > '20160222'
	GROUP BY A.ProductCatalogId, A.SN, B.Manufacturer, B.ManufacturerPN, B.Name, CONVERT(NVARCHAR,B.Description), C.Name, A.Printed

END



go

