CREATE VIEW [dbo]._dta_mv_0 WITH SCHEMABINDING AS SELECT  [dbo].[ChannelAdvisor].[MarkedForDeletion] as _col_1,  count_big(*) as _col_2 FROM  [dbo].[ChannelAdvisor]   GROUP BY  [dbo].[ChannelAdvisor].[MarkedForDeletion]
go

