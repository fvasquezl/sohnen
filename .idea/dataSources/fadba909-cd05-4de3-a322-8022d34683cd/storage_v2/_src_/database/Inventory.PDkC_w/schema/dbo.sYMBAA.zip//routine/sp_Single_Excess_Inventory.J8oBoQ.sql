-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Excess_Inventory]
	@pSKU as integer, @pDateStart date, @pDateEnd date	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	 SELECT DISTINCT PC.ID AS [SKU] 
		,PC.Manufacturer As [Manufacturer]
		,Cast((GS.TotalStock - (Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode Like 'OUT%' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) + (Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode Like 'IN%' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd)) as int) AS [InvStart]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode Like 'IN%' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvTotalAdded]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode Like 'OUT%' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvTotalRemoved]
		,Cast(GS.TotalStock as int) As [InvCurrent]

		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode Like 'OUT%' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd)/DATEDIFF(day,@pDateStart,@pDateEnd) AS [AvgRemovedPerDay]
		,PC.TargetInventory As [TargetStockInDays]
		,Cast(GS.TotalStock/((Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode Like 'OUT%' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd)/DATEDIFF(day,@pDateStart,@pDateEnd)) as decimal(10,2)) As [DaysUntilWeRunOut]
		
		,'AddedDetails---->' As [AddedDetails---->]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN50' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvAddedAuditInput]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN51' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvAddedLampProduction]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN52' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvAddedAssembly]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN53' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvAddedRMAReturn]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN54' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvAddedFBAReturn]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN55' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvAddedPurchaseOrder]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN56' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvAddedOther]
		
		,'RemovedDetails---->' As [RemovedDetails---->]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'OUT51' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvRemovedAuditAdj]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN52' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvRemovedOrder]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN53' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvRemovedAssembly]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN54' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvRemovedRMAExchange]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN55' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvRemovedFBAShipment]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN56' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvRemovedPOAdjustment]
		,(Select IsNull(Sum(BH2.Qty),'0') FROM [Inventory].[dbo].[Bins_History] AS BH2 WHERE BH2.Product_Catalog_ID = @pSKU AND BH2.ScanCode = 'IN51' AND BH2.Stamp BETWEEN @pDateStart AND @pDateEnd) As [InvRemovedOther]

		
		
  FROM [Inventory].[dbo].[ProductCatalog] As PC
  LEFT OUTER JOIN [Inventory].[dbo].[Bins_History] As BH ON (PC.[ID] = BH.[Product_Catalog_ID])
  LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] As GS ON (PC.[ID] = GS.ProductCatalogId)
  WHERE PC.ID = @pSKU

END
go

