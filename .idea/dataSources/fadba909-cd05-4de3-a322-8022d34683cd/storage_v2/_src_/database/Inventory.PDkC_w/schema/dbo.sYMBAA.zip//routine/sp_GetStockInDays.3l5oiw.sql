-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-05-09
-- Description:	Get Stock SKU History by Days
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetStockInDays]
	@SKU			INT,
	@INITIAL_DATE	NVARCHAR(10),
	@FINAL_DATE		NVARCHAR(10)
AS
BEGIN
	DECLARE @CURSOR_DAYS	CURSOR,
			@DATE1			DATETIME,
			@DATE2			DATETIME,
			@NEW_DATE		DATE,
			@DATES			DATE,
			@LAST_QTY		INT,
			@NEW_QTY		INT
	SET NOCOUNT ON;
	SET ANSI_WARNINGS OFF;
	SET ANSI_WARNINGS ON;

	--SET @NEW_DATE = CONVERT(DATETIME,@INITIAL_DATE) 
	SET @NEW_DATE = DATEADD(MONTH,-6,CONVERT(DATETIME,@INITIAL_DATE))
	--SET @DATE1 = CONVERT(DATETIME,@INITIAL_DATE)
	SET @DATE1 = DATEADD(MONTH,-6,CONVERT(DATETIME,@INITIAL_DATE))
	SET @DATE2 = CONVERT(DATETIME,@FINAL_DATE)
	    
	DECLARE @tmpDays TABLE (Dates DATE, Qty INT)

	WHILE(@NEW_DATE <= @DATE2)
	BEGIN
		INSERT INTO @tmpDays (Dates) VALUES (@NEW_DATE)
		SET @NEW_DATE = DATEADD(DD,1,@NEW_DATE)
	END

	--DECLARE @tmpSKUHistory TABLE (
	--	id INT, TransactionId INT, mydate DATE, Bin_Id NVARCHAR(6), Reason NVARCHAR(2000), inputs INT, outputs INT, globalqty INT, username NVARCHAR(250), comments NVARCHAR(2500)
	--)

	DECLARE @tmpSKUHistory TABLE (
		SKU INT, Global_Stock INT, Activity_Date DATE
	)

	--INSERT INTO @tmpSKUHistory (id, TransactionId, mydate, Bin_Id, Reason, inputs, outputs, globalqty, username, comments)
	--EXEC Inventory.dbo.sp_Bins_History @SKU, @DATE1, @DATE2
	INSERT INTO @tmpSKUHistory
	SELECT SKU, Global_Stock, Activity_Date FROM Inventory.dbo.BinMovement WITH(NOLOCK) WHERE SKU = @SKU AND Activity_Date BETWEEN @DATE1 AND @DATE2
	
	SET @NEW_QTY = 0
	SET @LAST_QTY = 0

	SET @CURSOR_DAYS = CURSOR FOR 

	SELECT Dates FROM @tmpDays

	OPEN @CURSOR_DAYS 
		FETCH NEXT FROM @CURSOR_DAYS 
		INTO @DATES
	   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @NEW_QTY = (SELECT Global_Stock FROM @tmpSKUHistory WHERE Activity_Date = @DATES AND SKU = @SKU) --AND TransactionId = (SELECT MAX(TransactionId) FROM @tmpSKUHistory WHERE mydate = @DATES))
			
			IF(@NEW_QTY IS NULL)
			BEGIN
				SET @NEW_QTY = @LAST_QTY
			END

			UPDATE @tmpDays SET Qty = @NEW_QTY WHERE Dates = @DATES

			SET @LAST_QTY = @NEW_QTY

			NEXT_FETCH:
			FETCH NEXT FROM @CURSOR_DAYS
			INTO @DATES
		END
	CLOSE      @CURSOR_DAYS
	DEALLOCATE @CURSOR_DAYS

	SELECT CONVERT(NVARCHAR,Dates,101) AS Dates, Qty FROM @tmpDays
	WHERE CONVERT(NVARCHAR,Dates,112) BETWEEN @INITIAL_DATE AND @FINAL_DATE
	ORDER BY CONVERT(NVARCHAR,Dates,112) ASC
END
go

