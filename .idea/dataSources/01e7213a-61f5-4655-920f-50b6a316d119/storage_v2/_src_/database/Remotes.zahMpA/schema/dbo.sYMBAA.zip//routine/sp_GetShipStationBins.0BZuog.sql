-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 11-5-2018
-- Description:	Get Shipstation Bins and Quantity by SS Order Number
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetShipStationBins] 
	-- Add the parameters for the stored procedure here
	@OrderNumber NVARCHAR(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		--SS1
		SELECT O.[OrderNumber]
			  ,ITM.[SKU]
			  ,(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN LEFT(REPLACE(ITM.[SKU],'USED','RMTC'),9)+'-USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN LEFT(REPLACE(ITM.[SKU],'CN','RMTC'),9)+'-CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-CN'
				WHEN ITM.[SKU] LIKE 'SKU%' THEN (SELECT (CASE WHEN [Condition] LIKE '%new%' AND ([IsCN] = 0 OR [IsCN] IS NULL) THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
															WHEN [Condition] LIKE '%new%' AND [IsCN] = 1 THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
															WHEN [Condition] LIKE '%used%' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-USED'
															ELSE '' END)
															FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [MerchantSKU] = REPLACE(ITM.[SKU],'SKU','RMTC'))
				ELSE LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW' END) AS [CleanSKU]
			  ,ITM.[Quantity]

			  ,REPLACE(REPLACE(REPLACE(REPLACE(STUFF(( SELECT  ', ' , [BinID], [StockQty]
						FROM  [Remotes].[dbo].[fn_GetBinDetailsByScanCode](
		
				--GetCleanSKU		
				(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN LEFT(REPLACE(ITM.[SKU],'USED','RMTC'),9)--+'-USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN LEFT(REPLACE(ITM.[SKU],'CN','RMTC'),9)--+'-CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-CN'
				ELSE LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-NEW' 
				END),
		
				--GetScanCode
				(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN 'USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN 'CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN 'USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN 'NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN 'CN'
				WHEN ITM.[SKU] LIKE 'SKU%' THEN (SELECT (CASE WHEN [Condition] LIKE '%new%' AND ([IsCN] = 0 OR [IsCN] IS NULL) THEN 'NEW'
															WHEN [Condition] LIKE '%new%' AND [IsCN] = 1 THEN 'NEW'
															WHEN [Condition] LIKE '%used%' THEN 'USED'
															ELSE '' END)
															FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [MerchantSKU] = REPLACE(ITM.[SKU],'SKU','RMTC'))
				ELSE 'NEW' END)
		
				)
					  FOR XML PATH(''))
					  , 1, 2, ''),'<BinID>',''),'</BinID>',' | '),'<StockQty>',''),'</StockQty>','') AS [Bins]
		  FROM [SS1].[orders].[Order] AS O
		  LEFT OUTER JOIN [SS1].[orders].[Item] AS ITM ON (O.[OrderId] = ITM.[OrderId])
		  WHERE O.[OrderNumber] = @OrderNumber


		UNION ALL  
    
		--SS2
		SELECT O.[OrderNumber]
			  ,ITM.[SKU]
			  ,(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN LEFT(REPLACE(ITM.[SKU],'USED','RMTC'),9)+'-USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN LEFT(REPLACE(ITM.[SKU],'CN','RMTC'),9)+'-CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-CN'
				WHEN ITM.[SKU] LIKE 'SKU%' THEN (SELECT (CASE WHEN [Condition] LIKE '%new%' AND ([IsCN] = 0 OR [IsCN] IS NULL) THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
															WHEN [Condition] LIKE '%new%' AND [IsCN] = 1 THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
															WHEN [Condition] LIKE '%used%' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-USED'
															ELSE '' END)
															FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [MerchantSKU] = REPLACE(ITM.[SKU],'SKU','RMTC'))
				ELSE LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW' END) AS [CleanSKU]
			  ,ITM.[Quantity]

			  ,REPLACE(REPLACE(REPLACE(REPLACE(STUFF(( SELECT  ', ' , [BinID], [StockQty]
						FROM  [Remotes].[dbo].[fn_GetBinDetailsByScanCode](
		
				--GetCleanSKU		
				(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN LEFT(REPLACE(ITM.[SKU],'USED','RMTC'),9)--+'-USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN LEFT(REPLACE(ITM.[SKU],'CN','RMTC'),9)--+'-CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-CN'
				ELSE LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-NEW' 
				END),
		
				--GetScanCode
				(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN 'USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN 'CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN 'USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN 'NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN 'CN'
				WHEN ITM.[SKU] LIKE 'SKU%' THEN (SELECT (CASE WHEN [Condition] LIKE '%new%' AND ([IsCN] = 0 OR [IsCN] IS NULL) THEN 'NEW'
															WHEN [Condition] LIKE '%new%' AND [IsCN] = 1 THEN 'NEW'
															WHEN [Condition] LIKE '%used%' THEN 'USED'
															ELSE '' END)
															FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [MerchantSKU] = REPLACE(ITM.[SKU],'SKU','RMTC'))
				ELSE 'NEW' END)
		
				)
					  FOR XML PATH(''))
					  , 1, 2, ''),'<BinID>',''),'</BinID>',' | '),'<StockQty>',''),'</StockQty>','') AS [Bins]
		  FROM [SS2].[orders].[Order] AS O
		  LEFT OUTER JOIN [SS2].[orders].[Item] AS ITM ON (O.[OrderId] = ITM.[OrderId])
		  WHERE O.[OrderNumber] = @OrderNumber
  
  
		UNION ALL

		--SS3
		SELECT O.[OrderNumber]
			  ,ITM.[SKU]
			  ,(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN LEFT(REPLACE(ITM.[SKU],'USED','RMTC'),9)+'-USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN LEFT(REPLACE(ITM.[SKU],'CN','RMTC'),9)+'-CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-CN'
				WHEN ITM.[SKU] LIKE 'SKU%' THEN (SELECT (CASE WHEN [Condition] LIKE '%new%' AND ([IsCN] = 0 OR [IsCN] IS NULL) THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
															WHEN [Condition] LIKE '%new%' AND [IsCN] = 1 THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
															WHEN [Condition] LIKE '%used%' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-USED'
															ELSE '' END)
															FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [MerchantSKU] = REPLACE(ITM.[SKU],'SKU','RMTC'))
				ELSE LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW' END) AS [CleanSKU]

			  ,ITM.[Quantity]

			  ,REPLACE(REPLACE(REPLACE(REPLACE(STUFF(( SELECT  ', ' , [BinID], [StockQty]
						FROM  [Remotes].[dbo].[fn_GetBinDetailsByScanCode](
		
				--GetCleanSKU		
				(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN LEFT(REPLACE(ITM.[SKU],'USED','RMTC'),9)--+'-USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN LEFT(REPLACE(ITM.[SKU],'CN','RMTC'),9)--+'-CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-CN'
				ELSE LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-NEW' 
				END),
		
				--GetScanCode
				(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN 'USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN 'CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN 'USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN 'NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN 'CN'
				WHEN ITM.[SKU] LIKE 'SKU%' THEN (SELECT (CASE WHEN [Condition] LIKE '%new%' AND ([IsCN] = 0 OR [IsCN] IS NULL) THEN 'NEW'
															WHEN [Condition] LIKE '%new%' AND [IsCN] = 1 THEN 'NEW'
															WHEN [Condition] LIKE '%used%' THEN 'USED'
															ELSE '' END)
															FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [MerchantSKU] = REPLACE(ITM.[SKU],'SKU','RMTC'))
				ELSE 'NEW' END)
		
				)
					  FOR XML PATH(''))
					  , 1, 2, ''),'<BinID>',''),'</BinID>',' | '),'<StockQty>',''),'</StockQty>','') AS [Bins]
		  FROM [SS3].[orders].[Order] AS O
		  LEFT OUTER JOIN [SS3].[orders].[Item] AS ITM ON (O.[OrderId] = ITM.[OrderId])
		  WHERE O.[OrderNumber] = @OrderNumber
  

  		UNION ALL

		--SS4
		SELECT O.[OrderNumber]
			  ,ITM.[SKU]
			  ,(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN LEFT(REPLACE(ITM.[SKU],'USED','RMTC'),9)+'-USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN LEFT(REPLACE(ITM.[SKU],'CN','RMTC'),9)+'-CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-CN'
				WHEN ITM.[SKU] LIKE 'SKU%' THEN (SELECT (CASE WHEN [Condition] LIKE '%new%' AND ([IsCN] = 0 OR [IsCN] IS NULL) THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
															WHEN [Condition] LIKE '%new%' AND [IsCN] = 1 THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW'
															WHEN [Condition] LIKE '%used%' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-USED'
															ELSE '' END)
															FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [MerchantSKU] = REPLACE(ITM.[SKU],'SKU','RMTC'))
				ELSE LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)+'-NEW' END) AS [CleanSKU]

			  ,ITM.[Quantity]

			  ,REPLACE(REPLACE(REPLACE(REPLACE(STUFF(( SELECT  ', ' , [BinID], [StockQty]
						FROM  [Remotes].[dbo].[fn_GetBinDetailsByScanCode](
		
				--GetCleanSKU		
				(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN LEFT(REPLACE(ITM.[SKU],'USED','RMTC'),9)--+'-USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN LEFT(REPLACE(ITM.[SKU],'CN','RMTC'),9)--+'-CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-CN'
				ELSE LEFT(REPLACE(ITM.[SKU],'SKU','RMTC'),9)--+'-NEW' 
				END),
		
				--GetScanCode
				(CASE WHEN ITM.[SKU] LIKE 'USED%' THEN 'USED'
				WHEN ITM.[SKU] LIKE 'CN%' THEN 'CN'
				WHEN ITM.[SKU] LIKE '%USED' THEN 'USED'
				WHEN ITM.[SKU] LIKE '%NEW' THEN 'NEW'
				WHEN ITM.[SKU] LIKE '%-CN' THEN 'CN'
				WHEN ITM.[SKU] LIKE 'SKU%' THEN (SELECT (CASE WHEN [Condition] LIKE '%new%' AND ([IsCN] = 0 OR [IsCN] IS NULL) THEN 'NEW'
															WHEN [Condition] LIKE '%new%' AND [IsCN] = 1 THEN 'NEW'
															WHEN [Condition] LIKE '%used%' THEN 'USED'
															ELSE '' END)
															FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [MerchantSKU] = REPLACE(ITM.[SKU],'SKU','RMTC'))
				ELSE 'NEW' END)
		
				)
					  FOR XML PATH(''))
					  , 1, 2, ''),'<BinID>',''),'</BinID>',' | '),'<StockQty>',''),'</StockQty>','') AS [Bins]
		  FROM [SS4].[orders].[Order] AS O
		  LEFT OUTER JOIN [SS4].[orders].[Item] AS ITM ON (O.[OrderId] = ITM.[OrderId])
		  WHERE O.[OrderNumber] = @OrderNumber
  


END
go

