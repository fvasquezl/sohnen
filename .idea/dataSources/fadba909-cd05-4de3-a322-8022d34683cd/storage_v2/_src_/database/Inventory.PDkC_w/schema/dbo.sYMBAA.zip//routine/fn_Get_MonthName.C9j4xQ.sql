-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_MonthName]
(
	
	@pMonth int
)
RETURNS varchar(20)
AS
BEGIN
	DECLARE @lresult as varchar(20);
	SET @lresult  =
	CASE @pMonth
         WHEN 1 THEN 'Jan'
         WHEN 2 THEN 'Feb'
         WHEN 3 THEN  'Mar'
         WHEN 4 THEN  'Apr'
         WHEN 5 THEN 'May'
         WHEN 6 THEN  'Jun'
         WHEN 7 THEN  'Jul'
         WHEN 8 THEN  'Aug'
         WHEN 9 THEN  'Sep'
         WHEN 10 THEN  'Oct'
         WHEN 11 THEN  'Nov'
         WHEN 12 THEN  'Dec'
      END
	
	
	
	-- Return the result of the function
	RETURN @lresult

END
go

