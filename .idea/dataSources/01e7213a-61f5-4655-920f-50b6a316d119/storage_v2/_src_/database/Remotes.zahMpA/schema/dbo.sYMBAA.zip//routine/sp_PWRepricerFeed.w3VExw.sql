
-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 5-18-2016
-- Description:	Repricer feed for RemotesWorldwide
-- =============================================
CREATE PROCEDURE [dbo].[sp_PWRepricerFeed] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		---Keep history of below feeds
		IF OBJECT_ID('Remotes.dbo.FeedHistory_LastRepricer', 'U') IS NOT NULL 
	    DROP TABLE [Remotes].[dbo].[FeedHistory_LastRepricer]; 

		--FBM
		SELECT 
		CASE WHEN MM.[IsCN] = 1 THEN REPLACE(MM.[MerchantSKU],'RMTC','SKU')+'-CN' 
		ELSE REPLACE(MM.[MerchantSKU],'RMTC','SKU') END AS 'SKU', 
		'140392' AS 'MARKETPLACE_ID', 
		MM.[Floor] AS 'MIN_PRICE', 
		MM.[Ceiling] AS 'MAX_PRICE', 
		'140538' AS 'PROFILE_ID'
		------------
		--Below is the only segement not in below feed
		,GETDATE() AS 'STAMP'
		INTO [Remotes].[dbo].[FeedHistory_LastRepricer]
		-----------

		FROM [Remotes].[dbo].[MarketplaceMapping] AS MM  WITH (NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD  WITH (NOLOCK) ON (MM.[SKU] = SKUD.[SKU]) 
		WHERE MM.[FulfillmentType] = 'Merchant'
		AND MM.[IsSnL] = 0

		--FBA
		------------
		--Below is the only segement not in below feed
		INSERT INTO [Remotes].[dbo].[FeedHistory_LastRepricer]
		-------------
		
		SELECT 
		CASE WHEN MM.[IsCN] = 1 THEN REPLACE(MM.[MerchantSKU],'RMTC','SKU')+'-CN' 
		ELSE REPLACE(MM.[MerchantSKU],'RMTC','SKU') END AS 'SKU', 
		'140392' AS 'MARKETPLACE_ID', 
		MM.[Floor] AS 'MIN_PRICE', 
		MM.[Ceiling] AS 'MAX_PRICE', 
		'140507' AS 'PROFILE_ID' 
		------------
		--Below is the only segement not in below feed
		,GETDATE() AS 'STAMP'
		---------
		FROM [Remotes].[dbo].[MarketplaceMapping] AS MM  WITH (NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD  WITH (NOLOCK) ON (MM.[SKU] = SKUD.[SKU]) 
		WHERE MM.[FulfillmentType] = 'Amazon'
		AND MM.[IsSnL] = 0

		--SNL
		------------
		--Below is the only segement not in below feed
		INSERT INTO [Remotes].[dbo].[FeedHistory_LastRepricer]
		-------------
		
		SELECT 
		CASE WHEN MM.[IsCN] = 1 THEN REPLACE(MM.[MerchantSKU],'RMTC','SKU')+'-CN' 
		ELSE REPLACE(MM.[MerchantSKU],'RMTC','SKU') END AS 'SKU', 
		'140392' AS 'MARKETPLACE_ID', 
		MM.[Floor]-2 AS 'MIN_PRICE', 
		
		(CASE WHEN MM.[Ceiling] > '16.99' THEN '16.99'
		WHEN MM.[Ceiling] < '16.99' THEN MM.[Ceiling]
		ELSE '16.99' END)
		 AS 'MAX_PRICE', 

		'152791' AS 'PROFILE_ID' 
		------------
		--Below is the only segement not in below feed
		,GETDATE() AS 'STAMP'
		---------
		FROM [Remotes].[dbo].[MarketplaceMapping] AS MM  WITH (NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD  WITH (NOLOCK) ON (MM.[SKU] = SKUD.[SKU]) 
		WHERE MM.[IsSnL] = 1


		--SELECT [SKU], [MARKETPLACE_ID], [MIN_PRICE], [MAX_PRICE], [PROFILE_ID] FROM [FeedHistory_LastRepricer] 
			 

		DECLARE @selectstatement NVARCHAR(2000)
		DECLARE @cmd NVARCHAR(2000)

		---Start Feed---
		SET @selectstatement = 'SELECT [SKU], [MARKETPLACE_ID], [MIN_PRICE], [MAX_PRICE], [PROFILE_ID] FROM [Remotes].[dbo].[FeedHistory_LastRepricer] WITH (NOLOCK)'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "\\192.168.0.226\sharedb\AmazonAPI\pricewatchers\pw-body.txt" -SBSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd

		EXEC master..xp_CMDShell '\\192.168.0.226\sharedb\AmazonAPI\PriceWatchers\sendpwfeed.bat'

END

go

