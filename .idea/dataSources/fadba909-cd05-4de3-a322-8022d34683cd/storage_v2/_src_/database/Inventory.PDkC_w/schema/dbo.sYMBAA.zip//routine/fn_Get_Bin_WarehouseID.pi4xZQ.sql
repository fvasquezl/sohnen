-- =============================================
-- Author:		Luis Batista
-- Create date: Jul 07 2014
-- Description:	Retrive the bin WarehouseId
-- =============================================
CREATE FUNCTION fn_Get_Bin_WarehouseID
(
	@pBinId varchar(6)
)
RETURNS varchar(2)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(2)

	
	SELECT @ResultVar = WarehouseID From Inventory.dbo.Bins WHERE Bin_Id = @pBinId;

	If @ResultVar is null
	BEGIN
		SET @ResultVar = '';
	END
	-- Return the result of the function
	RETURN @ResultVar;

END
go

