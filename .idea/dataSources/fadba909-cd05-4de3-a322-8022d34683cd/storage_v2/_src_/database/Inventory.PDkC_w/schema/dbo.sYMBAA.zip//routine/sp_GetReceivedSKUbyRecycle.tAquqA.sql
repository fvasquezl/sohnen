-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-06-16
-- Description:	Get Received SKU and SubSKU in Recycle
-- =============================================
CREATE PROCEDURE sp_GetReceivedSKUbyRecycle
	@SEARCH	NVARCHAR(150),
	@TYPE	NVARCHAR(10),
	@DATE1	NVARCHAR(8),
	@DATE2	NVARCHAR(8)
AS
BEGIN
	SET NOCOUNT ON;

	IF(ISNULL(@TYPE,'') = 'SKU')
	BEGIN
		SELECT MR.SKU, SUM(MR.QuantityReceived) AS QuantityReceived, PC.Name AS Product, C.Name, PC.CategoryID
		FROM RecycleAPI.dbo.MaterialReceived MR
		LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC
		ON PC.ID = MR.SKU
		LEFT OUTER JOIN Inventory.dbo.Categories C
		ON C.ID = PC.CategoryID
		WHERE MR.SKU LIKE @SEARCH AND CONVERT(NVARCHAR,MR.CREATE_DATE,112) BETWEEN @DATE1 AND @DATE2
		GROUP BY  MR.SKU, PC.Name, PC.CategoryID, C.Name
		ORDER BY SUM(MR.QuantityReceived) DESC
	END
	--ELSE
	--BEGIN
	--	IF(ISNULL(@TYPE,'') = 'SUBSKU')
	--	BEGIN

	--	END
	--END
END
go

