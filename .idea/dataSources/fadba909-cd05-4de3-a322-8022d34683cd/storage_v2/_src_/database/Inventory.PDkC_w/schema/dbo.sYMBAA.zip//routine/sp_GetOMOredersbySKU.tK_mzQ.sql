
-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-05-06
-- Description:	GetOM Orders by SKU and Date
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetOMOredersbySKU]
	@SKU		INT,
	@DATE1		NVARCHAR(8),
	@DATE2		NVARCHAR(8),
	@CATEGORY	NVARCHAR(50),
	@SEARCH		NVARCHAR(50) = NULL
AS
BEGIN
	DECLARE @SQL NVARCHAR(4000)
	SET NOCOUNT ON;

    CREATE TABLE #tmpTopSell ( SKU INT, SubSKU1 INT, SubSKU2 INT, SubSKU3 INT, QuantityOrdered INT, Name NVARCHAR(500), CategoryID INT, Seq INT )
	CREATE CLUSTERED INDEX IDX_tmpTopSell ON #tmpTopSell ([SKU],[Seq])
	
	INSERT INTO #tmpTopSell (SKU, QuantityOrdered, Name, CategoryID, Seq)
	SELECT OD.SKU, SUM(OD.QuantityOrdered), PC.Name, PC.CategoryID, 0
	FROM OrderManager.dbo.[Order Details] OD (NOLOCK)
	LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
	ON CONVERT(NVARCHAR,PC.ID) = OD.SKU
	LEFT OUTER JOIN Inventory.dbo.Categories C (NOLOCK)
	ON C.ID = PC.CategoryID
	INNER JOIN OrderManager.dbo.Orders O (NOLOCK)
	ON O.OrderNumber = OD.OrderNumber AND O.Cancelled = 0
	WHERE CONVERT(NVARCHAR,OD.DetailDate,112) BETWEEN @DATE1 AND @DATE2 AND
	--OD.OrderNumber IN (
	--	SELECT OrderNumber 
	--	FROM OrderManager.dbo.Orders (NOLOCK) WHERE CONVERT(NVARCHAR,OrderDate,112) BETWEEN @DATE1 AND @DATE2 --AND OrderStatus IN('Shipped','Order Approved','Order Received','Payment Received','Pending Shipment')
	--) AND 
	OD.Adjustment = 0 AND PC.CategoryID IN (5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,10,11,12,13,62,20,21,22,23,64,14,24,59,60,69,70, 36 ,101,105,109,123,128,133,138,143,30, 158) --/*-*/--
	GROUP BY OD.SKU, PC.Name, PC.CategoryID, C.Name
	ORDER BY SUM(OD.QuantityOrdered) DESC

	SET @SQL = ' INSERT INTO #tmpTopSell (SKU, SubSKU1, QuantityOrdered, Name, CategoryID, Seq)
					SELECT TTS.SKU, AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 1
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '

	SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								WHEN ISNULL(@CATEGORY,'') = 'TV Parts' THEN '30'
								WHEN ISNULL(@CATEGORY,'') = 'Mexican Handcrafted' THEN '158'
								ELSE '0' END)

	SET @SQL = @SQL + ' ) GROUP BY TTS.SKU, AD.SubSKU, PC.Name, PC.CategoryID '

	EXEC(@SQL)

	--START V2
	SET @SQL = ' INSERT INTO #tmpTopSell (SKU, SubSKU1, SubSKU2, QuantityOrdered, Name, CategoryID, Seq)
					SELECT TTS.SKU, TTS.SubSKU1, AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 2
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
					ON AD.ProductCatalogID = TTS.SubSKU1
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
					ON PC.ID = AD.SubSKU WHERE TTS.Seq = 1 AND PC.CategoryID IN ( '

	SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								WHEN ISNULL(@CATEGORY,'') = 'TV Parts' THEN '30'
								WHEN ISNULL(@CATEGORY,'') = 'Mexican Handcrafted' THEN '158'
								ELSE '0' END)

	SET @SQL = @SQL + ' ) GROUP BY TTS.SKU, TTS.SubSKU1, AD.SubSKU, PC.Name, PC.CategoryID '

	EXEC(@SQL)
	--END V2
	
	SET @SQL = ' INSERT INTO #tmpTopSell (SKU, SubSKU1, SubSKU2, SubSKU3, QuantityOrdered, Name, CategoryID, Seq)
					SELECT TTS.SKU, TTS.SubSKU1, TTS.SubSKU2, AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 3
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
					ON  AD.ProductCatalogID = TTS.SubSKU2 OR AD.ProductCatalogID = TTS.SubSKU1 OR AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '

	SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' THEN '69' WHEN ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '70' ELSE '0' END)

	SET @SQL = @SQL + ' ) GROUP BY TTS.SKU, TTS.SubSKU1, TTS.SubSKU2, AD.SubSKU, PC.Name, PC.CategoryID '
	
	EXEC(@SQL)

	IF(ISNULL(@SEARCH,'') = 'SKU')
	BEGIN
		SELECT O.CartID, S.CartName, OD.SKU,
			SUM(ISNULL(OD.QuantityOrdered,0)) AS QuantityOrdered, SUM(ISNULL(OD.QuantityOrdered,0) * CONVERT(DECIMAL(18,2),ISNULL(OD.PricePerUnit,0))) AS TotalPrice,--, O.ProductTotal, O.TaxTotal, O.ShippingTotal, O.GrandTotal
			MIN(CONVERT(DECIMAL(18,2),ISNULL(OD.PricePerUnit,0))) AS MinPricePerUnit, MAX(CONVERT(DECIMAL(18,2),ISNULL(OD.PricePerUnit,0))) AS MaxPricePerUnit,
			CONVERT(DECIMAL(18,2),(SUM(ISNULL(OD.QuantityOrdered,0) * CONVERT(DECIMAL(18,2),ISNULL(OD.PricePerUnit,0))) / SUM(ISNULL(OD.QuantityOrdered,0)))) AveragePricePerUnit,
			ISNULL((SELECT DISTINCT Price FROM [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTableV2](OD.SKU)),0) AS MITCost
		FROM OrderManager.dbo.[Order Details] OD WITH(NOLOCK)
		INNER JOIN OrderManager.dbo.Orders O WITH(NOLOCK) 
		ON O.OrderNumber = OD.OrderNumber AND O.Cancelled = 0
		LEFT OUTER JOIN OrderManager.dbo.ShoppingCarts S WITH(NOLOCK)
		ON S.ID = O.CartID
		WHERE CONVERT(NVARCHAR,OD.DetailDate,112) BETWEEN @DATE1 AND @DATE2 AND
		OD.SKU IN (
			SELECT CONVERT(NVARCHAR,SKU) FROM #tmpTopSell WHERE SKU = @SKU OR SubSKU1 = @SKU OR SubSKU2 = @SKU OR SubSKU3 = @SKU
		)
		GROUP BY O.CartID, S.CartName, OD.SKU
		ORDER BY O.CartID, OD.SKU
	END
	ELSE
	BEGIN
		SELECT O.OrderNumber, CONVERT(NVARCHAR,O.OrderDate,101) AS OrderDate, OD.SKU, SUBSTRING(OD.Product,0,50) + (CASE WHEN LEN(OD.Product) > 50 THEN '...' ELSE '' END) AS Product, OD.QuantityOrdered, OD.WebSKU, O.OrderStatus, CONVERT(DECIMAL(18,2),OD.PricePerUnit) AS PricePerUnit--, O.ProductTotal, O.TaxTotal, O.ShippingTotal, O.GrandTotal
		,O.CartID
		FROM OrderManager.dbo.[Order Details] OD (NOLOCK)
		INNER JOIN OrderManager.dbo.Orders O (NOLOCK) 
		ON O.OrderNumber = OD.OrderNumber AND O.Cancelled = 0
		WHERE CONVERT(NVARCHAR,OD.DetailDate,112) BETWEEN @DATE1 AND @DATE2 AND
		--OD.OrderNumber IN (
		--SELECT OrderNumber 
		--	FROM OrderManager.dbo.Orders (NOLOCK) WHERE CONVERT(NVARCHAR,OrderDate,112) BETWEEN @DATE1 AND @DATE2 --AND OrderStatus IN('Shipped','Order Approved','Order Received','Payment Received','Pending Shipment')
		--) AND OD.Adjustment = 0 
		--AND 
		OD.SKU IN (
			SELECT CONVERT(NVARCHAR,SKU) FROM #tmpTopSell WHERE SKU = @SKU OR SubSKU1 = @SKU OR SubSKU2 = @SKU OR SubSKU3 = @SKU
		)
		ORDER BY O.OrderNumber, OD.SKU
	END

END

go

