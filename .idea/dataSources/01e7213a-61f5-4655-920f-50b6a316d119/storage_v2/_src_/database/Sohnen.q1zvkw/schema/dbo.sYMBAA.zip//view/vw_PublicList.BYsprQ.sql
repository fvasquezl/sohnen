CREATE VIEW dbo.vw_PublicList
AS
SELECT        SKUD.ID, SKUD.SKU, SKUD.Brand, SKUD.Model, SKUD.Description, SKUD.EstimatedRetail, INV.QtyNew, INV.QtyGradeB, INV.QtyGradeC, INV.QtyGradeX, CAT.CategoryName
FROM            dbo.SKUData AS SKUD LEFT OUTER JOIN
                         dbo.Inventory AS INV ON SKUD.SKU = INV.SKU LEFT OUTER JOIN
                         dbo.Categories AS CAT ON SKUD.CategoryID = CAT.CategoryID
WHERE        (INV.QtyNew > 0) OR
                         (INV.QtyGradeB > 0) OR
                         (INV.QtyGradeC > 0) OR
                         (INV.QtyGradeX > 0)
go

