-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-12-02
-- Description:	Get Vendor Central Report
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetAmazon_Vendor_Central]
	@SearchVal		NVARCHAR(100),
	@Print_date		NVARCHAR(8),
	@Status			NVARCHAR(10),
	@CountryCode	NVARCHAR(3)
AS
BEGIN
	DECLARE @SQL	NVARCHAR(MAX),
	@NEW_STATUS		NVARCHAR(20)
	SET NOCOUNT ON;

	IF(@CountryCode = 'MX' AND @Status = 'Pending')
	BEGIN
		SET @SearchVal = '%' + @SearchVal + '%'
		SELECT AU.PO, AU.ASIN, AU.SKU, AU.MITSKU, AU.Type, (CASE WHEN AU.print_date IS NULL THEN 'Pending' ELSE 'Printed' END) AS print_date, ISNULL(AU.Quantity,1) AS Quantity, @CountryCode AS CountryCode
		FROM WebStation.AZ.AmazonUpload AU WHERE AU.print_date IS NULL AND CONVERT(NVARCHAR,AU.CREATE_DATE,112) = @Print_date AND AU.PO LIKE @SearchVal
	END
	ELSE
	BEGIN
		SET @NEW_STATUS = (CASE WHEN @Status = 'PO' THEN '%' ELSE @Status END)

		SET @SQL = ' SELECT AU.PO, AU.ASIN, AU.SKU, AU.MITSKU, AU.Type, (CASE WHEN AU.print_date IS NULL THEN ''Pending'' ELSE ''Printed'' END) AS print_date, ISNULL(AU.Quantity,1) AS Quantity,
						A.CountryCode
					FROM WebStation.AZ.AmazonUpload AU (NOLOCK)
					LEFT OUTER JOIN MiTech.amz.Amazon A (NOLOCK)
					ON A.ASIN = AU.ASIN AND CONVERT(NVARCHAR,A.UPC) = AU.SKU AND CONVERT(NVARCHAR,A.ProductSKU) = AU.MITSKU AND (A.CountryCode = ''MX'' OR A.CountryCode = ''US'') 
					WHERE (CASE WHEN AU.print_date IS NULL THEN ''Pending'' ELSE ''Printed'' END) LIKE '''+@NEW_STATUS+''' AND ISNULL(A.CountryCode,'''') LIKE '''+@CountryCode+''' '
		IF @Status = 'Printed'
		BEGIN
			SET @SQL = @SQL + ' AND CONVERT(NVARCHAR,AU.print_date,112) = '''+@Print_date+''' '
		END
		ELSE
		BEGIN
			IF @Status = 'PO'
			BEGIN
				SET @SQL = @SQL + ' AND ISNULL(AU.PO,'''') <> '''' '
			END
		END
		IF LEN(RTRIM(LTRIM(@SearchVal))) >= 3
		BEGIN
			SET @SQL = @SQL + ' AND (AU.PO LIKE ''%'+@SearchVal+'%'' OR AU.ASIN LIKE ''%'+@SearchVal+'%'' OR AU.SKU LIKE ''%'+@SearchVal+'%'' 
								OR AU.MITSKU LIKE ''%'+@SearchVal+'%'' OR AU.Type LIKE ''%'+@SearchVal+'%'' ) '
		END

		SET @SQL = @SQL + ' GROUP BY AU.PO, AU.ASIN, AU.SKU, AU.MITSKU, AU.Type, AU.print_date, AU.Quantity, A.CountryCode
							ORDER BY AU.PO DESC '

		EXECUTE(@SQL)
	END
END
go

