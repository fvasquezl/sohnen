-- =============================================
-- Author:		MI Technologies, Inc.
-- Create date: 11/11/2010
-- Description:	Adds a new user group an update the relationships with other tables
-- =============================================
CREATE PROCEDURE [dbo].[sp_SkuHistory]
	-- Add the parameters for the stored procedure here
	@sku as int
AS
BEGIN
	SELECT 
	BH.[ID] AS [TrID],
	US.[FullName] AS [User],
	Case 
		WHEN BH.[Flow] = 1 Then 'Added' 
		WHEN BH.[Flow] = 2 Then 'Removed' 
	End AS [Movement],
	BH.[Qty] AS [Qty],
	BH.[Bin_Id] AS [BinID],
	LS.listdisplay AS [Reason],
	BH.[Comments] AS [Comments],
	LEFT(CONVERT(VARCHAR,BH.[Stamp], 120), 22) AS [Date],
	B.[WarehouseID] As [WH],
	B.Location As [Location] 
	FROM [Inventory].[dbo].[Bins_History] AS BH 
	LEFT OUTER JOIN [Inventory].[dbo].[Users] AS US ON (BH.[User_Id] = US.[ID]) 
	LEFT OUTER JOIN [Inventory].[dbo].All_List AS LS ON (BH.ScanCode = LS.listvalue)
	LEFT OUTER JOIN [Inventory].[dbo].[Bins] AS B ON (BH.Bin_Id = B.Bin_Id)
	WHERE BH.[Product_Catalog_ID] = @sku
	ORDER BY Stamp DESC 
END
go

