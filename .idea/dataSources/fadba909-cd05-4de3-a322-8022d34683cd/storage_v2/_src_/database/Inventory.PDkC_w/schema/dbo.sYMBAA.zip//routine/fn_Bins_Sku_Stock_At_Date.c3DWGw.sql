-- =============================================
-- Author:		Luis Bautista
-- Create date: 03 JUL 2014
-- Description:	Stocks at date
-- =============================================
CREATE FUNCTION [dbo].[fn_Bins_Sku_Stock_At_Date]
(
	@pSKU int, @pDate Datetime
)
RETURNS int	
AS
BEGIN
	DECLARE @ResultVar int;
	DECLARE @ins int;
	DECLARE @outs int;
	
	

	SELECT @ins = SUM(a.Qty) 
	FROM Inventory.dbo.Bins_History a
	 WHERE (a.Product_Catalog_ID = @pSKU) and (a.Stamp <= @pDate)and (a.Flow = 1);
	 

	 IF @ins is null
	BEGIN
		SET @ins = 0;
	END

	SELECT @outs = SUM(a.Qty) 
	FROM Inventory.dbo.Bins_History a 
	 WHERE (a.Product_Catalog_ID = @pSKU) and (a.Stamp <= @pDate)and (a.Flow = 2);


	  IF @outs is null
	BEGIN
		SET @outs = 0;
	END

	SET @ResultVar = @ins - @outs;

	IF @ResultVar is null
	BEGIN
		SET @ResultVar = 0;
	END
	-- Return the result of the function
	RETURN @ResultVar; 

END
go

