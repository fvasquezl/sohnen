-- =============================================
-- Author:		Hector Mendoza
-- Create date: 10/25/2016
-- Description:	SP for to insert RMAS into the Inventory Database only from Exclusive Bulbs
-- =============================================
CREATE PROCEDURE [dbo].[spInsertStoredExclusiveRma]
	-- Add the parameters for the stored procedure here
	@webOrder varchar(255),
	@orderNumber int,
	@type varchar(255),
	@rmaReason varchar(255),
	@reason varchar(255),
	@replacementOrder int,
	@resolution varchar(255),
	@refund int,
	@charge int,
	@issuedBy varchar(255),
	@account varchar(255),
	@isExclusiveBulbs int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	INSERT INTO Inventory.dbo.ExclusiveRMAs (WebOrder,DateIssued,OrderNumber,Type,RMAReason,Reason,ReplacementOrder,Resolution,Refund,Charge,IssuedBy,isExclusiveBulbs) VALUES (@webOrder,GETDATE(),@orderNumber,@type,@rmaReason,@reason,@replacementOrder,@resolution,@refund,@charge,@issuedBy,@isExclusiveBulbs);
	SELECT SCOPE_IDENTITY() as id;
END
go

