



--This procedure is created to generate random Merchant SKU for Amazon channel.

CREATE PROCEDURE [dbo].[CreateAmazonSpArcSKU]

AS 
BEGIN
Declare @ID				AS nVarchar(10)
Declare @PartNumber	    AS nVarchar(max)
Declare @ItemSKU		AS nVarchar(25)

Declare @MyID nvarchar(max)


DECLARE CreateSKU_cursor CURSOR
FOR
--Select all of ASINs that are NULL
SELECT 
	[ID]
	, REPLACE(REPLACE(REPLACE(REPLACE([PartNumber], ' ', '')
	,'-', '')
	,'/', '')
	,'.', '')	AS [PartNumber] 
FROM Inventory.dbo.AmazonSparc 
WHERE 
	[item_sku] = ''
	OR [item_sku] IS NULL


OPEN CreateSKU_cursor
FETCH NEXT FROM CreateSKU_cursor INTO @ID, @PartNumber

WHILE @@FETCH_STATUS = 0
BEGIN

	---- Set SpArc SKU
	SET @MyID = newid();
	SET @ItemSKU = CONVERT(varchar(5), LEFT(@MyID,5)) + 'ARC' + CONVERT(varchar(8), RIGHT(@MyID,3)) 
	 
	
	UPDATE Inventory.dbo.AmazonSparc 
	SET 
		[item_sku] = @ItemSKU 
		, [part_number] = RIGHT(@ItemSKU,4) +  @PartNumber
		, [model] = RIGHT(@ItemSKU,4) +  @PartNumber
	WHERE [ID] = @ID



FETCH NEXT FROM CreateSKU_cursor INTO @ID, @PartNumber

END

CLOSE CreateSKU_cursor
DEALLOCATE CreateSKU_cursor

END



go

