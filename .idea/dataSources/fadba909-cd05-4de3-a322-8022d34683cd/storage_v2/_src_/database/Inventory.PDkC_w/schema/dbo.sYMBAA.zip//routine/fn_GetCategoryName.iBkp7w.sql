-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetCategoryName]
(
	@CategoryID as int
)
RETURNS varchar (100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @CategoryName as varchar(100)

	-- Add the T-SQL statements to compute the return value here
	SELECT @CategoryName = name FROM Categories (NOLOCK) WHERE ID = @CategoryID

	-- Return the result of the function
	RETURN @CategoryName

END
go

