

--This procedure is created to concatenate the different models that a product can be used for
-- to be posted is the title or description of a listing on ebay or othersites. 
-- This Prodedure uses a cursor to select all of the compatible
-- models and insert them into a single varchar.
--The Output is the title that will be used in EBAY under 80 Characters.
----------------------------------------
--Updates:
--1. created by Keoki Rosa 004/02/2012
--2.
----------------------------------------
CREATE Procedure [dbo].[Title_Compatible_Models] (@PartNumber as Varchar(25))
--RETURNS nvarChar(max)

AS
BEGIN

Create Table #TMP
( ID Int Identity(1,1),
  RETURNVALUE VARCHAR(500),
  Spaces Int);

Declare Cont_Cursor Cursor
	For
		Select a.Manufacturer, b.Model
			from Inventory.dbo.Compatibility A
			Inner Join Inventory.dbo.CompatibilityDetails B
			On A.PartNumber = B.PartNumber
			where B.PartNumber = @PartNumber
			Group by a.Manufacturer, b.Model
			Order by A.Manufacturer,  b.model
			
Open Cont_Cursor

Declare @ReturnValue as Varchar(500), @Manufacturer as Varchar(25), @model as Varchar(40), @cnt as Int, 
		@Title as varchar(82), @Len as int, @LenR as Int, @LenSpace as Int
		
Fetch Next from Cont_Cursor into @Manufacturer, @model

Set @cnt = 1
Set @Title = @Manufacturer +' '+ @PartNumber+' Lamp Housing - ' 
Set @Len = Len(@title)
sET @LenR = '0'

While (@@FETCH_STATUS<> -1)
Begin
	If (@@FETCH_STATUS<> -2)
		If 60 - @Len - @LenR - LEN(@MODEL) - @LenSpace > 0 
			Begin
			If @cnt = 1
				Begin
					Set @ReturnValue = @Model
					Set @LenSpace = 0
					Set @LenR = LEN(@returnValue)
				End
			Else
				Begin
					Set @ReturnValue = @ReturnValue + ' ' + @model 
					Set @LenSpace = @LenSpace + 1
					Set @LenR = LEN(@returnValue)
				End
			Set @cnt = 2	
			End
		Else 
			Begin
				iNSERT iNTO #TMP (RETURNVALUE, spaces) VALUEs ( @Title + @rETURNvALUE, LEN(@Title + @rETURNvALUE) )
				Set @ReturnValue = ''
				
				Set @ReturnValue = @Model
				Set @LenSpace = 0
				Set @LenR = LEN(@returnValue)
		
				Set @cnt = 2 
			End
						
	Fetch Next from Cont_Cursor into @Manufacturer, @Model
END
--Insert the last record
iNSERT iNTO #TMP (RETURNVALUE, spaces) VALUEs ( @Title + @rETURNvALUE, LEN(@Title + @rETURNvALUE) )

--Return the information from the Temp Table
sELECT * FROM #TMP

CLOSE Cont_Cursor
DEALLOCATE Cont_Cursor
DROP tABLE #TMP

End
go

