CREATE VIEW dbo.PartNumberList
AS
SELECT DISTINCT Manufacturer, PartNumber
FROM         dbo.Compatibility
go

