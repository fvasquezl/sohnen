CREATE VIEW [dbo]._dta_mv_124   AS SELECT  [dbo].[ProductCatalog].[CategoryID] as _col_1,  [dbo].[ProductCatalog].[ID] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[ProductCatalog],  [dbo].[Global_Stocks]   WHERE  [dbo].[ProductCatalog].[ID] = [dbo].[Global_Stocks].[ProductCatalogId]  GROUP BY  [dbo].[ProductCatalog].[CategoryID],  [dbo].[ProductCatalog].[ID]
go

