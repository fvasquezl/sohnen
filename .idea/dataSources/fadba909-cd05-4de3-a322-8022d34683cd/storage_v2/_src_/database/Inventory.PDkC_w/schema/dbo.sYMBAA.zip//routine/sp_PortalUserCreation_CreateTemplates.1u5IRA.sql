-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 3-11-2016
-- Description:	PortalUserCreation - CreateTemplates in OM
-- =============================================
CREATE PROCEDURE sp_PortalUserCreation_CreateTemplates 
	-- Add the parameters for the stored procedure here
	@pCustomerName NVARCHAR(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

      DECLARE @stCompanyPrefix AS NVARCHAR(MAX)
  --This will set TemplateName to example: ResellerOrdersCalcom 
  --This will set TableName to example: CalcomOrders 
  SET @stCompanyPrefix = @pCustomerName

  INSERT INTO [OrderManager].[dbo].[ImportTemplates] (
		[TemplateName]
      ,[FileType]
      ,[Delimiter]
      ,[ColumnHeaders]
      ,[DefaultLocation]
      ,[TableName]
	  ) 
	  VALUES
	  (
	  'ResellerOrders'+@stCompanyPrefix,
	  'A',
	  'C',
	  '0',
	  '\\mitsql\sharedb\StoneEdge\Resellers.mdb',
	  @stCompanyPrefix + 'Orders'
	  )

	DECLARE @stTemplateID AS INT
	SET @stTemplateID = (SELECT [TemplateID] FROM [OrderManager].[dbo].[ImportTemplates] WHERE [TemplateName] LIKE '%'+@stCompanyPrefix+'%')
	PRINT @stTemplateID

	INSERT INTO [OrderManager].[dbo].[ImportTemplateFields] (
		[TemplateID]
      ,[DataType]
      ,[Source]
      ,[Destination]
      ,[Order]
      ,[FieldUID]
	  )
	SELECT @stTemplateID AS [TemplateID]
      ,[DataType]
      ,[Source]
      ,[Destination]
      ,[Order]
      ,[FieldUID]
	  FROM [OrderManager].[dbo].[ImportTemplateFields]
	  --Copies Dynamics Template
	  WHERE [TemplateID] = '7'


END
go

