
CREATE FUNCTION [dbo].[fnUpperCamelCase] (@Text nVarChar(MAX))
RETURNS nVarChar(MAX)
AS
BEGIN
    SET @Text = LOWER(@Text)
    DECLARE @New nVarChar(MAX) = (CASE WHEN @Text IS NULL THEN NULL ELSE '' END)
    DECLARE @Len   Int = LEN(@Text)
    DECLARE @Index Int = 1
    WHILE (@Index <= @Len)
        IF (SUBSTRING(@Text, @Index, 1) LIKE '[^a-z]' AND @Index + 1 <= @Len) BEGIN
            SELECT @New = @New + UPPER(SUBSTRING(@Text, @Index, 2)), @Index = @Index + 2
		END
        ELSE BEGIN
            SELECT @New = @New + SUBSTRING(@Text, @Index, 1) , @Index = @Index + 1
		END
    RETURN ( UPPER(LEFT(@New, 1)) + RIGHT(@New, ABS(@Len - 1)) )
END


go

