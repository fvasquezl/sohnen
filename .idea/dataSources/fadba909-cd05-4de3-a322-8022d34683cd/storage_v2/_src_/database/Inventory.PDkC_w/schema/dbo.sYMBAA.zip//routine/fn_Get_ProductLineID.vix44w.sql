-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_Get_ProductLineID
(
	@ProductCatalogID int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ProductLineID int

	-- Add the T-SQL statements to compute the return value here
	select @ProductLineID =  a.ProductLineID from Inventory.dbo.ProductCatalog a
	where a.ID = @ProductCatalogID

	-- Return the result of the function
	RETURN (@ProductLineId)


END
go

