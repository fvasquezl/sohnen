-- =============================================
-- Author:		Luis Alberto Bautista Gallardo for MI Technologies, Inc.
-- Create date: NOV-17-2010
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_IsValidUserID]
(
	-- Add the parameters for the function here
	@UserID int, @FunctionID as int
)
RETURNS bit	--Equals to Boolean
AS
BEGIN
	-- Declare the return variable here
	DECLARE @myValidUSer as BIT
	DECLARE @myGroup as INT

	SET @MyValidUser = 0
	
	-- Add the T-SQL statements to compute the return value here
	SELECT @MyGroup =  a.GroupID from Inventory.dbo.Users a
	where a.ID = @UserID

	SELECT @MyValidUser = permission FROM Inventory.dbo.GroupPermissions 
	WHERE ( GroupID = @MyGroup )  AND ( FunctionID = @FunctionID )
	
	-- Return the result of the function
	RETURN @myValidUser

END
go

