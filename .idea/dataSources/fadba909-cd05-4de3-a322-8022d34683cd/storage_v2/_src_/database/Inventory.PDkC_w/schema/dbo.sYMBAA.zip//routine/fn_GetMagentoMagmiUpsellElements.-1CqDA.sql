-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 10-30-2015
-- Description:	Get Magmi Magento Upsell Elements
-- =============================================
CREATE FUNCTION [dbo].[fn_GetMagentoMagmiUpsellElements] 
(
	-- Add the parameters for the function here
	@pCatalogID int, @pItemType NVARCHAR(MAX), @pTVorFP NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	
--	DECLARE @liststr NVARCHAR(MAX)
	DECLARE @tmpTable TABLE([SKU] NVARCHAR(MAX))

------Generic UPSELL-----
	--Bare to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKU' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	WHEN @pItemType = 'BareSKU' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] != '-' THEN PJD.[CatalogID] + '-OSRAM-Bare-' + @pTVorFP
	WHEN @pItemType = 'BareSKU' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] = '-' AND PJD.[BareSKUPX] != '-' THEN PJD.[CatalogID] + '-Phoenix-Bare-' + @pTVorFP
	WHEN @pItemType = 'BareSKU' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] = '-' AND PJD.[BareSKUPX] = '-' AND PJD.[BareSKUUSH] != '-' THEN PJD.[CatalogID] + '-Ushio-Bare' + @pTVorFP
	WHEN @pItemType = 'BareSKU' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] = '-' AND PJD.[BareSKUPX] = '-' AND PJD.[BareSKUUSH] = '-' AND PJD.[BareSKUOEM] != '-' THEN PJD.[CatalogID] + '-OEM-Bare' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Bare to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKU' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	WHEN @pItemType = 'BareSKU' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] != '-' THEN PJD.[CatalogID] + '-OSRAM-Module-' + @pTVorFP
	WHEN @pItemType = 'BareSKU' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] = '-' AND PJD.[EncSKUPX] != '-' THEN PJD.[CatalogID] + '-Phoenix-Module-' + @pTVorFP
	WHEN @pItemType = 'BareSKU' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] = '-' AND PJD.[EncSKUPX] = '-' AND PJD.[EncSKUUSH] != '-' THEN PJD.[CatalogID] + '-Ushio-Module-' + @pTVorFP
	WHEN @pItemType = 'BareSKU' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] = '-' AND PJD.[EncSKUPX] = '-' AND PJD.[EncSKUUSH] = '-' AND PJD.[EncSKUOEM] != '-' THEN PJD.[CatalogID] + '-OEM-Module-' + @pTVorFP
	WHEN @pItemType = 'BareSKU' AND PJD.[EncSKU] != '-' THEN PJD.[CatalogID] + '-Generic-Module-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID


	--Enc to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKU' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	WHEN @pItemType = 'EncSKU' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] != '-' THEN PJD.[CatalogID] + '-Osram-Bare-' + @pTVorFP 
	WHEN @pItemType = 'EncSKU' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] = '-' AND PJD.[BareSKUPX] != '-' THEN PJD.[CatalogID] + '-Phoenix-Bare-' + @pTVorFP 
	WHEN @pItemType = 'EncSKU' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] = '-' AND PJD.[BareSKUPX] = '-' AND PJD.[BareSKUUSH] != '-' THEN PJD.[CatalogID] + '-Ushio-Bare-' + @pTVorFP 
	WHEN @pItemType = 'EncSKU' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] = '-' AND PJD.[BareSKUPX] = '-' AND PJD.[BareSKUUSH] = '-' AND PJD.[BareSKUOEM] != '-' THEN PJD.[CatalogID] + '-OEM-Bare-' + @pTVorFP 
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Enc to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKU' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	WHEN @pItemType = 'EncSKU' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] != '-' THEN PJD.[CatalogID] + '-Osram-Module-' + @pTVorFP 
	WHEN @pItemType = 'EncSKU' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] = '-' AND PJD.[EncSKUPX] != '-' THEN PJD.[CatalogID] + '-Phoenix-Module-' + @pTVorFP 
	WHEN @pItemType = 'EncSKU' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] = '-' AND PJD.[EncSKUPX] = '-' AND PJD.[EncSKUUSH] != '-' THEN PJD.[CatalogID] + '-Ushio-Module-' + @pTVorFP 
	WHEN @pItemType = 'EncSKU' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] = '-' AND PJD.[EncSKUPX] = '-' AND PJD.[EncSKUUSH] = '-' AND PJD.[EncSKUOEM] != '-' THEN PJD.[CatalogID] + '-OEM-Module-' + @pTVorFP 
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID
------Generic UPSELL-----

------Philips UPSELL-----
	--Philips UPSELL to Housing
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKUPH' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID
------Philips UPSELL-----

------Osram UPSELL-----
	--Bare to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKUOS' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Bare to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKUOS' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	WHEN @pItemType = 'BareSKUOS' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] != '-' THEN PJD.[CatalogID] + '-Osram-Module-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID


	--Enc to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKUOS' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Enc to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKUOS' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID
------Osram UPSELL-----	


------Phoenix UPSELL-----
	--Bare to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKUPX' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	WHEN @pItemType = 'BareSKUPX' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] != '-' THEN PJD.[CatalogID] + '-OSRAM-Bare-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Bare to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKUPX' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	WHEN @pItemType = 'BareSKUPX' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] != '-' THEN PJD.[CatalogID] + '-OSRAM-Module-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID


	--Enc to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKUPX' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	WHEN @pItemType = 'EncSKUPX' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] != '-' THEN PJD.[CatalogID] + '-Osram-Bare-' + @pTVorFP 
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Enc to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKUPX' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	WHEN @pItemType = 'EncSKUPX' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] != '-' THEN PJD.[CatalogID] + '-Osram-Module-' + @pTVorFP 
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID
------Phoenix UPSELL-----

------Ushio UPSELL-----
	--Bare to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKUUSH' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	WHEN @pItemType = 'BareSKUUSH' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] != '-' THEN PJD.[CatalogID] + '-OSRAM-Bare-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Bare to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKUUSH' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	WHEN @pItemType = 'BareSKUUSH' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] != '-' THEN PJD.[CatalogID] + '-OSRAM-Module-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID


	--Enc to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKUUSH' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	WHEN @pItemType = 'EncSKUUSH' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] != '-' THEN PJD.[CatalogID] + '-Osram-Bare-' + @pTVorFP 
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Enc to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKUUSH' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	WHEN @pItemType = 'EncSKUUSH' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] != '-' THEN PJD.[CatalogID] + '-Osram-Module-' + @pTVorFP 
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID
------Ushio UPSELL-----


------OEM UPSELL-----
	--Bare to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKUOEM' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	WHEN @pItemType = 'BareSKUOEM' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] != '-' THEN PJD.[CatalogID] + '-OSRAM-Bare-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Bare to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'BareSKUOEM' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	WHEN @pItemType = 'BareSKUOEM' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] != '-' THEN PJD.[CatalogID] + '-OSRAM-Module-' + @pTVorFP
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID


	--Enc to Bare
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKUOEM' AND PJD.[BareSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Bare-' + @pTVorFP
	WHEN @pItemType = 'EncSKUOEM' AND PJD.[BareSKUPH] = '-' AND PJD.[BareSKUOS] != '-' THEN PJD.[CatalogID] + '-Osram-Bare-' + @pTVorFP 
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID

	--Enc to Enc
	INSERT INTO @tmpTable ([SKU])
	SELECT 
	(CASE 
	WHEN @pItemType = 'EncSKUOEM' AND PJD.[EncSKUPH] != '-' THEN PJD.[CatalogID] + '-Philips-Module-' + @pTVorFP
	WHEN @pItemType = 'EncSKUOEM' AND PJD.[EncSKUPH] = '-' AND PJD.[EncSKUOS] != '-' THEN PJD.[CatalogID] + '-Osram-Module-' + @pTVorFP 
	ELSE '' END)
	FROM [MITDB].[dbo].[ProjectorData] AS PJD
	WHERE PJD.[CatalogID] = @pCatalogID
------OEM UPSELL-----


DECLARE @listStr VARCHAR(MAX)
SELECT @listStr = COALESCE(@listStr+',' ,'') + [SKU] FROM @tmpTable WHERE [SKU] != ''
--SELECT @listStr


	RETURN @listStr;

END
go

