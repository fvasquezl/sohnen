CREATE procedure [dbo].[spPrintOrder](@Id_Order int)
AS
select a.ID,a.Origin,a.Destination,a.Date,a.UserID,Flow,a.Comments,
b.ID,b.InventoryAdjustmentsID,b.Quantity,dbo.fn_GetProductName( b.ProductCatalogID)as ProductName
 from InventoryAdjustments as a , InventoryAdjustmentDetails as b 
 where
 a.ID = b.InventoryAdjustmentsID and a.ID=@Id_Order
go

