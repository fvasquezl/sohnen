-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_Bins_BinLocation
(
	@pBinId as varchar(6)
)
RETURNS varchar(254)
AS
BEGIN
	
	DECLARE @ResultVar varchar(100)

	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = location FROM Bins WHERE Bin_Id = @pBinId;

	-- Return the result of the function
	RETURN @ResultVar;

END
go

