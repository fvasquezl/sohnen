-- =============================================
-- Author:		Luis Bautista
-- Create date: Feb-20-2014
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Portal_Authentication]
(
	@pUser varchar(255), @pPassword varchar(255)
)
RETURNS @Authentication_Table TABLE 
(
	ValidUser int  
	,CustomerId int 
	,LogoURL varchar(255)
	,CatalogLanguage varchar(50)
	,CatalogCurrency varchar(50)
	,CustomerFullName varchar(255)
	,CompanyName varchar(255)
	,CustomerAddress varchar(255)
	,CustomerAddress2 varchar(255)
	,CustomerCity varchar(255)
	,CustomerState varchar(255)
	,CustomerZip varchar(255)
	,CustomerCountry varchar(255)
	,CustomerCurrencySimbol char(5)
	,CustomerCurrencyPrefix char(5)
	,CustomerCurrencyPosfix char(5)
	,TaxEnabled bit
	,TaxRate decimal(10, 6)
	,ShippingInclude bit
	,ShippingCost decimal(10, 2)
	,DeliveryTimeInDays integer
	,DeliveryCaption  varchar(50)
	,[Language] char(10)
)
AS
BEGIN
	
	DECLARE @ValidUser int = 0;
	DECLARE @CustomerId int = 0;
	DECLARE @CartId int = 0;
	DECLARE @LogoURL varchar(255) = '';
	DECLARE @CatalogLanguage varchar(50) = '';
	DECLARE @CatalogCurrency varchar(50) = '';
	-- Variables From Order Manager
	DECLARE @CustomerFullName varchar(255) = '';
	DECLARE @CompanyName varchar(255) = '';
	DECLARE @CustomerAddress varchar(255) = '';
	DECLARE @CustomerAddress2 varchar(255) = '';
	DECLARE @CustomerCity varchar(255) = '';
	DECLARE @CustomerState varchar(255) = '';
	DECLARE @CustomerZip varchar(255) = '';
	DECLARE @CustomerCountry varchar(255) = '';
	DECLARE @CustomerCurrencySimbol char(5)
	DECLARE @CustomerCurrencyPrefix char(5)
	DECLARE @CustomerCurrencyPosfix char(5)
	DECLARE @TaxEnabled bit
	DECLARE @TaxRate decimal(10,6)
	DECLARE @ShippingInclude bit
	DECLARE @ShippingCost decimal(10,2)
	DECLARE @DeliveryTimeInDays integer
	DECLARE @DeliveryCaption  varchar(50)
	DECLARE @Language char(10)
	
	
	SELECT   @ValidUser = 1
			, @CustomerId = a.CustomerID
			, @CartId = a.CartId
			, @LogoURL =  a.LogoURL
			, @CatalogLanguage = a.CatalogLanguage
			, @CatalogCurrency = a.CatalogCurrency 
	FROM Inventory.dbo.Users a
	WHERE (a.USR = @pUser ) AND (a.Password = @pPassword) and (a.GroupID = 28);
	
	IF @ValidUser = 1 
	BEGIN
		SELECT   @CustomerFullName = omCustomers.FullName
				 ,@CompanyName = omCustomers.Company
				 ,@CustomerAddress = omCustomers.Address
				 ,@CustomerAddress2 = omCustomers.Address2
				 ,@CustomerCity = omCustomers.City
				 ,@CustomerState = omCustomers.State
				 ,@CustomerZip = omCustomers.Zip
			     ,@CustomerCountry = omCustomers.Country
		FROM OrderManager.dbo.Customers omCustomers
		WHERE omCustomers.CustomerID = @CustomerId;
		
		SELECT 
		@CustomerCurrencySimbol = RSC.CurrencySimbol
		,@CustomerCurrencyPrefix = RSC.CurrencyPrefix
		,@CustomerCurrencyPosfix = RSC.CurrencyPosfix
		,@TaxEnabled = RSC.TaxEnabled
		,@TaxRate = RSC.TaxRate
		,@ShippingInclude = RSC.ShippingInclude
		,@ShippingCost = RSC.ShippingCost
		,@DeliveryTimeInDays = RSC.DeliveryTimeInDays
		,@DeliveryCaption  = RSC.DeliveryCaption 
		,@Language = RSC.[Language]
	 FROM [Inventory].[dbo].[ResellerPortal_Customer_settings] RSC
	WHERE RSC.[Customer_Id] = @CustomerId;
	
	END;
	
	INSERT INTO @Authentication_Table  (
	ValidUser 
	,CustomerId
	,LogoURL 
	,CatalogLanguage 
	,CatalogCurrency
	,CustomerFullName 
	,CompanyName
	,CustomerAddress 
	,CustomerAddress2
	,CustomerCity 
	,CustomerState 
	,CustomerZip 
	,CustomerCountry 
	,CustomerCurrencySimbol
	,CustomerCurrencyPrefix
	,CustomerCurrencyPosfix
	,TaxEnabled
	,TaxRate
	,ShippingInclude
	,ShippingCost
	,DeliveryTimeInDays
	,DeliveryCaption
	,[Language]
	)
		VALUES (  @ValidUser, @CustomerId, @LogoURL, @CatalogLanguage, @CatalogCurrency
				, @CustomerFullName, @CompanyName, @CustomerAddress, @CustomerAddress2
				, @CustomerCity, @CustomerState, @CustomerZip, @CustomerCountry
				, @CustomerCurrencySimbol
				, @CustomerCurrencyPrefix
				, @CustomerCurrencyPosfix
				, @TaxEnabled
				, @TaxRate
				, @ShippingInclude
				, @ShippingCost
				, @DeliveryTimeInDays
				, @DeliveryCaption	
				, @Language
		);
	
	RETURN 
END
go

