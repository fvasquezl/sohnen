-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER tr_Accounts_Update
   ON  Accounts
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    
    DECLARE @account_family_new varchar(100);
    DECLARE @account_family_old varchar(100);
    DECLARE @warehouse_type int;
    DECLARE @warehouseid int;
    
    SELECT @account_family_new = a.family, @warehouseid = a.ID FROM inserted a;
    SELECT @account_family_old = family FROM deleted;
    
    
    IF (@account_family_new <> @account_family_old)
	BEGIN
	
		IF @account_family_new = 'STORE'
		BEGIN
				UPDATE Inventory.dbo.Inventory SET warehouse_type = 1 WHERE AccountID = @warehouseid;
		END
		
		IF @account_family_new = 'FOREIGN STORE'
		BEGIN
				UPDATE Inventory.dbo.Inventory SET warehouse_type = 2 WHERE AccountID = @warehouseid;
		END
		
    END

END
go

