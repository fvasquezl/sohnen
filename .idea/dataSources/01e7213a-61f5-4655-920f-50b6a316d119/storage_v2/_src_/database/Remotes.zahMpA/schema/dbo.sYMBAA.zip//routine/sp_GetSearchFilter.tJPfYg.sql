-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-07-12
-- Description:	Get Search by SKU
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSearchFilter]
	@SEARCH NVARCHAR(200),
	@TYPE	INT
AS
BEGIN
	SET NOCOUNT ON;

	SET @SEARCH = '%' + @SEARCH + '%'

    IF(ISNULL(@TYPE,0) = 1)
	BEGIN
		SELECT D.SKU, D.Manufacturer, D.PartNumber, B.ScanCode, SUM(B.StockQty) AS StockQty
		FROM Remotes.dbo.SKUData D WITH(NOLOCK)
		INNER JOIN Remotes.dbo.BinStock B  WITH(NOLOCK)
		ON B.SKU = D.SKU
		WHERE ISNULL(D.SKU,'') LIKE @SEARCH OR ISNULL(D.Manufacturer,'') LIKE @SEARCH OR ISNULL(D.PartNumber,'') LIKE @SEARCH 
		GROUP BY D.SKU, D.Manufacturer, D.PartNumber, B.ScanCode
		ORDER BY D.SKU, B.ScanCode
	END
	ELSE
	BEGIN
		SELECT D.SKU, D.Manufacturer, D.PartNumber, B.ScanCode, SUM(B.StockQty) AS StockQty
		FROM Remotes.dbo.SKUData D WITH(NOLOCK)
		LEFT OUTER JOIN Remotes.dbo.BinStock B  WITH(NOLOCK)
		ON B.SKU = D.SKU
		WHERE ISNULL(D.SKU,'') LIKE @SEARCH OR ISNULL(D.Manufacturer,'') LIKE @SEARCH OR ISNULL(D.PartNumber,'') LIKE @SEARCH
		GROUP BY D.SKU, D.Manufacturer, D.PartNumber, B.ScanCode
		ORDER BY D.SKU, B.ScanCode
	END
END
go

