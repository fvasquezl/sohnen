-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 1-4-2016
-- Description:	Get Bin Content by MerchantSKU
-- =============================================
CREATE FUNCTION [dbo].[fn_GetBinContentByMerchantSKU] 
(	
	-- Add the parameters for the function here
	@pMerchantSKU nvarchar(max)
)
RETURNS @Result TABLE (SKU INT, BinID NVARCHAR(MAX), Qty INT, Location NVARCHAR(MAX), WarehouseID NVARCHAR(MAX))
AS
BEGIN

		DECLARE @tmpTable AS TABLE([ASIN] NVARCHAR(MAX), [MerchantSKU] NVARCHAR(MAX), [SKU] INT)

		INSERT INTO @tmpTable ([ASIN],[MerchantSKU],[SKU])
		SELECT AMSKU.[ASIN] AS 'ASIN'
			  ,AMSKU.[SellerSKU] AS 'MerchantSKU'
			  ,AZ.[ProductCatalogID] AS 'SKU'
		  FROM [MiTech].[amz].[AmazonSellerSKU] AS AMSKU
		  LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ ON (AMSKU.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'US')
		  WHERE AMSKU.[SellerSKU] = @pMerchantSKU

		INSERT INTO @tmpTable ([ASIN],[MerchantSKU],[SKU])
		SELECT AMSKU.[ASIN] AS 'ASIN'
			  ,AMSKU.[SellerSKU] AS 'MerchantSKU'
			  ,AZ.[ProductCatalogID] AS 'SKU'
		  FROM [MiTech].[amz].[AmazonSellerSKU] AS AMSKU
		  LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ ON (AMSKU.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'US')
		  WHERE AMSKU.[SellerSKU] = @pMerchantSKU


		  INSERT INTO @Result ([SKU],[BinID],[Qty],[Location],[WarehouseID])
		  		SELECT TMPT.[SKU] AS 'SKU'
				,BC.[Bin_Id] AS 'BinID'
				,BC.[Counter] AS 'Qty'
				,B.[Location] AS 'Location'
				,B.[WarehouseID] AS 'WarehouseID'
		FROM @tmpTable AS TMPT
		LEFT OUTER JOIN [Inventory].[dbo].[Bin_Content] AS BC ON (TMPT.[SKU] = BC.[ProductCatalog_Id])
		LEFT OUTER JOIN [Inventory].[dbo].[Bins] AS B ON (BC.[Bin_Id] = B.[Bin_Id])
		WHERE [MerchantSKU] = @pMerchantSKU

RETURN;

END
go

