CREATE VIEW [dbo]._dta_mv_69   AS SELECT  [dbo].[AmazonSearchDATA].[ASIN] as _col_1,  [dbo].[AmazonSearchDATA].[Status] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[AmazonSearchDATA]   WHERE ( [dbo].[AmazonSearchDATA].[StatusUserID] = 233  AND  [dbo].[AmazonSearchDATA].[Brand] = N'3M'  AND  [dbo].[AmazonSearchDATA].[CountryCode] = N'US' ) GROUP BY  [dbo].[AmazonSearchDATA].[ASIN],  [dbo].[AmazonSearchDATA].[Status]
go

