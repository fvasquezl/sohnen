-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-04-21
-- Description:	Get Sum In Transit Qty by SKU
-- =============================================
CREATE FUNCTION fn_GetInTransitQty
(
	@SKU INT
)
RETURNS INT
AS
BEGIN
	DECLARE @RETURN INT

	-- Add the T-SQL statements to compute the return value here
	SET @RETURN = ISNULL((SELECT SUM(QtyShipped) FROM Inventory.dbo.InTransit WHERE SKU = @SKU),0)

	-- Return the result of the function
	RETURN @RETURN

END
go

