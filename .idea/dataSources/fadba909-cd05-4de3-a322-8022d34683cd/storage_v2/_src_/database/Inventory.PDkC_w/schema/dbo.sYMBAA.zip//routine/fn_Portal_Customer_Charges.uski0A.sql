-- =============================================
-- Author:		Luis Bautista
-- Create date: Jun-04_2014
-- Description: Retirn the Taxes ans shipping cost for a given customer id
-- =============================================
CREATE FUNCTION [dbo].[fn_Portal_Customer_Charges]
(
	@pCustomer_Id int
	,@pItemSubtotal decimal(18,4)
	,@pShippingMethod int
)
RETURNS 
@CustomerCharges TABLE 
(
	Taxes decimal(14,2)
	,ShippingCost decimal(14,2)
	,Discount decimal(14,2)
)
AS
BEGIN
	Insert into @CustomerCharges(Taxes, ShippingCost, Discount)
	values (@pItemSubtotal * 0.10, @pItemSubtotal * 0.05, 0 );
	
	RETURN 
END
go

