


--This procedure is created to concatenate the different models that a product can be used for
-- to be posted is the title or description of a listing on ebay or othersites. 
-- This Prodedure uses a cursor to select all of the compatible
-- models and insert them into a single varchar.
--The Output is the title that will be used in EBAY under 80 Characters.
----------------------------------------
--Updates:
--1. created by Keoki Rosa 004/02/2012
--2.
----------------------------------------
CREATE Procedure [dbo].[Compatible_Models_by_PN] (@PartNumber as Varchar(25))
--RETURNS nvarChar(max)

AS
BEGIN

		Select a.Manufacturer, b.Model
			from Inventory.dbo.Compatibility A
			Inner Join Inventory.dbo.CompatibilityDetails B
			On A.PartNumber = B.PartNumber
			where B.PartNumber = @PartNumber
			Group by a.Manufacturer, b.Model
			Order by A.Manufacturer,  b.model
End

go

