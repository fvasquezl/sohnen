

-- ==========================================================================================
-- Author:		Santos Escobar
-- Create date: 2016-05-04
-- Description:	Update WebStation.AZ.Amazon table (backup). Update user from table.
-- ==========================================================================================

CREATE TRIGGER [dbo].[TRG_Amazon_Backup] ON [dbo].[Amazon] 
   AFTER INSERT, DELETE, UPDATE
AS 
BEGIN
	--DECLARE @ASIN NVARCHAR(50),
			--@CountryCode NVARCHAR(3)
	-- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
	SET NOCOUNT ON;

	--DECLARE @Operation NCHAR(2), @ModelNumber NVARCHAR(4000), @Comments nvarchar(500), @Title nvarchar(4000)
	--DECLARE @Bullet1 nvarchar(4000), @Bullet2 nvarchar(4000), @Bullet3 nvarchar(4000), @Bullet4 nvarchar(4000), @Bullet5 nvarchar(4000)
	--DECLARE @Description nvarchar(4000), @ImageURL nvarchar(4000), @CurrentSellerList nvarchar(4000), @AutoAnalytics nvarchar(4000)
	
	--DECLARE @id INT, @user_ID INT

	--SELECT @ModelNumber = A.ModelNumber, @Comments = A.Comments, @Title = A.Title, @Bullet1 = A.Bullet1, @Bullet2 = A.Bullet2, @Bullet3 = A.Bullet3, @Bullet4 = A.Bullet4, @Bullet5 = A.Bullet5 , @Description = A.[Description], @ImageURL = A.ImageURL, @CurrentSellerList = A.CurrentSellerList, @AutoAnalyticS = A.AutoAnalytics
	--FROM Inventory.dbo.Amazon AS A (NOLOCK) WHERE A.id IN (SELECT id FROM inserted)

	--IF EXISTS(SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted) BEGIN
	--	SET @Operation = 'UP'

	--	--INSERT INTO WebStation.AZ.Amazon ([RegType],[RegDate],[id],[ASIN],[ProductCatalogId],[manufacturer],[ModelNumber],[manufacturerpn],[LampType],[price],[BrandMentioned],[BrandSell],[IsActive],[NoteS],[Category],[Stamp],[Comments],[CountryCode],[Title],[ChannelName],[FulfillmentChannel],[AssignedChannelAPI],[IsChecked],[EnteredTime],[BuyBoxPrice],[CategoryId],[ResearchRequired],[user_ID],[create_user],[create_date],[change_user],[change_date],[print_date],[FloorPriceOverride],[FloorPriceOverrideValue],[Bullet1],[Bullet2],[Bullet3],[Bullet4],[Bullet5],[Description],[ImageURL],[CurrentSellerList],[AutoAnalytics],[UpdateUser],[UpdateDate],[UpsellToASIN],[UpsellToASINStamp])
	--	--SELECT @Operation, GETDATE(), [id],[ASIN],[ProductCatalogId],[manufacturer], @ModelNumber, [manufacturerpn],[LampType],[price],[BrandMentioned],[BrandSell],[IsActive],[NoteS],[Category],[Stamp], @Comments, [CountryCode], @Title, [ChannelName],[FulfillmentChannel],[AssignedChannelAPI],[IsChecked],[EnteredTime],[BuyBoxPrice],[CategoryId],[ResearchRequired],[user_ID],[create_user],[create_date],[change_user],[change_date],[print_date],[FloorPriceOverride],[FloorPriceOverrideValue], @Bullet1, @Bullet2, @Bullet3, @Bullet4, @Bullet5, @Description, @ImageURL, @CurrentSellerList, @AutoAnalytics, [UpdateUser],[UpdateDate],[UpsellToASIN],[UpsellToASINStamp]
	--	--FROM inserted

	--	SELECT @user_ID = user_ID, @id = id FROM INSERTED
	--	UPDATE Inventory.dbo.Amazon SET change_user = @user_ID, change_date = GETDATE() WHERE id = @id
	--END
	--ELSE IF EXISTS(SELECT * FROM inserted) AND NOT EXISTS (SELECT * FROM deleted) BEGIN
	--	SET @Operation = 'IN'

	--	SELECT @user_ID = user_ID, @id = id FROM inserted
	--	UPDATE Inventory.dbo.Amazon SET create_user = @user_ID, create_date = GETDATE() WHERE id = @id
	--END
	----ELSE IF EXISTS(SELECT * FROM deleted) AND NOT EXISTS(SELECT * FROM inserted) BEGIN
	----	SET @Operation = 'DL'
		
	----	INSERT INTO WebStation.AZ.Amazon ([RegType],[RegDate],[id],[ASIN],[ProductCatalogId],[manufacturer],[ModelNumber],[manufacturerpn],[LampType],[price],[BrandMentioned],[BrandSell],[IsActive],[NoteS],[Category],[Stamp],[Comments],[CountryCode],[Title],[ChannelName],[FulfillmentChannel],[AssignedChannelAPI],[IsChecked],[EnteredTime],[BuyBoxPrice],[CategoryId],[ResearchRequired],[user_ID],[create_user],[create_date],[change_user],[change_date],[print_date],[FloorPriceOverride],[FloorPriceOverrideValue],[Bullet1],[Bullet2],[Bullet3],[Bullet4],[Bullet5],[Description],[ImageURL],[CurrentSellerList],[AutoAnalytics],[UpdateUser],[UpdateDate],[UpsellToASIN],[UpsellToASINStamp])
	----	SELECT @Operation, GETDATE(), [id],[ASIN],[ProductCatalogId],[manufacturer], @ModelNumber, [manufacturerpn],[LampType],[price],[BrandMentioned],[BrandSell],[IsActive],[NoteS],[Category],[Stamp], @Comments, [CountryCode], @Title, [ChannelName],[FulfillmentChannel],[AssignedChannelAPI],[IsChecked],[EnteredTime],[BuyBoxPrice],[CategoryId],[ResearchRequired],[user_ID],[create_user],[create_date],[change_user],[change_date],[print_date],[FloorPriceOverride],[FloorPriceOverrideValue], @Bullet1, @Bullet2, @Bullet3, @Bullet4, @Bullet5, @Description, @ImageURL, @CurrentSellerList, @AutoAnalytics, [UpdateUser],[UpdateDate],[UpsellToASIN],[UpsellToASINStamp]
	----	FROM deleted
	----END
	IF EXISTS(SELECT * FROM deleted)
	BEGIN		
		INSERT INTO [WebStation].[AZ].[Amazon] ([ASIN],[ProductCatalogId],[manufacturer],[manufacturerpn],[LampType],[price],[BrandMentioned],[BrandSell],[IsActive],[NoteS],[Category],[Stamp],[CountryCode]
				,[Title],[ChannelName],[FulfillmentChannel],[AssignedChannelAPI],[IsChecked],[EnteredTime],[BuyBoxPrice],[CategoryId],[ResearchRequired],[user_ID],[create_user],[create_date],[change_user],[change_date],[print_date]
				,[FloorPriceOverride],[FloorPriceOverrideValue],[Bullet1],[Bullet2],[Bullet3],[Bullet4],[Bullet5],[Description],[ImageURL],[CurrentSellerList],[AutoAnalytics],[UpdateUser],[UpdateDate],[UpsellToASIN],[UpsellToASINStamp]
				,[MITSalesRank],[MITSalesRankStamp],[FixPricing],[IsLive],[FLXActive],[FLXStamp],[AmazonUPC],[FLXLaunched],[AZSalesRank],[AZSalesRankCategory],[AZPartNumber],[FLXInvLinking])
		SELECT D.[ASIN],D.[ProductCatalogId],D.[manufacturer],D.[manufacturerpn],D.[LampType],D.[price],D.[BrandMentioned],D.[BrandSell],D.[IsActive],D.[NoteS],D.[Category],D.[Stamp],D.[CountryCode]
				,D.[Title],D.[ChannelName],D.[FulfillmentChannel],D.[AssignedChannelAPI],D.[IsChecked],D.[EnteredTime],D.[BuyBoxPrice],D.[CategoryId],D.[ResearchRequired],D.[user_ID],D.[create_user],D.[create_date],D.[change_user],D.[change_date],D.[print_date]
				,D.[FloorPriceOverride],D.[FloorPriceOverrideValue],D.[Bullet1],D.[Bullet2],D.[Bullet3],D.[Bullet4],D.[Bullet5],D.[Description],D.[ImageURL],D.[CurrentSellerList],D.[AutoAnalytics],D.[UpdateUser],D.[UpdateDate],D.[UpsellToASIN],D.[UpsellToASINStamp]
				,D.[MITSalesRank],D.[MITSalesRankStamp],D.[FixPricing],D.[IsLive],D.[FLXActive],D.[FLXStamp],D.[AmazonUPC],D.[FLXLaunched],D.[AZSalesRank],D.[AZSalesRankCategory],D.[AZPartNumber],D.[FLXInvLinking]
		FROM deleted D
		LEFT OUTER JOIN [WebStation].[AZ].[Amazon] A WITH(NOLOCK) 
		ON D.ASIN = A.ASIN AND D.CountryCode = A.CountryCode
		WHERE A.ASIN IS NULL
	END
	ELSE
	BEGIN
		INSERT INTO [WebStation].[AZ].[Amazon] ([ASIN],[ProductCatalogId],[manufacturer],[manufacturerpn],[LampType],[price],[BrandMentioned],[BrandSell],[IsActive],[NoteS],[Category],[Stamp],[CountryCode]
				,[Title],[ChannelName],[FulfillmentChannel],[AssignedChannelAPI],[IsChecked],[EnteredTime],[BuyBoxPrice],[CategoryId],[ResearchRequired],[user_ID],[create_user],[create_date],[change_user],[change_date],[print_date]
				,[FloorPriceOverride],[FloorPriceOverrideValue],[Bullet1],[Bullet2],[Bullet3],[Bullet4],[Bullet5],[Description],[ImageURL],[CurrentSellerList],[AutoAnalytics],[UpdateUser],[UpdateDate],[UpsellToASIN],[UpsellToASINStamp]
				,[MITSalesRank],[MITSalesRankStamp],[FixPricing],[IsLive],[FLXActive],[FLXStamp],[AmazonUPC],[FLXLaunched],[AZSalesRank],[AZSalesRankCategory],[AZPartNumber],[FLXInvLinking])
		SELECT D.[ASIN],D.[ProductCatalogId],D.[manufacturer],D.[manufacturerpn],D.[LampType],D.[price],D.[BrandMentioned],D.[BrandSell],D.[IsActive],D.[NoteS],D.[Category],D.[Stamp],D.[CountryCode]
				,D.[Title],D.[ChannelName],D.[FulfillmentChannel],D.[AssignedChannelAPI],D.[IsChecked],D.[EnteredTime],D.[BuyBoxPrice],D.[CategoryId],D.[ResearchRequired],D.[user_ID],D.[create_user],D.[create_date],D.[change_user],D.[change_date],D.[print_date]
				,D.[FloorPriceOverride],D.[FloorPriceOverrideValue],D.[Bullet1],D.[Bullet2],D.[Bullet3],D.[Bullet4],D.[Bullet5],D.[Description],D.[ImageURL],D.[CurrentSellerList],D.[AutoAnalytics],D.[UpdateUser],D.[UpdateDate],D.[UpsellToASIN],D.[UpsellToASINStamp]
				,D.[MITSalesRank],D.[MITSalesRankStamp],D.[FixPricing],D.[IsLive],D.[FLXActive],D.[FLXStamp],D.[AmazonUPC],D.[FLXLaunched],D.[AZSalesRank],D.[AZSalesRankCategory],D.[AZPartNumber],D.[FLXInvLinking]
		FROM inserted D
		LEFT OUTER JOIN [WebStation].[AZ].[Amazon] A WITH(NOLOCK) 
		ON D.ASIN = A.ASIN AND D.CountryCode = A.CountryCode
		WHERE A.ASIN IS NULL
	END
END

go

