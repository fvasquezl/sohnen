-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-08-14
-- Description:	Get Valid Login BinManager
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetLoginBinManager]
	@UserID		NVARCHAR(20),
	@Password	NVARCHAR(60),
	@User_IP	NVARCHAR(15)
AS
BEGIN
	DECLARE @USERTABLE TABLE (UserID NVARCHAR(20), UserName NVARCHAR(50), IsActive BIT, ID INT)
	DECLARE @TABLE TABLE (CONN_ID INT)
	SET NOCOUNT ON;

	INSERT INTO @USERTABLE
    SELECT usr, FullName, IsActive, ID
	FROM Inventory.dbo.Users
	WHERE usr = @UserID AND password = @Password

	IF((SELECT COUNT(*) FROM @USERTABLE) > 0)
	BEGIN
		INSERT INTO Inventory.dbo.SYS_LOGCONN (USER_ID,USER_IP,LOG_DATE,LOG_TIME,SYSTEM_TYPE) OUTPUT Inserted.CONN_ID INTO @TABLE
		VALUES (@UserID,@User_IP,CONVERT(NVARCHAR(8),GETDATE(),112),REPLACE(CONVERT(NVARCHAR(8),GETDATE(),114),':',''),'BM2') 
	END

	SELECT UserID, UserName, IsActive, ID, (SELECT MAX(CONN_ID) FROM @TABLE) AS Conn_ID
	FROM @USERTABLE
END
go

