-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 9-15-2017
-- Description:	Flex Activate RESET ALL
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonFLEXActivate-RESETALL] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

	   DECLARE @selectstatement NVARCHAR(2000)
		DECLARE @cmd NVARCHAR(2000)
				  
		--Delete History Older than 30 Days
		DELETE FROM [Inventory].[dbo].[History_AmazonFlexActivate] WHERE [stamp] < GETDATE()-0


		INSERT INTO [Inventory].[dbo].[History_AmazonFlexActivate]
		SELECT [sku], [product-id], [product-id-type], [price], [minimum-seller-allowed-price], [maximum-seller-allowed-price], [item-condition], CASE WHEN [quantity] = 0 AND [add-delete] = 'a' then NULL ELSE [quantity] end AS [quantity], [add-delete], [will-ship-internationally], [expedited-shipping], [standard-plus], [item-note], [fulfillment-center-id], [product-tax-code], [leadtime-to-ship], CASE WHEN [add-delete] = 'd' THEN 'Prime' ELSE '' END AS [merchant_shipping_group_name], [batteries_required], [are_batteries_included], [supplier_declared_dg_hz_regulation1] 
		--History Section
		,GETDATE() AS [stamp]
		--History End
		FROM [Inventory].[dbo].[AmazonFlexActivate] AS [AZFLEXCurrent]
		

		SET @selectstatement = 'SELECT [sku], [product-id], [product-id-type], [price], [minimum-seller-allowed-price], [maximum-seller-allowed-price], [item-condition], CASE WHEN [quantity] = 0 AND [add-delete] = ''a'' then NULL ELSE [quantity] end AS [quantity], [add-delete], [will-ship-internationally], [expedited-shipping], [standard-plus], [item-note], [fulfillment-center-id], [product-tax-code], [leadtime-to-ship], CASE WHEN [add-delete] = ''d'' THEN ''Prime'' ELSE '''' END AS [merchant_shipping_group_name], [batteries_required], [are_batteries_included], [supplier_declared_dg_hz_regulation1] FROM [Inventory].[dbo].[AmazonFlexActivate] AS [AZFLEXCurrent]'

		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebflexactivate-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd

	
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebflexactivate.bat"'
END
go

