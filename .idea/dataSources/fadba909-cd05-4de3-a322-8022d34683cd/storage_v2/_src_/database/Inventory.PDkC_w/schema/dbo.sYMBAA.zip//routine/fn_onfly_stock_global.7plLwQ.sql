-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_onfly_stock_global
(
	@ProductCatalogId int
	
)
RETURNS int
AS
BEGIN
		-- Declare the return variable here
	DECLARE @ResultVar int;
	DECLARE @ins int;
	DECLARE @outs int;
	DECLARE @tins int;
	DECLARE @touts int;
	

	
	SELECT @ins =  SUM (b.quantity)
	 FROM Inventory.dbo.InventoryAdjustments a,
	      Inventory.dbo.InventoryAdjustmentDetails b
	 WHERE (a.ID = b.InventoryAdjustmentsID)
			and (b.ProductCatalogID = @ProductCatalogId)
		
			and (a.Flow = 1);
			
			
	SELECT @outs =  SUM (b.quantity)
	 FROM Inventory.dbo.InventoryAdjustments a,
	      Inventory.dbo.InventoryAdjustmentDetails b
	 WHERE (a.ID = b.InventoryAdjustmentsID)
			and (b.ProductCatalogID = @ProductCatalogId)
		
			and (a.Flow = 2);
	
	
	
			
	SET @ResultVar = @ins +  @outs ;
	
	return @ResultVar;	
END
go

