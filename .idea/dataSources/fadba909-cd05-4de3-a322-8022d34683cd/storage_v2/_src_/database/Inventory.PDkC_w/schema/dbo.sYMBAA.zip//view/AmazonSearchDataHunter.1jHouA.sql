CREATE VIEW dbo.AmazonSearchDataHunter
AS
SELECT     AST.ASIN, AST.CountryCode, AST.SearchTerm, AST.PotentialSKU
FROM         dbo.AmazonSearchTemp AS AST LEFT OUTER JOIN
                      dbo.AmazonSearchDATA AS ASD ON AST.ASIN = ASD.ASIN AND AST.CountryCode = AST.CountryCode
WHERE     (ASD.ASIN IS NULL)
go

