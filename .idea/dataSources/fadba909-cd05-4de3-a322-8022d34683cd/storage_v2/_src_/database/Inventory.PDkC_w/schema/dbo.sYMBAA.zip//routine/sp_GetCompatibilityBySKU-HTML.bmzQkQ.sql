
-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-06-09
-- Description:	Get function fn_GetCompatiblityListForEbay 
--	and split then insert in temp table to returned
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetCompatibilityBySKU-HTML]
	@pSKU INT
AS

DECLARE @listPN VARCHAR(MAX)
DECLARE @listAltPN VARCHAR(MAX)
DECLARE @listModels VARCHAR(MAX)
DECLARE @listAltModels VARCHAR(MAX)

BEGIN
	SET NOCOUNT ON;

SELECT @listPN = COALESCE(@listPN+'<br> ' ,'') + IsNull(COMP.[Manufacturer],'') + ' ' + IsNull(COMP.[PartNumber],'')
FROM [Inventory].[dbo].[Compatibility] AS COMP
WHERE COMP.[ProductCatalogID] = @pSKU

SELECT @listAltPN = COALESCE(@listAltPN+'<br> ' ,'') + IsNull(AltCOMP.[OriginalManufacturer],'')+' '+IsNull(AltCOMP.[AlternativePN],'')
FROM [Inventory].[dbo].[CompatibilityAlternativePN] AS AltCOMP
LEFT OUTER JOIN [Inventory].[dbo].[Compatibility] AS COMP ON (AltCOMP.[OriginalManufacturer] = COMP.[Manufacturer] AND AltCOMP.[PartNumber] = COMP.[PartNumber])
WHERE COMP.[ProductCatalogID] = @pSKU

SELECT @listModels = COALESCE(@listModels+'<br> ' ,'') + IsNull(CD.[OriginalManufacturer],'') + ' ' + IsNull(CD.[Model],'')
FROM [Inventory].[dbo].[CompatibilityDetails] AS CD
LEFT OUTER JOIN [Inventory].[dbo].[Compatibility] AS COMP ON (CD.[OriginalManufacturer] = COMP.[Manufacturer] AND CD.[PartNumber] = COMP.[PartNumber])
WHERE COMP.[ProductCatalogID] = @pSKU

SELECT @listAltModels = COALESCE(@listAltModels+'<br> ' ,'') + IsNull(AltModels.[OriginalManufacturer],'')+' '+IsNull(AltModels.[AlternativeModel],'')
FROM [Inventory].[dbo].[CompatibilityAlternativeModels] AS AltModels
LEFT OUTER JOIN [Inventory].[dbo].[CompatibilityDetails] AS CD ON (AltModels.[OriginalManufacturer] = CD.[OriginalManufacturer] AND AltModels.[OriginalModel] = CD.[Model])
LEFT OUTER JOIN [Inventory].[dbo].[Compatibility] AS COMP ON (CD.[OriginalManufacturer] = COMP.[Manufacturer] AND CD.[PartNumber] = COMP.[PartNumber])
WHERE COMP.[ProductCatalogID] = @pSKU


SELECT '<table id="extraInfo" width="100%" border="0"><tr><td valign="top">PartNumbers: <br>' + @listPN + ' <br><br>AltPartNumbers: <br>' + @listAltPN + '</td><td valign="top">Models: <br>' + @listModels + ' <br><br>AltModels: <br>' + @listAltModels + '</td></tr></table>' AS extraInfo


END

go

