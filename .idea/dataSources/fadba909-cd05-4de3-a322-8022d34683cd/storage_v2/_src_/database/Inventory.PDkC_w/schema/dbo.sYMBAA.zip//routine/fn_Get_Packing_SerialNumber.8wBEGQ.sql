-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-12-08
-- Description:	Get Serial Number
-- =============================================
CREATE FUNCTION fn_Get_Packing_SerialNumber
(
	@OrderNumber NVARCHAR(50), @SKU NVARCHAR(50)
)
RETURNS nvarchar(50)
AS
BEGIN
	DECLARE @SerialNumber NVARCHAR(50)

	SELECT @SerialNumber = A.SerialNumber 
	FROM  OrderManager.dbo.Packing A
	INNER JOIN OrderManager.dbo.[Order Details] B
	ON B.OrderNumber = A.OrderNumber AND B.ItemNumber = A.ItemNumber
	WHERE A.OrderNumber = @OrderNumber AND B.SKU = @SKU AND ISNULL(A.SerialNumber,'') <> ''

	RETURN @SerialNumber

END
go

