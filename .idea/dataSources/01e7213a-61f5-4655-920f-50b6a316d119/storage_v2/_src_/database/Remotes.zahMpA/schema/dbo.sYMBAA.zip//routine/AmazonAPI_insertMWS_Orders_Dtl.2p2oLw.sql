-- =============================================
-- Author:		Hubet Cardenas Isla
-- Create date: 2017-03-24
-- Description:	Insert Amazon Markerplace Web Service Detail
-- =============================================
CREATE PROCEDURE [dbo].[AmazonAPI_insertMWS_Orders_Dtl] 
	-- Add the parameters for the stored procedure here
	@pOption NVARCHAR(50),
	@ASIN NVARCHAR(25) = NULL,
	@OrderItemId NVARCHAR(50) = NULL,
	@SellerSKU NVARCHAR(50) = NULL,
	@Title NVARCHAR(512) = NULL,
	@QuantityOrdered INT = NULL,
	@QuantityShipped INT = NULL,
	@ItemPrice NVARCHAR(30) = NULL,
	@ShippingPrice NVARCHAR(16) = NULL,
	@GiftWrapPrice NVARCHAR(16) = NULL,
	@ItemTax NVARCHAR(16) = NULL,
	@ShippingTax NVARCHAR(16) = NULL,
	@GiftWrapTax NVARCHAR(16) = NULL,
	@ShippingDiscount NVARCHAR(16) = NULL,
	@ConditionId NVARCHAR(20) = NULL,
	@ConditionSubtypeId NVARCHAR(25) = NULL,
	@AmazonOrderId NVARCHAR(50) = NULL,
	@PromotionDiscount NVARCHAR(50) = NULL
AS
	DECLARE @Exist INT
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	IF @pOption = 'INSERT'
	BEGIN
		SELECT @Exist = COUNT(*)
		  FROM [dbo].[AmazonAPI_OrderDetails] WITH(NOLOCK)
		 WHERE [AmazonOrderId] = @AmazonOrderId
		   AND [ASIN] = @ASIN

		IF @Exist <= 0
		BEGIN
			INSERT INTO [dbo].[AmazonAPI_OrderDetails]([ASIN],
																	[OrderItemId],
																	[SellerSKU],
																	[Title],
																	[QuantityOrdered],
																	[QuantityShipped],
																	[ItemPrice],
																	[ShippingPrice],
																	[GiftWrapPrice],
																	[ItemTax],
																	[ShippingTax],
																	[GiftWrapTax],
																	[ShippingDiscount],
																	[ConditionId],
																	[ConditionSubtypeId],
																	[AmazonOrderId],
																	[PromotionDiscount])
															 VALUES(@ASIN,
																	@OrderItemId,
																	@SellerSKU,
																	@Title,
																	@QuantityOrdered,
																	@QuantityShipped,
																	@ItemPrice,
																	@ShippingPrice,
																	@GiftWrapPrice,
																	@ItemTax,
																	@ShippingTax,
																	@GiftWrapTax,
																	@ShippingDiscount,
																	@ConditionId,
																	@ConditionSubtypeId,
																	@AmazonOrderId,
																	@PromotionDiscount)
		END
		ELSE
		BEGIN
			UPDATE [dbo].[AmazonAPI_OrderDetails]
			   SET [ASIN] = @ASIN,
				   [OrderItemId] = @OrderItemId,
				   [SellerSKU] = @SellerSKU,
				   [Title] = @Title,
				   [QuantityOrdered] = @QuantityOrdered,
				   [QuantityShipped] = @QuantityShipped,
				   [ItemPrice] = @ItemPrice,
				   [ShippingPrice] = @ShippingPrice,
				   [GiftWrapPrice] = @GiftWrapPrice,
				   [ItemTax] = @ItemTax,
				   [ShippingTax] = @ShippingTax,
				   [GiftWrapTax] = @GiftWrapTax,
				   [ShippingDiscount] = @ShippingDiscount,
				   [ConditionId] = @ConditionId,
				   [ConditionSubtypeId] = @ConditionSubtypeId,
				   [AmazonOrderId] = @AmazonOrderId,
				   [PromotionDiscount] = @PromotionDiscount,
				   [StampChange] = GETDATE()
			 WHERE [AmazonOrderId] = @AmazonOrderId
			   AND [ASIN] = @ASIN
		END
	END
	ELSE IF @pOption = 'SELECT'
	BEGIN
		--Delete OrderDetail is equal or minus zero
		DELETE FROM dbo.AmazonAPI_OrderDetails WHERE ISNULL(QuantityOrdered,0) <= 0
		SELECT TOP 1000 [AmazonOrderId]
		  FROM [dbo].[AmazonAPI_Orders] WITH(NOLOCK)
		 WHERE [AmazonOrderId] NOT IN(SELECT [AmazonOrderId]
									    FROM [dbo].[AmazonAPI_OrderDetails] WITH(NOLOCK)) 
		   --AND [OrderStatus] NOT IN ('Shipped', 'Canceled')
		 ORDER BY [StampInsert] DESC
	END
END
--SELECT * FROM dbo.AmazonAPI_OrderDetails WITH(NOLOCK) WHERE ISNULL(QuantityOrdered,0) <= 0
go

