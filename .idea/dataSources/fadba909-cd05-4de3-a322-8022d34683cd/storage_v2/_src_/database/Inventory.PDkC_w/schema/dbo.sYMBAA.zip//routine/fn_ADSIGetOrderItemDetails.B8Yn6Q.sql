
-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 8-10-2016
-- Description:	Get FBA Inventory by SKU
-- =============================================
CREATE FUNCTION [dbo].[fn_ADSIGetOrderItemDetails] 
(
	-- Add the parameters for the function here
	@pOrderNumber int
)
RETURNS @Result TABLE (SKU INT,Name NVARCHAR(MAX), [QtyOrdered] INT, [BoxLength] Decimal(10,2), [BoxWidth] Decimal(10,2), [BoxHeight] Decimal(10,2), [BoxWeightOz] Decimal(10,1), [BoxWeightLbs] Decimal(10,2), [Cubic] Decimal(10,2), [FlatRateOptions] NVARCHAR(MAX))
AS
BEGIN
	BEGIN
		INSERT INTO @Result
		SELECT PC.[ID] AS [SKU]
				,OD.[Product] AS [Name]
				--,(SELECT SUM([QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] WHERE [OrderNumber] = @pOrderNumber AND [SKU] = PC.[ID]) AS [QtyOrdered]
				,OD.[QuantityOrdered] AS [QtyOrdered]
				,PC.[BoxLength]*OD.[QuantityOrdered] AS [BoxLength]
				--,PC.[BoxWidth]*(SELECT SUM([QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] WHERE [OrderNumber] = @pOrderNumber AND [SKU] = PC.[ID]) AS [BoxWidth]
				,PC.[BoxWidth]*OD.[QuantityOrdered] AS [BoxWidth]
				,PC.[BoxHeight]*OD.[QuantityOrdered] AS [BoxHeight]
				,PC.[BoxWeightOz]*OD.[QuantityOrdered] AS [BoxWeightOz]
				,((PC.[BoxWeightOz]*OD.[QuantityOrdered])/16) AS [SingleBoxWeightLbs]
				,((PC.[BoxLength]*OD.[QuantityOrdered])*
				(PC.[BoxWidth]*OD.[QuantityOrdered])*
				(PC.[BoxHeight]*OD.[QuantityOrdered]))/1728 AS [Cubic]
				,PC.[FlatRateOptions]
		FROM [OrderManager].[dbo].[Order Details] AS OD
		LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (OD.[SKU] = CAST(PC.[ID] AS NVARCHAR(MAX)))
		WHERE OD.[OrderNumber] = @pOrderNumber
		AND OD.[Adjustment] = 0
		AND PC.[ID] IS NOT NULL
		

	
	END 

	RETURN;

END

go

