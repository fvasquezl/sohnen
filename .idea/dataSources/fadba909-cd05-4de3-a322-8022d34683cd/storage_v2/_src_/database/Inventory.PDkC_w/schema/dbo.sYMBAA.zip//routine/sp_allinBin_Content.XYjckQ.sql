-- =============================================
-- Author:		Luis Bautista
-- Create date: Jun-9-2014
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_allinBin_Content]
AS
BEGIN
	SELECT a.ProductCatalog_Id , a.Counter, a.Bin_Id FROM Inventory.dbo.Bin_Content a  Order by  a.ProductCatalog_Id
END
go

