-- =============================================
-- Author:		Pavel torres
-- Create date: 2018-11-03
-- Description:	Get Search by SKU
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSearchFilter_VShippingStation]
	@SEARCH NVARCHAR(200)
AS
BEGIN
	SET NOCOUNT ON;

	SET @SEARCH = '%' + @SEARCH + '%'

    SELECT  S.SKU + '-' + B.ScanCode AS SKU, S.Manufacturer, S.PartNumber
	FROM Remotes.dbo.SKUData S WITH(NOLOCK)
	LEFT OUTER JOIN Remotes.dbo.BinCode B WITH(NOLOCK)
	ON B.ScanType = 'BINTP'
	WHERE (ISNULL(S.SKU,'')+'-'+ISNULL(B.ScanCode,'')) LIKE '%'+@SEARCH+'%'
	ORDER BY S.SKU, B.ScanCode
END
go

