
-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 5-3-2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonSparcPriceFeed] 


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		/*********************************************************************************************************************************/
		/*****************************NOW PROCEEDING TO UPDATE QUANTITIES ON AMAZON FOR ALL LISTINGS**************************************/
		/********************************************************SEPARATE TO DIFFERENT JOB************************************************/
		/*********************************************************************************************************************************/
		DECLARE @selectstatementinv AS NVARCHAR(MAX)
		DECLARE @cmdinv AS VARCHAR(2000)

/**
		/***********PRICE FBM*************/
		DECLARE @selectstatementprice AS NVARCHAR(MAX)
		DECLARE @cmdprice AS VARCHAR(2000)

 		--SET @selectstatementprice = 'SELECT row_number() OVER (Order by SPR.[item_sku]) AS MessageID, ''Update'' AS OperationType, (SELECT DISTINCT SPR.[item_sku] AS SKU, ''USD'' AS ''StandardPrice/@currency'', SPR.[price] AS StandardPrice, ''USD'' AS ''MinimumSellerAllowedPrice/@currency'', ''1.99'' AS MinimumSellerAllowedPrice, ''USD'' AS ''MaximumSellerAllowedPrice/@currency'', ''1099.99'' AS MaximumSellerAllowedPrice FROM [Inventory].[dbo].[AmazonSparc] AS SPR2 WHERE SPR.[item_sku] = SPR2.[item_sku] FOR XML PATH(''Price''),TYPE) FROM [Inventory].[dbo].[AmazonSparc] AS SPR WHERE SPR.[MITSKU] IS NOT NULL OR SPR.[MITSKU] != '''' FOR XML PATH(''Message''),TYPE'

		SET @selectstatementprice = 'SELECT 
									row_number() OVER (Order by SPR.[item_sku]) AS MessageID
									, ''Update'' AS OperationType, 
									(
										SELECT DISTINCT 
											SPR.[item_sku] AS SKU
											, ''USD'' AS ''StandardPrice/@currency''
											, (pc.PriceFloor + pc.PriceCeiling) / 2  AS StandardPrice
											, ''USD'' AS ''MinimumSellerAllowedPrice/@currency''
											, pc.PriceFloor AS MinimumSellerAllowedPrice
											, ''USD'' AS ''MaximumSellerAllowedPrice/@currency''
											, pc.PriceCeiling AS MaximumSellerAllowedPrice 
										FROM [Inventory].[dbo].[AmazonSparc] AS SPR2 
										LEFT JOIN Inventory.dbo.ProductCatalog pc
										ON
											SPR2.MITSKU = pc.ID
										WHERE SPR.[item_sku] = SPR2.[item_sku] 
	
									FOR XML PATH(''Price''),TYPE) 

									FROM [Inventory].[dbo].[AmazonSparc] AS SPR WHERE (SPR.[MITSKU] IS NOT NULL OR SPR.[MITSKU] != '''' )
									'

		SET @cmdprice = 'bcp "' + @selectstatementprice + '" queryout "C:\sharedb\AmazonAPI\Sparc\spcbody-price.xml" -SMITSQL -Usa -PZ91bM473 -c -x -r'
		EXEC master..xp_cmdshell @cmdprice
		EXEC master..xp_CMDShell 'c:\sharedb\AmazonAPI\Sparc\spcsendprice.bat'

**/

END

go

