-- =============================================
-- Author:		Hector Mendoza
-- Create date: October 10,2016
-- Description:	Stored procedure to store a RMA Lamp and return the last instert id
-- =============================================
CREATE PROCEDURE [dbo].[spStoreRmaLamp] 
	-- Add the parameters for the stored procedure here
	@rma INT,
	@sku INT,
	@status varchar(15),
	@defect varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	INSERT INTO OrderManager.dbo.RMAReturnData(RMAnumber,SKU,Status,Defect) VALUES (@rma,@sku,@status,@defect);
	SELECT SCOPE_IDENTITY() as LastInserted;
END
go

