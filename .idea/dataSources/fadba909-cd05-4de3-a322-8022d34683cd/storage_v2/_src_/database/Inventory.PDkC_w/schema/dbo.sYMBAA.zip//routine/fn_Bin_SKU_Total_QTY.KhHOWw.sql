-- =============================================
-- Author:		Luis Bautista
-- Create date: Jun_25_2014
-- Description:	Sum SKU QTY in all bins
-- =============================================
CREATE FUNCTION [dbo].[fn_Bin_SKU_Total_QTY]
(
	@pSKU int	
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar int	

	
	SELECT @ResultVar = SUM(a.Counter) FROM Inventory.dbo.Bin_Content a WHERE a.ProductCatalog_Id = @pSKU;

	IF @ResultVar is null
	BEGIN
		SET @ResultVar = 0;
	END
	-- Return the result of the function
	RETURN @ResultVar;

END
go

