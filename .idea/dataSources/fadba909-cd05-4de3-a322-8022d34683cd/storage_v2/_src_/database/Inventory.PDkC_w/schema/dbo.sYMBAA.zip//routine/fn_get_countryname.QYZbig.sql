-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_get_countryname]
(
	@pcode varchar(5)
)
RETURNS  varchar(50)
AS
BEGIN
	declare @country as varchar(100)
	
	select @country =  a.name from Inventory.dbo.Countries a
	where a.code = @pcode
	
	return @country

END
go

