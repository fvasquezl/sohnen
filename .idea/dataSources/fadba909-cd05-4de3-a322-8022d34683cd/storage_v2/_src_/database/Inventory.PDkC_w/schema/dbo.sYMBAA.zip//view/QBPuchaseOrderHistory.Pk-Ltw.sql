CREATE VIEW dbo.QBPuchaseOrderHistory
AS
SELECT        TOP (100) PERCENT dbo.QBPurchaseOrderLine.PurchaseOrderLineItemRefFullName AS SKU, dbo.ProductCatalog.Name, 
                         dbo.QBPurchaseOrderLine.RefNumber AS PO#, dbo.QBPurchaseOrderLine.TxnDate AS [Date Issued], 
                         dbo.QBPurchaseOrderLine.CustomFieldPurchaseOrderLineOther1 AS [Date Expected], dbo.QBPurchaseOrderLine.PurchaseOrderLineQuantity AS [Qty Ordered], 
                         dbo.QBPurchaseOrderLine.PurchaseOrderLineReceivedQuantity AS [Qty Received], 
                         dbo.QBPurchaseOrderLine.PurchaseOrderLineQuantity - dbo.QBPurchaseOrderLine.PurchaseOrderLineReceivedQuantity AS [Qty Missing], 
                         dbo.QBPurchaseOrderLine.IsFullyReceived AS [Fully Received?]
FROM            dbo.QBPurchaseOrderLine LEFT OUTER JOIN
                         dbo.ProductCatalog ON LEFT(CAST(dbo.QBPurchaseOrderLine.PurchaseOrderLineItemRefFullName AS nvarchar), 6) = LEFT(CAST(dbo.ProductCatalog.ID AS nvarchar),
                          6)
WHERE        (dbo.QBPurchaseOrderLine.PurchaseOrderLineItemRefFullName IS NOT NULL)
ORDER BY SKU
go

