-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-05-21
-- Description:	Convert to HTML UTF8
-- =============================================
CREATE FUNCTION fn_convert_utf8
(@Text NVARCHAR(MAX))
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @RETURN NVARCHAR(MAX), @ITEXT INT, @I INT, @TEXTRETURN NVARCHAR(MAX)
	SET @TEXTRETURN = ''
	SET @I = 0	
	SET @ITEXT = LEN(@Text)
	WHILE(@I < @ITEXT)
	BEGIN
		SELECT TOP 1 @RETURN = HTMLNUmber FROM Inventory.dbo.fn_return_convert_utf8('') WHERE TextOrSimbol COLLATE Latin1_General_CS_AS = SUBSTRING(@Text,@I+1,1)
		SET @RETURN = CASE WHEN ISNULL(@RETURN,'') = '' THEN SUBSTRING(@Text,@I+1,1) ELSE @RETURN END
		SET @TEXTRETURN = @TEXTRETURN + @RETURN
		SET @I = @I + 1
		SET @RETURN = ''
	END

	RETURN @TEXTRETURN
END
go

