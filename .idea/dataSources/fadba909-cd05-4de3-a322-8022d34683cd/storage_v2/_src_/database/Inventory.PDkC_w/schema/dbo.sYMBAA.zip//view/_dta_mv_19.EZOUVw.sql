CREATE VIEW [dbo]._dta_mv_19 WITH SCHEMABINDING AS SELECT  [dbo].[ResellerPortalOrderDetails].[WebOrderNumber] as _col_1,  count_big(*) as _col_2 FROM  [dbo].[ResellerPortalOrderDetails]  GROUP BY  [dbo].[ResellerPortalOrderDetails].[WebOrderNumber]
go

