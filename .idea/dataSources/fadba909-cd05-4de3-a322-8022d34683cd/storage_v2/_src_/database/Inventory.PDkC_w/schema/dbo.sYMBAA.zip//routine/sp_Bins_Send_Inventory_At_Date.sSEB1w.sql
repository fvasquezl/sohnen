-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Bins_Send_Inventory_At_Date]
@pDate datetime , @Maillist as varchar(1000)
AS
BEGIN
	

DECLARE @sql NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
DECLARE @date VARCHAR(12)
DECLARE @datestart varchar(25)
DECLARE @subtext VARCHAR(50)
DECLARE @subject VARCHAR(62)
DECLARE @recipients VARCHAR(255)
DECLARE @FileName as varchar(100);


SET  @datestart = cast(@pDate as varchar(25));

SET @FileName = 'InventoryAt_'+ @datestart;

SET @FileName = REPLACE(@FileName,' ','-');
SET @FileName = REPLACE(@FileName,':','-');
SET @FileName = REPLACE(@FileName,'/','-');
SET @FileName = REPLACE(@FileName,'\','-');
SET @FileName = REPLACE(@FileName,'*','-');
SET @FileName = REPLACE(@FileName,'.','-');

SET @FileName =  @FileName + '.csv';


SET @sql = 'EXECUTE Inventory.dbo.sp_Bins_Create_Inventory_At_Date ''' + @datestart + ''';'; 


SET @date = CONVERT(VARCHAR(12),GETDATE(),107);

SET @subtext = 'Inventory Report For ';
SET @subject = @subtext + @datestart + ' - Generated ' + @date;
SET @recipients =  @Maillist;
SET @body ='<html><center><H1>Inventory Report For <br>' + @datestart + '</H1><br><br> <body bgcolor=yellow><table border = 2>'
SET @body = @body + '</center></table><br><br>Regards,<br>AutoBot by MI Technologies, Inc</body></html>'

--If @body is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',
@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML',
@query = @sql,
@attach_query_result_as_file = 1,
@query_attachment_filename =  @FileName,
@query_result_separator = '	',
@query_result_no_padding = 1


END
go

