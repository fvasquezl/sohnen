
CREATE FUNCTION [dbo].[fn_getAssemblyDetails](@pSKU nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @ReturnValue VARCHAR(MAX)
	DECLARE @GetBulb VARCHAR(MAX)
	DECLARE @GetHousing VARCHAR(MAX)

	Select @GetBulb = AD.SubSKU
	FROM [Inventory].[dbo].AssemblyDetails AS AD (NOLOCK)
	LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) ON (AD.SubSKU = PC.ID)
	--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS (NOLOCK) ON (AD.ProductCatalogID = GS.ProductCatalogId)
	WHERE CONVERT(NVARCHAR,AD.ProductCatalogID) = @pSKU AND PC.CategoryID IN ('5','6','7','8','9','15','16','17','18','19')
	
	SELECT @GetHousing = AD.SubSKU
	FROM [Inventory].[dbo].AssemblyDetails AS AD (NOLOCK)
	LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) ON (AD.SubSKU = PC.ID)
	--LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS (NOLOCK) ON (AD.ProductCatalogID = GS.ProductCatalogId)
	WHERE CONVERT(NVARCHAR,AD.ProductCatalogID) = @pSKU AND PC.CategoryID IN ('59','60')

	SET @ReturnValue = @GetBulb+','+@GetHousing	

	RETURN @ReturnValue
END



go

