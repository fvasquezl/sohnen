-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-05-09
-- Description:	Transfer Stock and history
-- =============================================
CREATE PROCEDURE [dbo].[sp_BinTransferStock]
	@BIN_ID		NVARCHAR(10),
	@TOBIN_ID	NVARCHAR(10),
	@SKU		NVARCHAR(50),
	@QTY		INT,
	@UserID		NVARCHAR(50),
	@ScanCode	NVARCHAR(5),
	@Comment	NVARCHAR(500),
	@TYPE		NVARCHAR(5)
AS
BEGIN
	DECLARE @VALID			INT = 0,
			@CURSOR_STOCK	CURSOR,
			@CURSOR_SKU		NVARCHAR(50),
			@CURSOR_QTY		INT,
			@CURSOR_TYPE	NVARCHAR(5),
			--@GlobalStock	INT,
			@TransactionID NVARCHAR(200) = CONVERT(NVARCHAR,GETDATE()); 

	SET XACT_ABORT ON;
	SET NOCOUNT ON;

    --Valid User
	IF(NOT EXISTS(SELECT * FROM Remotes.dbo.Account WITH(NOLOCK) WHERE Username = @UserID AND Deleted = 0))
	BEGIN
		SET @VALID = 4
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	--Valid BinID
	IF(NOT EXISTS(SELECT * FROM Remotes.dbo.BinMaster WITH(NOLOCK) WHERE BinID = @BIN_ID AND isActive = 1))
	BEGIN
		SET @VALID = 1
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	--Valid To BinID
	IF(NOT EXISTS(SELECT * FROM Remotes.dbo.BinMaster WITH(NOLOCK) WHERE BinID = @TOBIN_ID AND isActive = 1))
	BEGIN
		SET @VALID = 1
		SELECT @VALID AS RESULT
		RETURN @VALID
	END

	IF(ISNULL(@ScanCode,'') <> 'TRN12')
	BEGIN
		--Valid SKU
		IF(NOT EXISTS(SELECT * FROM Remotes.dbo.SKUData WITH(NOLOCK) WHERE SKU = @SKU))
		BEGIN
			SET @VALID = 2
			SELECT @VALID AS RESULT
			RETURN @VALID
		END
		--Valid Qty
		IF(ISNULL(@QTY,0) <= 0)
		BEGIN
			SET @VALID = 3
			SELECT @VALID AS RESULT
			RETURN @VALID
		END
	END

	BEGIN TRANSACTION @TransactionID
	BEGIN TRY
		IF(ISNULL(@ScanCode,'') <> 'TRN12')
		BEGIN
			--Output Stock
			SET @VALID = 6
			--Valid Qty
			IF((SELECT StockQty FROM Remotes.dbo.BinStock WITH(NOLOCK) WHERE BinID = @BIN_ID AND SKU = @SKU AND ScanCode = @TYPE) >= @QTY)
			BEGIN
				UPDATE Remotes.dbo.BinStock SET StockQty = StockQty - @QTY, ChangeDate = GETDATE(), ChangeUser = @UserID WHERE BinID = @BIN_ID AND SKU = @SKU AND ScanCode = @TYPE
				DELETE FROM Remotes.dbo.BinStock WHERE BinID = @BIN_ID AND SKU = @SKU AND ScanCode = @TYPE AND ISNULL(StockQty,0) <= 0
				SET @VALID = 0
			END
			ELSE
			BEGIN				
				SET @VALID = 3
			END
		
			--Insert Output History
			IF(ISNULL(@VALID,-1) = 0)
			BEGIN
				SET @VALID = 7
				INSERT INTO Remotes.dbo.BinHistory (BinID, SKU, Quantity, Flow, ScanCode, CreateUser, Comments, ScanType)
				VALUES (@BIN_ID, @SKU, @QTY, 2, @ScanCode, @UserID, @Comment, @TYPE)
				SET @VALID = 0
			END
	
			--Input Stock
			SET @VALID = 5
			IF(EXISTS(SELECT * FROM Remotes.dbo.BinStock WITH(NOLOCK) WHERE BinID = @TOBIN_ID AND SKU = @SKU AND ScanCode = @TYPE))
			BEGIN
				UPDATE Remotes.dbo.BinStock SET StockQty = StockQty + @QTY, ChangeDate = GETDATE(), ChangeUser = @UserID WHERE BinID = @TOBIN_ID AND SKU = @SKU AND ScanCode = @TYPE
			END
			ELSE
			BEGIN
				INSERT INTO Remotes.dbo.BinStock (BinID, SKU, ScanCode, StockQty, CreateUser) VALUES (@TOBIN_ID, @SKU, @TYPE, @QTY, @UserID)
			END
			SET @VALID = 0

			--Insert Input History
			IF(ISNULL(@VALID,-1) = 0)
			BEGIN
				SET @VALID = 7
				INSERT INTO Remotes.dbo.BinHistory (BinID, SKU, Quantity, Flow, ScanCode, CreateUser, Comments, ScanType)
				VALUES (@TOBIN_ID, @SKU, @QTY, 1, @ScanCode, @UserID, @Comment, @TYPE)
				SET @VALID = 0
			END
		END
		ELSE
		BEGIN			
			SET @CURSOR_STOCK = CURSOR FOR 

			SELECT SKU, ScanCode, StockQty FROM Remotes.dbo.BinStock WITH(NOLOCK) WHERE BinID = @BIN_ID

			OPEN @CURSOR_STOCK 
			FETCH NEXT FROM @CURSOR_STOCK 
			INTO @CURSOR_SKU, @CURSOR_TYPE, @CURSOR_QTY

			WHILE (@@FETCH_STATUS = 0)
			BEGIN				
				--Output Stock
				SET @VALID = 6
				--Valid Qty
				IF((SELECT StockQty FROM Remotes.dbo.BinStock WITH(NOLOCK) WHERE BinID = @BIN_ID AND SKU = @CURSOR_SKU AND ScanCode = @CURSOR_TYPE) >= @CURSOR_QTY)
				BEGIN
					UPDATE Remotes.dbo.BinStock SET StockQty = StockQty - @CURSOR_QTY, ChangeDate = GETDATE(), ChangeUser = @UserID WHERE BinID = @BIN_ID AND SKU = @CURSOR_SKU AND ScanCode = @CURSOR_TYPE
					DELETE FROM Remotes.dbo.BinStock WHERE BinID = @BIN_ID AND SKU = @CURSOR_SKU AND ScanCode = @CURSOR_TYPE AND ISNULL(StockQty,0) <= 0
					SET @VALID = 0
				END
				ELSE
				BEGIN				
					SET @VALID = 3
				END

				--Insert Output History
				IF(ISNULL(@VALID,-1) = 0)
				BEGIN
					SET @VALID = 7
					INSERT INTO Remotes.dbo.BinHistory (BinID, SKU, Quantity, Flow, ScanCode, CreateUser, Comments, ScanType)
					VALUES (@BIN_ID, @CURSOR_SKU, @CURSOR_QTY, 2, @ScanCode, @UserID, @Comment, @CURSOR_TYPE)
					SET @VALID = 0
				END
				
				--Input Stock
				SET @VALID = 5
				IF(EXISTS(SELECT * FROM Remotes.dbo.BinStock WITH(NOLOCK) WHERE BinID = @TOBIN_ID AND SKU = @CURSOR_SKU AND ScanCode = @CURSOR_TYPE))
				BEGIN
					UPDATE Remotes.dbo.BinStock SET StockQty = StockQty + @CURSOR_QTY, ChangeDate = GETDATE(), ChangeUser = @UserID WHERE BinID = @TOBIN_ID AND SKU = @CURSOR_SKU AND ScanCode = @CURSOR_TYPE
				END
				ELSE
				BEGIN
					INSERT INTO Remotes.dbo.BinStock (BinID, SKU, ScanCode, StockQty, CreateUser) VALUES (@TOBIN_ID, @CURSOR_SKU, @CURSOR_TYPE, @CURSOR_QTY, @UserID)
				END
				SET @VALID = 0

				--Insert Input History
				IF(ISNULL(@VALID,-1) = 0)
				BEGIN
					SET @VALID = 7
					INSERT INTO Remotes.dbo.BinHistory (BinID, SKU, Quantity, Flow, ScanCode, CreateUser, Comments, ScanType)
					VALUES (@TOBIN_ID, @CURSOR_SKU, @CURSOR_QTY, 1, @ScanCode, @UserID, @Comment, @CURSOR_TYPE)
					SET @VALID = 0
				END
				
				NEXT_FETCH:
				FETCH NEXT FROM @CURSOR_STOCK
				INTO @CURSOR_SKU, @CURSOR_TYPE, @CURSOR_QTY
			END
			CLOSE      @CURSOR_STOCK
			DEALLOCATE @CURSOR_STOCK
		END
	END TRY
	BEGIN CATCH
		SET @VALID = 8
	END CATCH

	--RollBack if Error exists
	IF(ISNULL(@VALID,1) > 0)
	BEGIN
		ROLLBACK TRANSACTION @TransactionID
		SELECT @VALID AS RESULT
		RETURN @VALID
	END
	COMMIT TRANSACTION @TransactionID
	SELECT @VALID AS RESULT
END
go

