-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-08-06
-- Description:	Get FLEX Verification Report by Day
-- =============================================
CREATE PROCEDURE sp_GetFlexVerificationReport
AS
BEGIN
	DECLARE @MinDate DATETIME
	SET NOCOUNT ON;

    DECLARE @Batch TABLE (BatchId INT)
	DECLARE @TBL TABLE (SKU NVARCHAR(55), Quantity INT, FNSKU NVARCHAR(50))	

	INSERT INTO @Batch
	SELECT PickTaskId FROM [192.168.0.226].AmazonExclusiveBulbs.dbo.BatchOrders WITH(NOLOCK) WHERE CName = 'Remotes' AND Printed = 1 AND CONVERT(DATE,CreateDate) = CONVERT(DATE,GETDATE()) GROUP BY PickTaskId

	SET @MinDate = (SELECT MIN(CreateDate) FROM [192.168.0.226].AmazonExclusiveBulbs.dbo.BatchOrders WITH(NOLOCK) WHERE CName = 'Remotes' AND Printed = 1 AND PickTaskId IN (SELECT BatchId FROM @Batch))
	
	INSERT INTO @TBL
	SELECT (CASE WHEN CHARINDEX('-CN',SKU) > 0 THEN SKU ELSE SKU + '-NEW' END), SUM(RequestedQuantity) AS RequestedQuantity, FNSKU
	FROM [192.168.0.226].AmazonExclusiveBulbs.dbo.BatchOrders WITH(NOLOCK) 
	WHERE CName = 'Remotes' AND Printed = 1 AND PickTaskId IN (SELECT BatchId FROM @Batch)
	GROUP BY SKU, FNSKU

	SELECT T.SKU, T.FNSKU, T.Quantity,
		ISNULL((
			SELECT SUM(B.Quantity) 
			FROM Remotes.dbo.BinHistory B WITH(NOLOCK)
			WHERE B.Flow = 2 AND B.CreateDate >= @MinDate AND (B.SKU + '-' + B.ScanType) = T.SKU
			AND REPLACE(REPLACE(B.Comments,'FLEX VERIFICATION[',''),']','') = T.FNSKU
		),0) AS Discount
	FROM @TBL T
	ORDER BY T.SKU, T.FNSKU
END
go

