CREATE VIEW [dbo]._dta_mv_154   AS SELECT  [dbo].[Bin_Content].[ProductCatalog_Id] as _col_1,  [dbo].[Bin_Content].[Bin_Id] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[Bin_Content]  GROUP BY  [dbo].[Bin_Content].[ProductCatalog_Id],  [dbo].[Bin_Content].[Bin_Id]
go

