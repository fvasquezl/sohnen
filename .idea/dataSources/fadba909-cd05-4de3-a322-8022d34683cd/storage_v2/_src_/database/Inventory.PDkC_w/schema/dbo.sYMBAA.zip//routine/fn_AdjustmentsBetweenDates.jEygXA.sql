-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_AdjustmentsBetweenDates]
(
	-- Add the parameters for the function here
	@sku as int , @InitialDate as varchar(50), @FinalDate as varchar(50), @myFlow as int
)
RETURNS real
AS
BEGIN
	-- Declare the return variable here
	DECLARE @MyQtty as real

	-- Add the T-SQL statements to compute the return value here
	SELECT @MyQtty = SUM(b.Quantity)
	 FROM Inventory.dbo.InventoryAdjustments a,
	      Inventory.dbo.InventoryAdjustmentDetails b
	 WHERE (a.ID = b.InventoryAdjustmentsID)
			and (Flow = @MyFlow)
			and (b.ProductCatalogID = @sku)
			and (a.Date between @InitialDate and @finalDate)
  	
	-- Return the result of the function
	if @myqtty is null
	BEGIN
		SET @MyQtty = 0
	END
	
	RETURN @MyQtty

END
go

