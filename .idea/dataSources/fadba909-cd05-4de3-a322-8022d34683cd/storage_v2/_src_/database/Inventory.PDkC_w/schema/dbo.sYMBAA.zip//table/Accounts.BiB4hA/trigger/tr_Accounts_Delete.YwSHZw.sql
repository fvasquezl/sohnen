-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER tr_Accounts_Delete
   ON  dbo.Accounts
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    DECLARE @id INT;
    
    SET @id = (SELECT id FROM deleted);
    
    -- DELETE all related items in the inventory (warehouses) table
    DELETE FROM inventory WHERE AccountId = @id;

END
go

