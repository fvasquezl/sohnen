-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <6-2-2015>
-- Description:	<Update CustomerSpecificPricing using the CustomerSpecificPricingManagement Table>
-- =============================================
CREATE PROCEDURE [dbo].[sp_CustomerSpecificPricingManagement-Update]
	@CustomerID INT = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;



	---Update pricing if Autoprice is checked... also updates "LiveRates" if LiveRates and Autoprice are checked.
	UPDATE CSP SET CSP.SalePrice =

	Cast(CEILING
	
	(CASE 
	WHEN PC.[CategoryID] IN ('24','60') THEN
	--Get the LowestCost
	(IsNull(Inventory.dbo.fn_GetLowestPriceFromSuppliersTable(CSP.ProductCatalogID),'999')
	--Add the Percent Increase
	*(IsNull((SELECT CSPM2.CostPlusPercent/100 FROM [Inventory].[dbo].[CustomerSpecificPricingManagement] AS CSPM2 WHERE CSPM2.[CustomerID] = @CustomerID AND CSPM2.[CategoryID] = PC.[CategoryID]),'0.40')+1))
	--Add the AddedAmount
	+IsNull((SELECT CSPM2.AddAmount FROM [Inventory].[dbo].[CustomerSpecificPricingManagement] AS CSPM2 WHERE CSPM2.[CustomerID] = @CustomerID AND CSPM2.[CategoryID] = PC.[CategoryID]),'10.00')
	
	WHEN [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PC.[ID]) = 0 OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PC.[ID]) IS NULL THEN '999'
	
	ELSE
	--Get the UnitCost
	(IsNull([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PC.[ID]),'999')
	--Add the Percent Increase
	*(IsNull((SELECT CSPM2.CostPlusPercent/100 FROM [Inventory].[dbo].[CustomerSpecificPricingManagement] AS CSPM2 WHERE CSPM2.[CustomerID] = @CustomerID AND CSPM2.[CategoryID] = PC.[CategoryID]),'0.40')+1))
	--Add the AddedAmount
	+IsNull((SELECT CSPM2.AddAmount FROM [Inventory].[dbo].[CustomerSpecificPricingManagement] AS CSPM2 WHERE CSPM2.[CustomerID] = @CustomerID AND CSPM2.[CategoryID] = PC.[CategoryID]),'10.00')
	END) 
	
	AS INT)


	FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP
	LEFT OUTER JOIN [Inventory].[dbo].[CustomerSpecificPricingManagement] AS CSPM ON (CSP.[CustomerID] = CSPM.[CustomerID])
	LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (CSP.[ProductCatalogID] = PC.[ID])
	WHERE CSP.[Autoprice] = '1' AND CSP.[CustomerID] = @CustomerID
	

	---SET LIVERATES for items that AutoPrice is not checked.

	UPDATE CSP SET 
	CSP.[DSEconomyPrice] = CASE WHEN CSP.[UseLiveRates] = '1' AND PC.[AvgStandardShipCost] IS NOT NULL THEN Ceiling(PC.[AvgStandardShipCost]+0.75) ELSE (SELECT CSPM2.[DSEconomyDefault] FROM [Inventory].[dbo].[CustomerSpecificPricingManagement] AS CSPM2 WHERE CSPM2.[CustomerID] = @CustomerID AND CSPM2.[CategoryID] = PC.[CategoryID]) END,
	CSP.[DS2ndDayPrice] = CASE WHEN CSP.[UseLiveRates] = '1' AND PC.[Avg2DayShipCost] IS NOT NULL THEN Ceiling(PC.[Avg2DayShipCost]+0.75) ELSE (SELECT CSPM2.[DS2ndDayDefault] FROM [Inventory].[dbo].[CustomerSpecificPricingManagement] AS CSPM2 WHERE CSPM2.[CustomerID] = @CustomerID AND CSPM2.[CategoryID] = PC.[CategoryID]) END,
	CSP.[DS1DayPrice] = CASE WHEN CSP.[UseLiveRates] = '1' AND PC.[Avg1DayShipCost] IS NOT NULL THEN Ceiling(PC.[Avg1DayShipCost]+0.75) ELSE (SELECT CSPM2.[DS1DayDefault] FROM [Inventory].[dbo].[CustomerSpecificPricingManagement] AS CSPM2 WHERE CSPM2.[CustomerID] = @CustomerID AND CSPM2.[CategoryID] = PC.[CategoryID]) END
	
	FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP
	LEFT OUTER JOIN [Inventory].[dbo].[CustomerSpecificPricingManagement] AS CSPM ON (CSP.[CustomerID] = CSPM.[CustomerID])
	LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (CSP.[ProductCatalogID] = PC.[ID])
	WHERE CSP.[CustomerID] = @CustomerID

	---------------------------------------------------------
	--------Set All Categories Active------------------------
	---------------------------------------------------------
	UPDATE CSP SET CSP.Active = '1' 
	FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP
	LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (CSP.[ProductCatalogID] = PC.[ID])
	WHERE PC.[CategoryID] IN ('5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','29','30','36','59','60','61','62','63','64','82', '83', '84', '85', '87', '88', '89', '90', '91', '93', '94', '95', '96', '97', '98', '99', '100', '101', '102', '103', '104', '105', '106', '107', '108', '109', '110', '111', '112', '113', '114', '115', '116', '117', '118', '119', '120', '121', '122', '123', '124', '125', '126', '127', '128', '129', '130', '131', '132', '133', '134', '135', '136', '137', '138', '139', '140', '141', '142', '143', '144', '145') AND CustomerID = @CustomerID

END
go

