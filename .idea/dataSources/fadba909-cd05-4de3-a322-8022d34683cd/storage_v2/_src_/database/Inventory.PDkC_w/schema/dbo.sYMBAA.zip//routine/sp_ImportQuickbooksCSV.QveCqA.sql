-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <2-16-2015>
-- Description:	<Import CSV Purchase Order History from Quickbooks>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ImportQuickbooksCSV] 
		@FilePath NVARCHAR(2000)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[Inventory].[dbo].[PurchaseOrderData_tmp]') AND type in (N'U'))
DROP TABLE [Inventory].[dbo].[PurchaseOrderData_tmp]



DECLARE @FileLocation VARCHAR(200);
DECLARE @FirstImportRow VARCHAR(200);

--Set File Location and Starting Row
SET @FileLocation = @FilePath
SET @FirstImportRow = '2';



--Create Temp Table
CREATE TABLE [Inventory].[dbo].[PurchaseOrderData_tmp]
(
[X] NVARCHAR(MAX),
[Date] NVARCHAR(MAX),
[Num] NVARCHAR(MAX),
[Item] NVARCHAR(MAX),
[Name] NVARCHAR(MAX),
[Deliv Date] NVARCHAR(MAX),
[Qty] NVARCHAR(MAX),
[Rcv'd] NVARCHAR(MAX),
[Backordered] NVARCHAR(MAX),
[Sales Price] NVARCHAR(MAX),
[Other 1] NVARCHAR(MAX)
)

--Insert and Convert the CSV file into temp table
INSERT [Inventory].[dbo].[PurchaseOrderData_tmp]
EXEC [Inventory].[dbo].[SSP_CSVToTable]
     @InputFile = @FileLocation
    ,@FirstLine = @FirstImportRow


--Drop Existing Final Table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[Inventory].[dbo].[PurchaseOrderData]') AND type in (N'U'))
DROP TABLE [Inventory].[dbo].[PurchaseOrderData]

----ReCreate Final Table
CREATE TABLE [Inventory].[dbo].[PurchaseOrderData]
(
PONumber NVARCHAR(max),
PODate date,
SKU NVARCHAR(max),
VendorName NVARCHAR(max),
DeliveryDate date,
QtyOrdered NVARCHAR(max),
QtyReceived NVARCHAR(max),
QtyBackOrdered NVARCHAR(max),
UnitCost NVARCHAR(max),
ETA NVARCHAR(max)
)

--Insert from Temp Table to Final Table
INSERT INTO [Inventory].[dbo].[PurchaseOrderData] (PONumber, PODate, SKU, VendorName, DeliveryDate, QtyOrdered, QtyReceived, QtyBackOrdered, UnitCost, ETA)
SELECT 
PODtmp.[Num] AS 'PONumber'
,Cast(PODtmp.[Date] AS date) AS 'PODate'
,LEFT(PODtmp.[Item],6) AS 'SKU'
,PODtmp.[Name] AS 'VendorName'
,Cast(PODtmp.[Deliv Date] as date) AS 'DeliveryDate'
,IsNull(PODtmp.[Qty],0) AS 'QtyOrdered'
,IsNull(PODtmp.[Rcv'd],0) AS 'QtyReceived'
,IsNull(PODtmp.[Backordered],0) AS 'QtyBackOrdered'
,IsNull(PODtmp.[Sales Price],0) AS 'UnitCost'
,PODtmp.[Other 1] AS 'ETA'
FROM [Inventory].[dbo].[PurchaseOrderData_tmp] AS PODtmp
WHERE PODtmp.[Num] IS NOT NULL 
AND LEFT(PODtmp.[Item],6) IN (SELECT Cast(ID as NVARCHAR(MAX)) FROM Inventory.dbo.ProductCatalog)
AND PODtmp.[Num] NOT IN (SELECT PONumber FROM [Inventory].[dbo].[PurchaseOrderData])

/**
CREATE NONCLUSTERED INDEX IX_PurchaseOrderData_SKU
ON Inventory.dbo.PurchaseOrderData (SKU DESC )   
INCLUDE (QtyOrdered, QtyReceived, QtyBackOrdered, UnitCost, PONumber, PODate, DeliveryDate)   
     
ALTER INDEX IX_PurchaseOrderData_SKU ON  Inventory.dbo.PurchaseOrderData  
REBUILD WITH (FILLFACTOR = 80); 
**/

--IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
--OBJECT_ID(N'[Inventory].[dbo].[PurchaseOrderData_tmp]') AND type in (N'U'))
--DROP TABLE [Inventory].[dbo].[PurchaseOrderData_tmp]

END
go

