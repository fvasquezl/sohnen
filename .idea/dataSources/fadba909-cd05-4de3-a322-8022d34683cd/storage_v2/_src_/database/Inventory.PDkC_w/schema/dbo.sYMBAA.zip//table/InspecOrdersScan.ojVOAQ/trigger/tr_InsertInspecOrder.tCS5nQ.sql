-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-07-21
-- Description:	Insert Inspec Order
-- =============================================
CREATE TRIGGER [dbo].[tr_InsertInspecOrder]
   ON  [Inventory].[dbo].[InspecOrdersScan]
   AFTER INSERT, UPDATE
AS 
BEGIN
	DECLARE @OrderNumber INT

	SET NOCOUNT ON;

	SET @OrderNumber = ISNULL((SELECT OrderNumber FROM inserted),0)

	IF((SELECT COUNT(*) FROM WebStation.OE.WorkOrders WHERE WorkOrderID = @OrderNumber) > 0 AND @OrderNumber > 0)
	BEGIN
		INSERT INTO WebStation.OE.HistoryWorkOrder (WorkOrderID, WOType, CreateUser, Status) VALUES (@OrderNumber, 'OM', 'Inspect', 30)
		UPDATE WebStation.OE.WorkOrders SET StatusID = 30 WHERE WorkOrderID = @OrderNumber AND StatusID < 30
	END
END
go

