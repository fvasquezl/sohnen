

CREATE FUNCTION [dbo].[fn_getFBA_Pending_Orders_BareLamps] (@MITSKU nVarChar(50))
RETURNS int
AS
BEGIN

Declare @OrderQty  AS INT


SET @OrderQty = 0

SET @OrderQty = (Select SUM(amfo.OrderQty) FROM Inventory.dbo.AmazonFBAOrders amfo
	LEFT JOIN Inventory.dbo.AmazonFBA amf
	ON amfo.ASIN = amf.ASIN
	LEFT JOIN Inventory.dbo.ProductCatalog pc
	ON amf.MITSKU = pc.ID
	WHERE amfo.Completed = 'No'
	AND (amf.MITSKU LIKE @MITSKU OR pc.CustomField04 LIKE @MITSKU) )
	
IF @OrderQty IS NULL
BEGIN
		 SET @OrderQty = 0
END

RETURN @OrderQty

END



go

