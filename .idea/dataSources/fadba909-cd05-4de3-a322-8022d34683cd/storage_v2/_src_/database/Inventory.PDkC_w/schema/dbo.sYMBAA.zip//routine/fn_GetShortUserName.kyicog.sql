-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetShortUserName] 
(
	-- Add the parameters for the function here
	@MYUserID int	
)
RETURNS varchar(100)
AS
BEGIN

	-- Declare the return variable here
	DECLARE @Username as varchar(100)

	-- Add the T-SQL statements to compute the return value here
	SELECT @Username = usr FROM Users WHERE ID = @MyUserID

	-- Return the result of the function
	RETURN @Username

END
go

