
-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 5-3-2016
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_PWLaunchItems] 


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		---Keep history of below feeds
		IF OBJECT_ID('Remotes.dbo.FeedHistory_Launch', 'U') IS NOT NULL 
	    DROP TABLE [Remotes].[dbo].[FeedHistory_Launch]; 



		---Keep history of below feeds
		SELECT CASE 
		WHEN MM.[IsCN] = 1 THEN REPLACE(MM.[MerchantSKU],'RMTC','SKU')+'-CN' 
		ELSE REPLACE(MM.[MerchantSKU],'RMTC','SKU') END AS [sku], 
		MM.[ASIN] AS [product-id],
		'1' AS [product-id-type],
		MM.[Ceiling] AS [price],
		'4' AS [minimum-seller-allowed-price],
		'399' AS [maximum-seller-allowed-price],
		(CASE WHEN MM.Condition = 'New' THEN '11' 
		WHEN MM.Condition = 'Used - Like New' THEN '1' 
		WHEN MM.Condition = 'Used - Very Good' THEN '2' 
		WHEN MM.Condition = 'Used - Good' THEN '3' 
		ELSE '11' END) AS [item-condition],
		(CASE WHEN MM.[Condition] = 'New' AND MM.[IsCN] = 1 AND (MM.[FulfillmentType] LIKE 'Merchant' OR MM.[IsSnL] = 1) 
			THEN CAST(FLOOR(IsNull([Remotes].[dbo].[fn_GetQtyByScanCode](MM.[SKU],'CN'),0) *0.5) AS NVARCHAR(50))
		WHEN MM.[Condition] = 'New' AND MM.[IsCN] = 0 AND (MM.[FulfillmentType] LIKE 'Merchant' OR MM.[IsSnL] = 1) 
			THEN CAST(FLOOR(IsNull([Remotes].[dbo].[fn_GetQtyByScanCode](MM.[SKU],'NEW'),0)*0.5) AS NVARCHAR(50))
		WHEN MM.[Condition] LIKE 'Used%' AND (MM.[FulfillmentType] LIKE 'Merchant' OR MM.[IsSnL] = 1) 
			THEN CAST(FLOOR(IsNull([Remotes].[dbo].[fn_GetQtyByScanCode](MM.[SKU],'USED'),0) *0.5) AS NVARCHAR(50))
		WHEN MM.[FulfillmentType] = 'Amazon' AND MM.[IsSnL] = 0 THEN ''
		ELSE '' END) AS [quantity],
		'a' AS [add-delete],
		'1' AS [will-ship-internationally],
		'' AS [expedited-shipping],
		'Y' AS [standard-plus], 
		--(CASE WHEN MM.[Condition] = 'NEW' THEN '' 
		--WHEN MM.[Condition] = 'NEW' AND MM.[IsCN] = 0 THEN 'FACTORY ORIGINAL '+SKUD.[Manufacturer]+' ITEM.' 
		--ELSE '' END) AS [item-note], 
		'' AS [item-note],
		(CASE WHEN MM.[IsSnL] = 1 THEN 'DEFAULT'
		WHEN MM.[FulfillmentType] = 'Merchant' AND (MM.[IsSnL] = 0 OR MM.[IsSnL] IS NULL) THEN 'DEFAULT' 
		WHEN MM.[FulfillmentType] = 'Amazon' AND (MM.[IsSnL] = 0 OR MM.[IsSnL] IS NULL) THEN 'AMAZON_NA' 
		ELSE '' END) AS [fulfillement-center-id],
		'A_GEN_TAX' AS [product-tax-code],
		(CASE WHEN MM.[FulfillmentType] = 'Merchant' OR MM.[IsSnL] = 1 THEN '1' ELSE '' END) AS [leadtime-to-ship],
		
		(CASE WHEN MM.[IsSnL] = 1 THEN 'PrimeSnL'
				WHEN MM.[FulfillmentType] = 'Merchant' AND (MM.[IsSnL] = 0 OR MM.[IsSnL] IS NULL) THEN 'Prime'
				WHEN MM.[FulfillmentType] = 'Amazon' AND (MM.[IsSnL] = 0 OR MM.[IsSnL] IS NULL) THEN ''
				ELSE 'RushDelivery' END) AS [merchant_shipping_group_name],
		(CASE WHEN SKUD.[CategoryID] LIKE '11%' THEN 'Yes' ELSE 'No' END) AS [batteries_required],
		(CASE WHEN SKUD.[CategoryID] LIKE '11%' THEN 'Yes' ELSE 'No' END) AS [are_batteries_included],
		'not_applicable' AS [supplier_declared_dg_hz_regulation1]
		----------------
		--This segment not in feed
		,GETDATE() AS 'stamp'
		----------------
		INTO [Remotes].[dbo].[FeedHistory_Launch]
		FROM [Remotes].[dbo].[MarketplaceMapping] AS MM  WITH (NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD  WITH (NOLOCK) ON (MM.[SKU] = SKUD.[SKU]) 
		WHERE Cast(MM.Stamp as date) > (DATEADD(DD, -2, GETDATE())) 
		AND (MM.[FulfillmentType] = 'Amazon' OR MM.[FulfillmentType] = 'Merchant')
		
		
		--SELECT * FROM [Remotes].[dbo].[FeedHistory_Launch]

		---Start Feed---	
		DECLARE @selectstatement AS NVARCHAR(MAX)
		DECLARE @cmd AS VARCHAR(2000)
	
		SET @selectstatement = 'SELECT [sku],[product-id],[product-id-type],[price],[minimum-seller-allowed-price],[maximum-seller-allowed-price],[item-condition],[quantity],[add-delete],[will-ship-internationally],[expedited-shipping],[standard-plus],[item-note],[fulfillement-center-id],[product-tax-code],[leadtime-to-ship],[merchant_shipping_group_name],[batteries_required],[are_batteries_included],[supplier_declared_dg_hz_regulation1] FROM [Remotes].[dbo].[FeedHistory_Launch]  WITH (NOLOCK)'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "\\192.168.0.226\sharedb\AmazonAPI\PriceWatchers\pwbody-addsku.txt" -SBSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd

		EXEC master..xp_cmdshell '"\\192.168.0.226\sharedb\AmazonAPI\PriceWatchers\pwaddsku-txt.bat"'



END

go

