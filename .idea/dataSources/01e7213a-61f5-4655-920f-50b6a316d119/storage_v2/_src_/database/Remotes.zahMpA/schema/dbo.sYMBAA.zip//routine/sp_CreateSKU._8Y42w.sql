-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2019-03-27
-- Description:	Get the last SKU
-- =============================================
CREATE PROCEDURE sp_CreateSKU
AS
BEGIN
	DECLARE @COUNT	INT,
			@SKU	NVARCHAR(50)

	SET NOCOUNT ON;

    SET @COUNT = ISNULL((SELECT CAST((MAX(SUBSTRING(LTRIM(RTRIM(SKU)),5,LEN(SKU)-1))) AS INT) + 1 FROM [Remotes].[dbo].[SKUData]),1)
	SET NOCOUNT ON;

	SET @SKU = 'RMTC' + RIGHT('00000' + CONVERT(NVARCHAR,@COUNT),5)
		
	SELECT @SKU AS SKU
END
go

