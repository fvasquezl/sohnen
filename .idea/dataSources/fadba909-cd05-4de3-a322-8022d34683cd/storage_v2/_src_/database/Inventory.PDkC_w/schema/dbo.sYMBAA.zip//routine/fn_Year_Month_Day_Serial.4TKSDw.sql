-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-06-02
-- Description:	Get Year-Month-Day Symbol for Serial
-- =============================================
CREATE FUNCTION fn_Year_Month_Day_Serial
(
	@YEAR INT, @MONTH INT, @DAY INT
)
RETURNS NVARCHAR(3)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @RETURN_VALUE NVARCHAR(3)

	-- Add the T-SQL statements to compute the return value here
	SET @RETURN_VALUE = (CASE @YEAR 
							WHEN 2015 THEN 'A' 
							WHEN 2016 THEN 'B' 
							WHEN 2017 THEN 'C' 
							WHEN 2018 THEN 'D' 
							WHEN 2019 THEN 'E' 
							WHEN 2020 THEN 'F' 
							WHEN 2021 THEN 'G' 
							WHEN 2022 THEN 'H' 
							WHEN 2023 THEN 'I' 
							WHEN 2024 THEN 'J' 
							WHEN 2025 THEN 'K' 
							ELSE 'Z' END)

	SET @RETURN_VALUE = @RETURN_VALUE + (CASE @MONTH 
											WHEN 1 THEN '1' --January
											WHEN 2 THEN '2' --February
											WHEN 3 THEN '3' --March
											WHEN 4 THEN '4' --April
											WHEN 5 THEN '5' --May
											WHEN 6 THEN '6' --June
											WHEN 7 THEN '7' --July
											WHEN 8 THEN '8' --August
											WHEN 9 THEN '9' --September
											WHEN 10 THEN 'A' --October
											WHEN 11 THEN 'B' --November
											WHEN 12 THEN 'C' --December
											ELSE 'Z' END)

	SET @RETURN_VALUE = @RETURN_VALUE + (CASE @DAY 
											WHEN 1 THEN '1' 
											WHEN 2 THEN '2' 
											WHEN 3 THEN '3' 
											WHEN 4 THEN '4' 
											WHEN 5 THEN '5' 
											WHEN 6 THEN '6' 
											WHEN 7 THEN '7' 
											WHEN 8 THEN '8' 
											WHEN 9 THEN '9' 
											WHEN 10 THEN 'A' 
											WHEN 11 THEN 'B' 
											WHEN 12 THEN 'C' 
											WHEN 13 THEN 'D' 
											WHEN 14 THEN 'E' 
											WHEN 15 THEN 'F' 
											WHEN 16 THEN 'G' 
											WHEN 17 THEN 'H' 
											WHEN 18 THEN 'I' 
											WHEN 19 THEN 'J' 
											WHEN 20 THEN 'K' 
											WHEN 21 THEN 'L' 
											WHEN 22 THEN 'M' 
											WHEN 23 THEN 'N' 
											WHEN 24 THEN 'O' 
											WHEN 25 THEN 'P' 
											WHEN 26 THEN 'Q' 
											WHEN 27 THEN 'R' 
											WHEN 28 THEN 'S' 
											WHEN 29 THEN 'T' 
											WHEN 30 THEN 'U' 
											WHEN 31 THEN 'V' 
											ELSE 'Z' END)

	-- Return the result of the function
	RETURN @RETURN_VALUE

END
go

