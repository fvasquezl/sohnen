-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Catalog_Filter_By_Make_PN]
(
	@pMake varchar(255), @pPartnumber varchar(255)
)
RETURNS 
@Catalog_filter_result TABLE 
(
	Make varchar(255)
	,Partnumber varchar(255)
	,ImageURL varchar(255)
	,BigImage varchar(255)
	,Compatibility nvarchar(1000)
)
AS
BEGIN
	-- Fill the table variable with the rows for your result set
	
	DECLARE @Make varchar(255);
	DECLARE @PartNumber varchar(255);
	DECLARE @ImageURL varchar(255);
	DECLARE @Compatibility nvarchar(1000);
	
	INSERT INTO @Catalog_filter_result
	SELECT MITDB_PD.Brand AS Make
			, MITDB_PD.PartNumber as Partnumber
			, 'http://photos.discount-merchant.com/photos/sku/' + MITDB_PD.[EncSKU] + '/th/' + MITDB_PD.[EncSKU] +'-1.jpg' as ImageURL
			, 'http://photos.discount-merchant.com/photos/sku/' + MITDB_PD.[EncSKU] + '/' + MITDB_PD.[EncSKU] +'-1.jpg' as BigImage
			,Compatibility = Inventory.dbo.fn_Catalog_Maker_Models_HTML(MITDB_PD.Brand, MITDB_PD.PartNumber)
	FROM  MITDB.dbo.ProjectorData  MITDB_PD
	WHERE (MITDB_PD.Brand =  @pMake) 
			AND
			(
				   (MITDB_PD.PartNumber = @pPartnumber)
				or (MITDB_PD.PartNumberV2 = @pPartnumber)
				or (MITDB_PD.PartNumberV3 = @pPartnumber)
			);
	
	RETURN 
END
go

