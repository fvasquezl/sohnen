-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 12-6-2014
-- Description:	Get Lowest Price based on category from the supplier Views
-- =============================================
CREATE FUNCTION [dbo].[fn_GetLowestPriceFromSuppliersTable] 
(
	-- Add the parameters for the function here
	@pSKU NVARCHAR(MAX)
)
RETURNS decimal(10,2)
AS
BEGIN

	DECLARE @SKU INT
	-- Declare the return variable here
	IF IsNumeric(@pSKU) <> 1 GOTO EndALL
	
	IF IsNumeric(@pSKU) = 1 SET @SKU = @pSKU

	DECLARE @Result decimal(10,2)

	IF (Select CategoryID FROM [Inventory].[dbo].[ProductCatalog] WITH(NOLOCK) WHERE ID = @pSKU) = '24' GOTO FPGetLowestPrice
	IF (Select CategoryID FROM [Inventory].[dbo].[ProductCatalog] WITH(NOLOCK) WHERE ID = @pSKU) = '60' GOTO HousingGetLowestPrice
	IF (Select CategoryID FROM [Inventory].[dbo].[ProductCatalog] WITH(NOLOCK) WHERE ID = @pSKU) != '24' AND (Select CategoryID FROM [Inventory].[dbo].[ProductCatalog] WITH(NOLOCK) WHERE ID = @pSKU) != '60' GOTO GetRESTLowestPrice

HousingGetLowestPrice:
	
	BEGIN
	SET @Result = (Select CAST(MIN(IsNULL([UnitCost],29)) AS Decimal(10,2)) FROM [Inventory].[dbo].[Suppliers] WITH(NOLOCK) WHERE [ProductCatalogID] = @pSKU AND [UnitCost] != '0' AND [UnitCost] IS NOT NULL)
	  
	 END
	 GOTO ENDALL

FPGetLowestPrice:
	
	BEGIN
	SET @Result = (Select CAST(MIN(IsNULL([UnitCost],999)) AS Decimal(10,2)) FROM [Inventory].[dbo].[Suppliers] WITH(NOLOCK) WHERE [ProductCatalogID] = @pSKU AND [UnitCost] != '0' AND [UnitCost] IS NOT NULL)
	END 
	GOTO ENDALL


GetRESTLowestPrice:
	
	BEGIN
	SET @Result = (Select CAST(MIN([UnitCost]) AS Decimal(10,2)) FROM [Inventory].[dbo].[Suppliers] WITH(NOLOCK) WHERE [ProductCatalogID] = @pSKU AND [UnitCost] != '0' AND [UnitCost] IS NOT NULL)

	END 
	GOTO ENDALL

EndALL:

	-- Add the T-SQL statements to compute the return value here
--	SELECT @Result = @pSKU

	-- Return the result of the function
	RETURN IsNULL(@Result,999)

END
go

