


CREATE PROCEDURE [dbo].[sp_Update_VirtStock_BulbsAndKits]

AS 
BEGIN
Declare @MITSKU	       AS Varchar(10)
Declare @VirtualStock  AS INT

SET @VirtualStock = 0

DECLARE GetItemsInCategory_cursor CURSOR
FOR
--Select all of the projector lamps SKUs
--RPTV Bare Lamp Categories:  '5','6','7','8','9','61'
--FP Bare Lamp Categories:  '15','16','17','18','19','63
--STAGE Bare Lamp Categories:  '88','89','90','91'
--RPTV Housing Categories:  '59'
--FP Housing Categories: '60'

SELECT ID FROM Inventory.dbo.ProductCatalog WITH(NOLOCK) WHERE CategoryID IN (
--RPTV Bare Lamps
'5','6','7','8','9','61',
--FP Bare Lamps
'15','16','17','18','19','63',
--STAGE Bare Lamps
'88','89','90','91',
--RPTV KITS
'59',
--FP KITS
'60'
)


OPEN GetItemsInCategory_cursor
FETCH NEXT FROM GetItemsInCategory_cursor INTO @MITSKU

WHILE @@FETCH_STATUS = 0
BEGIN
	
			-- Query to check seperable quantity for this SKU in cursor
			SELECT @VirtualStock = SUM(GS.GlobalStock) FROM [Inventory].[dbo].[Global_Stocks] AS GS
			INNER JOIN [Inventory].[dbo].[AssemblyDetails] AS AD ON (GS.ProductCatalogID = AD.ProductCatalogId)	
			WHERE AD.SubSKU = @MITSKU  --AND AD3.IsRequired = '1'

	
	UPDATE Inventory.dbo.Global_Stocks with(UPDLOCK) SET VirtualStock = ISNULL(@VirtualStock, 0) WHERE ProductCatalogId = @MITSKU

	PRINT @MITSKU
	PRINT @VirtualStock

SET @VirtualStock = 0


FETCH NEXT FROM GetItemsInCategory_cursor INTO @MITSKU

END

CLOSE GetItemsInCategory_cursor
DEALLOCATE GetItemsInCategory_cursor

END

go

