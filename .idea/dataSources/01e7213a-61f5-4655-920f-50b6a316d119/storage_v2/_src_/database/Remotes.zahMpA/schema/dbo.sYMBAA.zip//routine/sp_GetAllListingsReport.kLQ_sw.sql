-- =============================================
-- Author:		Hubet Cárdenas Isla
-- Create date: 2018-07-30
-- Description:	Get All Listings Report 
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetAllListingsReport] 
	-- Add the parameters for the stored procedure here
	@pOption NVARCHAR(50) = NULL,
	@item_name NVARCHAR(50) = NULL,		
	@item_description NVARCHAR(250) = NULL,		
	@listing_id NVARCHAR(50) = NULL,		
	@seller_sku NVARCHAR(50) = NULL,		
	@price NVARCHAR(50) = NULL,		
	@quantity NVARCHAR(50) = NULL,		
	@open_date NVARCHAR(50) = NULL,		
	@image_url NVARCHAR(50) = NULL,		
	@item_is_marketplace NVARCHAR(50) = NULL,		
	@product_id_type NVARCHAR(50) = NULL,		
	@zshop_shipping_fee NVARCHAR(50) = NULL,		
	@item_note NVARCHAR(50) = NULL,		
	@item_condition NVARCHAR(50) = NULL,		
	@zshop_category1 NVARCHAR(50) = NULL,		
	@zshop_browse_path NVARCHAR(50) = NULL,		
	@zshop_storefront_feature NVARCHAR(50) = NULL,		
	@asin1 NVARCHAR(50) = NULL,		
	@asin2 NVARCHAR(50) = NULL,		
	@asin3 NVARCHAR(50) = NULL,		
	@will_ship_internationally NVARCHAR(50) = NULL,		
	@expedited_shipping NVARCHAR(50) = NULL,		
	@zshop_boldface NVARCHAR(50) = NULL,		
	@product_id NVARCHAR(50) = NULL,		
	@bid_for_featured_placement NVARCHAR(50) = NULL,		
	@add_delete NVARCHAR(50) = NULL,		
	@pending_quantity NVARCHAR(50) = NULL,		
	@fulfillment_channel NVARCHAR(50) = NULL,		
	@merchant_shipping_group NVARCHAR(50) = NULL,
	@status NVARCHAR(50) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @pOption = 'DELETE'
	BEGIN
		TRUNCATE TABLE [dbo].[AmazonAPI_All_Listings_Report_SG]
	END
	ELSE IF @pOption = 'CLEAN'
	BEGIN
		--DELETE A
		--  FROM [AZ].[AmazonAPI_All_Listings_Report] A
		-- INNER JOIN [Inventory].[dbo].[AmazonNukedASINs] N
		--    ON N.[ASIN] = A.[product_id]
		--   AND N.[CountryCode] = 'US'
		SELECT ''
	END
	ELSE IF @pOption = 'INSERT'
	BEGIN
		IF LEN(RTRIM(LTRIM(@seller_sku))) > 0 AND
		   LEN(RTRIM(LTRIM(@product_id))) > 0
		BEGIN
			INSERT INTO [dbo].[AmazonAPI_All_Listings_Report_SG]([item_name]
												   ,[item_description]
												   ,[listing_id]
												   ,[seller_sku]
												   ,[price]
												   ,[quantity]
												   ,[open_date]
												   ,[image_url]
												   ,[item_is_marketplace]
												   ,[product_id_type]
												   ,[zshop_shipping_fee]
												   ,[item_note]
												   ,[item_condition]
												   ,[zshop_category1]
												   ,[zshop_browse_path]
												   ,[zshop_storefront_feature]
												   ,[asin1]
												   ,[asin2]
												   ,[asin3]
												   ,[will_ship_internationally]
												   ,[expedited_shipping]
												   ,[zshop_boldface]
												   ,[product_id]
												   ,[bid_for_featured_placement]
												   ,[add_delete]
												   ,[pending_quantity]
												   ,[fulfillment_channel]
												   ,[merchant_shipping_group]
												   ,[status])
											 VALUES(@item_name,		
													@item_description,		
													@listing_id,		
													@seller_sku,		
													@price,		
													@quantity,		
													@open_date,		
													@image_url,		
													@item_is_marketplace,		
													@product_id_type,		
													@zshop_shipping_fee,		
													@item_note,		
													@item_condition,		
													@zshop_category1,		
													@zshop_browse_path,		
													@zshop_storefront_feature,		
													@asin1,		
													@asin2,		
													@asin3,		
													@will_ship_internationally,		
													@expedited_shipping,		
													@zshop_boldface,		
													@product_id,		
													@bid_for_featured_placement,		
													@add_delete,		
													@pending_quantity,		
													@fulfillment_channel,		
													@merchant_shipping_group,
													@status)
		END
	END
	IF @pOption = 'DELETE_PRODUCTION'
	BEGIN
		DELETE [dbo].[AmazonAPI_All_Listings_Report]
		
		INSERT INTO [dbo].[AmazonAPI_All_Listings_Report]
		SELECT * FROM [dbo].[AmazonAPI_All_Listings_Report_SG]
	END
END
go

