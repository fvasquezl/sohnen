CREATE VIEW [dbo].[_dta_mv_90]  
 AS 
SELECT  [dbo].[Categories].[ID] as _col_1,  [dbo].[Categories].[Name] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[ProductCatalog],  [dbo].[Categories]   WHERE  [dbo].[ProductCatalog].[CategoryID] = [dbo].[Categories].[ID]  GROUP BY  [dbo].[Categories].[ID],  [dbo].[Categories].[Name]
go

