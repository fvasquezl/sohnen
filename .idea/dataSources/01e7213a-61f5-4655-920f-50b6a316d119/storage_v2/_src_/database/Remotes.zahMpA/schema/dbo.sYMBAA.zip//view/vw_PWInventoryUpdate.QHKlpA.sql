CREATE VIEW dbo.vw_PWInventoryUpdate
AS
SELECT        CASE WHEN MM.[IsCN] = 1 THEN REPLACE(MM.[MerchantSKU], 'RMTC', 'SKU') + '-CN' ELSE REPLACE(MM.[MerchantSKU], 'RMTC', 'SKU') END AS sku, MM.ASIN AS [product-id], '1' AS [product-id-type], '' AS price, 
                         '4' AS [minimum-seller-allowed-price], '999' AS [maximum-seller-allowed-price], 
                         (CASE WHEN MM.Condition = 'New' THEN '11' WHEN MM.Condition = 'Used - Like New' THEN '1' WHEN MM.Condition = 'Used - Very Good' THEN '2' WHEN MM.Condition = 'Used - Good' THEN '3' ELSE '11' END) 
                         AS [item-condition], (CASE WHEN MM.[Condition] = 'New' AND MM.[IsCN] = 1 AND (MM.[FulfillmentType] LIKE 'Merchant' OR
                         MM.[IsSnL] = 1) THEN CAST(FLOOR(IsNull([Remotes].[dbo].[fn_GetQtyByScanCode](MM.[SKU], 'CN'), 0) * 0.5) AS NVARCHAR(50)) WHEN MM.[Condition] = 'New' AND MM.[IsCN] = 0 AND (MM.[FulfillmentType] LIKE 'Merchant' OR
                         MM.[IsSnL] = 1) THEN CAST(FLOOR(IsNull([Remotes].[dbo].[fn_GetQtyByScanCode](MM.[SKU], 'NEW'), 0) * 0.5) AS NVARCHAR(50)) WHEN MM.[Condition] LIKE 'Used%' AND (MM.[FulfillmentType] LIKE 'Merchant' OR
                         MM.[IsSnL] = 1) THEN CAST(FLOOR(IsNull([Remotes].[dbo].[fn_GetQtyByScanCode](MM.[SKU], 'USED'), 0) * 0.5) AS NVARCHAR(50)) WHEN MM.[FulfillmentType] = 'Amazon' AND MM.[IsSnL] = 0 THEN '' ELSE '' END) AS quantity, 
                         'a' AS [add-delete], '1' AS [will-ship-internationally], '' AS [expedited-shipping], 'Y' AS [standard-plus], '' AS [item-note], (CASE WHEN MM.[IsSnL] = 1 THEN 'DEFAULT' WHEN MM.[FulfillmentType] = 'Merchant' AND 
                         (MM.[IsSnL] = 0 OR
                         MM.[IsSnL] IS NULL) THEN 'DEFAULT' WHEN MM.[FulfillmentType] = 'Amazon' AND (MM.[IsSnL] = 0 OR
                         MM.[IsSnL] IS NULL) THEN 'AMAZON_NA' ELSE 'DEFAULT' END) AS [fulfillement-center-id], 'A_GEN_TAX' AS [product-tax-code], (CASE WHEN MM.[FulfillmentType] = 'Merchant' OR
                         MM.[IsSnL] = 1 THEN '1' ELSE '' END) AS [leadtime-to-ship], (CASE WHEN MM.[IsSnL] = 1 THEN 'PrimeSnL' WHEN MM.[FulfillmentType] = 'Merchant' AND 
                         MM.[IsSnL] = 0 THEN 'RushDelivery' WHEN MM.[FulfillmentType] = 'Amazon' AND MM.[IsSnL] = 0 THEN '' ELSE 'RushDelivery' END) AS merchant_shipping_group_name, 
                         (CASE WHEN SKUD.[CategoryID] LIKE '11%' THEN 'Yes' ELSE 'No' END) AS batteries_required, (CASE WHEN SKUD.[CategoryID] LIKE '11%' THEN 'Yes' ELSE 'No' END) AS are_batteries_included, 
                         'not_applicable' AS supplier_declared_dg_hz_regulation1
FROM            dbo.MarketplaceMapping AS MM WITH (NOLOCK) LEFT OUTER JOIN
                         dbo.SKUData AS SKUD WITH (NOLOCK) ON MM.SKU = SKUD.SKU
WHERE        (MM.FulfillmentType = 'Amazon') OR
                         (MM.FulfillmentType = 'Merchant')
go

