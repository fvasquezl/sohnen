-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 01 JAN 2016
-- Description:	Consignment Stocks at date
-- =============================================
CREATE FUNCTION [dbo].[fn_BinsConsignment_Sku_Stock_At_Date]
(
	@pSKU int, @pUserID int, @pDate Datetime
)
RETURNS int	
AS
BEGIN
	DECLARE @ResultVar int;
	DECLARE @ins int;
	DECLARE @outs int;
	
	

	SELECT @ins = SUM(BH.Qty) 
	FROM Inventory.dbo.Bins_History AS BH (NOLOCK)
	 WHERE (BH.Product_Catalog_ID = @pSKU) and (BH.Stamp <= @pDate) and (BH.Flow = 1)
	 AND (BH.[Bin_ID] IN (SELECT BC.[Bin_ID] FROM [Inventory].[dbo].[BinConsignment] AS BC (NOLOCK) WHERE BC.[UserID] = @pUserID));
	 

	 IF @ins is null
	BEGIN
		SET @ins = 0;
	END

	SELECT @outs = SUM(BH.Qty) 
	FROM Inventory.dbo.Bins_History AS BH (NOLOCK)
	 WHERE (BH.Product_Catalog_ID = @pSKU) and (BH.Stamp <= @pDate)and (BH.Flow = 2)
	 AND (BH.[Bin_ID] IN (SELECT BC.[Bin_ID] FROM [Inventory].[dbo].[BinConsignment] AS BC (NOLOCK) WHERE BC.[UserID] = @pUserID));

	  IF @outs is null
	BEGIN
		SET @outs = 0;
	END

	SET @ResultVar = @ins - @outs;

	IF @ResultVar is null
	BEGIN
		SET @ResultVar = 0;
	END
	-- Return the result of the function
	RETURN @ResultVar; 

END
go

