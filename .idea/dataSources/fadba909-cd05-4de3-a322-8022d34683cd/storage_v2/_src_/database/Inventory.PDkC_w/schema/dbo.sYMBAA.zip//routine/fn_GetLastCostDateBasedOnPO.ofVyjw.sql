-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: <Create Date,,>
-- Description:	Get Last Avg Date by SKU
-- =============================================
CREATE FUNCTION fn_GetLastCostDateBasedOnPO
(	
	@SKU INT
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT TOP 1 POD.SKU, POD.PODate, 
	(CASE WHEN ISNULL(POD.UnitCost,'') = '' 
		THEN (SELECT TOP 1 UnitCost FROM Inventory.dbo.PurchaseOrderData (NOLOCK) WHERE SKU = POD.SKU AND ISNULL(UnitCost,'') <> '' ORDER BY POD.PODate DESC)
		ELSE POD.UnitCost
	END) AS UnitCost
	FROM Inventory.dbo.PurchaseOrderData (NOLOCK) POD
	WHERE POD.SKU = @SKU
	ORDER BY POD.PODate DESC
)
go

