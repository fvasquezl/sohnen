CREATE VIEW dbo.[FP-Philips-SKU-FINALAmir]
AS
SELECT        C.ProductCatalogID AS [LAMP+ENC], AssyEncGS.TotalStock AS [LAMP+ENC - QOH+VQOH], C.Manufacturer, C.PartNumber, Asy.SubSKU AS Bulb, 
                         AsyGS.TotalStock AS [Bulb QOH+VQOH], AsyEnc.SubSKU AS Enc, AssyEncGS.TotalStock AS [Enc QOH+VQOH]
FROM            dbo.Compatibility AS C RIGHT OUTER JOIN
                         dbo.ProductCatalog AS AsyEncPC RIGHT OUTER JOIN
                         dbo.AssemblyDetails AS AsyEnc ON AsyEncPC.ID = AsyEnc.SubSKU LEFT OUTER JOIN
                         dbo.Global_Stocks AS AssyEncGS ON AsyEnc.SubSKU = AssyEncGS.ProductCatalogId RIGHT OUTER JOIN
                         dbo.ProductCatalog AS PC ON AsyEnc.ProductCatalogID = PC.ID LEFT OUTER JOIN
                         dbo.Categories AS CAT ON PC.CategoryID = CAT.ID ON C.ProductCatalogID = PC.ID LEFT OUTER JOIN
                         dbo.Global_Stocks AS AsyGS RIGHT OUTER JOIN
                         dbo.AssemblyDetails AS Asy ON AsyGS.ProductCatalogId = Asy.SubSKU ON PC.ID = Asy.ProductCatalogID LEFT OUTER JOIN
                         dbo.ProductCatalog AS AsyPC INNER JOIN
                         dbo.Global_Stocks ON AsyPC.ID = dbo.Global_Stocks.id ON Asy.SubSKU = AsyPC.ID
WHERE        (Asy.SubSKU LIKE '103%' OR
                         Asy.SubSKU LIKE '101%') AND (CAT.ID = '20') AND (AsyEncPC.CategoryID = '60')
go

