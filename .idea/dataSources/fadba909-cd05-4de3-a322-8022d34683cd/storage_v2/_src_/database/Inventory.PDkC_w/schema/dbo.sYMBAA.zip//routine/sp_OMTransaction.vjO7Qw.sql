-- =============================================
-- Author:		Hubet Cárdenas Isla
-- Create date: 2017-11-06
-- Description:	Get OM Transaction
-- =============================================
CREATE PROCEDURE [dbo].[sp_OMTransaction]
	-- Add the parameters for the stored procedure here
	@pOption NVARCHAR(50) = NULL, 
	@pTransactionID NVARCHAR(50) = NULL
AS
	DECLARE @iTotalQty INT,
		    @iTotalOrders INT,
			@iTotalItems INT
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @pOption = 'ONSTOCK'
	BEGIN
		--Total Qty
		SELECT @iTotalQty = SUM(TD.[RequestedQty])
		  FROM [WebStation].[OE].[TransactionDetail] TD WITH(NOLOCK)
		 INNER JOIN [WebStation].[OE].[Transactions] T WITH(NOLOCK)
				 ON T.[TransactionID] = TD.[TransactionID]
			    AND T.[isActive] = 1
		  LEFT OUTER JOIN [Inventory].[dbo].[Users] U WITH(NOLOCK)
					   ON U.[usr] = T.[CreateUser]
		 WHERE [Bin_ID] IS NOT NULL
		   AND CONVERT(NVARCHAR, TD.[TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
														   ELSE CONVERT(NVARCHAR, TD.[TransactionID])
													   END
		
		--Total Orders
		SELECT @iTotalOrders = COUNT(*)
		  FROM (SELECT WorkOrderID
				  FROM [WebStation].[OE].[WorkOrders] WITH(NOLOCK)
				 WHERE CONVERT(NVARCHAR, [TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
																ELSE CONVERT(NVARCHAR, [TransactionID])
													        END
				 GROUP BY WorkOrderID) TMP
		
		--Total Items:
		SELECT @iTotalItems = SUM(QtyOrdered)
		FROM [WebStation].[OE].[WorkOrders] W WITH(NOLOCK)
		LEFT OUTER JOIN [WebStation].[OE].[WorkOrderDetail] D WITH(NOLOCK)
		ON D.WorkOrderID = W.WorkOrderID
		 WHERE CONVERT(NVARCHAR, [TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
													    ELSE CONVERT(NVARCHAR, [TransactionID])
													END
		
		SELECT MAIN.[SKU],
			   MAIN.[Bin_ID],
			   MAIN.[RequestedQuantity],
			   MAIN.[TransactionID],
			   MAIN.[CreateUser],
			   MAIN.[CreateDate],
			   MAIN.[fullname],
			   @iTotalQty TOTAL_QTY,
			   @iTotalOrders TOTAL_ORDERS,
			   @iTotalItems TOTAL_ITEMS,
			   @pOption [OPTION]
		  FROM (SELECT TD.[SKU],
					   TD.[Bin_ID],
					   SUM(TD.[RequestedQty]) AS [RequestedQuantity],
					   TD.[TransactionID],
					   T.[CreateUser],
					   T.[CreateDate],
					   U.[fullname]
				  FROM [WebStation].[OE].[TransactionDetail] TD WITH(NOLOCK)
				 INNER JOIN [WebStation].[OE].[Transactions] T WITH(NOLOCK)
						 ON T.[TransactionID] = TD.[TransactionID]
						AND T.[isActive] = 1
				  LEFT OUTER JOIN [Inventory].[dbo].[Users] U WITH(NOLOCK)
							   ON U.[usr] = T.[CreateUser]
				 WHERE [Bin_ID] IS NOT NULL
				   AND CONVERT(NVARCHAR, TD.[TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
																   ELSE CONVERT(NVARCHAR, TD.[TransactionID])
													           END
				 GROUP BY TD.[SKU], TD.[Bin_ID], T.[CreateUser], TD.[TransactionID], T.[CreateDate], U.[fullname]) MAIN
		ORDER BY MAIN.Bin_ID ASC
	END
	ELSE IF @pOption = 'OUTSTOCK'
	BEGIN
		--Total Qty
		SELECT @iTotalQty = SUM(TD.[RequestedQty])
		  FROM [WebStation].[OE].[TransactionDetail] TD WITH(NOLOCK)
		 INNER JOIN [WebStation].[OE].[Transactions] T WITH(NOLOCK)
				 ON T.[TransactionID] = TD.[TransactionID]
			    AND T.[isActive] = 1
		  LEFT OUTER JOIN [Inventory].[dbo].[Users] U WITH(NOLOCK)
					   ON U.[usr] = T.[CreateUser]
		 WHERE [Bin_ID] IS NULL
		   AND CONVERT(NVARCHAR, TD.[TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
														   ELSE CONVERT(NVARCHAR, TD.[TransactionID])
													   END
		
		
		--Total Orders
		SELECT @iTotalOrders = COUNT(*)
		  FROM (SELECT WorkOrderID
				  FROM [WebStation].[OE].[WorkOrders] WITH(NOLOCK)
				 WHERE CONVERT(NVARCHAR, [TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
																ELSE CONVERT(NVARCHAR, [TransactionID])
													        END
				 GROUP BY WorkOrderID) TMP
		
		--Total Items:
		SELECT @iTotalItems = SUM(QtyOrdered)
		FROM [WebStation].[OE].[WorkOrders] W WITH(NOLOCK)
		LEFT OUTER JOIN [WebStation].[OE].[WorkOrderDetail] D WITH(NOLOCK)
		ON D.WorkOrderID = W.WorkOrderID
		 WHERE CONVERT(NVARCHAR, [TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
													    ELSE CONVERT(NVARCHAR, [TransactionID])
													END
		
		SELECT MAIN.[SKU],
			   MAIN.[Bin_ID],
			   SUM(MAIN.[RequestedQty]) AS [RequestedQuantity],
			   MAIN.[TransactionID],
			   MAIN.[CreateUser],
			   MAIN.[CreateDate],
			   MAIN.[fullname],
			   @iTotalQty TOTAL_QTY,
			   @iTotalOrders TOTAL_ORDERS,
			   @iTotalItems TOTAL_ITEMS,
			   @pOption [OPTION]
		  FROM (SELECT TD.[SKU],
						(CASE WHEN ISNULL(TD.[Bin_ID], '') = '' THEN 
								CONVERT(NVARCHAR, (SELECT [Inventory].[dbo].[fn_get_lampsku](CAST(IIF(ISNUMERIC(TD.[SKU]) = 1, TD.[SKU], 0) as int))))
								 + '-' +
								 CONVERT(NVARCHAR, 
									CONVERT(INT, (SELECT [Inventory].[dbo].[fn_Get_Global_Stock](CAST(IIF(ISNUMERIC((SELECT [Inventory].[dbo].[fn_get_lampsku](cast(iif(isnumeric(TD.[SKU]) = 1, TD.[SKU], 0) as int)))) = 1, (SELECT [Inventory].[dbo].[fn_get_lampsku](cast(iif(isnumeric(TD.[SKU]) = 1, TD.[SKU], 0) as int))), 0) as int))) )
								 )
								 + ',' +
								 CONVERT(NVARCHAR, (SELECT [Inventory].[dbo].[fn_get_kitsku](CAST(IIF(ISNUMERIC(TD.[SKU]) = 1, TD.[SKU], 0) as int))))
								 + '-' +
								 CONVERT(NVARCHAR, 
									CONVERT(INT, (SELECT [Inventory].[dbo].[fn_Get_Global_Stock](CAST(IIF(ISNUMERIC((SELECT [Inventory].[dbo].[fn_get_kitsku](cast(iif(isnumeric(TD.[SKU]) = 1, TD.[SKU], 0) as int)))) = 1, (SELECT [Inventory].[dbo].[fn_get_kitsku](cast(iif(isnumeric(TD.[SKU]) = 1, TD.[SKU], 0) as int))), 0) as int))) )
								 )
							 ELSE TD.Bin_ID
						END) AS [Bin_ID],

					  -- (CASE WHEN ISNULL(TD.Bin_ID,'') = '' THEN CONVERT(NVARCHAR, (SELECT [Inventory].[dbo].[fn_GetLampKitGlobalSKU](CAST(IIF(ISNUMERIC(TD.[SKU]) = 1, TD.[SKU], 0) as int))))
							--ELSE TD.Bin_ID
					  --  END) AS [Bin_ID],
					   TD.[RequestedQty],
					   TD.[TransactionID], T.[CreateUser], T.[CreateDate], U.[fullname]
				  FROM [WebStation].[OE].[TransactionDetail] TD WITH(NOLOCK)
				 INNER JOIN [WebStation].[OE].[Transactions] T WITH(NOLOCK)
						 ON T.[TransactionID] = TD.[TransactionID]
						AND T.[isActive] = 1
				  LEFT OUTER JOIN [Inventory].[dbo].[Users] U WITH(NOLOCK)
							   ON U.[usr] = T.[CreateUser]
				 WHERE [Bin_ID] IS NULL
				   AND CONVERT(NVARCHAR, TD.[TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
																   ELSE CONVERT(NVARCHAR, TD.[TransactionID])
													           END
				 ) MAIN
				 GROUP BY [SKU], [Bin_ID], [CreateUser], [TransactionID], [CreateDate], [fullname]
	END
	ELSE IF @pOption = 'MAIN_REPORT'
	BEGIN
		SELECT [TransactionID], 
			   [CreateUser],
			   [CreateDate],
			   CASE WHEN [Status] = 1 THEN 'In progress...' ELSE 'Complete' END AS [STATUS],
			   CASE WHEN [Status] = 1 THEN '\library\images\cancel_Blue.png' ELSE '\library\images\icnPdf_Blue.png' END AS [image],
			   CONVERT(INT, ISNULL([Status], 0)) AS isActive
		  FROM [WebStation].[OE].[Transactions] TD WITH(NOLOCK)
		 WHERE [isActive] = 1
		   AND CONVERT(NVARCHAR, TD.[TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
														   ELSE CONVERT(NVARCHAR, TD.[TransactionID])
													   END
	END
	ELSE IF @pOption = 'DETAIL_REPORT'
	BEGIN
		SELECT  [WorkOrderID]
			   ,[SKU]
			   ,[RequestedQty]
			   ,[Bin_ID]
		  FROM [WebStation].[OE].[TransactionDetail] TD WITH(NOLOCK)
		 WHERE CONVERT(NVARCHAR, TD.[TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
														   ELSE CONVERT(NVARCHAR, TD.[TransactionID])
													   END
	END
END
/*
EXEC [Inventory].[dbo].[sp_OMTransaction] @pOption = 'ONSTOCK', @pTransactionID = '1000000'
EXEC [Inventory].[dbo].[sp_OMTransaction] @pOption = 'OUTSTOCK', @pTransactionID = '1000000'
EXEC [Inventory].[dbo].[sp_OMTransaction] @pOption = 'MAIN_REPORT', @pTransactionID = '1000000'
EXEC [Inventory].[dbo].[sp_OMTransaction] @pOption = 'DETAIL_REPORT', @pTransactionID = '1000000'
*/
go

