-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-12-05
-- Description:	Get OutStock Print Label by Transaction ID
-- =============================================
CREATE PROCEDURE [dbo].[sp_FlexOutStockTransaction]
	@TransactionID NVARCHAR(1500)
AS
BEGIN
	DECLARE @CreateDate DATETIME
	SET NOCOUNT ON;

	SET @CreateDate = (SELECT MAX(CreateDate) FROM [WebStation].[FX].[Transaction] WITH(NOLOCK) WHERE CONVERT(NVARCHAR, [TransactionID]) IN (SELECT Item FROM Inventory.dbo.fnSplit(@TransactionID,',')))

    SELECT TD.[SKU], CONVERT(NVARCHAR,[Inventory].[dbo].[fn_get_lampsku](CAST(IIF(ISNUMERIC(TD.[SKU]) = 1, TD.[SKU], 0) as int))) AS Lamp,
		--CASE WHEN PC.[CategoryID] NOT IN(10,14) THEN 
		CONVERT(NVARCHAR,Inventory.[dbo].[fn_get_kitsku](CAST(IIF(ISNUMERIC(TD.[SKU]) = 1, TD.[SKU], 0) as int))) 
		--ELSE '' END 
		AS Kit,
		SUM(TD.[RequestedQuantity]) AS RequestedQuantity, @CreateDate AS CreateDate,
		RTRIM(LTRIM(ISNULL(PC.ProductAlert,''))) AS ProductAlert
	FROM [WebStation].[FX].[TransactionDetail] TD WITH(NOLOCK)
	INNER JOIN [WebStation].[FX].[Transaction] T WITH(NOLOCK)
	ON T.[TransactionID] = TD.[TransactionID] AND T.[isActive] = 1
	INNER JOIN Inventory.dbo.ProductCatalog PC
	ON CONVERT(NVARCHAR,PC.ID) = TD.[SKU]
	WHERE TD.[Bin_ID] IS NULL AND CONVERT(NVARCHAR, TD.[TransactionID]) IN (SELECT Item FROM Inventory.dbo.fnSplit(@TransactionID,','))
	GROUP BY TD.[SKU], PC.CategoryID, PC.ProductAlert
	ORDER BY PC.CategoryID

END
go

