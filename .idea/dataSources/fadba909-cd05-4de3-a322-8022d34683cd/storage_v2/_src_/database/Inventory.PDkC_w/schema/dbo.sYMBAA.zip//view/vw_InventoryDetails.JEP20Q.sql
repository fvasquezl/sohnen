CREATE VIEW dbo.vw_InventoryDetails
AS
SELECT     a.Origin, a.Destination, a.UserID, a.Flow, b.InventoryAdjustmentsID, b.ProductCatalogID, b.Quantity, dbo.fn_GetProductName(b.ProductCatalogID) AS ProductName, 
                      dbo.fn_GetUserName(a.UserID) AS UserName, dbo.fn_GetAccountName(a.Origin) AS OriginName, dbo.fn_GetAccountName(a.Destination) AS DestinationName, a.Date, 
                      a.Comments
FROM         dbo.InventoryAdjustments AS a INNER JOIN
                      dbo.InventoryAdjustmentDetails AS b ON a.ID = b.InventoryAdjustmentsID
go

