-- =============================================
-- Author:		<AMIR TAFRESHI>
-- Create date: <1-2-2015>
-- Description:	<>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetRecommendedOrderQtyAsListforInventoryAnalizer]
(	
	-- Add the parameters for the function here
		@pSKU NVARCHAR(MAX),	@pDaysToCalculate INT
)

RETURNS TABLE 
AS
RETURN 
(
	-- Get the recommended order quantity based on last 15 days sales from Order Manager
	SELECT DISTINCT '15' AS DayCount,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3))
FROM [OrderManager].[dbo].[Order Details] AS OD2AA 
LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  
where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-15) AND GetDate()), 0) / 15) * @pDaysToCalculate) as Decimal(10,1))) AS 'Calc'

  FROM [OrderManager].[dbo].[Order Details] AS OD
  LEFT OUTER JOIN [Inventory].dbo.[ProductCatalog] AS PC ON (OD.SKU = Cast(PC.ID AS NVARCHAR(MAX)))
  LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PC.ID = GS.ProductCatalogId)
  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O ON (OD.OrderNumber = O.OrderNumber)
  where OD.Adjustment = 0 AND OD.SKU = @pSKU

Union

	-- Get the recommended order quantity based on last 15 days sales from Order Manager
SELECT DISTINCT '30' AS DayCount,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3)) 
FROM [OrderManager].[dbo].[Order Details] AS OD2AA 
LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  
where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-30) AND GetDate()), 0) / 30) * @pDaysToCalculate) as Decimal(10,1))) AS 'Calc'

  FROM [OrderManager].[dbo].[Order Details] AS OD
  LEFT OUTER JOIN [Inventory].dbo.[ProductCatalog] AS PC ON (OD.SKU = Cast(PC.ID AS NVARCHAR(MAX)))
  LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PC.ID = GS.ProductCatalogId)
  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O ON (OD.OrderNumber = O.OrderNumber)
  where OD.Adjustment = 0 AND OD.SKU = @pSKU

Union

	-- Get the recommended order quantity based on last 15 days sales from Order Manager
SELECT DISTINCT '60' AS DayCount,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3)) 
FROM [OrderManager].[dbo].[Order Details] AS OD2AA 
LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  
where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-60) AND GetDate()), 0) / 60) * @pDaysToCalculate) as Decimal(10,1)))  AS 'Calc'

  FROM [OrderManager].[dbo].[Order Details] AS OD
  LEFT OUTER JOIN [Inventory].dbo.[ProductCatalog] AS PC ON (OD.SKU = Cast(PC.ID AS NVARCHAR(MAX)))
  LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PC.ID = GS.ProductCatalogId)
  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O ON (OD.OrderNumber = O.OrderNumber)
  where OD.Adjustment = 0 AND OD.SKU = @pSKU

Union

	-- Get the recommended order quantity based on last 15 days sales from Order Manager
SELECT DISTINCT '90' AS DayCount,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3)) 
FROM [OrderManager].[dbo].[Order Details] AS OD2AA 
LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  
where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-90) AND GetDate()), 0) / 90) * @pDaysToCalculate) as Decimal(10,1))) AS 'Calc'

  FROM [OrderManager].[dbo].[Order Details] AS OD
  LEFT OUTER JOIN [Inventory].dbo.[ProductCatalog] AS PC ON (OD.SKU = Cast(PC.ID AS NVARCHAR(MAX)))
  LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PC.ID = GS.ProductCatalogId)
  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O ON (OD.OrderNumber = O.OrderNumber)
  where OD.Adjustment = 0 AND OD.SKU = @pSKU

Union

	-- Get the recommended order quantity based on last 15 days sales from Order Manager
SELECT DISTINCT '180' AS DayCount,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3))  
FROM [OrderManager].[dbo].[Order Details] AS OD2AA 
LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  
where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-180) AND GetDate()), 0) / 180) * @pDaysToCalculate) as Decimal(10,1))) AS 'Calc'

  FROM [OrderManager].[dbo].[Order Details] AS OD
  LEFT OUTER JOIN [Inventory].dbo.[ProductCatalog] AS PC ON (OD.SKU = Cast(PC.ID AS NVARCHAR(MAX)))
  LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PC.ID = GS.ProductCatalogId)
  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O ON (OD.OrderNumber = O.OrderNumber)
  where OD.Adjustment = 0 AND OD.SKU = @pSKU
  

  
)
go

