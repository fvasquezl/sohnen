-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 4-25-2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_NukeOMandPortalOrder] 
	-- Add the parameters for the stored procedure here
	@OrderNumber int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Delete eBulb.
		DELETE FROM [Resellers].[dbo].[ResellerOrders] WHERE CustomerID = 1332724 AND OrderNumber IN (SELECT SourceOrderID FROM OrderManager.dbo.Orders WHERE OrderNumber = @OrderNumber)
    -- Insert statements for procedure here
		DELETE RPO FROM [Inventory].[dbo].[ResellerPortalOrder] AS RPO
		LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O ON (O.[SourceOrderID] = CONVERT(NVARCHAR,[WebOrderNumber]))
		 Where O.[OrderNumber] = @OrderNumber

		DELETE RPOD FROM [Inventory].[dbo].[ResellerPortalOrderDetails]  AS RPOD
		LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O ON (O.[SourceOrderID] = CONVERT(NVARCHAR,[WebOrderNumber]))
		 Where O.[OrderNumber] = @OrderNumber

		DELETE FROM [OrderManager].[dbo].[Orders] WHERE [OrderNumber] = @OrderNumber
		DELETE FROM [OrderManager].[dbo].[Order Details] WHERE [OrderNumber] = @OrderNumber
		DELETE FROM [OrderManager].[dbo].[Transactions] WHERE [OrderNumber] = @OrderNumber
		DELETE FROM [OrderManager].[dbo].[Tracking] WHERE [NumericKey] = @OrderNumber
		DELETE FROM [OrderManager].[dbo].[Notes] WHERE NumericKey = @OrderNumber
END

go

