-- =============================================
-- Author:		Luis Bautista
-- Create date: JUL_03 2014
-- Description:	Retrive the order elements to be processed 
-- =============================================
CREATE PROCEDURE [dbo].[sp_Bin_Get_Order]
	 @pOrderNum int
AS
BEGIN
SET FMTONLY OFF

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
IF OBJECT_ID('tempdb..#temporder') IS NOT NULL
BEGIN
    DROP TABLE #temporder
END

 
 
create table #temporder (sku varchar(20), QuantityOrdered int);

insert into #temporder
SELECT   sku
		, sum(QuantityOrdered) as QuantityOrdered
	
  FROM        OrderManager.dbo.[Order Details]  
      
    WHERE(IsNumeric(SKU) = 1) 
                  AND (LEN(SKU) > 5)
                  AND (OrderNumber = @pOrderNum) 
          GROUP BY SKU
          order by sku;
       
       

 
 SELECT a.sku
		, cast(a.QuantityOrdered as CHAR(10)) as QuantityOrdered 
		, '' as QtyRemoved
		,b.Bin_Id 
		,b.Counter as QtyInBin
		, 1 as active
  FROM #temporder a 
		LEFT  OUTER JOIN Inventory.dbo.Bin_Content b
		ON a.sku = b.ProductCatalog_Id
   WHERE ((substring(b.Bin_Id,1,2) <> 'TM' )
		AND (substring(b.Bin_Id,1,2) <> 'TR' )
		AND (substring(b.Bin_Id,1,2) <> 'DF' )
		AND (inventory.dbo.fn_Get_Bin_WarehouseID(b.Bin_Id) <> 'DF'))
		OR
		(
			b.Bin_Id is null
		)
  ORDER by a.sku, b.Counter DESC, b.Bin_Id ASC;
 
 
END
go

