CREATE VIEW [dbo]._dta_mv_125   AS SELECT  [dbo].[ProductCatalog].[CategoryID] as _col_1,  [dbo].[ProductCatalog].[ID] as _col_2,  [dbo].[Global_Stocks].[TotalStock] as _col_3,  [dbo].[Global_Stocks].[id] as _col_4 FROM  [dbo].[ProductCatalog],  [dbo].[Global_Stocks]   WHERE  [dbo].[ProductCatalog].[ID] = [dbo].[Global_Stocks].[ProductCatalogId]
go

