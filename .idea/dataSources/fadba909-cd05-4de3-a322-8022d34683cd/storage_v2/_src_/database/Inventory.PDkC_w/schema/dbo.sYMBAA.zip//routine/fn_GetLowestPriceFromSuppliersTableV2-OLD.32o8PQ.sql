-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 12-6-2014
-- Description:	Get Lowest Price based on category from the supplier Views
-- =============================================
CREATE FUNCTION [dbo].[fn_GetLowestPriceFromSuppliersTableV2] 
(
	-- Add the parameters for the function here
	@pSKU int
)
RETURNS @Result TABLE (Supplier NVARCHAR(MAX),Price DECIMAL(10,2))
AS
BEGIN
	

	IF (Select CategoryID FROM [Inventory].[dbo].[ProductCatalog] WHERE ID = @pSKU) = '24' GOTO FPGetLowestPrice
	IF (Select CategoryID FROM [Inventory].[dbo].[ProductCatalog] WHERE ID = @pSKU) = '60' GOTO HousingGetLowestPrice


HousingGetLowestPrice:
	
	BEGIN
	INSERT INTO @Result
	SELECT TOP(1) LCT.Supplier AS 'Supplier', LCT.Price AS 'Price' FROM (
	SELECT DISTINCT 'Moldgate' AS 'Supplier', FPHVCI.[MoldGateCost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[MoldGateCost] > 0 UNION ALL
	SELECT DISTINCT 'GrandBulb' AS 'Supplier', FPHVCI.[GrandBulbCost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[GrandBulbCost] > 0 UNION ALL
	SELECT DISTINCT 'MITech' AS 'Supplier', FPHVCI.[MICost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[MICost] > 0 UNION ALL
	SELECT DISTINCT 'SouthernTech' AS 'Supplier', FPHVCI.[SouthernTechCost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[SouthernTechCost] > 0 UNION ALL
	SELECT DISTINCT 'KW' AS 'Supplier', FPHVCI.[KWCost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[KWCost] > 0 UNION ALL
	SELECT DISTINCT 'Leader' AS 'Supplier', FPHVCI.[LeaderCost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[LeaderCost] > 0 UNION ALL
	SELECT DISTINCT 'Yita' AS 'Supplier', FPHVCI.[YitaCost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[YitaCost] > 0 UNION ALL
	SELECT DISTINCT 'FYV' AS 'Supplier', FPHVCI.[FYVCost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[FYVCost] > 0 UNION ALL
	SELECT DISTINCT 'LampsChoice' AS 'Supplier', FPHVCI.[LampsChoiceCost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[LampsChoiceCost] > 0 UNION ALL
	SELECT DISTINCT 'OnlyLamp' AS 'Supplier', FPHVCI.[OnlyLampCost] AS 'Price' FROM [Inventory].[dbo].[FP-Housing-Vendor-CostInfo] AS FPHVCI (NOLOCK) WHERE FPHVCI.MITSKU = @pSKU AND FPHVCI.[OnlyLampCost] > 0
	) AS LCT
	ORDER BY Price ASC
	 
	 END
	 GOTO ENDALL

FPGetLowestPrice:
	
	BEGIN
	INSERT INTO @Result
	SELECT TOP(1) LCT.Supplier AS 'Supplier', LCT.Price AS 'Price' FROM (
	SELECT DISTINCT 'MITech' AS 'Supplier', FPGVCI.[MiTechCost] AS 'Price' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] AS FPGVCI (NOLOCK) WHERE FPGVCI.ID = @pSKU AND FPGVCI.[MiTechCost] > 0 UNION ALL
	SELECT DISTINCT 'Arclite' AS 'Supplier', FPGVCI.[ArcLiteUnitCost] AS 'Price' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] AS FPGVCI (NOLOCK) WHERE FPGVCI.ID = @pSKU AND FPGVCI.[ArcLiteUnitCost] > 0 UNION ALL
	SELECT DISTINCT 'Glory' AS 'Supplier', FPGVCI.[GloryUnitCost] AS 'Price' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] AS FPGVCI (NOLOCK) WHERE FPGVCI.ID = @pSKU AND FPGVCI.[GloryUnitCost] > 0 UNION ALL
	SELECT DISTINCT 'CnLamp' AS 'Supplier', FPGVCI.[ClpUnitCost] AS 'Price' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] AS FPGVCI (NOLOCK) WHERE FPGVCI.ID = @pSKU AND FPGVCI.[ClpUnitCost] > 0 UNION ALL
	SELECT DISTINCT 'GrandBulb' AS 'Supplier', FPGVCI.[GrandBulbsCost] AS 'Price' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] AS FPGVCI (NOLOCK) WHERE FPGVCI.ID = @pSKU AND FPGVCI.[GrandBulbsCost] > 0 UNION ALL
	SELECT DISTINCT 'Leader' AS 'Supplier', FPGVCI.[LeaderCoCost] AS 'Price' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] AS FPGVCI (NOLOCK) WHERE FPGVCI.ID = @pSKU AND FPGVCI.[LeaderCoCost] > 0 UNION ALL
	SELECT DISTINCT 'Yita' AS 'Supplier', FPGVCI.[YitaCost] AS 'Price' FROM [Inventory].[dbo].[FP-Generic-Vendor-CostInfo] AS FPGVCI (NOLOCK) WHERE FPGVCI.ID = @pSKU AND FPGVCI.[YitaCost] > 0
	) AS LCT
	ORDER BY Price ASC
	
	END 
	GOTO ENDALL


EndALL:

	RETURN;

END
go

