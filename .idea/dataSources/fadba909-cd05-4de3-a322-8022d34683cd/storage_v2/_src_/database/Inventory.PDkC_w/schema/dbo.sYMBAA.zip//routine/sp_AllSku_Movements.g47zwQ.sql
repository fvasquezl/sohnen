-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_AllSku_Movements]
AS
BEGIN
	SELECT Product_Catalog_ID, Stamp, Bin_Id,  Qty, CASE Flow when 1 then 'IN' WHEN 2 THEN 'OUT'	END as FlowCaption, ScanCode , Inventory.dbo.fn_GetUserName(User_Id) as UserName  FROM Inventory.dbo.Bins_History a   WHERE   (Stamp between '2015-10-5 00:00:00' AND '2016-3-28 23:59:59') AND (Bin_ID like '%GH%') AND ([ScanCode]  LIKE '%1%') Order By Stamp
END
go

