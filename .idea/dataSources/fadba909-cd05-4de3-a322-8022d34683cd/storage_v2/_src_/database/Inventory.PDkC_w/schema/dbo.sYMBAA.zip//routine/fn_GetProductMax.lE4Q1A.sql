-- =============================================
-- Author:		Luis Alberto Bautista Gallardo for MI Technologies, Inc.
-- Create date: NOV-17-2010
-- Description:	Return a integer values which represent the maximun inventory stock
-- =============================================
CREATE FUNCTION [dbo].[fn_GetProductMax]
(
	-- Add the parameters for the function here
	@ProductCatalogID int
)
RETURNS numeric(12,2)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Qty numeric (12,2)

	-- Add the T-SQL statements to compute the return value here
	select @Qty =  a.InventoryMax from Inventory.dbo.ProductCatalog a
	where a.ID = @ProductCatalogID

	-- Return the result of the function
	RETURN (@qty)

END
go

