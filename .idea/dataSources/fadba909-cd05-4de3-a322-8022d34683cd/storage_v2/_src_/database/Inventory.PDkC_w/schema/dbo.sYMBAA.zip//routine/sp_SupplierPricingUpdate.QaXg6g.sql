-- =============================================
-- Author:		Jonathan Amezcua
-- Create date: 2018-06-05
-- Description:	Updates unit cost on dbo.Suppliers
-- =============================================
CREATE PROCEDURE [dbo].[sp_SupplierPricingUpdate] 
	@SupplierID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	UPDATE S
		SET S.UnitCost = SP.UnitCost
	FROM Inventory.dbo.Suppliers AS S
	INNER JOIN Inventory.dbo.BulkSupplierPricing AS SP
		ON S.ProductCatalogId = SP.MITSKU
	Where S.SupplierID = @SupplierID

END
go

