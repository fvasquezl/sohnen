-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-11-10
-- Description:	Get Kit for Assembly
-- =============================================
CREATE FUNCTION [dbo].[fn_get_kitsku]
(	
	@pSKU INT
)
RETURNS INT
AS
BEGIN
	DECLARE @ResultVar INT

	SET @ResultVar  = (SELECT TOP 1 ZASSY.SubSKU 
						 FROM [Inventory].[dbo].[AssemblyDetails] ZASSY (NOLOCK)
                         LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] ZPC (NOLOCK)
						              ON (ZASSY.ProductCatalogID = ZPC.ID)
                         LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] QPC (NOLOCK)
						              ON (ZASSY.SubSKU = QPC.ID)                        
                        WHERE (QPC.CategoryID IN (59,60))--(QPC.CategoryID NOT IN (5,9,15,19)) 
						  AND (ZASSY.ProductCatalogID = @pSKU) 
                       )
	RETURN @ResultVar
END
go

