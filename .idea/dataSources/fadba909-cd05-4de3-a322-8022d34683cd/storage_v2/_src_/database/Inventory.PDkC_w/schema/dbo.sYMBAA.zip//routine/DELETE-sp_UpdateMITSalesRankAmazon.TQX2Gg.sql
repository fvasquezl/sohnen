-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-06-03
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_UpdateMITSalesRankAmazon]
AS
BEGIN
	SET NOCOUNT ON;

--USA
	UPDATE Inventory.dbo.Amazon SET MITSalesRank = NULL, MITSalesRankStamp = NULL WHERE CountryCode = 'US'

	DECLARE @TBL_SalesRank TABLE ( WebSKU NVARCHAR(150), QuantityOrdered INT, ASIN NVARCHAR(150))
	DECLARE @TBL_SR TABLE (ASIN NVARCHAR(150), SalesRank INT)
	
	INSERT INTO @TBL_SalesRank (WebSKU, QuantityOrdered, ASIN)
	SELECT OD.WebSKU, SUM(OD.QuantityOrdered) AS QuantityOrdered, A.ASIN
	FROM OrderManager.dbo.Orders O WITH(NOLOCK)
	INNER JOIN OrderManager.dbo.[Order Details] OD WITH(NOLOCK)
	ON OD.OrderNumber = O.OrderNumber AND OD.Adjustment = 0
	LEFT OUTER JOIN Inventory.dbo.AmazonMerchantSKU AMSKU0 WITH(NOLOCK) 
	ON AMSKU0.DARTFBMSKU = OD.WebSKU
	LEFT OUTER JOIN Inventory.dbo.AmazonMerchantSKU AMSKU1 WITH(NOLOCK) 
	ON AMSKU1.DARTFBMSKU + 'FLX' = OD.WebSKU
	LEFT OUTER JOIN Inventory.dbo.AmazonMerchantSKU AMSKU2 WITH(NOLOCK) 
	ON AMSKU2.DARTMFPSKU = OD.WebSKU
	LEFT OUTER JOIN Inventory.dbo.AmazonMerchantSKU AMSKU3 WITH(NOLOCK) 
	ON AMSKU3.DARTFBASKU = OD.WebSKU
	INNER JOIN Inventory.dbo.Amazon A WITH(NOLOCK)
	ON A.ASIN = ISNULL(AMSKU0.ASIN,ISNULL(AMSKU1.ASIN,ISNULL(AMSKU2.ASIN,ISNULL(AMSKU3.ASIN,'')))) AND A.CountryCode IN ('US')
	WHERE O.CartID IN (48,53) AND ISNULL(OD.WebSKU,'') <> '' AND CONVERT(NVARCHAR,O.OrderDate,112) > '20150101' 
	AND ISNULL(AMSKU0.ASIN,ISNULL(AMSKU1.ASIN,ISNULL(AMSKU2.ASIN,''))) <> ''
	GROUP BY OD.WebSKU, A.ASIN
	
	INSERT INTO @TBL_SR (ASIN, SalesRank)
	SELECT ASIN, ROW_NUMBER () OVER (ORDER BY SUM(QuantityOrdered) DESC ) AS SalesRank
	FROM @TBL_SalesRank
	GROUP BY ASIN

	UPDATE A SET MITSalesRank = SR.SalesRank, MITSalesRankStamp = GETDATE()
	FROM Inventory.dbo.Amazon A WITH(NOLOCK)
	INNER JOIN @TBL_SR SR
	ON SR.ASIN = A.ASIN
	WHERE A.CountryCode IN ('US')


--CANADA
	UPDATE Inventory.dbo.Amazon SET MITSalesRank = NULL, MITSalesRankStamp = NULL WHERE CountryCode = 'CA'

	DELETE FROM @TBL_SalesRank
	DELETE FROM @TBL_SR
	
	INSERT INTO @TBL_SalesRank (WebSKU, QuantityOrdered, ASIN)
	SELECT OD.WebSKU, SUM(OD.QuantityOrdered) AS QuantityOrdered, A.ASIN
	FROM OrderManager.dbo.Orders O WITH(NOLOCK)
	INNER JOIN OrderManager.dbo.[Order Details] OD WITH(NOLOCK)
	ON OD.OrderNumber = O.OrderNumber AND OD.Adjustment = 0
	LEFT OUTER JOIN Inventory.dbo.AmazonMerchantSKU AMSKU0 WITH(NOLOCK) 
	ON AMSKU0.DARTFBMSKU = OD.WebSKU
	LEFT OUTER JOIN Inventory.dbo.AmazonMerchantSKU AMSKU1 WITH(NOLOCK) 
	ON AMSKU1.DARTFBMSKU + 'FLX' = OD.WebSKU
	LEFT OUTER JOIN Inventory.dbo.AmazonMerchantSKU AMSKU2 WITH(NOLOCK) 
	ON AMSKU2.DARTMFPSKU = OD.WebSKU
	LEFT OUTER JOIN Inventory.dbo.AmazonMerchantSKU AMSKU3 WITH(NOLOCK) 
	ON AMSKU3.DARTFBASKU = OD.WebSKU
	INNER JOIN Inventory.dbo.Amazon A WITH(NOLOCK)
	ON A.ASIN = ISNULL(AMSKU0.ASIN,ISNULL(AMSKU1.ASIN,ISNULL(AMSKU2.ASIN,ISNULL(AMSKU3.ASIN,'')))) AND A.CountryCode IN ('CA')
	WHERE O.CartID IN (48,53) AND ISNULL(OD.WebSKU,'') <> '' AND CONVERT(NVARCHAR,O.OrderDate,112) > '20150101' 
	AND ISNULL(AMSKU0.ASIN,ISNULL(AMSKU1.ASIN,ISNULL(AMSKU2.ASIN,''))) <> ''
	GROUP BY OD.WebSKU, A.ASIN
	
	INSERT INTO @TBL_SR (ASIN, SalesRank)
	SELECT ASIN, ROW_NUMBER () OVER (ORDER BY SUM(QuantityOrdered) DESC ) AS SalesRank
	FROM @TBL_SalesRank
	GROUP BY ASIN

	UPDATE A SET MITSalesRank = SR.SalesRank, MITSalesRankStamp = GETDATE()
	FROM Inventory.dbo.Amazon A WITH(NOLOCK)
	INNER JOIN @TBL_SR SR
	ON SR.ASIN = A.ASIN
	WHERE A.CountryCode IN ('CA')


END
go

