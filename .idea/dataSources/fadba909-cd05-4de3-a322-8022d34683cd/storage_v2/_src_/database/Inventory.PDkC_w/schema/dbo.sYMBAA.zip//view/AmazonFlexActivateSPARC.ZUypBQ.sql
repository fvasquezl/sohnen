CREATE VIEW dbo.AmazonFlexActivateSPARC
AS
SELECT        AZSP.item_sku AS sku, AZSP.ASIN AS [product-id], '1' AS [product-id-type], '' AS price, '' AS [minimum-seller-allowed-price], '' AS [maximum-seller-allowed-price], '11' AS [item-condition], (CASE WHEN (PC.[TotalStock] > 1 OR
                         PC.[AlwaysInStock] = 1) THEN '' WHEN PC.[TotalStock] <= 1 THEN CAST(PC.[TotalStock] AS INT) ELSE '' END) AS quantity, (CASE WHEN (PC.[TotalStock] > 1 OR
                         PC.[AlwaysInStock] = 1) THEN 'a' WHEN PC.[TotalStock] <= 1 THEN 'd' ELSE 'd' END) AS [add-delete], '' AS [will-ship-internationally], '' AS [expedited-shipping], '' AS [standard-plus], '' AS [item-note], 
                         (CASE WHEN (PC.[TotalStock] > 1 OR
                         PC.[AlwaysInStock] = 1) THEN 'AMAZON_NA' WHEN PC.[TotalStock] <= 3 THEN '' ELSE '' END) AS [fulfillment-center-id], '' AS [product-tax-code], '' AS [leadtime-to-ship], (CASE WHEN (PC.[TotalStock] > 1 OR
                         PC.[AlwaysInStock] = 1) THEN '' WHEN PC.[TotalStock] <= 1 THEN 'Prime' ELSE 'Prime' END) AS merchant_shipping_group_name, 'No' AS batteries_required, 'No' AS are_batteries_included, 
                         'not_applicable' AS supplier_declared_dg_hz_regulation1
FROM            dbo.AmazonSparc AS AZSP WITH (NOLOCK) LEFT OUTER JOIN
                         dbo.Global_Stocks AS GS WITH (NOLOCK) ON AZSP.MITSKU = GS.ProductCatalogId LEFT OUTER JOIN
                         dbo.ProductCatalog AS PC WITH (NOLOCK) ON AZSP.MITSKU = PC.ID
WHERE        (AZSP.RelationshipType = 'Child') AND (AZSP.MITSKU IS NOT NULL)
go

