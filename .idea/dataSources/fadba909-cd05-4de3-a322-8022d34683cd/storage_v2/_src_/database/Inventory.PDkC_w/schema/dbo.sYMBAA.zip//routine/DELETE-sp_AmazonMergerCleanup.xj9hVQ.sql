-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 8-6-2018
-- Description:	Amazon Merger Delete Merged ASINs/MerchantSKU's with 2 Orders or Less
-- =============================================
-- Modify by:	Eduardo Gutierrez
-- Modify Date: 2018-08-13
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonMergerCleanup] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    
	IF OBJECT_ID('tempdb..#TempDuplicates') IS NOT NULL
	  DROP TABLE #TempDuplicates

	CREATE TABLE #TempDuplicates ([ASIN] NVARCHAR(MAX),[Count] INT)
	
	--Detect Duplicate ASIN's from All_Listing_Report from Amazon.
	INSERT INTO #TempDuplicates
	SELECT DISTINCT ALR.[asin1]
		  ,COUNT(ALR.[asin1]) AS [Repeats]  
	  FROM [AmazonExclusiveBulbs].[dbo].[All_Listings_Report] AS ALR WITH(NOLOCK)
	  GROUP BY ALR.[asin1]
	  HAVING COUNT(ALR.[asin1]) > 1
	  ORDER BY [Repeats] DESC
	    
	IF OBJECT_ID('tempdb..#OMOrders') IS NOT NULL
	DROP TABLE #OMOrders

	CREATE TABLE #OMOrders (WebSKU NVARCHAR(200), [QuantitySold] INT)
	CREATE INDEX IDX_TOMOrders ON #OMOrders(WebSKU)

	IF OBJECT_ID('[Inventory].[dbo].[TempMergersWorthless]') IS NOT NULL
	  DROP TABLE [Inventory].[dbo].[TempMergersWorthless]

	CREATE TABLE [Inventory].[dbo].[TempMergersWorthless] ([MerchantSKU] NVARCHAR(MAX),[RetainedASIN] NVARCHAR(MAX), [OriginalASIN] NVARCHAR(MAX), [MergedQty] INT, [Title] NVARCHAR(MAX), [QuantitySold] INT)
	
	--Detect Listings with 0 sales were RetainedASIN DOES NOT EQUAL OriginalASIN (means this only pics MerchantSKU's that belonged to ASINs that have been deleted by Amazon - It leaves the RetainedASIN in place)
	INSERT INTO [Inventory].[dbo].[TempMergersWorthless]
	 SELECT  ALR.[seller_sku] AS [MerchantSKU]
	 ,DUP.[ASIN] AS [RetainedASIN]
	 ,AZMSKU.[ASIN] AS [OriginalASIN]
	 ,DUP.[Count] AS [MergedQty]
	 ,ALR.[item_name] AS [Title]
	 , 0
	 --,IsNull((SELECT SUM(OD.[QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] AS OD WHERE [OD].[WebSKU] = ALR.[seller_sku]),0) AS [QtySold]
	 FROM [AmazonExclusiveBulbs].[dbo].[All_Listings_Report] AS ALR WITH(NOLOCK)
	 LEFT OUTER JOIN #TempDuplicates AS DUP WITH(NOLOCK) 
	 ON (ALR.[asin1] = DUP.[ASIN])
	 LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU WITH(NOLOCK)
	  ON (ALR.[seller_sku] = AZMSKU.[DARTFBMSKU]+'FLX')
	 WHERE DUP.[Count] > 1  AND (DUP.[ASIN] != AZMSKU.[ASIN]) 
	 --AND IsNull((SELECT SUM(OD.[QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] AS OD WHERE [OD].[WebSKU] = ALR.[seller_sku]),0) < 3
	 ORDER BY [RetainedASIN] DESC

	INSERT INTO #OMOrders
	SELECT [MerchantSKU], SUM(OD.[QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] AS OD WITH(NOLOCK)
	INNER JOIN [Inventory].[dbo].[TempMergersWorthless] ALR WITH(NOLOCK)
	ON [OD].[WebSKU] = ALR.[MerchantSKU] 
	GROUP BY [MerchantSKU]

	UPDATE ALR SET ALR.[QuantitySold] = OD.[QuantitySold]
	FROM [Inventory].[dbo].[TempMergersWorthless] ALR  WITH(NOLOCK)
	INNER JOIN #OMOrders OD
	ON OD.WebSKU = ALR.[MerchantSKU]

	SELECT * FROM [Inventory].[dbo].[TempMergersWorthless] WITH(NOLOCK) WHERE QuantitySold < 3 Order By [RetainedASIN] DESC
	SELECT * FROM [Inventory].[dbo].[TempMergersWorthless] WITH(NOLOCK) WHERE QuantitySold > 2 Order By [RetainedASIN] DESC

	--EMAIL ASINS with High Sales > 2
	DECLARE @xml NVARCHAR(MAX)
	DECLARE @body NVARCHAR(MAX)
	DECLARE @date VARCHAR(12)
	DECLARE @subtext VARCHAR(50)
	DECLARE @subject VARCHAR(62)
	DECLARE @recipients VARCHAR(255)
	DECLARE @datestart date

	SET @xml =CAST(( 	
	  SELECT DISTINCT ALR.[MerchantSKU]  AS 'td',''
	 ,[RetainedASIN]  AS 'td',''
	 ,[OriginalASIN]  AS 'td',''
	 ,AZ.[BrandMentioned] AS 'td',''
	 ,[MergedQty]  AS 'td',''
	 ,ALR.[Title]  AS 'td',''
	 ,[QuantitySold] AS 'td'
	 FROM [Inventory].[dbo].[TempMergersWorthless] AS ALR WITH(NOLOCK)
	 LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ WITH(NOLOCK)
	 ON (ALR.[OriginalASIN] = AZ.[ASIN])
	 WHERE [QuantitySold] > 2
	 ORDER BY [RetainedASIN] DESC
	FOR XML PATH('tr'), ELEMENTS 
	) AS NVARCHAR(MAX))

	/** FIX HTML **/
	 SET @xml = replace(@xml, '&amp;', '&')
	 SET @xml = replace(@xml, '&lt;' , '<')
	 SET @xml = replace(@xml, '&gt;' , '>')
	/** FIX HTML END**/

	SET @subtext = 'Merger Report - High Selling Items - '
	SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
	SET @subject = @subtext + @date
	SET @recipients = 'amir.tafreshi@mitechnologiesinc.com;marketplace@mitechnologiesinc.com'
	SET @body ='<html><center><H1>Merger Report - High Selling Items - <br>' + @date + '</H1><br><br></Center>Marketplace Team,<br>AutoBot has detected the following ASIN Mergers: <br><br> <Center><body bgcolor=yellow><table border = 2><tr>
	<th>MerchantSKU</th>
	<th>RetainedASIN</th>
	<th>OriginalASIN</th>
	<th>OriginalAsinBrandMentioned</th>
	<th>MergedQty</th>
	<th>Title</th>
	<th>QtySold</th>
	</tr>' 
	SET @body = @body + @xml +'</center></table><br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'

	If @body is not null BEGIN

	EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

	@recipients = @recipients,
	@subject = @subject,
	@body = @body,
	@body_format ='HTML'

	END

	--Store in AmazonNukedASIN Table
	INSERT INTO [Inventory].[dbo].[AmazonNukedASINs] ([ASIN],[CountryCode], [NukeStamp], [UserID])
	SELECT [OriginalASIN], 'US' AS [CountryCode], GETDATE() AS [NukeStamp], 'sp_AmazonMergerCle' AS [UserID] FROM [Inventory].[dbo].[TempMergersWorthless] WITH(NOLOCK)
	WHERE QuantitySold < 3 AND [OriginalASIN] NOT IN (SELECT [ASIN] FROM [Inventory].[dbo].[AmazonNukedASINs] WITH(NOLOCK))

	--DELETE ASINS FROM Amazon and AmazonMerchantSKU Table
	DELETE FROM [Inventory].[dbo].[Amazon] WHERE [CountryCode] = 'US' AND [ASIN] IN (SELECT [OriginalASIN] FROM [Inventory].[dbo].[TempMergersWorthless] WITH(NOLOCK) WHERE QuantitySold < 3)
	--MSKU will automatically recreate if available in other countries
	DELETE FROM [Inventory].[dbo].[AmazonMerchantSKU] WHERE [ASIN] IN (SELECT [OriginalASIN] FROM [Inventory].[dbo].[TempMergersWorthless] WITH(NOLOCK) WHERE QuantitySold < 3)

	--START FEED TO AMAZON TO NUKE MerchantSKU Listings of Merged ASINs with 0 Sales History		
	DECLARE @selectstatement NVARCHAR(2000)
	DECLARE @cmd NVARCHAR(2000)
		
	SET @selectstatement = 'SELECT [MerchantSKU] AS [sku], '''' AS [product-id], '''' AS [product-id-type], '''' AS [price], '''' AS [minimum-seller-allowed-price], '''' AS [maximum-seller-allowed-price], '''' AS [item-condition], '''' AS [quantity], ''x'' AS [add-delete], '''' AS [will-ship-internationally], '''' AS [expedited-shipping], '''' AS [standard-plus], '''' AS [item-note], '''' AS [fulfillment-center-id], '''' AS [product-tax-code], '''' AS [leadtime-to-ship], '''' AS [merchant_shipping_group_name], '''' AS [batteries_required], '''' AS [are_batteries_included], '''' AS [supplier_declared_dg_hz_regulation1] FROM [Inventory].[dbo].[TempMergersWorthless] WITH(NOLOCK) WHERE QuantitySold < 3' 

	SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebflexactivate-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
	EXEC master..xp_cmdshell @cmd
			
	EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebflexactivate.bat"'	

END
go

