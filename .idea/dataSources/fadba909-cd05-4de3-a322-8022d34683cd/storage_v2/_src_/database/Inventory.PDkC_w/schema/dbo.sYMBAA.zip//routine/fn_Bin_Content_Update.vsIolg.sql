-- =============================================
-- Author:		Luis Bautista
-- Create date: Jun-07-2014
-- Description:	Update the bin content
-- =============================================
CREATE FUNCTION [dbo].[fn_Bin_Content_Update]
(
	
	@pBin varchar(10), @pSKU int, @pQty int, @pUserId int, @pFlow int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar int;
	DECLARE @Exist int;
	DECLARE @Bin_Counter int;
	
	SET @ResultVar = 0;
	SET @Exist = 0;
	SET @Bin_Counter = 0;
	
	
	/*Check for a valid qty*/
	IF @pQty <=0
	BEGIN
		SET @ResultVar = -1
	END;
	
	
	IF @ResultVar = 0
	BEGIN
			/* CHECK IF IS VALID BIN*/
			SET @Exist = (SELECT top 1 a.id FROM Inventory.dbo.Bins a WHERE a.Bin_Id = @pBin);
			IF @Exist is null 
			BEGIN
					SET		@Exist = 0;
			END;
	
			IF @Exist < 1
			BEGIN
				SET @ResultVar = -2
			END
	END;
	
	IF @ResultVar = 0
	BEGIN
		/* CHECK IF IS VALID SKU*/		
		SET @Exist = 0;
	

		SET @Exist = (SELECT top 1 a.id FROM Inventory.dbo.ProductCatalog a 
						WHERE a.id = @pSKU);
		IF @Exist is null 
		BEGIN
				SET @Exist = 0;
		END;
		
		IF @Exist < 1
		BEGIN
			SET @ResultVar = -3
		END
		
		
	END

	IF @ResultVar = 0
	BEGIN
		/* UPDATE THE BIN*/
		/* CHECK IF SKU exist in bin*/		
		SELECT top 1 
				 @Bin_Counter = a.Counter 
				,@Exist = a.id
				FROM Inventory.dbo.Bin_Content a 
				WHERE (a.Bin_Id = @pBin) AND (a.ProductCatalog_Id = @pSKU);
		
		IF @Exist is null 
		BEGIN
				SET @Exist = 0;
		END;
		
		
		
		
		
		
	END;
	
	
	
	-- Return the result of the function
	RETURN @ResultVar;


END
go

