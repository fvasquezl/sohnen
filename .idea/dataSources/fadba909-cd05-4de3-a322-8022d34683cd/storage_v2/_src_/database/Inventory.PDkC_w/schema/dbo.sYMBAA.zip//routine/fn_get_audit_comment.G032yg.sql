-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_get_audit_comment
(
	@AdjustmentId Int
)
RETURNS varchar(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(100)

	SELECT @ResultVar = Comment FROM InventoryAdjustmentsExtras WHERE InventoryAdjustmentID = @AdjustmentId;
	

	-- Return the result of the function
	RETURN @ResultVar

END
go

