-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 12-6-2014
-- Description:	Get Lowest Price based on category from the supplier Views
-- =============================================
CREATE FUNCTION [dbo].[fn_GetLowestPriceFromSuppliersTableV2] 
(
	-- Add the parameters for the function here
	@pSKU int
)
RETURNS @Result TABLE (Supplier NVARCHAR(MAX),Price DECIMAL(10,2))
AS
BEGIN
	

	BEGIN
	INSERT INTO @Result
	Select TOP(1) SI.[SupplierName], CAST([UnitCost] AS Decimal(10,2)) FROM [Inventory].[dbo].[Suppliers] AS S WITH(NOLOCK)
	LEFT OUTER JOIN [Inventory].[dbo].[SupplierInfo] AS SI WITH(NOLOCK) ON (S.[SupplierID] = SI.[SupplierId])
	WHERE S.[ProductCatalogID] = @pSKU AND S.[UnitCost] != '0' AND S.[UnitCost] IS NOT NULL
	ORDER BY S.[UnitCost] ASC
	 
	 END


	RETURN;

END
go

