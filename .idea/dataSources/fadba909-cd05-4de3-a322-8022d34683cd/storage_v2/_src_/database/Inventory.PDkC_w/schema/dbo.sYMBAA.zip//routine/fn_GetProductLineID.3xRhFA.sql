-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetProductLineID]
(
	@pProductCatalogID int
 
)
RETURNS integer
AS
BEGIN
	
	DECLARE @lresult int

	SET @lresult = 0;
	

	
			select @lresult =  a.productLineId from ProductCatalog a
			where a.ID = @pProductCatalogID ;
	
	-- Return the result of the function
	RETURN (@lresult)
END


go

