-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7/1/2018
-- Description:	Delete SKU
-- =============================================
CREATE PROCEDURE [dbo].[sp_DeleteSKU] 
	-- Add the parameters for the stored procedure here
	@pSKU NVARCHAR(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #TMP_MESSAGES(
											 [ID] int IDENTITY(1,1) PRIMARY KEY
											,[FMESSAGE] NVARCHAR(50))

BEGIN
	--CONDITION:  Can not delete items with INVENTORY in BIN SYSTEM  
	IF (SELECT COUNT([BinID]) FROM [Remotes].[dbo].[BinStock] WHERE [SKU] = @pSKU) = 0
		
		BEGIN

			DECLARE @CntMarketplaceMapping INT
			SET @CntMarketplaceMapping = (SELECT COUNT([SKU]) FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [SKU] = @pSKU)

			DECLARE @CntBinHistory INT
			SET @CntBinHistory = (SELECT COUNT([SKU]) FROM [Remotes].[dbo].[BinHistory] WHERE [SKU] = @pSKU)

			DECLARE @CntChannelAdvisor INT
			SET @CntChannelAdvisor = (SELECT COUNT([Inventory Number]) FROM [Remotes].[dbo].[ChannelAdvisor] WHERE [Inventory Number] LIKE '%'+@pSKU+'%')

			DECLARE @CntImages INT
			SET @CntImages = (SELECT COUNT([SKU]) FROM [Remotes].[dbo].[Image] WHERE [SKU] = @pSKU)


			--DELETE FROM THESE TABLES
			---------BinStock-----------
			--This is really not necessary
			DELETE FROM [Remotes].[dbo].[BinStock] WHERE [SKU] = @pSKU
			---------BinStock-----------

						---------IMAGES-----------			
			INSERT INTO [Remotes].[dbo].[ImageDeleted] (
					  [ID]
					  ,[SKU]
					  ,[URL]
					  ,[name]
					  ,[ImageExists]
					  ,[ImageExistsStamp]
					  )
			  SELECT [ID]
				  ,[SKU]
				  ,[URL]
				  ,[name]
				  ,[ImageExists]
				  ,[ImageExistsStamp]
			  FROM [Remotes].[dbo].[Image]
			  WHERE [SKU] = @pSKU
			
			DELETE FROM [Remotes].[dbo].[Image] WHERE [SKU] = @pSKU
	

			--ALSO DELETE IMAGE FILES
			DECLARE @rmdircmd NVARCHAR(500)
			DECLARE @dirname NVARCHAR(500)
			SET @dirname = '\\192.168.0.232\public\http\remotes\'+@pSKU+'\'
			SET @rmdircmd = N'RMDIR ' + @dirname + ' /S /Q'
			exec master.dbo.xp_cmdshell @rmdircmd, no_output			
			---------IMAGES-----------			
			

						---------MARKETPLACE MAPPING-----------
			INSERT INTO [Remotes].[dbo].[MarketplaceMappingDeleted] (
					[SKU]
				  ,[MerchantSKU]
				  ,[ASIN]
				  ,[Stamp]
				  ,[Floor]
				  ,[Ceiling]
				  ,[DumpIt]
				  ,[ID]
				  ,[Condition]
				  ,[FulfillmentType]
				  ,[IsCN]
				  ,[Quantity]
				  )
			SELECT [SKU]
				  ,[MerchantSKU]
				  ,[ASIN]
				  ,[Stamp]
				  ,[Floor]
				  ,[Ceiling]
				  ,[DumpIt]
				  ,[ID]
				  ,[Condition]
				  ,[FulfillmentType]
				  ,[IsCN]
				  ,[Quantity]
			FROM [Remotes].[dbo].[MarketplaceMapping]
			WHERE [SKU] = @pSKU

			DELETE FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [SKU] = @pSKU
			---------MARKETPLACE MAPPING-----------


			---------CHANNEL ADVISOR-----------
			INSERT INTO [Remotes].[dbo].[ChannelAdvisorDeleted] (
					[ID]
					,[Inventory Number]
					,[Auction Title]
					,[Quantity Update Type]
					,[Quantity]
					,[Length]
					,[Height]
					,[Width]
					,[Weight]
					,[MPN]
					,[Short Description]
					,[Description]
					,[Manufacturer]
					,[Brand]
					,[Condition]
					,[Warranty]
					,[Seller Cost]
					,[Buy It Now Price]
					,[Retail Price]
					,[Picture URLs]
					,[Description Template Name]
					,[Posting Template Name]
					,[Schedule Name]
					,[eBay Category List]
					,[eBay Store Category Name]
					,[Labels]
					,[Classification]
					,[Attribute1Name]
					,[Attribute1Value]
					,[Attribute2Name]
					,[Attribute2Value]
					,[Attribute3Name]
					,[Attribute3Value]
					,[Attribute4Name]
					,[Attribute4Value]
					,[Attribute5Name]
					,[Attribute5Value]
					,[Attribute6Name]
					,[Attribute6Value]
					,[Attribute7Name]
					,[Attribute7Value]
					,[Attribute8Name]
					,[Attribute8Value]
			)
			SELECT	[ID]
					,[Inventory Number]
					,[Auction Title]
					,[Quantity Update Type]
					,[Quantity]
					,[Length]
					,[Height]
					,[Width]
					,[Weight]
					,[MPN]
					,[Short Description]
					,[Description]
					,[Manufacturer]
					,[Brand]
					,[Condition]
					,[Warranty]
					,[Seller Cost]
					,[Buy It Now Price]
					,[Retail Price]
					,[Picture URLs]
					,[Description Template Name]
					,[Posting Template Name]
					,[Schedule Name]
					,[eBay Category List]
					,[eBay Store Category Name]
					,[Labels]
					,[Classification]
					,[Attribute1Name]
					,[Attribute1Value]
					,[Attribute2Name]
					,[Attribute2Value]
					,[Attribute3Name]
					,[Attribute3Value]
					,[Attribute4Name]
					,[Attribute4Value]
					,[Attribute5Name]
					,[Attribute5Value]
					,[Attribute6Name]
					,[Attribute6Value]
					,[Attribute7Name]
					,[Attribute7Value]
					,[Attribute8Name]
					,[Attribute8Value]
					FROM [Remotes].[dbo].[ChannelAdvisor]
					WHERE [Inventory Number] LIKE '%'+@pSKU+'%'

			DELETE FROM [Remotes].[dbo].[ChannelAdvisor] WHERE [Inventory Number] LIKE '%'+@pSKU+'%'
			---------CHANNEL ADVISOR-----------


			---------BIN HISTORY-----------
			INSERT INTO [Remotes].[dbo].[BinHistoryDeleted] (
							[idx]
							,[BinID]
							,[SKU]
							,[Quantity]
							,[Flow]
							,[ScanCode]
							,[Comments]
							,[ScanType]
							,[CreateUser]
							,[CreateDate]
							)
				SELECT	[idx]
						,[BinID]
						,[SKU]
						,[Quantity]
						,[Flow]
						,[ScanCode]
						,[Comments]
						,[ScanType]
						,[CreateUser]
						,[CreateDate]
				FROM [Remotes].[dbo].[BinHistory]
				WHERE [SKU] = @pSKU

			DELETE FROM [Remotes].[dbo].[BinHistory] WHERE [SKU] = @pSKU
			---------BIN HISTORY-----------

			---------SKUDATA-----------
			INSERT INTO [Remotes].[dbo].[SKUDataDeleted] (
				  [SKU]
				  ,[Manufacturer]
				  ,[PartNumber]
				  ,[AlsoCompatibleWith]
				  ,[AlternatePN]
				  ,[ResearchComplete]
				  ,[Length]
				  ,[Width]
				  ,[Height]
				  ,[WeightOz]
				  ,[FloorPrice]
				  ,[CeilingPrice]
				  ,[updated_at]
				  ,[deleted_at]
				  ,[created_at]
				  ,[Amazon]
				  ,[eBay]
				  ,[CategoryID]
				  ,[OriginallySuppliedWith]
				  ,[CanReplaceSKUs]
				  ,[HaveCNVariant]
				  ,[UnitCostCN]
				  ,[UnitCostUSED]
				  ,[UnitCost]
				  )
			  SELECT [SKU]
				  ,[Manufacturer]
				  ,[PartNumber]
				  ,[AlsoCompatibleWith]
				  ,[AlternatePN]
				  ,[ResearchComplete]
				  ,[Length]
				  ,[Width]
				  ,[Height]
				  ,[WeightOz]
				  ,[FloorPrice]
				  ,[CeilingPrice]
				  ,[updated_at]
				  ,[deleted_at]
				  ,[created_at]
				  ,[Amazon]
				  ,[eBay]
				  ,[CategoryID]
				  ,[OriginallySuppliedWith]
				  ,[CanReplaceSKUs]
				  ,[HaveCNVariant]
				  ,[UnitCostCN]
				  ,[UnitCostUSED]
				  ,[UnitCost]
			  FROM [Remotes].[dbo].[SKUData]
			  WHERE [SKU] = @pSKU

			DELETE FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @pSKU
			---------SKUDATA-----------
			INSERT INTO #TMP_MESSAGES VALUES (
					cast('I have Deleted SKU: '+ @pSKU AS NVARCHAR(50)) )

			INSERT INTO #TMP_MESSAGES VALUES (
					cast('I have Deleted '+CAST(@CntMarketplaceMapping AS NVARCHAR(20))+' records from the Marketplace Mapping Table' AS NVARCHAR(50)))

		    INSERT INTO #TMP_MESSAGES VALUES (
					cast('I have Deleted '+CAST(@CntBinHistory AS NVARCHAR(20))+' records from the Bin History Table' AS NVARCHAR(50)))

			INSERT INTO #TMP_MESSAGES VALUES (
					cast('I have Deleted '+CAST(@CntChannelAdvisor AS NVARCHAR(20))+' records from the Channel Advisor Table' AS NVARCHAR(50)))

			INSERT INTO #TMP_MESSAGES VALUES (
					cast('I have Deleted '+CAST(@CntImages AS NVARCHAR(20))+' records from the Images Table' AS NVARCHAR(50)))

			PRINT 'I have Deleted SKU: '+@pSKU
			PRINT 'I have Deleted '+CAST(@CntMarketplaceMapping AS NVARCHAR(20))+' records from the Marketplace Mapping Table'
			PRINT 'I have Deleted '+CAST(@CntBinHistory AS NVARCHAR(20))+' records from the Bin History Table'
			PRINT 'I have Deleted '+CAST(@CntChannelAdvisor AS NVARCHAR(20))+' records from the Channel Advisor Table'
			PRINT 'I have Deleted '+CAST(@CntImages AS NVARCHAR(20))+' records from the Images Table'
			
			SELECT ID, FMESSAGE FROM #TMP_MESSAGES ORDER BY ID
		END

	ELSE
		BEGIN

			DECLARE @BinID NVARCHAR(20)
			DECLARE @BinQty NVARCHAR(20)
			DECLARE @TotalQty NVARCHAR(20)


			SET @BinID = (SELECT (STUFF((SELECT COALESCE([BinID] + ' ', '') FROM [Remotes].[dbo].[BinStock] WHERE [SKU] = @pSKU FOR XML PATH('')), 1, 0, '')))
			SET @BinQty = (SELECT (STUFF((SELECT COALESCE(CAST([StockQty] AS NVARCHAR(50))+ ' ', '') FROM [Remotes].[dbo].[BinStock] WHERE [SKU] = @pSKU FOR XML PATH('')), 1, 0, '')))
			SET @TotalQty = (SELECT SUM([StockQty]) FROM [Remotes].[dbo].[BinStock] WHERE [SKU] = @pSKU)

			INSERT INTO #TMP_MESSAGES VALUES (
					cast('Can not DELETE!  Inventory Exists in Bin Manager!' AS NVARCHAR(50)) )
			INSERT INTO #TMP_MESSAGES VALUES (
					cast('BinIDs: '+@BinID+' BinQty: '+@BinQty+' TotalStock: '+@TotalQty AS NVARCHAR(50)) )

			PRINT 'Can not DELETE!  Inventory Exists in Bin Manager!'
			PRINT 'BinIDs: '+@BinID+' BinQty: '+@BinQty+' TotalStock: '+@TotalQty

			SELECT ID, FMESSAGE FROM #TMP_MESSAGES ORDER BY ID
		END
END

END
go

