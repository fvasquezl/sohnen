-- =============================================
-- Author:		Luis
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Set_Vitual_Inventory]
	@pProductId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @minqty as REAL ;
	DECLARE @currentqty as REAL ;
	DECLARE @SubSKU int;
	DECLARE @SubSKUQTYRequired real;
	DECLARE @WarehouseID int;
	
	SET @minqty = 99999999999999;
	SET @currentqty = 0;
	
	
    DECLARE requires_cursor CURSOR FOR 
				SELECT SubSKU, SubSKUQTYRequired, WarehouseID
				FROM AssemblyDetails
				WHERE (ProductCatalogID =  @pProductId)
						and (ApprovedBy > 0) 
						and (IsRequired = 1);
						
			OPEN requires_cursor;

			FETCH NEXT FROM requires_cursor 
			INTO @SubSKU, @SubSKUQTYRequired, @WarehouseID;
			
			WHILE @@FETCH_STATUS = 0
			BEGIN
				   
				    				
					
					
					SET @currentqty = inventory.dbo.fn_Get_Global_Stock(@SubSKU)
					
					If @minqty > @currentqty
					BEGIN
							SET @minqty = @currentqty;
					END
					
					FETCH NEXT FROM requires_cursor 
					INTO @SubSKU, @SubSKUQTYRequired, @WarehouseID;
			END

			CLOSE requires_cursor;
			DEALLOCATE requires_cursor;
			
			If @minqty <> 99999999999999
					BEGIN
							UPDATE Global_Stocks SET VirtualStock = @minqty 
														WHERE ProductCatalogId = @pProductId ;
					END
			
			
END
go

