-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-06-01
-- Description:	Buyquest Tracking Export
-- =============================================
CREATE PROCEDURE [dbo].[sp_BUYQUEST_TRACKINGEXPORT]
AS
BEGIN
	SET NOCOUNT ON;

    --BUYQUEST TRACKINGEXPORT 2015

DECLARE @tmpTable TABLE (
[PO Number]				NVARCHAR(MAX),
[SO Number]				NVARCHAR(MAX),
[Vendor SO Number]		NVARCHAR(MAX),
[Ship To Name]			NVARCHAR(MAX),
[Ship To Address 1]		NVARCHAR(MAX),
[Ship To Address 2]		NVARCHAR(MAX),
[Ship To City]			NVARCHAR(MAX),
[Ship To State]			NVARCHAR(MAX),
[Ship To Zip]			NVARCHAR(MAX),
[Ship To Country]		NVARCHAR(MAX),
[Ship To Phone]			NVARCHAR(MAX),
[Item]					NVARCHAR(MAX),
[Vendor Code]			NVARCHAR(MAX),
[Quantity Fulfilled]	NVARCHAR(MAX),
[Quantity Unfulfilled]	NVARCHAR(MAX),
[Item Rate]				NVARCHAR(MAX),
[Weight]				NVARCHAR(MAX),
[Weight Units]			NVARCHAR(MAX),
[Shipping Method]		NVARCHAR(MAX),
[Ship Date]				NVARCHAR(MAX),
[Ship Complete?]		NVARCHAR(MAX),
[Blind Ship?]			NVARCHAR(MAX),
[Vendor Update]			NVARCHAR(MAX),
[Qty]					NVARCHAR(MAX),
[Tracking Number]		NVARCHAR(MAX),
[Restock ETA]			NVARCHAR(MAX),
[Remark]				NVARCHAR(MAX)
)

INSERT INTO @tmpTable ([PO Number],[SO Number],[Vendor SO Number],[Ship To Name],[Ship To Address 1],[Ship To Address 2],[Ship To City],[Ship To State],[Ship To Zip],[Ship To Country],[Ship To Phone],[Item],[Vendor Code],[Quantity Fulfilled],[Quantity Unfulfilled],[Item Rate],[Weight],[Weight Units],[Shipping Method],[Ship Date],[Ship Complete?],[Blind Ship?],[Vendor Update],[Qty],[Tracking Number],[Restock ETA],[Remark])
SELECT O.[PONumber] AS [PO Number],
	   O.[SourceOrderID] AS [SO Number],
	   O.[OrderNumber] AS [Vendor SO Number],
	   IsNull(O.[ShipName],'') AS [Ship To Name],
	   IsNull(O.[ShipAddress],'') AS [Ship To Address 1],
	   IsNull(O.[ShipAddress2],'') AS [Ship To Address 2],
	   IsNull(O.[ShipCity],'') AS [Ship to City],
	   IsNull(O.[ShipState],'') AS [Ship To State],
	   IsNull(O.[ShipZip],'') AS [Ship To Zip],
	   IsNull(O.[ShipCountry],'') AS [Ship To Country],
	   IsNull(O.[ShipPhone],'') AS [Ship To Phone],
	   IsNull(OD.[Product],'') AS [Item],
	   --This is the MITSKU we are importing originally
	   IsNull(OD.[Option01],'') AS [Vendor Code],
	   (CASE WHEN (TR.[TrackingID] IS NULL) THEN '0' ELSE OD.[QuantityShipped] END) AS [Quantity Fulfilled],
	   (CASE WHEN (TR.[TrackingID] IS NULL) THEN OD.[QuantityOrdered] ELSE '0' END) AS [Quantity Unfulfilled],
	   Cast(OD.[PricePerUnit] AS Decimal(10,2)) AS [Item Rate],
	   (CASE WHEN TR.[Pounds] IS NULL OR TR.[Pounds] = 0 THEN OD.[QuantityShipped] ELSE TR.[Pounds] END) AS [Weight],
	   'lb' AS [Weight Units],
	   CASE WHEN LEN(CAST(O.[Comments] AS NVARCHAR(MAX))) > 5 THEN --(LEFT(CAST(O.[Comments] AS NVARCHAR(MAX)),CHARINDEX('- SOI', CAST(O.[Comments] AS NVARCHAR(MAX)))-2)) 
	   SUBSTRING(CONVERT(NVARCHAR,O.[Comments]),0,(CHARINDEX('- SOI', CONVERT(NVARCHAR,O.[Comments]))))
	   ELSE '' END AS [Shipping Method],
	   REPLACE((CASE WHEN (O.[Cancelled] = 1) THEN '' ELSE CONVERT(VARCHAR(10),TR.[DateAdded],101) END),'01/01/1900','') AS [Ship Date],
	   (CASE WHEN (O.[Cancelled] = 1)  THEN 'No' ELSE 'Yes' END) AS [Ship Complete?],
	   'No' AS [Blind Ship?],
	   (CASE WHEN O.[Cancelled] = '1' THEN 'Out of Stock - Cancelled' ELSE '' END) AS [Vendor Update],
	   OD.QuantityShipped AS [Qty],
	   TR.[TrackingID] AS [Tracking Number],
	   REPLACE((CASE WHEN (TR.[TrackingID] IS NULL AND O.[Cancelled] = 0) THEN CAST(CONVERT(VARCHAR(10),GETDATE()+1,101) AS NVARCHAR(MAX)) ELSE '' END),'01/01/1900','') AS [Restock ETA],
	   (CASE WHEN (TR.[TrackingID] IS NULL AND O.[Cancelled] = 0)  THEN 'Shipping Soon' ELSE '' END) AS [Remark]
FROM [OrderManager].[dbo].[Orders] AS O WITH(NOLOCK)
LEFT OUTER JOIN [OrderManager].[dbo].[Order Details] AS OD WITH(NOLOCK) ON (O.[OrderNumber] = OD.[OrderNumber])
LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] AS TR WITH(NOLOCK) ON (O.[OrderNumber] = TR.[NumericKey])
WHERE O.[CustomerID] = '854443' 
AND OD.[Adjustment] = '0'
--Shows shipped orders
AND ((CAST(TR.[DateAdded] AS DATE) BETWEEN GETDATE()-5 AND GETDATE()) 
		--subfilter: Shows non-cancelled orders pending shipment
		OR ((O.[Cancelled]) = 0 AND TR.[DateAdded] IS NULL) 
		--subfilter: Shows cancelled orders in the last day
		OR (O.[Cancelled] = 1 AND O.[OrderDate] BETWEEN GETDATE()-5 AND GETDATE()))
		--DROP TABLE #tmpExportFeed
--Create Temp Table
CREATE TABLE #tmpExportFeed(
[PO Number]				NVARCHAR(MAX),
[SO Number]				NVARCHAR(MAX),
[Vendor SO Number]		NVARCHAR(MAX),
[Ship To Name]			NVARCHAR(MAX),
[Ship To Address 1]		NVARCHAR(MAX),
[Ship To Address 2]		NVARCHAR(MAX),
[Ship To City]			NVARCHAR(MAX),
[Ship To State]			NVARCHAR(MAX),
[Ship To Zip]			NVARCHAR(MAX),
[Ship To Country]		NVARCHAR(MAX),
[Ship To Phone]			NVARCHAR(MAX),
[Item]					NVARCHAR(MAX),
[Vendor Code]			NVARCHAR(MAX),
[Quantity Fulfilled]	NVARCHAR(MAX),
[Quantity Unfulfilled]	NVARCHAR(MAX),
[Item Rate]				NVARCHAR(MAX),
[Weight]				NVARCHAR(MAX),
[Weight Units]			NVARCHAR(MAX),
[Shipping Method]		NVARCHAR(MAX),
[Ship Date]				NVARCHAR(MAX),
[Ship Complete?]		NVARCHAR(MAX),
[Blind Ship?]			NVARCHAR(MAX),
[Vendor Update]			NVARCHAR(MAX),
[Qty]					NVARCHAR(MAX),
[Tracking Number]		NVARCHAR(MAX),
[Restock ETA]			NVARCHAR(MAX),
[Remark]				NVARCHAR(MAX)
)

INSERT INTO #tmpExportFeed
SELECT 
'"' + [PO Number] + '"' AS [PO Number],
'"' + [SO Number] + '"' AS [SO Number],
'"' + [Vendor SO Number] + '"' AS [Vendor SO Number],
'"' + [Ship To Name] + '"' AS [Ship To Name],
'"' + [Ship To Address 1] + '"' AS [Ship To Address 1],
'"' + [Ship To Address 2] + '"' AS [Ship To Address 2],
'"' + [Ship To City] + '"' AS [Ship To City],
'"' + [Ship To State] + '"' AS [Ship To State],
[Ship To Zip] AS [Ship To Zip],
'"' + [Ship To Country] +  '"' AS [Ship To Country],
'"' + [Ship To Phone] +  '"' AS [Ship To Phone],
'"' + [Item] +  '"' AS [Item],
'"' + [Vendor Code] + '"' AS [Vendor Code],
[Quantity Fulfilled] AS [Quantity Fulfilled],
[Quantity Unfulfilled] AS [Quantity Unfulfilled],
[Item Rate] AS [Item Rate],
[Weight] AS [Weight],
[Weight Units] AS [Weight Units],
'"' + [Shipping Method] + '"' AS [Shipping Method],
'"' + [Ship Date] + '"' AS [Ship Date],
'"' + [Ship Complete?] + '"' AS [Ship Complete?],
'"' + [Blind Ship?] + '"' AS [Blind Ship?],
'"' + [Vendor Update] + '"' AS [Vendor Update],
[Qty] AS [Qty],
'"''' + [Tracking Number] + '"' AS [Tracking Number],
'"' + [Restock ETA] + '"' AS [Restock ETA],
'"' + [Remark] + '"' AS [Remark]
FROM @tmpTable ORDER BY [PO Number] ASC

SELECT * FROM #tmpExportFeed

END
go

