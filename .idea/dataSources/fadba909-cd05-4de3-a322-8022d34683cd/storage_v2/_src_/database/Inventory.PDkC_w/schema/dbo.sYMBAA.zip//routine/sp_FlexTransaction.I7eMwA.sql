-- =============================================
-- Author:		Hubet Cárdenas Isla
-- Create date: 2017-09-14
-- Description:	Get Flex Transaction
-- =============================================
CREATE PROCEDURE [dbo].[sp_FlexTransaction]
	-- Add the parameters for the stored procedure here
	@pOption NVARCHAR(50) = NULL, 
	@pTransactionID NVARCHAR(50) = NULL
AS
	DECLARE @iTotalQty INT,
		    @iTotalOrders INT,
			@iTotalItems INT
BEGIN
	SET NOCOUNT ON;

	--Create Table Result
	DECLARE @TMPRESULT TABLE ([SKU] NVARCHAR(50), [Bin_ID] NVARCHAR(250), [RequestedQuantity] INT, [TransactionID] INT, [CreateUser] NVARCHAR(20), [CreateDate] DATETIME, [fullname] NVARCHAR(250), [CategoryName] NVARCHAR(250), SEQ INT)

    -- Insert statements for procedure here
	IF @pOption = 'ONSTOCK'
	BEGIN
		--Total Qty
		SELECT @iTotalQty = SUM(TD.[RequestedQuantity]) FROM [WebStation].[FX].[TransactionDetail] TD WITH(NOLOCK)
		INNER JOIN [WebStation].[FX].[Transaction] T WITH(NOLOCK)
		ON T.[TransactionID] = TD.[TransactionID] AND T.[isActive] = 1
		LEFT OUTER JOIN [Inventory].[dbo].[Users] U WITH(NOLOCK)
		ON U.[usr] = T.[CreateUser]
		WHERE [Bin_ID] IS NOT NULL AND CONVERT(NVARCHAR, TD.[TransactionID]) = (CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID ELSE CONVERT(NVARCHAR, TD.[TransactionID]) END)
		
		--Total Orders
		SELECT @iTotalOrders = COUNT(*)
		FROM (
			SELECT [OrderId] FROM [AmazonExclusiveBulbs].[dbo].[BatchOrders] WITH(NOLOCK)
			WHERE CONVERT(NVARCHAR, [TransactionID]) = (CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID ELSE CONVERT(NVARCHAR, [TransactionID]) END)
			GROUP BY [OrderId]
		) TMP
		
		--Total Items:
		SELECT @iTotalItems = SUM([RequestedQuantity]) FROM [AmazonExclusiveBulbs].[dbo].[BatchOrders] WITH(NOLOCK)
		WHERE CONVERT(NVARCHAR, [TransactionID]) = (CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID ELSE CONVERT(NVARCHAR, [TransactionID]) END)
		
		INSERT INTO @TMPRESULT
		SELECT MAIN.[SKU],
			   MAIN.[Bin_ID],
			   MAIN.[RequestedQuantity],
			   MAIN.[TransactionID],
			   MAIN.[CreateUser],
			   MAIN.[CreateDate],
			   MAIN.[fullname],
			   MAIN.[CategoryName]
			   , 1
		FROM (
			SELECT TD.[SKU],
					TD.[Bin_ID],
					SUM(TD.[RequestedQuantity]) AS [RequestedQuantity],
					TD.[TransactionID],
					T.[CreateUser],
					T.[CreateDate],
					U.[fullname],
					C.Name AS CategoryName
			FROM [WebStation].[FX].[TransactionDetail] TD WITH(NOLOCK)
			INNER JOIN [WebStation].[FX].[Transaction] T WITH(NOLOCK)
			ON T.[TransactionID] = TD.[TransactionID] AND T.[isActive] = 1
			LEFT OUTER JOIN [Inventory].[dbo].[Users] U WITH(NOLOCK)
			ON U.[usr] = T.[CreateUser]
			LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
			ON CONVERT(NVARCHAR,PC.ID) = TD.SKU
			LEFT OUTER JOIN Inventory.dbo.Categories C WITH(NOLOCK)
			ON C.ID = PC.CategoryID
			WHERE [Bin_ID] IS NOT NULL
			AND CONVERT(NVARCHAR, TD.[TransactionID]) = (CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID ELSE CONVERT(NVARCHAR, TD.[TransactionID]) END)
			GROUP BY TD.[SKU], TD.[Bin_ID], T.[CreateUser], TD.[TransactionID], T.[CreateDate], U.[fullname], C.Name
		) MAIN
		ORDER BY MAIN.CategoryName, MAIN.[Bin_ID] ASC

		INSERT INTO @TMPRESULT (Bin_ID,RequestedQuantity,CategoryName,SEQ, CreateDate, CreateUser, fullname, TransactionID)
		SELECT CategoryName+'		Total: ', SUM(RequestedQuantity), CategoryName,0, CreateDate, CreateUser, fullname, TransactionID FROM @TMPRESULT WHERE SEQ = 1 GROUP BY CategoryName, CreateDate, CreateUser, fullname, TransactionID

		SELECT MAIN.[SKU],
			MAIN.[Bin_ID],
			MAIN.[RequestedQuantity],
			MAIN.[TransactionID],
			MAIN.[CreateUser],
			MAIN.[CreateDate],
			MAIN.[fullname],
			@iTotalQty TOTAL_QTY,
			@iTotalOrders TOTAL_ORDERS,
			@iTotalItems TOTAL_ITEMS,
			@pOption [OPTION] 
		FROM @TMPRESULT MAIN 
		ORDER BY CategoryName, SEQ, MAIN.[Bin_ID]

	END
	ELSE IF @pOption = 'OUTSTOCK'
	BEGIN
		--Total Qty
		SELECT @iTotalQty = SUM(TD.[RequestedQuantity])
		  FROM [WebStation].[FX].[TransactionDetail] TD WITH(NOLOCK)
		 INNER JOIN [WebStation].[FX].[Transaction] T WITH(NOLOCK)
				 ON T.[TransactionID] = TD.[TransactionID]
			    AND T.[isActive] = 1
		  LEFT OUTER JOIN [Inventory].[dbo].[Users] U WITH(NOLOCK)
					   ON U.[usr] = T.[CreateUser]
					--INNER JOIN AmazonExclusiveBulbs.dbo.BatchOrders B
					--ON B.TransactionID = TD.TransactionID AND B.OrderId = TD.OrderId AND B.Fnsku = TD.Fnsku AND B.CName <> 'Remotes'
		 WHERE [Bin_ID] IS NULL
		   AND CONVERT(NVARCHAR, TD.[TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
														   ELSE CONVERT(NVARCHAR, TD.[TransactionID])
													   END
		
		--Total Orders
		SELECT @iTotalOrders = COUNT(*)
		  FROM (SELECT [OrderId] 
				  FROM [AmazonExclusiveBulbs].[dbo].[BatchOrders] WITH(NOLOCK)
				 WHERE CONVERT(NVARCHAR, [TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
																ELSE CONVERT(NVARCHAR, [TransactionID])
													        END
				 GROUP BY [OrderId]) TMP
		
		--Total Items:
		SELECT @iTotalItems = SUM([RequestedQuantity])
		  FROM [AmazonExclusiveBulbs].[dbo].[BatchOrders] WITH(NOLOCK)
		 WHERE CONVERT(NVARCHAR, [TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
													    ELSE CONVERT(NVARCHAR, [TransactionID])
													END
		
		INSERT INTO @TMPRESULT
		SELECT MAIN.[SKU],
			MAIN.[Bin_ID],
			SUM(MAIN.[RequestedQuantity]) AS [RequestedQuantity],
			MAIN.[TransactionID],
			MAIN.[CreateUser],
			MAIN.[CreateDate],
			MAIN.[fullname],
			MAIN.[CategoryName]
			, 1
		FROM (
			SELECT ISNULL(TD.[SKU], ISNULL(TD.[ASIN],'')) AS [SKU],
				(CASE WHEN ISNULL(TD.[SKU],'') = '' THEN TD.[Fnsku]
					ELSE CONVERT(NVARCHAR, (SELECT [Inventory].[dbo].[fn_get_lampsku](CAST(IIF(ISNUMERIC(TD.[SKU]) = 1, TD.[SKU], 0) as int))))
					+ '-' +
					CONVERT(NVARCHAR, 
						CONVERT(INT, (SELECT [Inventory].[dbo].[fn_Get_Global_Stock](CAST(IIF(ISNUMERIC((SELECT [Inventory].[dbo].[fn_get_lampsku](cast(iif(isnumeric(TD.[SKU]) = 1, TD.[SKU], 0) as int)))) = 1, (SELECT [Inventory].[dbo].[fn_get_lampsku](cast(iif(isnumeric(TD.[SKU]) = 1, TD.[SKU], 0) as int))), 0) as int))) )
					)
					+ ',' +
					CONVERT(NVARCHAR, (SELECT [Inventory].[dbo].[fn_get_kitsku](CAST(IIF(ISNUMERIC(TD.[SKU]) = 1, TD.[SKU], 0) as int))))
					+ '-' +
					CONVERT(NVARCHAR, 
						CONVERT(INT, (SELECT [Inventory].[dbo].[fn_Get_Global_Stock](CAST(IIF(ISNUMERIC((SELECT [Inventory].[dbo].[fn_get_kitsku](cast(iif(isnumeric(TD.[SKU]) = 1, TD.[SKU], 0) as int)))) = 1, (SELECT [Inventory].[dbo].[fn_get_kitsku](cast(iif(isnumeric(TD.[SKU]) = 1, TD.[SKU], 0) as int))), 0) as int))) )
					)
				END) AS [Bin_ID],
				TD.[RequestedQuantity], TD.[TransactionID], T.[CreateUser], T.[CreateDate], U.[fullname], C.Name AS CategoryName
			FROM [WebStation].[FX].[TransactionDetail] TD WITH(NOLOCK)
			INNER JOIN [WebStation].[FX].[Transaction] T WITH(NOLOCK)
			ON T.[TransactionID] = TD.[TransactionID] AND T.[isActive] = 1
			LEFT OUTER JOIN [Inventory].[dbo].[Users] U WITH(NOLOCK)
			ON U.[usr] = T.[CreateUser]
			LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
			ON CONVERT(NVARCHAR,PC.ID) = TD.SKU
			LEFT OUTER JOIN Inventory.dbo.Categories C WITH(NOLOCK)
			ON C.ID = PC.CategoryID
			WHERE [Bin_ID] IS NULL AND CONVERT(NVARCHAR, TD.[TransactionID]) = (CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID ELSE CONVERT(NVARCHAR, TD.[TransactionID]) END)
		) MAIN
		GROUP BY MAIN.[SKU], MAIN.[Bin_ID], MAIN.[CreateUser], MAIN.[TransactionID], MAIN.[CreateDate], MAIN.[fullname], MAIN.CategoryName

		INSERT INTO @TMPRESULT (Bin_ID,RequestedQuantity,CategoryName,SEQ, CreateDate, CreateUser, fullname, TransactionID)
		SELECT CategoryName+'		Total: ', SUM(RequestedQuantity), CategoryName,0, CreateDate, CreateUser, fullname, TransactionID FROM @TMPRESULT WHERE SEQ = 1 GROUP BY CategoryName, CreateDate, CreateUser, fullname, TransactionID

		SELECT MAIN.[SKU],
			MAIN.[Bin_ID],
			MAIN.[RequestedQuantity],
			MAIN.[TransactionID],
			MAIN.[CreateUser],
			MAIN.[CreateDate],
			MAIN.[fullname],
			@iTotalQty TOTAL_QTY,
			@iTotalOrders TOTAL_ORDERS,
			@iTotalItems TOTAL_ITEMS,
			@pOption [OPTION] 
		FROM @TMPRESULT MAIN ORDER BY CategoryName, SKU, SEQ
	END
	ELSE IF @pOption = 'MAIN_REPORT'
	BEGIN
		SELECT [TransactionID], 
			   [CreateUser],
			   [CreateDate],
			   CASE WHEN [Status] = 1 THEN 'In progress...' ELSE 'Complete' END AS [STATUS],
			   CASE WHEN [Status] = 1 THEN '\library\images\cancel_Blue.png' ELSE '\library\images\icnPdf_Blue.png' END AS [image],
			   CONVERT(INT, ISNULL([Status], 0)) AS isActive
		  FROM [WebStation].[FX].[Transaction] TD WITH(NOLOCK)
		 WHERE [isActive] = 1
		   AND CONVERT(NVARCHAR, TD.[TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
														   ELSE CONVERT(NVARCHAR, TD.[TransactionID])
													   END
		ORDER BY TransactionID DESC
	END
	ELSE IF @pOption = 'DETAIL_REPORT'
	BEGIN
		SELECT [OrderId],
			   [Fnsku],
			   [RequestedQuantity],
			   [PickTaskId],
			   [ASIN],
			   [SKU],
			   [Bin_ID],
			   [ASIN] + [BrandMentioned] AS [BrandMentioned] 
		  FROM [WebStation].[FX].[TransactionDetail] TD WITH(NOLOCK)
		 WHERE CONVERT(NVARCHAR, TD.[TransactionID]) = CASE WHEN ISNULL(@pTransactionID, '') <> '' THEN @pTransactionID
														   ELSE CONVERT(NVARCHAR, TD.[TransactionID])
													   END
	END
END
/*
EXEC [Inventory].[dbo].[sp_FlexTransaction] @pOption = 'ONSTOCK', @pTransactionID = '1024078'
EXEC [Inventory].[dbo].[sp_FlexTransaction] @pOption = 'OUTSTOCK', @pTransactionID = '1024078'
EXEC [Inventory].[dbo].[sp_FlexTransaction] @pOption = 'MAIN_REPORT', @pTransactionID = '1024078'
EXEC [Inventory].[dbo].[sp_FlexTransaction] @pOption = 'DETAIL_REPORT', @pTransactionID = '1024078'
*/
go

