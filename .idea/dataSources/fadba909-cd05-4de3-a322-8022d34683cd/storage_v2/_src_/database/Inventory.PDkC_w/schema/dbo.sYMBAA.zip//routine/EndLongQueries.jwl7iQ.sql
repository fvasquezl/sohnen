
/**
* Owner: Ankit Gulati
* Date: 4-23-13
* This function kills the processes that takes long time. 
*/


CREATE PROCEDURE [dbo].[EndLongQueries]
AS
BEGIN

SET NOCOUNT ON

DECLARE @emaildba varchar(100), @subject varchar(256), @body varchar(8000), @killcmd INT

--SET @emaildba = {emailaddresses}
SET @killcmd = 0


DECLARE @servername varchar(256), @loginid varchar(256), @ntdomain varchar(100), @ntusername varchar(100),
	@hostname varchar(255), @hostproc varchar(10), @spid varchar(10), @execcont varchar(10), @waittype varchar(256),
	@waitresource varchar(255), @waittime varchar(10), @blockedby varchar(10), @starttime datetime, @runtimesecs varchar(10),
	@runtimemin varchar(10), @status varchar(20), @dbname varchar(255), @commandtype varchar(25), @sqllen int, @sqlcmd varchar(max)

DECLARE longquery CURSOR FOR
	select 
	@@SERVERNAME as ServerName,
	sproc.loginame LoginID,
	sproc.nt_domain AS NTDomain,
	sproc.nt_username AS NTUserName,
	sproc.Hostname AS HostName,
	sproc.hostprocess,
	sproc.spid AS Session_ID,
	sproc.ecid AS Execution_Context,
	sproc.lastwaittype AS Wait_Type, 
	sproc.waitresource AS Wait_Resource,
	sproc.waittime AS Wait_Time, 
	CASE WHEN sproc.blocked = 0 THEN 0 ELSE sproc.blocked END as BlockedBy,
	sproc.last_batch Started_At,
	datediff(second,sproc.last_batch,getdate()) AS Elapsed_Seconds,
	datediff(mi,sproc.last_batch,getdate()) AS Elapsed_Mins,
	sproc.status AS [Status], 
	DB_NAME(sproc.dbid) AS DBName,
	sproc.cmd AS Command,
	len(sqltext.TEXT) SQL_Length,
	SUBSTRING(sqltext.text, (sproc.stmt_start/2)+1, 
        ((CASE sproc.stmt_end
          WHEN -1 THEN DATALENGTH(sqltext.text)
         ELSE sproc.stmt_end
         END - sproc.stmt_start)/2) + 1) AS Query_SQL
	--,sproc.*
	from master.sys.sysprocesses sproc
	OUTER APPLY master.sys.dm_exec_sql_text(sproc.sql_handle) AS sqltext
	where sproc.spid <> @@SPID
	AND sproc.spid > 50
	AND sproc.cmd <> 'AWAITING COMMAND'
	AND sproc.cmd <> 'WAITFOR'
	AND datediff(mi,sproc.last_batch,getdate()) > 60  -- Running longer than 2 hours = 120. Setting it to 1 hour(60)
	ORDER BY sproc.spid, sproc.ecid


OPEN longquery
FETCH NEXT FROM longquery INTO @servername, @loginid, @ntdomain, @ntusername,
		@hostname, @hostproc, @spid, @execcont, @waittype,
		@waitresource, @waittime, @blockedby, @starttime, @runtimesecs,
		@runtimemin, @status, @dbname, @commandtype, @sqllen, @sqlcmd

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @killcmd = 0

	-- Auto KILL any user process running longer than x mins
	IF @runtimemin > 65  
		SET @killcmd = 1

	-- Auto kill any user process over x Mins with no WHERE clause
	IF @runtimemin > 180 AND CHARINDEX('WHERE',@sqlcmd) = 0
		SET @killcmd = 1

	IF @killcmd = 1
	BEGIN
		SET @subject = 'KILLED: ' + @servername + ' SPID: ' + @spid + ' process running for ' + @runtimemin + ' Mins'
		DECLARE @sql varchar(1000)
		SET @sql = 'KILL ' + @spid + ';'
		EXEC (@sql)
	END
	ELSE
	BEGIN
		SET @subject = CASE WHEN @blockedby <> 0 THEN 'Blocked: ' ELSE 'Warning: ' END + @servername + ' SPID: ' + @spid + ' Runtime: ' + @runtimemin + ' Mins'
	END

	--SET @body = 'Server: ' + @servername + CHAR(10) 
	--SET @body = @body + 'SPID: ' + @spid + CHAR(10) 
	--SET @body = @body + 'Start: ' + CONVERT(varchar(25), @starttime, 120) + ' Running for: ' + @runtimemin + ' Mins' + CHAR(10) 
	--SET @body = @body + 'Username: ' + @loginid + CHAR(10) 
	--SET @body = @body + 'Database: ' + @dbname + CHAR(10) 
	--SET @body = @body + 'Wait: ' + RTRIM(@waittype) + ' ' + @waittime + 'ms ' + CASE WHEN @blockedby <> 0 THEN 'Blocked By SPID: ' + @blockedby ELSE '' END+ CHAR(10) 
	--SET @body = @body + 'From Host: ' + RTRIM(@hostname) + ' PID: ' + @hostproc + CHAR(10) 
	--SET @body = @body + CHAR(10) + 'Query: ' + LEFT(@sqlcmd,100) + CHAR(10) 
	--SET @body = @body + CHAR(10) + CHAR(10) + '******* THIS IS AN UNMONITORED MAILBOX.  DO NOT REPLY TO THIS EMAIL ******* ' + CHAR(10) 

	PRINT @subject
	PRINT @body

	-- Send email
	--EXEC msdb.dbo.sp_send_dbmail @recipients = @emaildba, @subject=@subject, @body=@body, @body_format = 'TEXT'


	FETCH NEXT FROM longquery INTO @servername, @loginid, @ntdomain, @ntusername,
		@hostname, @hostproc, @spid, @execcont, @waittype,
		@waitresource, @waittime, @blockedby, @starttime, @runtimesecs,
		@runtimemin, @status, @dbname, @commandtype, @sqllen, @sqlcmd
END

CLOSE longquery
DEALLOCATE longquery

SET NOCOUNT OFF

END
go

