-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 5-5-2016
-- Description:	Vendor Central Loader Mexico
-- =============================================
CREATE PROCEDURE [dbo].[sp_VendorCentralLoaderMexico]
	-- Add the parameters for the stored procedure here
 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

			Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKU] + '-L01-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCEconomy] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'TV-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-l01' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Economy)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			CEILING(CASE WHEN PJD.[Brand] = 'Toshiba' THEN (35*1.16)*19 ELSE (19*1.16)*19 END) AS 'Coste neto unitario en factura (IVA excluido)',
			CEILING(CASE WHEN PJD.[Brand] = 'Toshiba' THEN (69.99*1.16)*19 ELSE (49.99*1.16)*19 END)-0.01 AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'TV' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'TV' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',TV de proyeccion,TV,Television,DLP,LCD,proyeccion,Lampara,foco,Bombilla,Cartucho,modulo,Reemplazo,Compatible,generico,OEM compatible,pelicula,video',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema Economy proveen una opcion economica para su televisor de proyeccion','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo con "Philips" que restaurara el brillo al 100% y dura mas tiempo! Este cambio en la seleccion puede ser hecho en la variacion de seleccion arriba.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo con "Phoenix" que restaurara el brillo al 100% y dura mas tiempo! Este cambio en la seleccion puede ser hecho en la variacion de seleccion arriba. ',256)
			ELSE LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo con Lutema Premium que da brillo y dura mas tiempo! Este cambio en la seleccion puede ser hecho en la variacion de seleccion arriba.',256)
			END) AS 'Caracteristica 4',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Philips para la mejor calidad de imagen, brillo y duracion de vida.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Phoenix para la mejor calidad de imagen, brillo y duracion de vida.',256)
			ELSE LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Premium para la mejor calidad de imagen, brillo y duracion de vida.',256)
			END) AS 'Caracteristica 5',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion economica para el reemplazo de la lampara de su Television de proyeccion '+[PJD].[brand]+' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo con "Philips". Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.   Esta lampara provee una opcion economica para el reemplazo de la lampara de su Television de proyeccion '+[PJD].[brand]+' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo con "Phoenoix". Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			ELSE LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion economica para el reemplazo de la lampara de su Television de proyeccion ' + PJD.[Brand] + ' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo Premium. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			END) AS 'Descripcion Larga del Producto',
			'3 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKU] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKU] = GS.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHILIPSSTOCK ON (PJD.[EncSKUPH] = GETPHILIPSSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHILIPSALWAYS ON (PJD.[EncSKUPH] = GETPHILIPSALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETOSRAMSTOCK ON (PJD.[EncSKUOS] = GETOSRAMSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETOSRAMALWAYS ON (PJD.[EncSKUPH] = GETOSRAMALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHOENIXSTOCK ON (PJD.[EncSKUPX] = GETPHOENIXSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHOENIXALWAYS ON (PJD.[EncSKUPH] = GETPHOENIXALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETUSHIOSTOCK ON (PJD.[EncSKUUSH] = GETUSHIOSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETUSHIOALWAYS ON (PJD.[EncSKUPH] = GETUSHIOALWAYS.[ID])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKU] != '-' AND PJD.[EncSKU] IS NOT NULL
			 AND PJD.[UPCEconomy] != '' AND PJD.[UPCEconomy] IS NOT NULL 
			 AND PJD.[Type] = 'TV'
			 AND PJD.[PartNumber] NOT LIKE '%SML%'
 
			 UNION ALL

			 Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKU] + '-L02-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCPremium] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'TV-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-l02' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Premium)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			CEILING(CASE WHEN PJD.[Brand] = 'Toshiba' THEN (45*1.16)*19 ELSE (24*1.16)*19 END) AS 'Coste neto unitario en factura (IVA excluido)',
			CEILING(CASE WHEN PJD.[Brand] = 'Toshiba' THEN (89.99*1.16)*19 ELSE (69.99*1.16)*19 END)-0.01 AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'TV' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'TV' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',TV de proyeccion,TV,Television,DLP,LCD,proyeccion,Lampara,foco,Bombilla,Cartucho,modulo,Reemplazo,Compatible,generico,OEM compatible,pelicula,video',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema Premium proveen una opcion mediano para su televisor de proyeccion','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo "Philips" que restaurara el brillo al 100% y dura mas tiempo! Este cambio puede ser hecho en la variacion de seleccion  arriba.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo "Phoenix" que restaurara el brillo al 100% y dura mas tiempo! Este cambio puede ser hecho en la variacion de seleccion  arriba.',256)
			ELSE LEFT('Este articulo es solo una opcion economica.',256)
			END) AS 'Caracteristica 4',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Philips para la mejor calidad de imagen, brillo y duracion de vida.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Phoenix para la mejor calidad de imagen, brillo y duracion de vida.',256)
			ELSE LEFT('NOTA: Este articulo es solo una opcion economica e presente la mejor calidad de imagen, brillo y duracion de vida.',256)
			END) AS 'Caracteristica 5',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT(REPLACE('Lampara de reemplazo Lutema Premium para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion economica para el reemplazo de la lampara de su Television de proyeccion '+[PJD].[brand]+' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo con "Philips". Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.   Esta lampara provee una opcion economica para el reemplazo de la lampara de su Television de proyeccion '+[PJD].[brand]+' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo con "Phoenix". Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			ELSE LEFT(REPLACE('Lampara de reemplazo Lutema Premium para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion economica para el reemplazo de la lampara de su Television de proyeccion ' + PJD.[Brand] + ' DLP / LCD. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			END) AS 'Descripcion Larga del Producto',
			'6 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKU] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKU] = GS.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHILIPSSTOCK ON (PJD.[EncSKUPH] = GETPHILIPSSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHILIPSALWAYS ON (PJD.[EncSKUPH] = GETPHILIPSALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETOSRAMSTOCK ON (PJD.[EncSKUOS] = GETOSRAMSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETOSRAMALWAYS ON (PJD.[EncSKUPH] = GETOSRAMALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHOENIXSTOCK ON (PJD.[EncSKUPX] = GETPHOENIXSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHOENIXALWAYS ON (PJD.[EncSKUPH] = GETPHOENIXALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETUSHIOSTOCK ON (PJD.[EncSKUUSH] = GETUSHIOSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETUSHIOALWAYS ON (PJD.[EncSKUPH] = GETUSHIOALWAYS.[ID])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKU] != '-' AND PJD.[EncSKU] IS NOT NULL
			 AND PJD.[UPCPremium] != '' AND PJD.[UPCPremium] IS NOT NULL 
			 AND PJD.[Type] = 'TV'
			 AND PJD.[PartNumber] NOT LIKE '%SML%'
 
			 UNION ALL

			 Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKUPH] + '-P01-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCPhilips] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'TV-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-p01' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Philips)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			CEILING(CASE WHEN PJD.[Brand] = 'Toshiba' THEN (80*1.16)*19 ELSE (70*1.16)*19 END) AS 'Coste neto unitario en factura (IVA excluido)',
			CEILING(CASE WHEN PJD.[Brand] = 'Toshiba' THEN (139.99*1.16)*19 ELSE (129.99*1.16)*19 END)-0.01 AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'TV' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'TV' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',TV de proyeccion,TV,Television,DLP,LCD,proyeccion,Lampara,foco,Bombilla,Cartucho,modulo,Reemplazo,Compatible,Philips,OEM Philips,pelicula,video',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema con Philips proveen la mejor opcion para su televisor de proyeccion','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('Este articulo es solo la mejor opcion! La Lampara de Reemplazo con "Philips" restaurara el brillo al 100% y dura mas tiempo!',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('Este articulo es solo la mejor opcion! La Lampara de Reemplazo con "Phoenix" restaurara el brillo al 100% y dura mas tiempo!',256)
			ELSE LEFT('Este articulo es solo la mejor opcion!',256)
			END) AS 'Caracteristica 4',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('NOTA: Este articulo es la mejor opcion. La Lutema con Philips les da el mejor calidad de imagen, brillo y duracion de vida.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('NOTA: Este articulo es la mejor opcion. La Lutema con Philips les da el mejor calidad de imagen, brillo y duracion de vida.',256)
			ELSE LEFT('NOTA: Este articulo es la mejor opcion e presente la mejor calidad de imagen, brillo y duracion de vida.',256)
			END) AS 'Caracteristica 5',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT(REPLACE('Lampara de reemplazo Lutema Philips para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee la mejor opcion para el reemplazo de la lampara de su Television de proyeccion '+[PJD].[brand]+' DLP / LCD. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.   Esta lampara provee la mejor opcion para el reemplazo de la lampara de su Television de proyeccion '+[PJD].[brand]+' DLP / LCD. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			ELSE LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una la mejor opcion para el reemplazo de la lampara de su Television de proyeccion ' + PJD.[Brand] + ' DLP / LCD. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			END) AS 'Descripcion Larga del Producto',
			'6 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKUPH] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKUPH] = GS.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHILIPSSTOCK ON (PJD.[EncSKUPH] = GETPHILIPSSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHILIPSALWAYS ON (PJD.[EncSKUPH] = GETPHILIPSALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETOSRAMSTOCK ON (PJD.[EncSKUOS] = GETOSRAMSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETOSRAMALWAYS ON (PJD.[EncSKUPH] = GETOSRAMALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHOENIXSTOCK ON (PJD.[EncSKUPX] = GETPHOENIXSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHOENIXALWAYS ON (PJD.[EncSKUPH] = GETPHOENIXALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETUSHIOSTOCK ON (PJD.[EncSKUUSH] = GETUSHIOSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETUSHIOALWAYS ON (PJD.[EncSKUPH] = GETUSHIOALWAYS.[ID])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKUPH] != '-' AND PJD.[EncSKUPH] IS NOT NULL
			 AND PJD.[UPCPhilips] != '' AND PJD.[UPCPhilips] IS NOT NULL 
			 AND PJD.[Type] = 'TV'
			 AND PJD.[PartNumber] NOT LIKE '%SML%'

			UNION ALL

			Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKUPX] + '-P02-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCPhilips] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'TV-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-p02' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Philips)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			CEILING(CASE WHEN PJD.[Brand] = 'Toshiba' THEN (85*1.16)*19 ELSE (75*1.16)*19 END) AS 'Coste neto unitario en factura (IVA excluido)',
			CEILING(CASE WHEN PJD.[Brand] = 'Toshiba' THEN (139.99*1.16)*19 ELSE (129.99*1.16)*19 END)-0.01 AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'TV' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'TV' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',TV de proyeccion,TV,Television,DLP,LCD,proyeccion,Lampara,Bombilla,Cartucho,modulo,Reemplazo,Phoenix,generico,OEM Phoenix,pelicula,video',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema con Philips proveen la mejor opcion para su televisor de proyeccion','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('Este articulo es solo la mejor opcion! La Lampara de Reemplazo con "Philips" restaurara el brillo al 100% y dura mas tiempo!',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('Este articulo es solo la mejor opcion! La Lampara de Reemplazo con "Phoenix" restaurara el brillo al 100% y dura mas tiempo!',256)
			ELSE LEFT('Este articulo es solo la mejor opcion!',256)
			END) AS 'Caracteristica 4',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('NOTA: Este articulo es la mejor opcion. La Lutema con Philips les da el mejor calidad de imagen, brillo y duracion de vida.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('NOTA: Este articulo es la mejor opcion. La Lutema con Philips les da el mejor calidad de imagen, brillo y duracion de vida.',256)
			ELSE LEFT('NOTA: Este articulo es la mejor opcion e presente la mejor calidad de imagen, brillo y duracion de vida.',256)
			END) AS 'Caracteristica 5',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT(REPLACE('Lampara de reemplazo Lutema Philips para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee la mejor opcion para el reemplazo de la lampara de su Television de proyeccion '+[PJD].[brand]+' DLP / LCD. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.   Esta lampara provee la mejor opcion para el reemplazo de la lampara de su Television de proyeccion '+[PJD].[brand]+' DLP / LCD. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			ELSE LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una la mejor opcion para el reemplazo de la lampara de su Television de proyeccion ' + PJD.[Brand] + ' DLP / LCD. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			END) AS 'Descripcion Larga del Producto',
			'6 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKUPX] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKUPX] = GS.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHILIPSSTOCK ON (PJD.[EncSKUPH] = GETPHILIPSSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHILIPSALWAYS ON (PJD.[EncSKUPH] = GETPHILIPSALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETOSRAMSTOCK ON (PJD.[EncSKUOS] = GETOSRAMSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETOSRAMALWAYS ON (PJD.[EncSKUPH] = GETOSRAMALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHOENIXSTOCK ON (PJD.[EncSKUPX] = GETPHOENIXSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHOENIXALWAYS ON (PJD.[EncSKUPH] = GETPHOENIXALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETUSHIOSTOCK ON (PJD.[EncSKUUSH] = GETUSHIOSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETUSHIOALWAYS ON (PJD.[EncSKUPH] = GETUSHIOALWAYS.[ID])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKUPX] != '-' AND PJD.[EncSKUPX] IS NOT NULL
			 AND PJD.[UPCPhilips] != '' AND PJD.[UPCPhilips] IS NOT NULL 
			 AND PJD.[Type] = 'TV'
			 AND PJD.[PartNumber] NOT LIKE '%SML%' 

			UNION ALL

			Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKU] + '-L01-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCEconomy] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'FP-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-l01' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Economy)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			Ceiling(IsNull(CAST(((Select [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PJD.[EncSKU]) * 1.4) + 8)*1.16 AS Decimal(10,2)),60)*19) AS 'Coste neto unitario en factura (IVA excluido)',
			(Ceiling(((IsNull(CAST(Round((PC.PriceFloor * 1.7),2) + 70.99 AS Decimal(10,2)),'149.99'))*1.16)*19)-0.01) AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',proyeccion,Cine,Cinema,pelicula,video,Video Wall,video en pared,Proyector,proyeccion,lampara,Bombilla,foco,Cartucho,modulo,reemplazo,Compatible,generico,OEM Compatible ',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema Economy proveen una opcion economica para su proyector.','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo con "Philips" que restaurara el brillo al 100% y dura mas tiempo! Este cambio en la seleccion puede ser hecho en la variacion de seleccion  arriba.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo con "Phoenix" que restaurara el brillo al 100% y dura mas tiempo! Este cambio en la seleccion puede ser hecho en la variacion de seleccion arriba. ',256)
			ELSE LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo con Lutema Premium que da brillo y dura mas tiempo! Este cambio en la seleccion puede ser hecho en la variacion de seleccion arriba.',256)
			END) AS 'Caracteristica 4',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Philips para la mejor calidad de imagen, brillo y duracion de vida.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Phoenix para la mejor calidad de imagen, brillo y duracion de vida.',256)
			ELSE LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Premium para la mejor calidad de imagen, brillo y duracion de vida.',256)
			END) AS 'Caracteristica 5',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion economica para el reemplazo de la lampara de su proyector '+[PJD].[brand]+' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo con "Philips". Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.   Esta lampara provee una opcion economica para el reemplazo de la lampara de su proyector '+[PJD].[brand]+' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo con "Phoenoix". Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			ELSE LEFT(REPLACE('Lampara de reemplazo Lutema Economy para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion economica para el reemplazo de la lampara de su proyector ' + PJD.[Brand] + ' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo Premium. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			END) AS 'Descripcion Larga del Producto',
			'3 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKU] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKU] = GS.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHILIPSSTOCK ON (PJD.[EncSKUPH] = GETPHILIPSSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHILIPSALWAYS ON (PJD.[EncSKUPH] = GETPHILIPSALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETOSRAMSTOCK ON (PJD.[EncSKUOS] = GETOSRAMSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETOSRAMALWAYS ON (PJD.[EncSKUPH] = GETOSRAMALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHOENIXSTOCK ON (PJD.[EncSKUPX] = GETPHOENIXSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHOENIXALWAYS ON (PJD.[EncSKUPH] = GETPHOENIXALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETUSHIOSTOCK ON (PJD.[EncSKUUSH] = GETUSHIOSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETUSHIOALWAYS ON (PJD.[EncSKUPH] = GETUSHIOALWAYS.[ID])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKU] != '-' AND PJD.[EncSKU] IS NOT NULL
			 AND PJD.[UPCEconomy] != '' AND PJD.[UPCEconomy] IS NOT NULL 
			 AND PJD.[Type] = 'FP'
			 AND PJD.[PartNumber] NOT LIKE '%SML%'
 
			 UNION ALL

			 Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKU] + '-L02-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCPremium] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'FP-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-l02' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Premium)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			Ceiling(IsNull(CAST(((Select [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PJD.[EncSKU]) * 1.6) + 8)*1.16 AS Decimal(10,2)),60)*19) AS 'Coste neto unitario en factura (IVA excluido)',
			(Ceiling(((IsNull(CAST(Round((PC.PriceFloor * 2),2) + 70.99 AS Decimal(10,2)),'149.99'))*1.16)*19)-0.01) AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',proyeccion,Cine,Cinema,pelicula,video,Video Wall,video en pared,Proyector,proyeccion,lampara,Bombilla,foco,Cartucho,modulo,reemplazo,Compatible,generico,OEM Compatible ',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema Premium proveen una opcion economica para su proyector.','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo "Philips" que restaurara el brillo al 100% y dura mas tiempo! Este cambio puede ser hecho en la variacion de seleccion arriba.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('Este articulo es solo una opcion economica. Recomendamos seleccionar la Lampara de Reemplazo "Phoenix" que restaurara el brillo al 100% y dura mas tiempo! Este cambio puede ser hecho en la variacion de seleccion arriba.',256)
			ELSE LEFT('Este articulo es solo una opcion economica.',256)
			END) AS 'Caracteristica 4',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Philips para la mejor calidad de imagen, brillo y duracion de vida.',256)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT('NOTA: Este articulo es solo una opcion economica. Recomendamos seleccionar nuestro opcion de Phoenix para la mejor calidad de imagen, brillo y duracion de vida.',256)
			ELSE LEFT('NOTA: Este articulo es solo una opcion economica.',256)
			END) AS 'Caracteristica 5',
			(CASE WHEN (PJD.[EncSKUPH] != '-' AND (GETPHILIPSSTOCK.[TotalStock] > 0 OR GETPHILIPSALWAYS.[AlwaysInStock] = '1')) THEN LEFT(REPLACE('Lampara de Reemplazo Lutema Premium para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion economica para el reemplazo de la lampara de su proyector '+[PJD].[brand]+' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo con "Philips". Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			WHEN (PJD.[EncSKUPX] != '-' AND (GETPHOENIXSTOCK.[TotalStock] > 0 OR GETPHOENIXALWAYS.[AlwaysInStock] = '1')) AND (PJD.[EncSKUPH] = '-') THEN LEFT(REPLACE('Lampara de Reemplazo Lutema Premium para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.   Esta lampara provee una opcion economica para el reemplazo de la lampara de su proyector '+[PJD].[brand]+' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo con "Phoenoix". Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			ELSE LEFT(REPLACE('Lampara de Reemplazo Lutema Premium para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion economica para el reemplazo de la lampara de su proyector ' + PJD.[Brand] + ' DLP / LCD. Para un brillo optimo y vida de larga duracion - Escoja la Lampara de Reemplazo Premium. Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000)
			END) AS 'Descripcion Larga del Producto',
			'6 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKU] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKU] = GS.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHILIPSSTOCK ON (PJD.[EncSKUPH] = GETPHILIPSSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHILIPSALWAYS ON (PJD.[EncSKUPH] = GETPHILIPSALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETOSRAMSTOCK ON (PJD.[EncSKUOS] = GETOSRAMSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETOSRAMALWAYS ON (PJD.[EncSKUPH] = GETOSRAMALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETPHOENIXSTOCK ON (PJD.[EncSKUPX] = GETPHOENIXSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETPHOENIXALWAYS ON (PJD.[EncSKUPH] = GETPHOENIXALWAYS.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GETUSHIOSTOCK ON (PJD.[EncSKUUSH] = GETUSHIOSTOCK.[ProductCatalogId])
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS GETUSHIOALWAYS ON (PJD.[EncSKUPH] = GETUSHIOALWAYS.[ID])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKU] != '-' AND PJD.[EncSKU] IS NOT NULL
			 AND PJD.[UPCPremium] != '' AND PJD.[UPCPremium] IS NOT NULL 
			 AND PJD.[Type] = 'FP'
			 AND PJD.[PartNumber] NOT LIKE '%SML%'
 
			 UNION ALL

			 --PHILIPS
			Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKUPH] + '-P01-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCPhilips] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'FP-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-p01' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Philips Inside)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			Ceiling(IsNull(CAST(((PC.[UnitCost] * 1.4) + 6)*1.16 AS Decimal(10,2)),60)*19) AS 'Coste neto unitario en factura (IVA excluido)',
			(Ceiling(((IsNull(CAST(Round((PC.PriceFloor * 2),2) + 70.99 AS Decimal(10,2)),'149.99'))*1.16)*19)-0.01) AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',proyeccion,Cine,Cinema,pelicula,video,Video Wall,video en pared,Proyector,proyeccion,lampara,Bombilla,foco,Cartucho,modulo,reemplazo,Compatible,Philips,OEM Compatible ',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema "Philips Inside" proveen una opcion optimizada para su proyector.','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			LEFT('Este articulo es la Lampara de Reemplazo "Philips" que restaurara el brillo al 100% y dura mas tiempo!',256) AS 'Caracteristica 4',
			LEFT('NOTA: Este articulo es la mejor opcion y provee la mejor calidad de imagen, brillo y duracion de vida.',256) AS 'Caracteristica 5',
			LEFT(REPLACE('Lampara de Reemplazo Lutema "Philips Inside" para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion optimizada para su proyector '+[PJD].[brand]+' DLP / LCD.  Escoja la Lampara de Reemplazo con "Philips" para un imagen impecable y con maximo brillo!  Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000) AS 'Descripcion Larga del Producto',
			'9 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKUPH] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKUPH] = GS.[ProductCatalogId])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKUPH] != '-' AND PJD.[EncSKUPH] IS NOT NULL
			 AND PJD.[UPCPhilips] != '' AND PJD.[UPCPhilips] IS NOT NULL 
			 AND PJD.[Type] = 'FP'
			 AND PJD.[PartNumber] NOT LIKE '%SML%'
			 --Exclude items that we don't have costs correct in the system.
			 AND PC.UnitCost < 250 AND PC.PriceFloor < 300


			 UNION ALL

			--OSRAM
			Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKUOS] + '-P02-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCPhilips] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'FP-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-p02' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Osram Inside)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			Ceiling(IsNull(CAST(((PC.[UnitCost] * 1.4) + 6)*1.16 AS Decimal(10,2)),60)*19) AS 'Coste neto unitario en factura (IVA excluido)',
			(Ceiling(((IsNull(CAST(Round((PC.PriceFloor * 2),2) + 70.99 AS Decimal(10,2)),'149.99'))*1.16)*19)-0.01) AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',proyeccion,Cine,Cinema,pelicula,video,Video Wall,video en pared,Proyector,proyeccion,lampara,Bombilla,foco,Cartucho,modulo,reemplazo,Compatible,Osram,OEM Compatible ',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema "Osram Inside" proveen una opcion optimizada para su proyector.','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			LEFT('Este articulo es la Lampara de Reemplazo "Osram" que restaurara el brillo al 100% y dura mas tiempo!',256) AS 'Caracteristica 4',
			LEFT('NOTA: Este articulo es la mejor opcion y provee la mejor calidad de imagen, brillo y duracion de vida.',256) AS 'Caracteristica 5',
			LEFT(REPLACE('Lampara de Reemplazo Lutema "Osram Inside" para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion optimizada para su proyector '+[PJD].[brand]+' DLP / LCD.  Escoja la Lampara de Reemplazo con "Osram" para un imagen impecable y con maximo brillo!  Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000) AS 'Descripcion Larga del Producto',
			'9 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKUOS] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKUOS] = GS.[ProductCatalogId])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKUOS] != '-' AND PJD.[EncSKUOS] IS NOT NULL
			 AND PJD.[UPCPhilips] != '' AND PJD.[UPCPhilips] IS NOT NULL 
			 AND PJD.[Type] = 'FP'
			 AND PJD.[PartNumber] NOT LIKE '%SML%'
			 --Exclude items that we don't have costs correct in the system.
			 AND PC.UnitCost < 250 AND PC.PriceFloor < 300
			  --If Philips exists, don't make competing item
			 AND (PJD.[EncSKUPH] = '-' OR PJD.[EncSKUPH] IS NULL)

			 UNION ALL

			 --Phoenix
			Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKUPX] + '-P03-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCPhilips] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'FP-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-p03' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Phoenix Inside)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			Ceiling(IsNull(CAST(((PC.[UnitCost] * 1.4) + 6)*1.16 AS Decimal(10,2)),60)*19) AS 'Coste neto unitario en factura (IVA excluido)',
			(Ceiling(((IsNull(CAST(Round((PC.PriceFloor * 2),2) + 70.99 AS Decimal(10,2)),'149.99'))*1.16)*19)-0.01) AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',proyeccion,Cine,Cinema,pelicula,video,Video Wall,video en pared,Proyector,proyeccion,lampara,Bombilla,foco,Cartucho,modulo,reemplazo,Compatible,Phoenix,OEM Compatible ',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema "Phoenix Inside" proveen una opcion optimizada para su proyector.','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			LEFT('Este articulo es la Lampara de Reemplazo "Phoenix" que restaurara el brillo al 100% y dura mas tiempo!',256) AS 'Caracteristica 4',
			LEFT('NOTA: Este articulo es la mejor opcion y provee la mejor calidad de imagen, brillo y duracion de vida.',256) AS 'Caracteristica 5',
			LEFT(REPLACE('Lampara de Reemplazo Lutema "Phoenix Inside" para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion optimizada para su proyector '+[PJD].[brand]+' DLP / LCD.  Escoja la Lampara de Reemplazo con "Phoenix" para un imagen impecable y con maximo brillo!  Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000) AS 'Descripcion Larga del Producto',
			'9 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKUPX] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKUPX] = GS.[ProductCatalogId])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKUPX] != '-' AND PJD.[EncSKUPX] IS NOT NULL
			 AND PJD.[UPCPhilips] != '' AND PJD.[UPCPhilips] IS NOT NULL 
			 AND PJD.[Type] = 'FP'
			 AND PJD.[PartNumber] NOT LIKE '%SML%'
			 --Exclude items that we don't have costs correct in the system.
			 AND PC.UnitCost < 250 AND PC.PriceFloor < 300
			--If Philips or Osram exist, don't make competing item
			 AND (PJD.[EncSKUPH] = '-' OR PJD.[EncSKUPH] IS NULL OR PJD.[EncSKUOS] = '-' OR PJD.[EncSKUOS] IS NULL)


			UNION ALL

			--Ushio
			Select 
			'MI Technologies Internacional S.A. de C.V., mx consumer electronics, MIWXN' AS 'Codigo de Proveedor' ,
			'Si' AS 'Estara disponible el producto para envio directo al cliente?' ,
			PJD.[EncSKUUSH] + '-P04-' + PJD.[CatalogID] AS 'Codigo para Ordenes de Compra',
			'UPC' AS 'Tipo de ID',
			PJD.[UPCPhilips] AS 'Numero de ID',
			'Lutema (LUTED)' AS 'Nombre del producto',
			'Si' AS 'Es una Variacion?',
			'VARIACION_TAMANO' AS 'Nombre del Tipo de Variacion',
			'FP-' + Replace(Replace(PJD.[Brand], '-' ,''), ' ' , '')+'-'+ Replace(Replace(PJD.[PartNumber], '-' ,''), ' ' , '') AS 'Agrupacion por Familia',
			'Lutema (LUTED)' AS 'Marca',
			'' AS 'Nueva Marca',
			LOWER(PJD.[PartNumber]) + '-p04' AS 'Modelo',
			Replace(PJD.[Brand] + ' ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' Lampara de Reemplazo para Television de Proyeccion DLP/LCD Foco (Ushio Inside)', '- Replacement', ' Replacement' ) AS 'Titulo Recomendado para Mostrar',
			'MXN' AS 'Moneda para Costo neto unitario en factura',
			Ceiling(IsNull(CAST(((PC.[UnitCost] * 1.4) + 6)*1.16 AS Decimal(10,2)),60)*19) AS 'Coste neto unitario en factura (IVA excluido)',
			(Ceiling(((IsNull(CAST(Round((PC.PriceFloor * 2),2) + 70.99 AS Decimal(10,2)),'149.99'))*1.16)*19)-0.01) AS 'MSRP - Precio Recomendado al Publico (en MXN, IVA excluido)',
			'Mexico' AS 'Pais de Origen',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Producto (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Longitud del Producto (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Producto (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Producto (kg)',
			'No' AS 'El paquete es pesado/voluminoso?',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '18' ELSE CEILING(Cast(RIGHT(LEFT(PC.[UnitDim],7),3) AS INT)*2.54) END AS INT) AS 'Altura del Paquete (cm)' ,
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '23' ELSE CEILING(Cast(LEFT(PC.[UnitDim],3) AS INT) *2.54) END AS INT) AS 'Longitud del Paquete (cm)',
			CAST(CASE WHEN Left(PC.[UnitDim],1) IS NULL OR Left(PC.[UnitDim],1) = ' ' OR Left(PC.[UnitDim],1) = ' '  THEN '13' ELSE CEILING(Cast(RIGHT(PC.[UnitDim],3) AS INT)*2.54) END AS INT) AS 'Ancho del Paquete (cm)',
			IsNull(CASE WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			WHEN (PC.[UnitWeight] = 0 OR PC.[UnitWeight] IS NULL) AND PJD.[Type] = 'FP' THEN '1' 
			ELSE CEILING(PC.[UnitWeight]/2.2) END,1) AS  'Peso del Paquete (kg)',
			'No' AS 'Se envia en multiples cajas?',
			'Otros Accesorios' AS 'Categoria',
			'Otros A/V' AS 'Subcategoria',
			'Cine En Casa, TV y Video - Accesorios' AS 'Nodo de Navegacion',
			'1' AS 'Productos por Caja',
			'No' AS 'Tiene pantalla?',
			'' AS 'Tamano de Pantalla',
			LEFT(REPLACE(REPLACE((SELECT [Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand],PJD.[PartNumber],'PartNumberSpecific')),'Part Numbers: ',''),' <br><br> Model Numbers: ',',')+',proyeccion,Cine,Cinema,pelicula,video,Video Wall,video en pared,Proyector,proyeccion,lampara,Bombilla,foco,Cartucho,modulo,reemplazo,Compatible,Ushio,OEM Compatible ',75) AS 'Palabras Clave para Busqueda' ,
			LEFT(REPLACE('Remplaza ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + ' - Lampara de reemplazo Lutema "Ushio Inside" proveen una opcion optimizada para su proyector.','- -','-'),256) AS 'Caracteristica 1',
			(CASE WHEN LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) = 'Compatible con los siguientes ' THEN 'Compatible con various modelos.'
			ELSE LEFT('Compatible con los siguientes ' +  REPLACE([Inventory].[dbo].[fn_GetCompatiblityListForEbay](PJD.[Brand], PJD.[PartNumber],'ModelSpecific'),'Model Numbers: ','modelos: '),256) END)  AS 'Caracteristica 2',
			LEFT('Manufacturada en MI Technologies, Inc. - Un producto hecho orgullosamente en Norte America.',256) AS 'Caracteristica 3',
			LEFT('Este articulo es la Lampara de Reemplazo "Ushio" que restaurara el brillo al 100% y dura mas tiempo!',256) AS 'Caracteristica 4',
			LEFT('NOTA: Este articulo es la mejor opcion y provee la mejor calidad de imagen, brillo y duracion de vida.',256) AS 'Caracteristica 5',
			LEFT(REPLACE('Lampara de Reemplazo Lutema "Ushio Inside" para ' + PJD.[Brand] + ' Numero de Parte ' + PJD.[PartNumber] + ' ' + PJD.[PartNumberV2] + '.  Esta lampara provee una opcion optimizada para su proyector '+[PJD].[brand]+' DLP / LCD.  Escoja la Lampara de Reemplazo con "Ushio" para un imagen impecable y con maximo brillo!  Compatible con los siguientes modelos: ' + MITDB.[dbo].[ConcatenateModelsTableTop4](PJD.[Brand], PJD.[PartNumber]),' -.','.'),2000) AS 'Descripcion Larga del Producto',
			'9 meses de garantia' AS 'Guarantia del Producto',
			'' AS 'Color',
			'No' AS 'Son Precisas Baterias?',
			'' AS 'Estan las Baterias Incluidas?',
			'' AS 'Cuantas Baterias Son Precisas?',
			'' AS 'Que Tipo de Baterias?',
			'' AS 'Vida de la Bateria (Horas)',
			'' AS 'Contenido Energetico de las Baterias de Litio',
			'' AS 'Empaquetado de las Baterias de Litio',
			'' AS 'Peso del Litio en Gramos',
			'' AS 'Voltaje de la Bateria de Litio',
			'' AS 'Numero de celulas de METAL litio',
			'' AS 'Numero de celulas de ION litio',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido?',
			'No' AS 'Es el ASIN (producto) un liquido, o contiene un liquido con una temperatura de combustion por debajo de los 200F (93C)?',
			'' AS 'Temperatura de Combustion',
			'No' AS 'Es el ASIN (producto) un aerosol o gas comprimido?',
			'No' AS 'Es el ASIN (producto) un material peligroso de acuerdo a la NOM-002-SCT-2011 y a la NOM-011-SCT2?',
			'' AS 'ID de Material Peligroso de Nacional Unidas',
			'Si' AS 'Esta el etiquetado del producto en espanol?',
			'Si' AS 'Esta el paquete en espanol?',
			'Si' AS 'Viene el producto con manual de instrucciones?',
			'Si' AS 'Esta el manual de instrucciones en espanol?',
			'----' AS '--',
			CAST(GS.[GlobalStock] AS INT) AS [QOH],
			CAST(GS.[VirtualStock] AS INT) AS [vQOH],
			CASE WHEN PC.[AlwaysInStock] = '1' THEN '500' ELSE CAST(GS.[TotalStock] AS INT) END AS [tQOH]
			 FROM MITDB.dbo.ProjectorData AS PJD
			 LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC ON (PJD.[EncSKUUSH] = PC.[ID])
			 LEFT OUTER JOIN Inventory.dbo.Global_Stocks AS GS ON (PJD.[EncSKUUSH] = GS.[ProductCatalogId])
			 WHERE 
			 --(PC.[AlwaysInStock] = '1' OR GS.[TotalStock] > 0)
			 PJD.[EncSKUUSH] != '-' AND PJD.[EncSKUUSH] IS NOT NULL
			 AND PJD.[UPCPhilips] != '' AND PJD.[UPCPhilips] IS NOT NULL 
			 AND PJD.[Type] = 'FP'
			 AND PJD.[PartNumber] NOT LIKE '%SML%'
			 --Exclude items that we don't have costs correct in the system.
			 AND PC.UnitCost < 250 AND PC.PriceFloor < 300
			--If Philips or Osram exist, don't make competing item
			 AND (PJD.[EncSKUPH] = '-' OR PJD.[EncSKUPH] IS NULL OR PJD.[EncSKUOS] = '-' OR PJD.[EncSKUOS] IS NULL OR PJD.[EncSKUPX] = '-' OR PJD.[EncSKUPX] IS NULL)





END
go

