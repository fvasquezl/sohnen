-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-06-28
-- Description:	Get Qty by BINID
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_GlobalStock_by_BinID]
(
	@SKU INT
)
RETURNS INT
AS
BEGIN
	DECLARE @RETURN INT,
			@GQTY	INT = 0,
			@VQTY	INT = 0,
			@VQTY2	INT = 0

	IF(EXISTS(SELECT * FROM Inventory.dbo.Bin_Content BC WITH(NOLOCK) WHERE BC.ProductCatalog_Id = @SKU AND Bin_id = 'SH308A'))
	BEGIN
		SET @GQTY = ISNULL((SELECT SUM(B.Counter)
					FROM Inventory.dbo.Bin_Content B WITH(NOLOCK)
					WHERE B.ProductCatalog_Id = @SKU
					AND Bin_id = 'SH308A'
				),0)

		SET @VQTY = ISNULL((
			SELECT SUM (QOH)
			FROM (
				SELECT PC.ID, ISNULL((SELECT SUM(BC.Counter) FROM Inventory.dbo.Bin_Content BC WHERE BC.ProductCatalog_Id = AD.ProductCatalogID AND BC.Bin_id = 'SH308A'),0) AS QOH
				FROM Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
				LEFT OUTER JOIN Inventory.dbo.AssemblyDetails AD WITH(NOLOCK)
				ON AD.SubSKU = PC.ID
				WHERE PC.ID = @SKU
			) VT
		),0)

		SET @VQTY2  = ISNULL((
			SELECT SUM (QOH)
			FROM (
				SELECT PC.ID, ISNULL((SELECT SUM(BC.Counter) FROM Inventory.dbo.Bin_Content BC WHERE BC.ProductCatalog_Id = AD.SubSKU AND BC.Bin_id = 'SH308A'),0) AS QOH
				FROM Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
				LEFT OUTER JOIN Inventory.dbo.AssemblyDetails AD WITH(NOLOCK)
				ON AD.ProductCatalogID = PC.ID
				WHERE PC.ID = @SKU
			) VT
		),0)
	END

	SET @RETURN = @GQTY + @VQTY + @VQTY2

	RETURN @RETURN

END
go

