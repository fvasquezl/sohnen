-- =============================================
-- Author:		Luis
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_DashBoard]
	@W_ID varchar(30)
AS
BEGIN
	 
SELECT  
MAX(A.FIRST_GR) AS AGING, 
SUM(A.STOCK_QTY) AS STOCK_QTY, 
(CASE WHEN A.BIN_TYPE = 'B' THEN 'Bin' ELSE '' END) AS BIN_TYPE, 
A.S_LOCATION,
P_LEFT, P_TOP,
P_WIDTH, P_HEIGHT,
PLANT
FROM (
	SELECT 
	S_LOCATION, 
	LOC_QTY, 
	BIN_TYPE, 
	ALIGN,
	PLANT, 
	DESCRIPTION, 
	P_LEFT, P_TOP,
	P_WIDTH, P_HEIGHT,
	b.Counter AS STOCK_QTY,
	DATEDIFF(DAY, b.LastStamp, GETDATE()) + 1 AS FIRST_GR
	FROM Inventory.dbo.WH_LOCATIONS (NOLOCK) 
	LEFT JOIN Inventory.dbo.Bin_Content b
	ON S_LOCATION = Bin_Id
	WHERE DELETE_FLAG = 0 AND WH_ID LIKE @W_ID 
	GROUP BY S_LOCATION, 
	LOC_QTY, 
	BIN_TYPE, 
	ALIGN, 
	DESCRIPTION, 
	P_LEFT, P_TOP,
	P_WIDTH, P_HEIGHT,
	LastStamp,
	b.Counter,
	PLANT
) A
GROUP BY  A.BIN_TYPE, A.S_LOCATION,
P_LEFT, P_TOP, P_WIDTH, P_HEIGHT, PLANT
ORDER BY A.S_LOCATION

END
go

