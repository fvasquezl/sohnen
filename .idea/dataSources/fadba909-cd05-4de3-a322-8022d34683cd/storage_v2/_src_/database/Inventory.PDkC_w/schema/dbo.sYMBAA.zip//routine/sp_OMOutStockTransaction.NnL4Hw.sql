-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-12-05
-- Description:	Get OutStock Print Label by Transaction ID
-- =============================================
CREATE PROCEDURE [dbo].[sp_OMOutStockTransaction]
	@TransactionID NVARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT CONVERT(NVARCHAR,TD.[SKU]) AS SKU, CONVERT(NVARCHAR,[Inventory].[dbo].[fn_get_lampsku](TD.[SKU])) AS Lamp,
		CASE WHEN PC.[CategoryID] NOT IN(10,14) THEN CONVERT(NVARCHAR,Inventory.[dbo].[fn_get_kitsku](TD.[SKU])) ELSE '' END AS Kit,
		SUM(TD.[RequestedQty]) AS RequestedQuantity, CONVERT(NVARCHAR,TD.[TransactionID]) AS [TransactionID], PC.CategoryID, T.CreateDate,
		RTRIM(LTRIM(ISNULL(PC.ProductAlert,''))) AS ProductAlert
	FROM [WebStation].[OE].[TransactionDetail] TD WITH(NOLOCK)
	INNER JOIN [WebStation].[OE].[Transactions] T WITH(NOLOCK)
	ON T.[TransactionID] = TD.[TransactionID] AND T.[isActive] = 1
	INNER JOIN Inventory.dbo.ProductCatalog PC
	ON CONVERT(NVARCHAR,PC.ID) = TD.[SKU]
	WHERE TD.[Bin_ID] IS NULL AND CONVERT(NVARCHAR, TD.[TransactionID]) = @TransactionID
	GROUP BY TD.[SKU], TD.[TransactionID], PC.CategoryID, T.CreateDate, PC.ProductAlert
	ORDER BY PC.CategoryID

END
go

