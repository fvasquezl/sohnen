


--This procedure is created to update the Floor & Ceil Price for FP Generic SKUs

CREATE PROCEDURE [dbo].[sp_UpdateProductCatalogFloorPrice]
AS 
BEGIN
Declare @MITSKU	           AS Varchar(10)
Declare @SubSKU	           AS Varchar(10)
Declare @PriceFloor        AS Float
Declare @PriceCeiling      AS Float
Declare @PriceFloorFBA     AS Float
Declare @PriceCeilingFBA   AS Float
Declare @SubSKUQTYRequired AS INT

--------------------------------------------------------------------------------------------------------------------------------------------
--SET PRICE for TV LAMPS
--------------------------------------------------------------------------------------------------------------------------------------------
--Bare PHILIPS  
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '63' , PriceCeiling = '72.99' WHERE CategoryID = '5'
--FBA 
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '59' , PriceCeilingFBA = '72.99' WHERE CategoryID = '5'

--Bare OSRAM
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor  = '55' , PriceCeiling  = '64.99' WHERE CategoryID = '6' AND Name NOT LIKE '%NeoLux%'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '51' , PriceCeilingFBA = '64.99' WHERE CategoryID = '6' AND Name NOT LIKE '%NeoLux%'

--Bare OSRAM NEOLUX
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor  = '37' , PriceCeiling  = '59.99' WHERE CategoryID = '6' AND Name LIKE '%NeoLux%'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '34' , PriceCeilingFBA = '59.99' WHERE CategoryID = '6' AND Name LIKE '%NeoLux%'

--Bare PHEONIX (Toshiba)
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '65' , PriceCeiling = '79.99' WHERE CategoryID = '7'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '61' , PriceCeilingFBA = '79.99' WHERE CategoryID = '7'

--Bare USHIO
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '45' , PriceCeiling = '69.99' WHERE CategoryID = '8'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '41' , PriceCeilingFBA = '69.99' WHERE CategoryID = '8'

--Bare GENERIC
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '16.5' , PriceCeiling = '29.99' WHERE CategoryID = '9'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '16' , PriceCeilingFBA = '29.99' WHERE CategoryID = '9'

--Bare GENERIC (Toshiba)
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '28' , PriceCeiling = '49.99' WHERE ID = '142551'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '27' , PriceCeilingFBA = '49.99' WHERE ID = '142551'

--------------------------------------------------------------------------------------------------------------------------------------------
--Enclosure PHILIPS  
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '70' , PriceCeiling = '79.99' WHERE CategoryID = '10'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '70' , PriceCeilingFBA = '79.99' WHERE CategoryID = '10'

--Enclosure OSRAM
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '60' , PriceCeiling = '79.99' WHERE CategoryID = '11'  AND Name NOT LIKE '%NeoLux%'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '60' , PriceCeilingFBA = '79.99' WHERE CategoryID = '11' AND Name NOT LIKE '%NeoLux%'

--Enclosure OSRAM NEOLUX
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '46' , PriceCeiling = '74.99' WHERE CategoryID = '11' AND Name LIKE '%NeoLux%'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '46' , PriceCeilingFBA = '74.99' WHERE CategoryID = '11' AND Name LIKE '%NeoLux%'

--Enclosure PHEONIX
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '80' , PriceCeiling = '84.99' WHERE CategoryID = '12'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '80' , PriceCeilingFBA = '84.99' WHERE CategoryID = '12'

--Enclosure USHIO
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '50' , PriceCeiling = '79.99' WHERE CategoryID = '13'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '50' , PriceCeilingFBA = '79.99' WHERE CategoryID = '13'

--Enclosure GENERIC
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '19.95' , PriceCeiling = '34.99' WHERE CategoryID = '14'
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '18.5' , PriceCeilingFBA = '34.99' WHERE CategoryID = '14'

--Enclosure GENERIC (Toshiba)
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloor = '32' , PriceCeiling = '49.99' 
WHERE ID = '126072' OR ID = '126073' OR ID = '126074' OR ID = '126075' OR ID = '126080' 
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET PriceFloorFBA = '30' , PriceCeilingFBA = '49.99' 
WHERE ID = '126072' OR ID = '126073' OR ID = '126074' OR ID = '126075' OR ID = '126080' 


--------------------------------------------------------------------------------------------------------------------------------------------
--SET PRICE for FP LAMPS
--------------------------------------------------------------------------------------------------------------------------------------------


--Bare OEM
--UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
--	PriceFloorFBA   = 
--		CASE 
--			WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '149' 
--			WHEN ( LowestSupplierCost >=1 AND LowestSupplierCost <=50)		THEN (LowestSupplierCost * 1.30) + 8
--			ELSE (LowestSupplierCost * 1.20) + 7 END,
--	PriceCeilingFBA = 
--	CASE 
--			WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '199' 
--			WHEN ( LowestSupplierCost >=1 AND LowestSupplierCost <=50)		THEN (LowestSupplierCost * 1.30) + 45
--			ELSE (LowestSupplierCost * 1.20) + 45
--	END
--WHERE 
	--CategoryID = '15' OR -- Philips FP Lamps Bare
	--CategoryID = '16' OR -- Osram FP Lamps Bare
	--CategoryID = '17' OR -- Pheonix FP Lamps Bare
	--CategoryID = '18'    -- Ushio FP Lamps Bare

--Enclosure OEM
--UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
--	PriceFloorFBA   = 
--		CASE 
--			WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '149' 
--			WHEN ( LowestSupplierCost >=1 AND LowestSupplierCost <=50)		THEN (LowestSupplierCost * 1.30) + 8
--			ELSE (LowestSupplierCost * 1.20) + 7 END,
--	PriceCeilingFBA = 
--	CASE 
--			WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '199' 
--			WHEN ( LowestSupplierCost >=1 AND LowestSupplierCost <=50)		THEN (LowestSupplierCost * 1.30) + 45
--			ELSE (LowestSupplierCost * 1.20) + 45
--	END
--WHERE 
	--CategoryID = '20' OR -- Philips FP Lamps with Housing
	--CategoryID = '21' OR -- Osram FP Lamps with Housing
	--CategoryID = '22' OR -- Pheonix FP Lamps with Housing
	--CategoryID = '23' OR -- Ushio FP Lamps with Housing
	--CategoryID = '64'    -- OEM FP Lamps with Housing

--Bare OEM
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
PriceFloor = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0')   THEN '149' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.2) AS Decimal(10,2)) + 8 END,
PriceCeiling = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0') THEN '249' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.3) AS Decimal(10,2)) + 40 END
WHERE 
CategoryID = '15' OR -- Philips FP Lamps Bare
CategoryID = '16' OR -- Osram FP Lamps Bare
CategoryID = '17' OR -- Pheonix FP Lamps Bare
CategoryID = '18'    -- Ushio FP Lamps Bare
--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
PriceFloorFBA = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0')   THEN '149' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.2) AS Decimal(10,2)) + 6 END,
PriceCeilingFBA = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0') THEN '249' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.3) AS Decimal(10,2)) + 40 END
WHERE 
CategoryID = '15' OR -- Philips FP Lamps Bare
CategoryID = '16' OR -- Osram FP Lamps Bare
CategoryID = '17' OR -- Pheonix FP Lamps Bare
CategoryID = '18'    -- Ushio FP Lamps Bare

--Enclosure OEM
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
PriceFloor = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0')   THEN '149' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.2) AS Decimal(10,2)) + 8 END,
PriceCeiling = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0') THEN '249' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.3) AS Decimal(10,2)) + 50 END
WHERE 
CategoryID = '20' OR -- Philips FP Lamps with Housing
CategoryID = '21' OR -- Osram FP Lamps with Housing
CategoryID = '22' OR -- Pheonix FP Lamps with Housing
CategoryID = '23' OR -- Ushio FP Lamps with Housing
CategoryID = '64'    -- OEM FP Lamps with Housing

--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
PriceFloorFBA = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0')   THEN '149' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.2) AS Decimal(10,2)) + 6 END,
PriceCeilingFBA = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0') THEN '249' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.3) AS Decimal(10,2)) + 50 END
WHERE 
CategoryID = '20' OR -- Philips FP Lamps with Housing
CategoryID = '21' OR -- Osram FP Lamps with Housing
CategoryID = '22' OR -- Pheonix FP Lamps with Housing
CategoryID = '23' OR -- Ushio FP Lamps with Housing
CategoryID = '64'    -- OEM FP Lamps with Housing


--Bare Generic
--FBM
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
PriceFloor = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0')   THEN '199' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.2) AS Decimal(10,2)) + 15 END,
PriceCeiling = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0') THEN '299' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.5) AS Decimal(10,2)) + 59 END
WHERE 
CategoryID = '19' -- Generic FP Lamps Bare

--UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
--	PriceFloor      = CASE WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '199' ELSE (LowestSupplierCost +10) * 1.3  END,
--	PriceFloor      = CASE WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '199' ELSE (LowestSupplierCost +10) * 1.3  END,
--	PriceCeilingFBM = CASE WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '199' ELSE (LowestSupplierCost +27) * 1.3  END,
--	PriceCeilingFBM = CASE WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '199' ELSE (LowestSupplierCost +27) * 1.3  END
--WHERE 
--CategoryID = '19' -- Generic FP Lamps Bare


--FBA
UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
PriceFloorFBA = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0')   THEN '199' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.3) AS Decimal(10,2)) + 14 END,
PriceCeilingFBA = CASE WHEN ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) IS NULL OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID]) = '0') THEN '299' ELSE CAST(([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable]([ID])*1.8) AS Decimal(10,2)) + 49 END
WHERE 
CategoryID = '19' -- Generic FP Lamps Bare

--UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
--	PriceFloorFBA   = CASE WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '199' ELSE (LowestSupplierCost +8.5) * 1.3  END,
--	PriceCeilingFBA = CASE WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '199' ELSE (LowestSupplierCost + 25) * 1.3  END
--WHERE 
--CategoryID = '19' -- Generic FP Lamps Bare


---Generic FP Lamps Housing
--UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET 
--	PriceFloorFBA   = 
--		CASE 
--			WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '199' 
--			WHEN ( LowestSupplierCost <=10)									THEN (LowestSupplierCost * 1.45) + 7
--			WHEN ( LowestSupplierCost >10 AND LowestSupplierCost <=30)		THEN (LowestSupplierCost * 1.40) + 7.5
--			WHEN ( LowestSupplierCost >30 AND LowestSupplierCost <=100)		THEN (LowestSupplierCost * 1.25) + 9
--			WHEN ( LowestSupplierCost >=101)								THEN (LowestSupplierCost * 1.20) + 15
			 
--			ELSE (LowestSupplierCost +8.5) * 1.3  END,
--	PriceCeilingFBA = 
--	CASE 
--			WHEN ( LowestSupplierCost  IS NULL OR LowestSupplierCost = '0') THEN '399' 
--			WHEN ( LowestSupplierCost <=10)									THEN (LowestSupplierCost * 1.45) + 45
--			WHEN ( LowestSupplierCost >10 AND LowestSupplierCost <=30)		THEN (LowestSupplierCost * 1.35) + 45
--			WHEN ( LowestSupplierCost >30 AND LowestSupplierCost <=100)		THEN (LowestSupplierCost * 1.30) + 55
--			WHEN ( LowestSupplierCost >=101)								THEN (LowestSupplierCost * 1.20) + 55	
--	END
--WHERE 
--CategoryID = '24' -- Generic FP Lamps Housing


SET @PriceFloor = 0
SET @PriceCeiling = 0

SET @PriceFloorFBA = 0
SET @PriceCeilingFBA = 0

--Enclosure GENERIC
DECLARE FPGeneric_cursor CURSOR
FOR
-- FP Generic - Select the Lowest Cost among all the suppliers.
Select ProductCatalogId, MIN(CASE WHEN UnitCost=0 OR UnitCost IS NULL THEN 299 Else UnitCost END) AS Cost
FROM Inventory.dbo.Suppliers 
WHERE ProductCatalogId IN (SELECT ID FROM Inventory.dbo.ProductCatalog WHERE  CategoryID = '24')
GROUP BY ProductCatalogId
ORDER BY ProductCatalogId



OPEN FPGeneric_cursor
FETCH NEXT FROM FPGeneric_cursor INTO @MITSKU, @PriceFloor

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @PriceFloorFBA = @PriceFloor
	
	-- Formula to set the Floor & Ceiling Prices  --lowered 2-20-2016
	SET @PriceFloor   = CEILING ((@PriceFloor*1.3) + 7)
	SET @PriceCeiling = CEILING ((@PriceFloor*1.5) + 55)
	

	SET @PriceFloorFBA   = CEILING ((@PriceFloorFBA*1.3) + 7)
	SET @PriceCeilingFBA = CEILING ((@PriceFloorFBA*1.5) + 55)

	
	-- Update the ProductCatalog table with the Floor & Ceiling Prices
	UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) 
	SET  PriceCeiling = @PriceCeiling, PriceFloor = @PriceFloor,
	PriceCeilingFBA = @PriceCeilingFBA, PriceFloorFBA = @PriceFloorFBA WHERE ID = @MITSKU		

FETCH NEXT FROM FPGeneric_cursor INTO @MITSKU, @PriceFloor

END

CLOSE FPGeneric_cursor
DEALLOCATE FPGeneric_cursor

-- For Kit SKUs 137001 etc
DECLARE FPGenericPackage_cursor CURSOR
FOR
-- FP Generic - Select all the SKUs for 
SELECT asd.ProductCatalogID, asd.SubSKU, pc.PriceFloor, pc.PriceCeiling, asd.SubSKUQTYRequired, pc.PriceFloorFBA, pc.PriceCeilingFBA FROM Inventory.dbo.AssemblyDetails asd
LEFT JOIN Inventory.dbo.ProductCatalog pc
ON asd.SubSKU = pc.ID 
WHERE SubSKU IN (SELECT ID FROM Inventory.dbo.ProductCatalog WHERE CategoryID = '24' ) 

 
OPEN FPGenericPackage_cursor
FETCH NEXT FROM FPGenericPackage_cursor INTO @MITSKU, @SubSKU, @PriceFloor, @PriceCeiling, @SubSKUQTYRequired, @PriceFloorFBA, @PriceCeilingFBA

WHILE @@FETCH_STATUS = 0
BEGIN
	-- Formula to set the Floor & Ceiling Prices
	SET @PriceFloor   = (@PriceFloor)  * @SubSKUQTYRequired
	SET @PriceCeiling = (@PriceCeiling)* @SubSKUQTYRequired 
	
	SET @PriceFloorFBA   = (@PriceFloorFBA)  * @SubSKUQTYRequired
	SET @PriceCeilingFBA = (@PriceCeilingFBA)* @SubSKUQTYRequired 
	
	-- Update the ProductCatalog table with the Floor & Ceiling Prices
	UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) 
	SET PriceCeiling = @PriceCeiling, PriceFloor = @PriceFloor, 
		PriceCeilingFBA = @PriceCeilingFBA, PriceFloorFBA = @PriceFloorFBA 
	WHERE ID = @MITSKU

FETCH NEXT FROM FPGenericPackage_cursor INTO @MITSKU, @SubSKU, @PriceFloor, @PriceCeiling, @SubSKUQTYRequired, @PriceFloorFBA, @PriceCeilingFBA

END

CLOSE FPGenericPackage_cursor
DEALLOCATE FPGenericPackage_cursor

------------MERCHANT PRIME CODE for FLOOR/CEILING-----------

--Toys
UPDATE PC SET 
PC.[PriceFloorMFP] = (SELECT TOP(1) PC2.[PriceFloor]+10 FROM [Inventory].[dbo].[ProductCatalog] AS PC2 WHERE PC2.[ID] = PC.[ID]), 
PC.[PriceCeilingMFP] = (SELECT TOP(1) PC2.[PriceCeiling]+5 FROM [Inventory].[dbo].[ProductCatalog] AS PC2 WHERE PC2.[ID] = PC.[ID]) 
FROM [Inventory].[dbo].[ProductCatalog] AS PC 
WHERE CategoryID IN ('36')


--OEM Lamps
UPDATE PC SET 
PC.[PriceFloorMFP] = (SELECT TOP(1) PC2.[PriceFloorFBA]+4 FROM [Inventory].[dbo].[ProductCatalog] AS PC2 WHERE PC2.[ID] = PC.[ID]), 
PC.[PriceCeilingMFP] = (SELECT TOP(1) PC2.[PriceCeilingFBA] FROM [Inventory].[dbo].[ProductCatalog] AS PC2 WHERE PC2.[ID] = PC.[ID]) 
FROM [Inventory].[dbo].[ProductCatalog] AS PC 
WHERE CategoryID IN 
(
--TV & Projector Lamps
'5', --Philips TV Lamps Bare
'6', --Osram TV Lamps Bare
'7', --Phoenix TV Lamps Bare
'8', --Ushio TV Lamps Bare
'10', --Philips TV Lamps with Housing
'11', --Osram TV Lamps with Housing
'12', --Phoenix TV Lamps with Housing
'13', --Ushio TV Lamps with Housing
'15', --Philips FP Lamps Bare
'16', --Osram FP Lamps Bare
'17', --Phoenix FP Lamps Bare
'18', --Ushio FP Lamps Bare
'20', --Philips FP Lamps with Housing
'21', --Osram FP Lamps with Housing
'22', --Phoenix FP Lamps with Housing
'23', --Ushio FP Lamps with Housing
'61', --OEM TV Lamps Bare
'62', --OEM TV Lamps with Housing
'63', --OEM FP Lamps Bare
'64', --OEM FP Lamps with Housing

--Medical Lamps
'25', --Lamp Bare - Medical
'26', --Lamp with Housing - Medical

--Specialty Lamps
'87', --Lamps Bare - Stage
'88', --Philips Stage Lamps Bare
'89', --Osram Stage Lamps Bare
'90', --Ushio Stage Lamps Bare
'91', --Generic Stage Lamps Bare
'93', --Lamps Bare - DJ
'94', --Lamps Bare - Theater
'95', --Lamps Bare - Film
'96', --Lamps Bare - Architainment
'97', --Philips DJ Lamps Bare
'98', --Osram DJ Lamps Bare
'99', --Ushio DJ Lamps Bare
'100', --Phoenix DJ Lamps Bare
'101', --Philips Theater Lamps Bare
'102', --Osram Theater Lamps Bare
'103', --Ushio Theater Lamps Bare
'104', --Phoenix Theater Lamps Bare
'105', --Philips Film Lamps Bare
'106', --Osram Film Lamps Bare
'107', --Ushio Film Lamps Bare
'108', --Phoenix Film Lamps Bare
'109', --Philips Architainment Lamps Bare
'110', --Osram Architainment Lamps Bare
'111', --Ushio Architainment Lamps Bare
'112', --Phoenix Architainment Lamps Bare
'113', --Phoenix Stage Lamps Bare
'114', --Generic DJ Lamps Bare
'115', --Generic Theater Lamps Bare
'116', --Generic Film Lamps Bare
'117', --Generic Architainment Lamps Bare
'118', --Theater LED System
'119', --Lamps Bare - Disinfection
'120', --Lamps Bare - Projection
'121', --Lamps Bare - Reprography
'122', --Lamps Bare - Insect Trap
'123', --Philips Medical Lamps Bare
'124', --Osram Medical Lamps Bare
'125', --Phoenix Medical Lamps Bare
'126', --Ushio Medical Lamps Bare
'127', --Generic Medical Lamps Bare
'128', --Philips Disinfection Lamps Bare
'129', --Osram Disinfection Lamps Bare
'130', --Phoenix Disinfection Lamps Bare
'131', --Ushio Disinfection Lamps Bare
'132', --Generic Disinfection Lamps Bare
'133', --Philips Projection Lamps Bare
'134', --Osram Projection Lamps Bare
'135', --Phoenix Projection Lamps Bare
'136', --Ushio Projection Lamps Bare
'137', --Generic Projection Lamps Bare
'138', --Philips Reprography Lamps Bare
'139', --Osram Reprography Lamps Bare
'140', --Phoenix Reprography Lamps Bare
'141', --Ushio Reprography Lamps Bare
'142', --Generic Reprography Lamps Bare
'143', --Philips Insect Trap Lamps Bare
'144', --Osram Insect Trap Lamps Bare
'145', --Phoenix Insect Trap Lamps Bare
'146', --Ushio Insect Trap Lamps Bare
'147'  --Generic Insect Trap Lamps Bare
)


--Other Lamp Categories
UPDATE PC SET 
PC.[PriceFloorMFP] = (SELECT TOP(1) PC2.[PriceFloorFBA]+4 FROM [Inventory].[dbo].[ProductCatalog] AS PC2 WHERE PC2.[ID] = PC.[ID]), 
PC.[PriceCeilingMFP] = (SELECT TOP(1) PC2.[PriceCeilingFBA] FROM [Inventory].[dbo].[ProductCatalog] AS PC2 WHERE PC2.[ID] = PC.[ID]) 
FROM [Inventory].[dbo].[ProductCatalog] AS PC 
WHERE CategoryID IN 
(
--TV & Projector Lamps
'9', --Generic TV Lamps Bare
'14', --Generic TV Lamps with Housing
'19', --Generic FP Lamps Bare
'24' --Generic FP Lamps with Housing
)


--Remotes
UPDATE PC SET 
PC.[PriceFloorMFP] = (SELECT TOP(1) PC2.[PriceFloor]+10 FROM [Inventory].[dbo].[ProductCatalog] AS PC2 WHERE PC2.[ID] = PC.[ID]), 
PC.[PriceCeilingMFP] = (SELECT TOP(1) PC2.[PriceCeiling]+5 FROM [Inventory].[dbo].[ProductCatalog] AS PC2 WHERE PC2.[ID] = PC.[ID]) 
FROM [Inventory].[dbo].[ProductCatalog] AS PC 
WHERE CategoryID IN 
(
--TV & Projector Lamps
'29' --Remote Controls
)


-- Price Ceiling Override
-- Added 2019-03-07
UPDATE pc SET 
	pc.[PriceCeiling] = pro.PriceCeiling,
	pc.[PriceCeilingFBA] = pro.PriceCeiling ,
	pc.[PriceCeilingMFP] = pro.PriceCeiling
FROM [Inventory].[dbo].[ProductCatalog] AS pc 
LEFT JOIN MiTech.mi.[PriceCeilingOveride] pro
ON
	pc.ID = pro.ProductSKU
WHERE pro.PriceCeiling IS NOT NULL


END
go

