-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-07-18
-- Description:	Get Year-Month-Day Symbol for Serial
-- =============================================
 CREATE FUNCTION [dbo].[fn_Year_Month_Day]
(
	@YEAR INT, @MONTH INT, @DAY INT
)
RETURNS NVARCHAR(3)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @RETURN_VALUE NVARCHAR(3)

	-- Add the T-SQL statements to compute the return value here
	SET @RETURN_VALUE = (CASE @YEAR 
							WHEN 2018 THEN 'A' 
							WHEN 2019 THEN 'B' 
							WHEN 2020 THEN 'C' 
							WHEN 2021 THEN 'D' 
							WHEN 2022 THEN 'E' 
							WHEN 2023 THEN 'F' 
							WHEN 2024 THEN 'G' 
							WHEN 2025 THEN 'H' 
							WHEN 2026 THEN 'I' 
							WHEN 2027 THEN 'J' 
							WHEN 2028 THEN 'K' 
							WHEN 2029 THEN 'L' 
							WHEN 2030 THEN 'M' 
							WHEN 2031 THEN 'N' 
							WHEN 2032 THEN 'O' 
							WHEN 2033 THEN 'P' 
							WHEN 2034 THEN 'Q' 
							WHEN 2035 THEN 'R' 
							WHEN 2036 THEN 'S' 
							WHEN 2037 THEN 'T' 
							WHEN 2038 THEN 'U' 
							WHEN 2039 THEN 'V' 
							ELSE 'Z' END)

	SET @RETURN_VALUE = @RETURN_VALUE + (CASE @MONTH 
											WHEN 1 THEN 'A' --January
											WHEN 2 THEN 'B' --February
											WHEN 3 THEN 'C' --March
											WHEN 4 THEN 'D' --April
											WHEN 5 THEN 'E' --May
											WHEN 6 THEN 'F' --June
											WHEN 7 THEN 'G' --July
											WHEN 8 THEN 'H' --August
											WHEN 9 THEN 'I' --September
											WHEN 10 THEN 'J' --October
											WHEN 11 THEN 'K' --November
											WHEN 12 THEN 'L' --December
											ELSE 'Z' END)

	SET @RETURN_VALUE = @RETURN_VALUE + (CASE @DAY 
											WHEN 1 THEN '1' 
											WHEN 2 THEN '2' 
											WHEN 3 THEN '3' 
											WHEN 4 THEN '4' 
											WHEN 5 THEN '5' 
											WHEN 6 THEN '6' 
											WHEN 7 THEN '7' 
											WHEN 8 THEN '8' 
											WHEN 9 THEN '9' 
											WHEN 10 THEN 'A' 
											WHEN 11 THEN 'B' 
											WHEN 12 THEN 'C' 
											WHEN 13 THEN 'D' 
											WHEN 14 THEN 'E' 
											WHEN 15 THEN 'F' 
											WHEN 16 THEN 'G' 
											WHEN 17 THEN 'H' 
											WHEN 18 THEN 'I' 
											WHEN 19 THEN 'J' 
											WHEN 20 THEN 'K' 
											WHEN 21 THEN 'L' 
											WHEN 22 THEN 'M' 
											WHEN 23 THEN 'N' 
											WHEN 24 THEN 'O' 
											WHEN 25 THEN 'P' 
											WHEN 26 THEN 'Q' 
											WHEN 27 THEN 'R' 
											WHEN 28 THEN 'S' 
											WHEN 29 THEN 'T' 
											WHEN 30 THEN 'U' 
											WHEN 31 THEN 'V' 
											ELSE 'Z' END)

	-- Return the result of the function
	RETURN @RETURN_VALUE

END
go

