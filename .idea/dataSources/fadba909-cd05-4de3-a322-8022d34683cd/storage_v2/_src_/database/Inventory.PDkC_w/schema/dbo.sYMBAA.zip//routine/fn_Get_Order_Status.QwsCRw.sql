-- =============================================
-- Author:		Luis Bautista	
-- Create date: <Create Date, ,>
-- Description:	Get order status from order manager database
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_Order_Status](
	@pOrderNumber int
)
RETURNS varchar(20)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(20);

	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = a.orderstatus FROM OrderManager.DBO.Orders a WHERE ordernumber = @pOrderNumber;
		If @ResultVar is null
	begin
			SET @ResultVar = '';
	end;
	-- Return the result of the function
	RETURN @ResultVar;

END
go

