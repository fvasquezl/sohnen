--This procedure is created to update the Virtual stock and "total stock" in the Global_stocks table
CREATE PROCEDURE [dbo].[sp_Update_VirtStock_LampWithHousing]
AS 
BEGIN
Declare @MITSKU	       AS Varchar(10)
Declare @CategoryCheck AS INT
Declare @UnitCost  AS Float
Declare @VirtualStock  AS INT
Declare @QOH  AS INT
Declare @EncPrice  AS DECIMAL(10,4)

Declare @SQL1  AS nVArchar(MAX)
Declare @SQL2  AS nVArchar(MAX)

SET @CategoryCheck = 0

SET @UnitCost = 0
SET @VirtualStock = 0
SET @EncPrice = 0

DECLARE AssemblyReq_cursor CURSOR
FOR
--Select all of the projector lamps SKUs
SELECT ID, UnitCost FROM Inventory.dbo.ProductCatalog WITH(NOLOCK) WHERE CategoryID IN ('10','11','12','13','14','20','21','22','23','24','64')--FP Categories
--AND ID = '135881'  --Test Condition 

OPEN AssemblyReq_cursor
FETCH NEXT FROM AssemblyReq_cursor INTO @MITSKU,  @UnitCost

WHILE @@FETCH_STATUS = 0
BEGIN
	--SET @CategoryCheck = (SELECT  COUNT(pc.CategoryID) FROM AssemblyDetails ad WITH(NOLOCK)
	--LEFT JOIN ProductCatalog pc WITH(NOLOCK)
	--ON ad.SubSKU = pc.ID
	--WHERE ad.ProductCatalogID = @MITSKU
	--AND (ad.IsRequired = '1'
	--AND pc.CategoryID  = '60') )
	
	--Checks to see if Barelamp and Housing are both available in Assembly Details
	SET @CategoryCheck = ISNULL((
		SELECT  COUNT(SubSKU) FROM Inventory.dbo.AssemblyDetails ad 
		INNER JOIN Inventory.dbo.ProductCatalog pc 
		ON ad.ProductCatalogID = pc.ID
		WHERE ad.ProductCatalogID = @MITSKU
		AND ad.SubSKU IN (Select pc.ID FROM Inventory.dbo.ProductCatalog pc LEFT JOIN Inventory.dbo.Categories ctg ON pc.CategoryID = Ctg.ID WHERE ctg.ParentID IN ('1', '3') OR ctg.ID IN ('59', '60')) 
	),0)
		
	IF @CategoryCheck = 2
		BEGIN
			-- Query to check buildable Qty.
			SELECT @VirtualStock = MIN ((gs.TotalStock)/ ISNULL(ad.SubSKUQTYRequired,1) )  FROM AssemblyDetails ad WITH(NOLOCK)
			INNER JOIN Global_Stocks gs WITH(NOLOCK)
			ON ad.SubSKU = gs.ProductCatalogId
			WHERE ad.ProductCatalogID = @MITSKU
			AND ad.IsRequired = '1'

			SELECT @QOH = GS.GlobalStock FROM Global_Stocks AS GS WHERE GS.ProductCatalogID =  @MITSKU

			SET @VirtualStock =  (IsNull(@VirtualStock,0) - IsNull(@QOH,0))

--			SET @VirtualStock = (CASE WHEN (IsNull(@VirtualStock,0) - IsNull(@QOH,0)) < 0 THEN 0 ELSE
--			IsNull(@VirtualStock,0) - IsNull(@QOH,0) END)
						
			-- Query to GET LOWEST COST for Lamp + Enclosure
			SELECT @EncPrice = ISNULL(Cast(Inventory.dbo.fn_GetLowestPriceFromSuppliersTable((SELECT TOP(1) AD2.SubSKU FROM [Inventory].[dbo].[AssemblyDetails] AS AD2
			INNER JOIN [Inventory].[dbo].[ProductCatalog] AS PC2 ON (AD2.SubSKU = PC2.ID)
			WHERE AD2.ProductCatalogID = @MITSKU AND PC2.CategoryID IN ('59','60'))) AS Decimal(10,4)),0)
			+ 
			ISNULL(Cast((SELECT SUM(PCBulbCost.UnitCost) 
			FROM [Inventory].[dbo].[ProductCatalog] AS PCBulbCost 
			where PCBulbCost.ID IN (SELECT AD2.SubSKU FROM [Inventory].[dbo].[AssemblyDetails] AS AD2
			INNER JOIN [Inventory].[dbo].[ProductCatalog] AS PC2 ON (AD2.SubSKU = PC2.ID)
			LEFT OUTER JOIN [Inventory].[dbo].[Categories] AS CAT2 ON (PC2.CategoryID = CAT2.ID)
			WHERE AD2.ProductCatalogID = @MITSKU AND PC2.[CategoryID] IN ('5','6','7','8','9','15','16','17','18','19','63'))) AS Decimal(10,4)),0)
			
			--Old Code 2016-04-22
			--ISNULL(Cast((SELECT TOP(1) PCBulbCost.UnitCost FROM [Inventory].[dbo].[ProductCatalog] AS PCBulbCost where PCBulbCost.ID = (SELECT AD2.SubSKU FROM [Inventory].[dbo].[AssemblyDetails] AS AD2
			--INNER JOIN [Inventory].[dbo].[ProductCatalog] AS PC2 ON (AD2.SubSKU = PC2.ID)
			--LEFT OUTER JOIN [Inventory].[dbo].[Categories] AS CAT2 ON (PC2.CategoryID = CAT2.ID)
			--WHERE AD2.ProductCatalogID = @MITSKU AND CAT2.ParentID IN ('1','3'))) AS Decimal(10,4)),0)

			--OLD CODE
			--SELECT @EncPrice = ROUND( CEILING(SUM(pc.UnitCost)),2) FROM [Inventory].[dbo].AssemblyDetails ad WITH(NOLOCK)
			--LEFT JOIN [Inventory].[dbo].ProductCatalog pc WITH(NOLOCK)
			--ON ad.SubSKU = pc.ID
			--WHERE ad.ProductCatalogID = @MITSKU
			--AND ad.IsRequired = '1'
		END
	ELSE
	BEGIN
		--Check if the SubSKU is in the 1, 2 and 4 Parent Category and need 2 for twin pack
		SET @CategoryCheck = ISNULL((
			SELECT COUNT(SubSKU) FROM Inventory.dbo.AssemblyDetails ad 
			INNER JOIN Inventory.dbo.ProductCatalog pc 
			ON ad.ProductCatalogID = pc.ID
			WHERE ad.ProductCatalogID = @MITSKU
			AND ad.SubSKUQTYRequired = 2
			AND ad.SubSKU IN (SELECT pc.ID FROM Inventory.dbo.ProductCatalog pc LEFT JOIN Inventory.dbo.Categories ctg ON pc.CategoryID = Ctg.ID WHERE ctg.ParentID IN ('0', '2', '4')) 
		),0)
		IF @CategoryCheck = 1
		BEGIN
			PRINT('TWIN PACK')
			PRINT(@MITSKU)

			SET @VirtualStock = ISNULL((
				SELECT CONVERT(INT, (MIN((gs.TotalStock) / ISNULL(ad.SubSKUQTYRequired,1) ) ) )
				FROM AssemblyDetails ad WITH(NOLOCK)
				INNER JOIN Global_Stocks gs WITH(NOLOCK)
				ON ad.SubSKU = gs.ProductCatalogId
				WHERE ad.ProductCatalogID = @MITSKU
				AND ad.IsRequired = '1'
			),0)

			SET @EncPrice = ISNULL(@UnitCost, '0')
		END
		ELSE
		BEGIN
			SET @VirtualStock = 0
			SET @EncPrice = ISNULL(@UnitCost, '0')
		END
	END
	
	--Print CAST(@MITSKU as varchar(10)) + ' update AND Virtual Stock is ' + CAST(@VirtualStock as varchar(2)) + ' Price -' + CAST(@EncPrice as varchar(20)) +' AND Category value is  = ' + CAST(@CategoryCheck as varchar(2)) 

	UPDATE Inventory.dbo.Global_Stocks with(UPDLOCK) SET VirtualStock = ISNULL(@VirtualStock, 0) WHERE ProductCatalogId = @MITSKU
	UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET VirtualStock = ISNULL(@VirtualStock,0), UnitCost = ISNULL(@EncPrice,0)  WHERE ID = @MITSKU
	
	PRINT 'MITSKU: '+CAST(@MitSKU AS NVARCHAR(MAX))
	PRINT 'VirtualStock: '+CAST(@VirtualStock  AS NVARCHAR(MAX))
	PRINT 'QOH: '+CAST(@QOH  AS NVARCHAR(MAX))
	PRINT 'EncPrice: '+CAST(@EncPrice  AS NVARCHAR(MAX))
	PRINT '----THE ABOVE SKU COMPLETE - MOVING TO NEXT----'
	

	--SET @SQL1 = 'UPDATE Inventory.dbo.Global_Stocks with(UPDLOCK) SET VirtualStock = ' + CAST(@VirtualStock as varchar)  + ' WHERE ProductCatalogId = ' + @MITSKU
	--SET @SQL2 = 'UPDATE Inventory.dbo.ProductCatalog with(UPDLOCK) SET VirtualStock = ' + CAST(@VirtualStock as varchar)  + ', UnitCost = ' + CAST(@EncPrice AS VARCHAR)+ ' WHERE ID = '+ @MITSKU
	
	--PRINT @SQL1
	--PRINT @SQL2
	--PRINT '-------------------------------------------'
	
SET @CategoryCheck = 0
SET @VirtualStock = 0
SET @EncPrice = 0

FETCH NEXT FROM AssemblyReq_cursor INTO @MITSKU, @UnitCost

END

CLOSE AssemblyReq_cursor
DEALLOCATE AssemblyReq_cursor

END
go

