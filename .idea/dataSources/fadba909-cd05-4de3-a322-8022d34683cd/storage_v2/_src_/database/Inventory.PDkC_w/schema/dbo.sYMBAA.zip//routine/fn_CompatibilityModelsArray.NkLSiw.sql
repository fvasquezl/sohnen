-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 4-29-2016
-- Description:	
-- =============================================
CREATE FUNCTION fn_CompatibilityModelsArray 
(
	-- Add the parameters for the function here
	@pManufacturer NVARCHAR(MAX), @pPartNumber NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result NVARCHAR(MAX)

	-- Add the T-SQL statements to compute the return value here
	
	DECLARE @tmpModel TABLE (MODELS NVARCHAR(1000))
	DECLARE @MODELS NVARCHAR(MAX)

	INSERT INTO @tmpModel (MODELS)
	SELECT (CDL1.[Model]+':'+
	ISNULL(substring(
    ((SELECT ','+ISNULL(CDL2.[AlternativeModel],'') FROM [Inventory].[dbo].[CompatibilityAlternativeModels] AS CDL2 
	WHERE CDL2.[OriginalManufacturer] = CDL1.[OriginalManufacturer] AND CDL2.[OriginalModel] = CDL1.[Model] ORDER BY CDL2.[AlternativeModel] FOR XML PATH (''))), 2, 1000),'') )  AS [Array]

	FROM [Inventory].[dbo].[CompatibilityDetails] AS CDL1
	WHERE CDL1.[OriginalManufacturer] = @pManufacturer and CDL1.[PartNumber] = @pPartNumber

	
	SELECT @MODELS = COALESCE(@MODELS+';','') + MODELS FROM @tmpModel

	
	SELECT @Result = CASE WHEN RIGHT(REPLACE(@MODELS,':;',';'),1) = ':' THEN LEFT(REPLACE(@MODELS,':;',';'),LEN(REPLACE(@MODELS,':;',';'))-1) ELSE REPLACE(@MODELS,':;',';') END 

	-- Return the result of the function
	RETURN @Result

END
go

