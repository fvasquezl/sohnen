-- =============================================
-- Author:		Araceli
-- Create date: 5/09/2016
-- Description:	Stored Procedure para obtener todos los RMA en la base de datos
-- =============================================
CREATE PROCEDURE [dbo].[sp_get_all_rmas]
	@rma nvarchar(50),
	@dateIssuedFirst nvarchar (10),
	@dateIssuedLast nvarchar (10)
AS
BEGIN
	
SET FMTONLY OFF;
	DECLARE @TempRmas TABLE 
	(
		RMA nvarchar(15),
		DateIssued nvarchar(20),
		DateDone nvarchar(10),
		Sku nvarchar(15),
        [Type] nvarchar (300),
		QuantityOrdered int,
		RMAreason nvarchar (250),
		--Resolution nvarchar (250),
		SoldBy nvarchar (50),
		RmaIssued nvarchar(50),
		--ReturnLabel nvarchar (50),
		TrackingNumber nvarchar (60), 
		StatusTrackingNumber nvarchar(50),
		Refund float,
		Charge float,
		[Status] nvarchar (50),
		Condition nvarchar(50),
		Notes nvarchar(max),
		OrderNumber int
	 )
	 
DECLARE @RmaQuery nvarchar(max);
DECLARE @ReturnsQuery nvarchar(max);
SET FMTONLY OFF;
 
INSERT INTO @TempRmas
SELECT 
r.RMAnumber,
CONVERT(VARCHAR(10), r.[DateIssued], 101) DateIssued,
--CONVERT(VARCHAR(10), d.DetailDate, 101) DateDone, 
case 
	when 
	CONVERT(nvarchar(100), n.Notes) like '%returned%' and 
	(CONVERT(nvarchar(100), n.Notes) like '%'+rd.WrongSKU+'%') and 
	CONVERT(nvarchar(100), n.Notes) like '%rma%' and 
	CONVERT(nvarchar(100), n.Notes) like '%'+CONVERT(nvarchar, r.RMAnumber)+'%' 
	then CONVERT(nvarchar(10), n.EntryDate, 101)
	END AS DateDone,
rd.WrongSKU Sku,
d.Product,
case 
	when 
	CONVERT(nvarchar(100), n.Notes) like '%returned%' and 
	(CONVERT(nvarchar(100), n.Notes) like '%'+rd.WrongSKU+'%') and 
	CONVERT(nvarchar(100), n.Notes) like '%rma%' and 
	CONVERT(nvarchar(100), n.Notes) like '%'+CONVERT(nvarchar, r.RMAnumber)+'%' 
	then rd.QuantityAuthorized
	END AS QuantityAuthorized,
r.[Reason],
cart.CartName,
r.[IssuedBy],
CONVERT(nvarchar(60), o.GiftMessage) TrackingNumber, 
rp.StatusTrackingNumber,
--o.ProductTotal Refund, -- Refund

CASE r.Exchange 
WHEN 1 THEN 0
ELSE o.ProductTotal
END AS  Refund,

(o.ProductTotal + o.TaxTotal + o.ShippingTotal) Charge,
--o.OrderStatus,

CASE r.Exchange 
WHEN 1 THEN 'Exchange'
ELSE o.OrderStatus
END AS  OrderStatus,

rp.Condition,
CONVERT(nvarchar(250), r.[Notes]) NotesRma,
r.[OrderNumber]
FROM 
[OrderManager].[dbo].[RMAs] r (nolock)
INNER JOIN
[OrderManager].[dbo].[RMADetails] rd (nolock)
ON r.RMAnumber = rd.RMAnumber
INNER JOIN 
[OrderManager].[dbo].[Order Details] d (nolock)
ON d.OrderNumber = r.OrderNumber and rd.WrongSKU = d.SKU 
INNER JOIN 
[OrderManager].[dbo].[Orders] o (nolock)
ON o.OrderNumber = r.OrderNumber
LEFT JOIN 
[OrderManager].[dbo].[ShoppingCarts] cart (nolock)
ON o.CartID = cart.ID
LEFT JOIN 
[Inventory].[dbo].[RMAPreprocessed] rp (nolock)
ON  o.OrderNumber = rp.OrderNumber
LEFT JOIN 
[OrderManager].[dbo].[Notes] n (nolock)
ON r.OrderNumber = n.NumericKey and n.Notes like '%Returned%' and (CONVERT(nvarchar(100), n.Notes) like '%'+rd.WrongSKU+'%') and
(CONVERT(nvarchar(100), n.Notes) like '%'+CONVERT(nvarchar, r.RMAnumber)+'%')
WHERE Adjustment = 0 
AND 
(
	(@dateIssuedFirst IS NULL OR LEN(@dateIssuedFirst) = 0)
	OR
	(
		r.OrderNumber IN(SELECT OrderNumber FROM [OrderManager].[dbo].[RMAs] (nolock) WHERE DateIssued BETWEEN @dateIssuedFirst and  @dateIssuedLast)
		--r.DateIssued BETWEEN @dateIssuedFirst and  @dateIssuedLast
	)
)
AND 
(
	(@rma IS NULL OR LEN(@rma) = 0)
	OR
	(
		o.OrderNumber =  (SELECT OrderNumber FROM [OrderManager].[dbo].[RMAs] (nolock) WHERE RMAnumber = @rma)
		--r.RMAnumber = @rma and o.OrderNumber = r.OrderNumber
	)
)
GROUP BY 
r.RMAnumber,
r.DateIssued,
r.Reason,
r.IssuedBy,
o.OrderStatus,
d.DetailDate,
CONVERT(nvarchar(250), r.Notes),
r.OrderNumber,
rd.WrongSKU,
d.Product,
rd.QuantityAuthorized,
o.MarketName,
CONVERT(nvarchar(60), o.GiftMessage),
cart.CartName,
o.ProductTotal, -- Refund
o.TaxTotal,
o.ShippingTotal,
rp.DateDone,
rp.Condition,
StatusTrackingNumber,
CONVERT(nvarchar(100), n.Notes),
CONVERT(nvarchar(10), n.EntryDate, 101),
r.Exchange 
--ORDER BY 
--RMAnumber,
--DateIssued

SET FMTONLY OFF;
INSERT INTO @TempRmas
SELECT 
t.RMAnumber,
CONVERT(VARCHAR(10), t.[Date], 101) DateIssued,
--CONVERT(VARCHAR(10), d.DetailDate, 101) DateDone, 
case 
	when 
	CONVERT(nvarchar(100), n.Notes) like '%returned%' and 
	(CONVERT(nvarchar(100), n.Notes) like '%'+rd.WrongSKU+'%') and 
	CONVERT(nvarchar(100), n.Notes) like '%rma%' and 
	CONVERT(nvarchar(100), n.Notes) like '%'+CONVERT(nvarchar, t.RMAnumber)+'%' 
	then CONVERT(nvarchar(10), n.EntryDate, 101)
	END AS DateDone,
rd.WrongSKU Sku,
d.Product,
case 
	when 
	CONVERT(nvarchar(100), n.Notes) like '%returned%' and 
	(CONVERT(nvarchar(100), n.Notes) like '%'+rd.WrongSKU+'%') and 
	CONVERT(nvarchar(100), n.Notes) like '%rma%' and 
	CONVERT(nvarchar(100), n.Notes) like '%'+CONVERT(nvarchar, t.RMAnumber)+'%' 
	then t.Quantity
	END AS Quantity,
r.[Reason],
cart.CartName,
t.ReturnedBy,
CONVERT(nvarchar(60), o.GiftMessage) TrackingNumber, 
rp.StatusTrackingNumber,
--o.ProductTotal Refund, -- Refund


CASE r.Exchange 
WHEN 1 THEN 0
ELSE o.ProductTotal
END AS  Refund,


(o.ProductTotal + o.TaxTotal + o.ShippingTotal) Charge,
--o.OrderStatus,

CASE r.Exchange 
WHEN 1 THEN 'Exchange'
ELSE o.OrderStatus
END AS  OrderStatus,


rp.Condition,
CONVERT(nvarchar(250), r.[Notes]) NotesRma,
t.[OrderNumber]
FROM 
[OrderManager].[dbo].[Returns] t (nolock)
LEFT JOIN
[OrderManager].[dbo].[RMAs] r (nolock)
ON t.RMANumber = r.RMAnumber
LEFT JOIN
[OrderManager].[dbo].[RMADetails] rd (nolock)
ON r.RMAnumber = rd.RMAnumber 
LEFT JOIN 
[OrderManager].[dbo].[Order Details] d (nolock)
ON d.OrderNumber = r.OrderNumber and rd.WrongSKU = d.SKU 
INNER JOIN 
[OrderManager].[dbo].[Orders] o (nolock)
ON o.OrderNumber = r.OrderNumber
LEFT JOIN 
[OrderManager].[dbo].[ShoppingCarts] cart (nolock)
ON o.CartID = cart.ID
LEFT JOIN 
[Inventory].[dbo].[RMAPreprocessed] rp (nolock)
ON  o.OrderNumber = rp.OrderNumber
LEFT JOIN 
[OrderManager].[dbo].[Notes] n (nolock)
ON r.OrderNumber = n.NumericKey and n.Notes like '%Returned%' and (CONVERT(nvarchar(100), n.Notes) like '%'+rd.WrongSKU+'%') and
(CONVERT(nvarchar(100), n.Notes) like '%'+CONVERT(nvarchar, r.RMAnumber)+'%')
WHERE Adjustment = 0 
AND t.RMANumber NOT IN (SELECT Distinct(tmp.RMA) FROM @TempRmas tmp)
AND 
(
	(@dateIssuedFirst IS NULL OR LEN(@dateIssuedFirst) = 0)
	OR
	(
		r.OrderNumber IN(SELECT OrderNumber FROM [OrderManager].[dbo].[RMAs] (nolock) WHERE DateIssued BETWEEN @dateIssuedFirst and  @dateIssuedLast)
		--t.Date BETWEEN @dateIssuedFirst and  @dateIssuedLast
	)
)
AND
(
	(@rma IS NULL OR LEN(@rma) = 0)
	OR
	(
		t.OrderNumber = (SELECT OrderNumber FROM [OrderManager].[dbo].[RMAs] (nolock) WHERE RMAnumber = @rma)
		--t.RMAnumber = @rma and o.OrderNumber = r.OrderNumber
	)
) AND LEN(t.RMANumber) > 1
GROUP BY 
t.RMAnumber,
t.Date,
r.Reason,
t.ReturnedBy,
o.OrderStatus,
d.DetailDate,
CONVERT(nvarchar(250), r.Notes),
t.OrderNumber,
rd.WrongSKU,
d.Product,
t.Quantity,
o.MarketName,
CONVERT(nvarchar(60), o.GiftMessage),
cart.CartName,
o.ProductTotal, -- Refund
o.TaxTotal,
o.ShippingTotal,
rp.DateDone,
rp.Condition,
StatusTrackingNumber,
CONVERT(nvarchar(100), n.Notes),
CONVERT(nvarchar(10), n.EntryDate, 101),
 r.Exchange 
--ORDER BY 
--RMAnumber,
--Date;


SET FMTONLY OFF;
SELECT 
tmp.OrderNumber NumericKey, --orders
tmp.DateDone,
tmp.RMA RMA,
tmp.DateIssued DateIssued,
tmp.Sku Sku,
tmp.[Type] [Type],
tmp.QuantityOrdered,
tmp.RMAreason RMAreason,
tmp.SoldBy SoldBy,
u.FullName RmaIssued,
tmp.TrackingNumber TrackingNumber, 
tmp.StatusTrackingNumber StatusTrackingNumber,
tmp.Refund Refund,
tmp.Charge Charge,
tmp.[Status] [Status],
tmp.Condition Condition,
tmp.Notes Notes,
tmp.OrderNumber OrderNumber,
O.CartID
FROM 
@TempRmas tmp
INNER JOIN 
OrderManager.dbo.usysOMUsers u (nolock)
ON tmp.RmaIssued = u.UserID
LEFT OUTER JOIN OrderManager.dbo.Orders O
ON O.OrderNumber = tmp.OrderNumber
WHERE tmp.QuantityOrdered IS NOT NULL
GROUP BY 
tmp.OrderNumber,
tmp.DateDone,
--CONVERT(nvarchar(10), EntryDate, 101),
--CONVERT(nvarchar(100), n.Notes), 
tmp.RMA,
tmp.DateDone,
DateIssued,
tmp.DateDone,
tmp.Sku,
tmp.[Type],
tmp.QuantityOrdered,
RMAreason,
SoldBy,
RmaIssued,
TrackingNumber, 
StatusTrackingNumber,
Refund,
Charge,
tmp.[Status],
Condition,
tmp.Notes,
u.FullName,
O.CartID
ORDER BY
DateDone desc,
OrderNumber,
RMA,
O.CartID
END
go

