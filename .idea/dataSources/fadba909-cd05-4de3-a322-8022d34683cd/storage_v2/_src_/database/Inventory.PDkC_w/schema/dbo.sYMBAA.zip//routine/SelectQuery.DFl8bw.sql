CREATE PROCEDURE [dbo].SelectQuery
AS
	SET NOCOUNT ON;
SELECT ID, InventoryAdjustmentsID, ProductCatalogID, Quantity, OMnumber, inventory.dbo.fn_GetProductName(ProductCatalogID) FROM dbo.InventoryAdjustmentDetails
go

