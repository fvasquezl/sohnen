-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-08-07
-- Description:	Update Virtual Stock Bulbs With Connector
-- =============================================
CREATE PROCEDURE [dbo].[sp_Update_VirtStock_BulbsWithConnector]
AS
BEGIN
	DECLARE @CURSORASSY CURSOR,
		@SKU		INT,
		@SUBSKU		INT,
		@STOCK		INT
	SET NOCOUNT ON;

	SET @CURSORASSY = CURSOR FOR
    
	SELECT AD.ProductCatalogID, AD.SubSKU
	FROM Inventory.dbo.AssemblyDetails AD WITH(NOLOCK)
	INNER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	ON PC.ID = AD.ProductCatalogID
	WHERE AD.SubSKU IN (
		SELECT PC.ID FROM Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
		LEFT OUTER JOIN Inventory.dbo.AssemblyDetails AD WITH(NOLOCK)
		ON AD.ProductCatalogID = PC.ID
		WHERE AD.ProductCatalogID IS NULL
		AND PC.CategoryID IN ('5','6','7','8','9','15','16','17','18','19','61','63','88','89','90','91')
	)
	AND PC.Name LIKE '%+%'

	OPEN @CURSORASSY FETCH NEXT FROM @CURSORASSY INTO @SKU, @SUBSKU
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
	
		SET @STOCK = CONVERT(INT,ISNULL((
						SELECT SUM(GS.GlobalStock) FROM Inventory.dbo.AssemblyDetails AD WITH(NOLOCK)
						INNER JOIN Inventory.dbo.Global_Stocks GS WITH(NOLOCK)
						ON GS.ProductCatalogId = AD.ProductCatalogID
						WHERE AD.SubSKU = @SKU AND ISNULL(GS.GlobalStock,0) > 0),0))

		--SELECT *, @STOCK, @SKU FROM Inventory.dbo.Global_Stocks WHERE ProductCatalogId = @SUBSKU
		UPDATE Inventory.dbo.Global_Stocks SET VirtualStock = (ISNULL(VirtualStock,0) + ISNULL(@STOCK,0))--, TotalStock = (ISNULL(GlobalStock,0) + ISNULL(VirtualStock,0) + ISNULL(@STOCK,0) )
		WHERE ProductCatalogId = @SUBSKU

		FETCH NEXT FROM @CURSORASSY INTO @SKU, @SUBSKU
	END
	CLOSE @CURSORASSY
	DEALLOCATE @CURSORASSY
END
go

