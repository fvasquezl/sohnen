-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_Count_Items_By_AdjustmentType
(
	@ProductCatalogId as integer, @InitialDate as datetime , @FinalDate as datetime, @FlowType as integer
)
RETURNS real
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar as real

	SET @ResultVar = 0
	
	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar =  SUM (b.quantity)
	 FROM Inventory.dbo.InventoryAdjustments a,
	      Inventory.dbo.InventoryAdjustmentDetails b
	 WHERE (a.ID = b.InventoryAdjustmentsID)
			and (b.ProductCatalogID = @ProductCatalogId)
			and (a.Date between @InitialDate and @finalDate)
			and (a.Flow = @flowtype)

	-- Return the result of the function
	RETURN @ResultVar

END
go

