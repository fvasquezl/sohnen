-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-10-27
-- Description:	Get SKU information by MIT Serial
-- =============================================
CREATE PROCEDURE spGetSKU_MITSerial
	@MITSerial		NVARCHAR(10)
AS
BEGIN
	DECLARE		@SKU	INT
	SET NOCOUNT ON;

	SELECT @SKU = ProductCatalogID FROM Inventory.dbo.LampProduction WHERE MITSERIAL = @MITSerial

	SELECT CASE WHEN ISNULL(@SKU,0) = 0 THEN '' ELSE CONVERT(NVARCHAR,@SKU) END
END
go

