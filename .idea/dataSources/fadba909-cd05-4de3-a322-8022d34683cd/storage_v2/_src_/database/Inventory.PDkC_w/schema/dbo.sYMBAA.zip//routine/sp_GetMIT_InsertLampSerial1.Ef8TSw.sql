-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-06-03
-- Description:	Insert Print and Reprint Serial
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetMIT_InsertLampSerial1] 
		@SKU				INT,
		@LotNumber			NVARCHAR(50),
		@BurnerSerial		NVARCHAR(50),
		@Assembler			NVARCHAR(50),
		@MITSerial_start	NVARCHAR(10),
		@MITSerial_end		NVARCHAR(10),
		@print_qty			INT,
		@status				NVARCHAR(1),
		@create_user		NVARCHAR(50),
		@print_in			NVARCHAR(50),
		@Supplier			NVARCHAR(50),
		@Brand				NVARCHAR(50)
AS
DECLARE
	@SEQ_NUM	INT = 0,
	@START_NUM	INT = 0,
	@MITSER		NVARCHAR(6)
BEGIN
	SET NOCOUNT ON;
	
	SET @Brand = (CASE WHEN ISNULL(@Brand,'') <> '' THEN @Brand ELSE 'M' END)

	IF(ISNULL(@status,'')='P')
	BEGIN
		IF(ISNULL((SELECT COUNT(*) FROM Inventory.dbo.LampProductionSerial WHERE @MITSerial_start BETWEEN MITSerial_start AND MITSerial_end OR @MITSerial_end BETWEEN MITSerial_start AND MITSerial_end),0) < 1)
		BEGIN
			SET @SEQ_NUM = CONVERT(INT,SUBSTRING(@MITSerial_end,LEN(@MITSerial_end)-3,4))			
			SET @START_NUM = CONVERT(INT,SUBSTRING(@MITSerial_start,LEN(@MITSerial_start)-3,4))
			SET @MITSER = SUBSTRING(@MITSerial_start,1,LEN(@Brand)+3)
			
			INSERT INTO Inventory.dbo.LampProductionSerial (SKU,MITSerial_start,MITSerial_end,seq_num,print_qty,status,create_user,print_in) 
			VALUES (@SKU,@MITSerial_start,@MITSerial_end,@SEQ_NUM,@print_qty,@status,@create_user,@print_in)

			WHILE (@START_NUM <= @SEQ_NUM)
			BEGIN
		
				INSERT INTO Inventory.dbo.LampProduction (Date,LotNumber,ProductCatalogID,BurnerSerial,MITSerial,Assembler,Supplier,Brand) 
				VALUES (GETDATE(),@LotNumber,@SKU,@BurnerSerial,@MITSER + RIGHT('0000' + CONVERT(NVARCHAR,@START_NUM),4),@Assembler,@Supplier,@Brand)

				SET @START_NUM = @START_NUM + 1
			END
		END
	END
	ELSE
	BEGIN
		INSERT INTO Inventory.dbo.LampProductionSerial (SKU,MITSerial_start,MITSerial_end,seq_num,print_qty,status,create_user,print_in) 
		VALUES (@SKU,@MITSerial_start,@MITSerial_end,@print_qty,@print_qty,@status,@create_user,@print_in)

		SET @START_NUM = 1
	END

	SELECT @START_NUM
END
go

