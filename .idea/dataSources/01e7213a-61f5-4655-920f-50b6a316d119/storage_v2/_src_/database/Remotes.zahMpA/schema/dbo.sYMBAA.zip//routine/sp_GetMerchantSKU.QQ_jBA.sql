
-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 3-29-2016
-- Description:	GiveMerchantSKUAutomated
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetMerchantSKU] 
	-- Add the parameters for the stored procedure here
	@pSKU NVARCHAR(MAX) = 0

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
	
	DECLARE @stMerchantSKU AS NVARCHAR(MAX)
	DECLARE @Sequencer AS INT

	--DECLARE @pSKU AS NVARCHAR(MAX)
	--SET @pSKU = 'RMTC01075'

	IF (SELECT TOP(1) [MerchantSKU] FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [SKU] = @pSKU) IS NOT NULL

	BEGIN

	  SET @Sequencer = CAST(RIGHT((SELECT TOP(1) [MerchantSKU] FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [SKU] = @pSKU AND RIGHT([MerchantSKU],5) NOT LIKE '%FBA%' ORDER BY [MerchantSKU] DESC),3) AS INT) + 1
	  --SET @Sequencer = CAST(RIGHT((SELECT TOP(1) [MerchantSKU] FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [SKU] = @pSKU AND RIGHT([MerchantSKU],5) NOT LIKE '%FBA%' AND ISNUMERIC(RIGHT([MerchantSKU], 3)) = 1 ORDER BY [MerchantSKU] DESC),3) AS INT) + 1
	 SET @stMerchantSKU = CAST(@pSKU AS NVARCHAR(MAX)) + '-' + CAST(REPLICATE('0',3-LEN(@Sequencer)) AS NVARCHAR(MAX)) + CAST(@Sequencer AS NVARCHAR(MAX))

 
	END
 

	IF (SELECT TOP(1) [MerchantSKU] FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [SKU] = @pSKU) IS NULL
		OR (SELECT TOP(1) RIGHT([MerchantSKU],4) FROM [Remotes].[dbo].[MarketplaceMapping] WHERE [SKU] = @pSKU ORDER BY [SKU] ASC) LIKE '%FBA%'
 
	BEGIN 
		SET @stMerchantSKU =  @pSKU + '-001'
	END 

	SELECT @stMerchantSKU
END

go

