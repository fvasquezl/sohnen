-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 10-31-2015
-- Description:	Get Inventory Analytics Summary
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetInventoryAnalyticsSummary] 
	-- Add the parameters for the stored procedure here
	@pSKU int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
DECLARE @SummaryTable TABLE ([Sold] INT, [SoldFBA] INT, [SoldTotal] INT, [Removed] INT, [PendingFBA] INT, [MissedOpportunities] INT, [Days] NVARCHAR(MAX), [SoldDaily] INT, [RemovedDaily] INT)

DECLARE @PendingFBAUnits INT
SET @PendingFBAUnits = (SELECT SUM([PendingFBA]) FROM [Inventory].[dbo].fn_GetRecursiveStockMovements(@pSKU,'30'))

DECLARE @MissedUnits30 INT
DECLARE @SoldUnits30 INT
DECLARE @SoldFBAUnits30 INT
DECLARE @SoldTotalUnits30 INT
DECLARE @RemovedQtyUnits30 INT

DECLARE @MissedUnits60 INT
DECLARE @SoldUnits60 INT
DECLARE @SoldFBAUnits60 INT
DECLARE @SoldTotalUnits60 INT
DECLARE @RemovedQtyUnits60 INT

DECLARE @MissedUnits90 INT
DECLARE @SoldUnits90 INT
DECLARE @SoldFBAUnits90 INT
DECLARE @SoldTotalUnits90 INT
DECLARE @RemovedQtyUnits90 INT


SELECT	@MissedUnits30 = SUM([MissedOpportunities]),
		@SoldUnits30 = SUM([SoldQty]),
		@SoldFBAUnits30 = SUM([SoldQtyFBA]),
		@SoldTotalUnits30 = SUM([SoldQty])+SUM([SoldQtyFBA]),
		@RemovedQtyUnits30 = SUM([RemovedQty])
 FROM [Inventory].[dbo].fn_GetRecursiveStockMovements(@pSKU,'30')

SELECT	@MissedUnits60 = SUM([MissedOpportunities]),
		@SoldUnits60 = SUM([SoldQty]),
		@SoldFBAUnits60 = SUM([SoldQtyFBA]),
		@SoldTotalUnits60 = SUM([SoldQty])+SUM([SoldQtyFBA]),
		@RemovedQtyUnits60 = SUM([RemovedQty])
 FROM [Inventory].[dbo].fn_GetRecursiveStockMovements(@pSKU,'60')

SELECT	@MissedUnits90 = SUM([MissedOpportunities]),
		@SoldUnits90 = SUM([SoldQty]),
		@SoldFBAUnits90 = SUM([SoldQtyFBA]),
		@SoldTotalUnits90 = SUM([SoldQty])+SUM([SoldQtyFBA]),
		@RemovedQtyUnits90 = SUM([RemovedQty])
 FROM [Inventory].[dbo].fn_GetRecursiveStockMovements(@pSKU,'90')

 
---Inventory Analytics Summary
INSERT INTO @SummaryTable ([Sold], [SoldFBA], [SoldTotal], [Removed], [PendingFBA], [MissedOpportunities], [Days], [SoldDaily], [RemovedDaily])
VALUES (@SoldUnits30, 
		@SoldFBAUnits30,
		@SoldTotalUnits30,
		@RemovedQtyUnits30,
		@PendingFBAUnits,
		@MissedUnits30,
		'0-30',
		CAST((@SoldTotalUnits30/30) AS DECIMAL(10,2)),
		CAST((@RemovedQtyUnits30/30) AS DECIMAL(10,2)))


INSERT INTO @SummaryTable
VALUES	((@SoldUnits60 - @SoldUnits30),
		(@SoldFBAUnits60 - @SoldFBAUnits30),
		(@SoldTotalUnits60 - @SoldTotalUnits30),
		(@RemovedQtyUnits60 - @RemovedQtyUnits30),
		'0',
		(@MissedUnits60 - @MissedUnits30),
		'31-60',
		(CAST(CAST((@SoldTotalUnits60 - @SoldTotalUnits30) AS DECIMAL(10,2)) / 30 AS DECIMAL(10,2))),
		(CAST(CAST((@RemovedQtyUnits60 - @RemovedQtyUnits30) AS DECIMAL(10,2)) / 30 AS DECIMAL(10,2))))


INSERT INTO @SummaryTable
VALUES	((@SoldUnits90 - @SoldUnits60), 
		(@SoldFBAUnits90 - @SoldFBAUnits60),
		(@SoldTotalUnits90 - @SoldTotalUnits60),
		(@RemovedQtyUnits90 - @RemovedQtyUnits60),
		'0',
		(@MissedUnits90 - @MissedUnits60),
		'61-90',
		(CAST(CAST((@SoldTotalUnits90 - @SoldTotalUnits60) AS DECIMAL(10,2)) / 30 AS DECIMAL(10,2))),
		(CAST(CAST((@RemovedQtyUnits90 - @RemovedQtyUnits60) AS DECIMAL(10,2)) / 30 AS DECIMAL(10,2))))


SELECT [Sold], [SoldFBA], [SoldTotal], [Removed], [PendingFBA], [MissedOpportunities], [Days], [SoldDaily], [RemovedDaily] FROM @SummaryTable

END
go

