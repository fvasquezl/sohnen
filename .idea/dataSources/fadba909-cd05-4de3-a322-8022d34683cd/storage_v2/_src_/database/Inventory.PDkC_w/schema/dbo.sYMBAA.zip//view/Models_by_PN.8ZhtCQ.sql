
CREATE VIEW [dbo].[Models_by_PN]
AS
SELECT     TOP (100) PERCENT A.Manufacturer, B.Model, B.PartNumber
FROM         dbo.Compatibility AS A INNER JOIN
                      dbo.CompatibilityDetails AS B ON A.PartNumber = B.PartNumber
GROUP BY B.PartNumber, A.Manufacturer, B.Model
ORDER BY B.PartNumber, A.Manufacturer, B.Model

go

