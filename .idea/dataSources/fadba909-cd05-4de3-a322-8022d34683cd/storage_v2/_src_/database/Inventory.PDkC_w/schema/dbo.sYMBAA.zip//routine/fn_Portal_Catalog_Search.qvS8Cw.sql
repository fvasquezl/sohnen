-- =============================================
-- Author:		Luis Bautista
-- Create date: FEB-21-2014
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Portal_Catalog_Search]
(
	@pPage INT, @pItemsByPage Int, @pBrand varchar(50), @pPN  varchar(50), @pModel  varchar(50),@pSearch varchar(50)
)
RETURNS @Catalog TABLE 
(
							  Id int 
							, CatalogId int
							, Manufacturer nvarchar(50)
							, [Type] nvarchar(50)
							, tbImage nvarchar(250)
							, BigImage nvarchar(250)
							, Models_List varchar(1000)
							, PN_List  varchar(1000)
							, PageNo Int default 0
							, ItemCounter int
							, TotalPages int
)
AS
BEGIN
	DECLARE @TotalItems INT
	DECLARE @InitialItem int
	DECLARE @LastItem int
	DECLARE @TotalPages int;
	
	
	Declare  @TempTable Table(
								Id int  identity(1,1)
							, CatalogId int
							, Manufacturer nvarchar(50)
							, [Type] nvarchar(50)
							, tbImage nvarchar(250)
							, BigImage nvarchar(250)
							, Models_List varchar(1000)
							, PN_List varchar(1000)
							, PageNo Int default 0
							, ItemCounter int
							, TotalPages int
			);

	
	
	IF (@pBrand = '')	AND (@pPN='') AND (@pModel = '') and (@pSearch <> '') 
	BEGIN
			
		INSERT INTO  @TempTable ( CatalogId, Manufacturer, [Type]
							, tbImage , BigImage 
							, Models_list ,PN_List , PageNo 
							,ItemCounter )
			SELECT	   CatalogId, Brand, [Type], 
							 tbImage , BigImage 
							, Models_Slash ,''
							, @pPage
							, @TotalItems
                                FROM [Inventory].[dbo].[Catalog_Pager]
                                WHERE (
										   (CatalogId like '%' + @pSearch +'%')
									   OR (PartNumber like '%' + @pSearch + '%')
									   OR (PartNumberV2 like '%' + @pSearch +'%')
									   OR (PartNumberV3 like '%' + @pSearch +'%')
									   OR (PriceGeneric like '%' + @pSearch +'%')
									   OR (PricePremium like '%' + @pSearch +'%')
									   OR (CatalogID_G like '%' + @pSearch +'%')
									   OR (CatalogID_O like '%' + @pSearch +'%')
									   OR (Warranty_G like '%' + @pSearch +'%')
									   OR (Warranty_O like '%' + @pSearch +'%')
									   OR (models like '%' + @pSearch +'%')
									   OR (Brand like '%' + @pSearch +'%')
										);
	END	
	
	
	IF (@pBrand <> '')	AND (@pPN<>'') AND (@pModel = '') and (@pSearch = '') 
	BEGIN
			
			INSERT INTO  @TempTable ( CatalogId, Manufacturer, [Type],
							 tbImage , BigImage 
							, Models_list ,PN_List , PageNo 
							,ItemCounter )
			SELECT	   CatalogId, Brand, [Type], 
							 tbImage , BigImage 
							, Models_Slash ,''
							, @pPage
							, @TotalItems
				          FROM [Inventory].[dbo].[Catalog_Pager]
                          WHERE (
										(Brand = @pBrand)
										AND
										 (
											(PartNumber = @pPN)
											OR (PartNumberV2 = @pPN)
											OR (PartNumberV3 = @pPN)
										  )
									   
									);
										
		
	END	
	
	
	
	IF (@pBrand <> '')	AND (@pPN='') AND (@pModel <> '') and (@pSearch = '') 
	BEGIN
			
			INSERT INTO @Catalog ( CatalogId, Manufacturer, [Type],
							 tbImage , BigImage 
							, Models_list ,PN_List , PageNo 
							,ItemCounter )
			SELECT	   CatalogId, Brand, [Type], 
							 tbImage , BigImage 
							, Models_Slash ,''
							, @pPage
							, @TotalItems
				          FROM [Inventory].[dbo].[Catalog_Pager]
                          WHERE (
										(Brand = @pBrand)
										AND
										 (
											Models like ('%' + @pModel + '%')
										  )
									   
									);
			
			
	END	


							
			SET @TotalItems = (SELECT COUNT(id) FROM @TempTable);
			SET @TotalPages = CEILING(@TotalItems / @pItemsByPage);
			SET @InitialItem = ((@pPage -1) * @pItemsByPage) + 1;
			SET @LastItem = (@pPage * @pItemsByPage) ;
			
			INSERT INTO @Catalog (id,CatalogId, Manufacturer, [Type]
							, tbImage , BigImage 
							, Models_List ,PN_List , PageNo 
							,ItemCounter, TotalPages )
			SELECT 
							id,CatalogId, Manufacturer, [Type]
							, tbImage , BigImage 
							, Models_List ,PN_List , PageNo ,@TotalItems, @TotalPages
                                FROM  @TempTable 
                                WHERE  Id between @InitialItem AND @LastItem
                                ;

			RETURN 
END
go

