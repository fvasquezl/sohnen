-- =============================================
-- Author:		Araceli Sánchez
-- Create date: 2016-03-30
-- Description:	Scan By Hour and Between Dates version to linq
-- =============================================
CREATE PROCEDURE [dbo].[sp_LampProductionScanByHourDashBoardLinq]
AS
BEGIN
	SELECT 
	REPLACE(C.PROD_LINE, '/', '_') PROD_LINE, 
	C.SKU, 
	C.PROD_PLAN, 
	C.PROD_QTY, 
	C.PROD_DEFF, 
	C.PROD_QTY - C.PROD_PLAN AS PROD_DIFF,
	(
		CASE 
		WHEN C.PROD_DEFF > 0 AND C.PROD_QTY > 0 
		THEN (C.PROD_DEFF / C.PROD_QTY) * 100 
		ELSE 0 
		END
	) AS PROD_PDR
    FROM (
		SELECT 
		A.PROD_LINE, 
		A.SKU, 
		A.PROD_PLAN, 
		SUM(CASE WHEN B.SCAN_TYPE = 'S' THEN 1 ELSE 0 END) AS PROD_QTY,
		SUM(CASE WHEN B.SCAN_TYPE = 'D' THEN 1 ELSE 0 END) AS PROD_DEFF
		FROM (
				SELECT 
				PROD_DATE, 
				PROD_LINE,
				SKU, 
				SUM(PROD_PLAN) AS PROD_PLAN
				FROM Inventory.dbo.LampProductionPlan
				WHERE 
				PROD_DATE = CONVERT(NVARCHAR,GETDATE(),112) AND 
				STATUS NOT IN ('F','C')
				GROUP BY 
				PROD_DATE, 
				PROD_LINE, 
				SKU
		) A
		LEFT OUTER JOIN 
		Inventory.dbo.LampProductionScan B
		ON 
		B.SKU = A.SKU AND 
		B.PROD_LINE = A.PROD_LINE 
		AND CONVERT(NVARCHAR,B.SCAN_DATETIME,112) = A.PROD_DATE
		GROUP BY 
		A.PROD_LINE, 
		A.SKU, 
		A.PROD_PLAN
    ) C
END
go

