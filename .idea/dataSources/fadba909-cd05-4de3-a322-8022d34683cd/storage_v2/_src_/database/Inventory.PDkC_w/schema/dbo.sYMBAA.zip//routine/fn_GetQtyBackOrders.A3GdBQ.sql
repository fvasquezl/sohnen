-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-06-04
-- Description:	Get All BackOrdersBySKU
-- =============================================
CREATE FUNCTION fn_GetQtyBackOrders
(
	@SKU INT
)
RETURNS INT
AS
BEGIN
	DECLARE @QtyOrdered INT

	SET @QtyOrdered = ISNULL((SELECT SUM(CONVERT(INT,ISNULL(QtyBackOrdered,'0'))) FROM Inventory.dbo.PurchaseOrderData WITH(NOLOCK) 
								WHERE CONVERT(INT,ISNULL(QtyBackOrdered,'0')) > 0 AND SKU = CONVERT(NVARCHAR,@SKU)),0)

	RETURN @QtyOrdered
END
go

