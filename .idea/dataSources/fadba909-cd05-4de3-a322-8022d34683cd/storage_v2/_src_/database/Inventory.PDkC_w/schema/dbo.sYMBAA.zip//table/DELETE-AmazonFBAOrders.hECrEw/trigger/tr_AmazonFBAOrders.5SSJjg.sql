-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-10-12
-- Description: Update OrderQty
-- =============================================
CREATE TRIGGER [dbo].[tr_AmazonFBAOrders]
   ON  [dbo].[AmazonFBAOrders]
   AFTER UPDATE
AS 
BEGIN
	DECLARE	@OrderID		INT,
			@Completed		NVARCHAR(50),
			@ASIN			NVARCHAR(50),
			@MerchantSKU	NVARCHAR(50),
			@OrderDate		DATE,
			@OrderQty		INT
	SET NOCOUNT ON;

	--SELECT @OrderID = OrderID, @Completed = Completed, @ASIN = ASIN, @MerchantSKU = MerchantSKU, @OrderDate = OrderDate, @OrderQty = OrderQty
	--FROM inserted

	--IF(ISNULL(@Completed,'No') = 'Yes')
	--BEGIN
	--	SET @OrderQty = ISNULL((SELECT SUM(ConfirmQty) FROM Inventory.dbo.AmazonFBAOrderConfirm WHERE ASIN = @ASIN AND MerchantSKU = @MerchantSKU AND ConfirmDate = @OrderDate),0)
	--	IF(@OrderQty > 0)
	--	BEGIN
	--		UPDATE Inventory.dbo.AmazonFBAOrders SET OrderQty = @OrderQty, CompletedDate = GETDATE()
	--		WHERE OrderID = @OrderID
	--	END
	--END
	--ELSE
	--BEGIN
	--	IF(ISNULL(@Completed,'No') = 'No')
	--	BEGIN
	--		UPDATE Inventory.dbo.AmazonFBAOrderConfirm SET ConfirmQty = ConfirmQty - @OrderQty, change_date = GETDATE() WHERE ASIN = @ASIN AND MerchantSKU = @MerchantSKU AND ConfirmDate = @OrderDate
	--	END
	--END
END
go

disable trigger tr_AmazonFBAOrders on [DELETE-AmazonFBAOrders]
go

