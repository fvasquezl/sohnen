

-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <3-10-2015>
-- Description:	<Send Portal User Emails for Tracking>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ExportResellerShipStation] 
		@CustomerID NVARCHAR(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @xml NVARCHAR(MAX)
DECLARE @sql NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
DECLARE @date VARCHAR(12)
DECLARE @subtext VARCHAR(50)
DECLARE @subject VARCHAR(62)
DECLARE @recipients VARCHAR(255)
DECLARE @datestart date

--Set Variables for CustomerID
	DECLARE @ShipFromEmail varchar(255);
		
	---Get values from order manager	
    SELECT @ShipFromEmail = OMC.[Email]
	FROM OrderManager.dbo.Customers AS OMC WHERE OMC.CustomerID = @CustomerID;  



SET @xml =CAST(( 
SELECT O.[OrderNumber]  AS 'td','',
	  (CASE WHEN len(IsNull(Cast(O.[OrderInst] AS NVARCHAR(50)),'')) - len(replace(IsNull(Cast(O.[OrderInst] AS NVARCHAR(50)),''), '-', '')) > 0 THEN CAST(O.[OrderInst] AS NVARCHAR(50)) ELSE CAST(O.[SourceOrderNumber] AS NVARCHAR(50)) END) AS 'td','',
	  O.[PONumber]  AS 'td','',
      CONVERT(VARCHAR(10),CAST(O.[OrderDate] AS DATE),101)  AS 'td','',
      CAST(O.[ProductTotal] AS Decimal(10,2))  AS 'td','',
	  CAST(O.[ShippingTotal] AS Decimal(10,2))  AS 'td','',
	  CAST(O.[GrandTotal] AS Decimal(10,2))  AS 'td','',
	  CONVERT(VARCHAR(10),CAST(TRK.[DateAdded] AS DATE),101)  AS 'td','',
	  O.[Shipping]  AS 'td','',
	  TRK.[TrackingID]  AS 'td'
FROM [OrderManager].[dbo].[Orders] AS O
LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] AS TRK ON (O.[OrderNumber] = TRK.[NumericKey])
WHERE O.[CustomerID] = @CustomerID AND CAST(TRK.[DateAdded] AS DATE) BETWEEN CAST(GETDATE()-1 AS DATE) AND CAST(GETDATE() AS DATE)

FOR XML PATH('tr'), ELEMENTS 
) AS NVARCHAR(MAX))



IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[Inventory].[dbo].[tmpExportTracking]') AND type in (N'U'))
DROP TABLE [Inventory].[dbo].[tmpExportTracking]


--Create Temp Table
CREATE TABLE [Inventory].[dbo].[tmpExportTracking](
	[MITOrderNumber] INT, 
	[CustomerOrderNumber] NVARCHAR(50), 
	[PONumber] NVARCHAR(20), 
	[OrderDate] date, 
	[ProductTotal] Decimal(10,2), 
	[ShippingTotal] Decimal(10,2), 
	[GrandTotal] Decimal(10,2), 
	[DateShipped] Date, 
	[MITechShipMethod] NVARCHAR(50), 
	[TrackingNumber] NVARCHAR(50));

INSERT INTO [Inventory].[dbo].[tmpExportTracking]
SELECT O.[OrderNumber]  AS [MITOrderNumber],
	  (CASE WHEN len(IsNull(Cast(O.[OrderInst] AS NVARCHAR(50)),'')) - len(replace(IsNull(Cast(O.[OrderInst] AS NVARCHAR(50)),''), '-', '')) > 0 THEN CAST(O.[OrderInst] AS NVARCHAR(50)) ELSE CAST(O.[SourceOrderNumber] AS NVARCHAR(50)) END) AS [CustomerOrderNumber],
	  O.[PONumber]  AS [PONumber],
      CONVERT(VARCHAR(10),CAST(O.[OrderDate] AS DATE),101)  AS [OrderDate],
      CAST(O.[ProductTotal] AS Decimal(10,2))  AS [ProductTotal],
	  CAST(O.[ShippingTotal] AS Decimal(10,2))  AS [ShippingTotal],
	  CAST(O.[GrandTotal] AS Decimal(10,2))  AS [GrandTotal],
	  CONVERT(VARCHAR(10),CAST(TRK.[DateAdded] AS DATE),101)  AS [DateShipped],
	  O.[Shipping]  AS [MITechShipMethod],
	  TRK.[TrackingID]  AS [TrackingNumber]
FROM [OrderManager].[dbo].[Orders] AS O
LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] AS TRK ON (O.[OrderNumber] = TRK.[NumericKey])
WHERE O.[CustomerID] = @CustomerID AND CAST(TRK.[DateAdded] AS DATE) BETWEEN CAST(GETDATE()-1 AS DATE) AND CAST(GETDATE() AS DATE)



/** FIX HTML **/
 SET @xml = replace(@xml, '&amp;', '&')
 SET @xml = replace(@xml, '&lt;' , '<')
 SET @xml = replace(@xml, '&gt;' , '>')
/** FIX HTML END**/

SET @subtext = 'Tracking Export - '
SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
SET @subject = @subtext + @date
SET @recipients = @ShipFromEmail+';neworder@mitechnologiesinc.com'
SET @body ='<html><center><H1>Tracking Export - <br>' + @date + '</H1><br><br></Center>Portal User,<br>Attached is a list of orders that were shipped today: <Center><body bgcolor=yellow><table border = 2><tr>
<th>MITOrderNumber</th>
<th>CustomerOrderNumber</th>
<th>PONumber</th>
<th>OrderDate</th>
<th>ProductTotal</th>
<th>ShippingTotal</th>
<th>GrandTotal</th>
<th>ShipDate</th>
<th>MITechShipMethod</th>
<th>TrackingNumber</th>
</tr>' 
SET @body = @body + @xml +'</center></table><br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'

PRINT @body

If @xml is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML',
@query='SELECT * FROM [Inventory].[dbo].[tmpExportTracking]',
@query_result_no_padding = 1,
@attach_query_result_as_file=1,
@query_attachment_filename = 'trackingexport.csv',
@query_result_separator = ','
END

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[Inventory].[dbo].[tmpExportTracking]') AND type in (N'U'))
DROP TABLE [Inventory].[dbo].[tmpExportTracking]




END

go

