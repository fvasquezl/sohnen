-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 5-12-2017
-- Description:	Clean Order Status in OM
-- =============================================
CREATE PROCEDURE [dbo].[sp_CleanOMOrderStatus] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
 
		SELECT DISTINCT [OrderStatus] 
		FROM [OrderManager].[dbo].[Orders] WITH(NOLOCK)

		--  Cancelled
		--  Pending Shipment
		--  Item Returned
		--  Shipped

		---------------------------------------------------------------------------------
		--------------------Clean up all Cancelled Orders--------------------
		DECLARE @NextOrder INT, @ordernumber_cursor CURSOR

		SET @ordernumber_cursor = CURSOR FOR 

		SELECT [OrderNumber] FROM [OrderManager].[dbo].[Orders] WITH(NOLOCK) WHERE ([Cancelled] = 1 AND [OrderStatus] != 'Cancelled') OR ([OrderStatus] = 'Order Canceled')


		OPEN @ordernumber_cursor 
		FETCH NEXT FROM @ordernumber_cursor 
		INTO @NextOrder
	   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
	
			UPDATE [OrderManager].[dbo].[Orders] SET [Cancelled] = 1, [OrderStatus] = 'Cancelled' WHERE [OrderNumber] = @NextOrder

			NEXT_FETCH:
			FETCH NEXT FROM @ordernumber_cursor
			INTO @NextOrder
		END
		CLOSE      @ordernumber_cursor
		DEALLOCATE @ordernumber_cursor

		---------------------------------------------------------------------------------
		--------------------Clean up all Pending Shipment Order Statuses------------------
		DECLARE ordernumber_cursor CURSOR  
		FOR SELECT [OrderNumber] FROM [OrderManager].[dbo].[Orders] WITH(NOLOCK) WHERE [OrderStatus] = 'Item Added' OR [OrderStatus] = 'Item Exchanged' OR [OrderStatus] = 'Order Received'
		OR [OrderStatus] = 'Payment Received' OR [OrderStatus] = 'Payment Voided' OR [OrderStatus] = 'Tracking Number Edited' OR [OrderStatus] = 'Order Approved'
		


		OPEN ordernumber_cursor 
		FETCH NEXT FROM ordernumber_cursor   
		INTO @NextOrder

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
			UPDATE [OrderManager].[dbo].[Orders] SET [OrderStatus] = 'Pending Shipment' WHERE [OrderNumber] = @NextOrder

			NEXT_FETCH1:
			FETCH NEXT FROM ordernumber_cursor
			INTO @NextOrder

		END   
		CLOSE ordernumber_cursor;  
		DEALLOCATE ordernumber_cursor;  


		---------------------------------------------------------------------------------
		--------------------Clean up all Pending Shipment Order Statuses------------------
		DECLARE ordernumber_cursor CURSOR  
		FOR SELECT [OrderNumber] FROM [OrderManager].[dbo].[Orders] WITH(NOLOCK) WHERE ([OrderStatus] = 'Item Added' OR [OrderStatus] = 'Item Exchanged' OR [OrderStatus] = 'Order Received'
		OR [OrderStatus] = 'Payment Received' OR [OrderStatus] = 'Payment Voided' OR [OrderStatus] = 'Tracking Number Edited' OR [OrderStatus] IS NULL OR [OrderStatus] = '') AND [Cancelled] = 0 
		AND [OrderNumber] NOT IN (SELECT [OrderNum] FROM [OrderManager].[dbo].[Tracking] WITH(NOLOCK))


		OPEN ordernumber_cursor 
		FETCH NEXT FROM ordernumber_cursor   
		INTO @NextOrder

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
			UPDATE [OrderManager].[dbo].[Orders] SET [OrderStatus] = 'Pending Shipment' WHERE [OrderNumber] = @NextOrder

			NEXT_FETCH2:
			FETCH NEXT FROM ordernumber_cursor
			INTO @NextOrder
		END   
		CLOSE ordernumber_cursor;  
		DEALLOCATE ordernumber_cursor;  

		---------------------------------------------------------------------------------
		--------------------Clean up all Shipped Order Statuses------------------
		DECLARE ordernumber_cursor CURSOR  
		FOR SELECT [OrderNumber] FROM [OrderManager].[dbo].[Orders] WITH(NOLOCK) WHERE ([OrderStatus] = 'Item Added' OR [OrderStatus] = 'Item Exchanged' OR [OrderStatus] = 'Order Received'
		OR [OrderStatus] = 'Payment Received' OR [OrderStatus] = 'Payment Voided' OR [OrderStatus] = 'Tracking Number Edited' OR [OrderStatus] IS NULL OR [OrderStatus] = '') AND [Cancelled] = 0 
		AND [OrderNumber] IN (SELECT [OrderNum] FROM [OrderManager].[dbo].[Tracking] WITH(NOLOCK))

		OPEN ordernumber_cursor 
		FETCH NEXT FROM ordernumber_cursor   
		INTO @NextOrder

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
			UPDATE [OrderManager].[dbo].[Orders] SET [OrderStatus] = 'Shipped' WHERE [OrderNumber] = @NextOrder

			NEXT_FETCH3:
			FETCH NEXT FROM ordernumber_cursor
			INTO @NextOrder
		END   
		CLOSE ordernumber_cursor;  
		DEALLOCATE ordernumber_cursor;  



END
go

