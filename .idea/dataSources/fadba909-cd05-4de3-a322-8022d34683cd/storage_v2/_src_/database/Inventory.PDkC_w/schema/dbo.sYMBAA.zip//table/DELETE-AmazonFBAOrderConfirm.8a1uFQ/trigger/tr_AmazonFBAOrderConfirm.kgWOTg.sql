-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-10-10
-- Description:	Update Complete Order in AmazonFBAOrders
-- =============================================
CREATE TRIGGER [dbo].[tr_AmazonFBAOrderConfirm]
   ON dbo.AmazonFBAOrderConfirm
   AFTER INSERT,UPDATE
AS 
BEGIN
	DECLARE @ASIN			NVARCHAR(50),
			@MerchantSKU	NVARCHAR(50),
			@Date			DATE,
			@ConfirmQty		INT,
			@CURSOR_FBA		CURSOR,
			@OrderID		INT,
			@OrderQty		INT,
			@QtyRec			INT = 0
	SET NOCOUNT ON;

 --   SELECT @ASIN = ASIN, @MerchantSKU = MerchantSKU, @Date = ConfirmDate, @ConfirmQty = ConfirmQty
	--FROM inserted

	--SET @CURSOR_FBA = CURSOR FOR 

	--SELECT OrderID, ISNULL(OrderQty,0)
	--FROM Inventory.dbo.AmazonFBAOrders WHERE ASIN = @ASIN AND MerchantSKU = @MerchantSKU AND CONVERT(DATE,OrderDate) = @Date AND Completed = 'No'

	--OPEN @CURSOR_FBA 
	--	FETCH NEXT FROM @CURSOR_FBA 
	--	INTO @OrderID, @OrderQty
	   
	--	WHILE (@@FETCH_STATUS = 0)
	--	BEGIN
			
	--		SET @QtyRec = ISNULL((CASE WHEN @ConfirmQty >= @OrderQty THEN @OrderQty ELSE @ConfirmQty END),0)

	--		IF(@QtyRec > 0 )
	--		BEGIN
	--			UPDATE Inventory.dbo.AmazonFBAOrders SET Completed = (CASE WHEN (OrderQty - @QtyRec) <= 0 THEN 'Yes' ELSE 'No' END), OrderQty = OrderQty - @QtyRec
	--			WHERE OrderID = @OrderID
	--		END

	--		NEXT_FETCH:
	--		FETCH NEXT FROM @CURSOR_FBA
	--		INTO @OrderID, @OrderQty
	--	END
	--CLOSE      @CURSOR_FBA
	--DEALLOCATE @CURSOR_FBA
END
go

disable trigger tr_AmazonFBAOrderConfirm on [DELETE-AmazonFBAOrderConfirm]
go

