-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 10-30-2015
-- Description:	Create InventoryAnalyticsRecursive by Category, TargetDays, UserID
-- =============================================
CREATE PROCEDURE [dbo].[sp_CreateInventoryAnalyticsRecursive]
	-- Add the parameters for the stored procedure here
	@pCategory int = 0, 
	@pTargetDays int = 0,
	@pUserID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

			/**
			DROP TABLE [Inventory].[dbo].[InventoryAnalyticsRecursive]

			CREATE TABLE [Inventory].[dbo].[InventoryAnalyticsRecursive] ([SKU] INT,[Description] NVARCHAR(MAX), [0-30DayMissedOpportunities] INT, [31-60DayMissedOpportunities] INT, [61-90DayMissedOpportunities] INT, [0-30DaySold] INT, [31-60DaySold] INT, [61-90DaySold] INT, [0-30DayRemoved] INT, [31-60DayRemoved] INT, [61-90DayRemoved] INT, [QOH] INT,
			[vQOH] INT, [tQOH] INT, [BackOrders] INT, [PendingFBARecursive] INT, [TargetDays] INT, [HighestRunMissed] INT, [HighestRunSold] INT, [SoldVariance] INT, [OrderBasedOnSold] INT, [HighestRunRemoved] INT, [RemovedVariance] INT, [OrderBasedOnRemoved] INT, [OrderVariance] INT, [WeMakeIt?] NVARCHAR(MAX), [LowestCost] Decimal(10,4), [LowestCostSupplier] NVARCHAR(MAX), [ERPUnitCost] Decimal(10,4), [DateStamp] datetime)
			**/

			---Turn into Stored Procedure
			---Put Catch on Cursor Errors

			DECLARE @st0to30MissedOpportunities INT
			DECLARE @st0to60MissedOpportunities INT
			DECLARE @st0to90MissedOpportunities INT
			DECLARE @stHighestRunMissed INT
			DECLARE @st0to30Sold INT
			DECLARE @st0to60Sold INT
			DECLARE @st0to90Sold INT
			DECLARE @stHighestRunSold Decimal(10,2)
			DECLARE @stLowestRunSold Decimal(10,2)
			DECLARE @stOrderBasedOnSold Decimal(10,2)
			DECLARE @st0to30Removed INT
			DECLARE @st0to60Removed INT
			DECLARE @st0to90Removed INT
			DECLARE @stHighestRunRemoved Decimal(10,2)
			DECLARE @stLowestRunRemoved Decimal(10,2)
			DECLARE @stOrderBasedOnRemoved Decimal(10,1)
			DECLARE @stPendingFBARecursive INT
			DECLARE @stBackorders INT
			DECLARE @stCurrentSKU INT
			DECLARE @stCurrentSKUStock INT
			DECLARE @stStartTime DATETIME
			DECLARE @stEndTime DATETIME
			DECLARE @stUserEmail NVARCHAR(MAX)
			DECLARE @CategoryName NVARCHAR(MAX)
			DECLARE @ErrorCatch NVARCHAR(MAX)
			DECLARE @CategorySKUCount NVARCHAR(MAX)
			DECLARE @ProcessedSKUCount NVARCHAR(MAX)

			--DECLARE @pCategory int 
			--DECLARE @pTargetDays int
			--DECLARE @pUserID int
			--SET @pCategory = '41'
			--SET @pTargetDays = '90'
			--SET @pUserID = '19'

			SET @stStartTime = GETDATE()
			SET @CategoryName = (SELECT [Name] FROM [Inventory].[dbo].[Categories] (NOLOCK) WHERE [ID] = @pCategory)

			DELETE IAR FROM [Inventory].[dbo].[InventoryAnalyticsRecursive] AS IAR (NOLOCK)
			LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) ON (IAR.[SKU] = PC.[ID])
			WHERE PC.[CategoryID] = @pCategory

			DECLARE MovementsByCategory_Cursor CURSOR FOR
			SELECT [ID] FROM [Inventory].[dbo].[ProductCatalog] (NOLOCK) WHERE [CategoryID] = @pCategory
			AND [ID] NOT IN (SELECT [SKU] FROM [Inventory].[dbo].[InventoryAnalyticsRecursive] (NOLOCK))

			OPEN MovementsByCategory_Cursor
			FETCH NEXT FROM MovementsByCategory_Cursor INTO @stCurrentSKU
			WHILE @@FETCH_STATUS = 0  
			BEGIN TRY

						SELECT @st0to30Sold = IsNull((SUM([SoldQty])+SUM([SoldQtyFBA])),0),
								@st0to30Removed = IsNull((SUM([RemovedQty])),0),
								@stPendingFBARecursive = IsNull((SUM([PendingFBA])),0),
								@st0to30MissedOpportunities = IsNull((SUM([MissedOpportunities])),0)
						FROM [Inventory].[dbo].fn_GetRecursiveStockMovements(@stCurrentSKU,'30')

						SELECT @st0to60Sold = IsNull((SUM([SoldQty])+SUM([SoldQtyFBA])),0),
								@st0to60Removed = IsNull((SUM([RemovedQty])),0),
								@st0to60MissedOpportunities = IsNull((SUM([MissedOpportunities])),0)
						FROM [Inventory].[dbo].fn_GetRecursiveStockMovements(@stCurrentSKU,'60')

						SELECT @st0to90Sold = IsNull((SUM([SoldQty])+SUM([SoldQtyFBA])),0),
								@st0to90Removed = IsNull((SUM([RemovedQty])),0),
								@st0to90MissedOpportunities = IsNull((SUM([MissedOpportunities])),0)
						FROM [Inventory].[dbo].fn_GetRecursiveStockMovements(@stCurrentSKU,'90')

						SET @stBackorders = IsNull((SELECT SUM(Cast(QtyBackordered AS INT)) FROM Inventory.dbo.PurchaseOrderData (NOLOCK) WHERE SKU = @stCurrentSKU),0)
						
						SET @stCurrentSKUStock = IsNull((Select GS.[TotalStock] FROM [Inventory].[dbo].[Global_stocks] AS GS (NOLOCK) WHERE GS.[ProductCatalogID] = @stCurrentSKU),0)

						SET @stHighestRunMissed = (CASE
								WHEN @st0to30MissedOpportunities >= (@st0to60MissedOpportunities - @st0to30MissedOpportunities) AND @st0to30MissedOpportunities >= (@st0to90MissedOpportunities - @st0to60MissedOpportunities) THEN @st0to30MissedOpportunities
								WHEN (@st0to60MissedOpportunities - @st0to30MissedOpportunities) >= @st0to30MissedOpportunities AND (@st0to60MissedOpportunities - @st0to30MissedOpportunities) >= (@st0to90MissedOpportunities - @st0to60MissedOpportunities) THEN (@st0to60MissedOpportunities - @st0to30MissedOpportunities)
								WHEN (@st0to90MissedOpportunities - @st0to60MissedOpportunities) >= @st0to30MissedOpportunities AND (@st0to90MissedOpportunities - @st0to60MissedOpportunities) >= (@st0to60MissedOpportunities - @st0to30MissedOpportunities) THEN (@st0to90MissedOpportunities - @st0to60MissedOpportunities)
								ELSE  @st0to30MissedOpportunities END) 

						SET @stHighestRunSold = (CASE
								WHEN @st0to30Sold >= (@st0to60Sold - @st0to30Sold) AND @st0to30Sold >= (@st0to90Sold - @st0to60Sold) THEN @st0to30Sold
								WHEN (@st0to60Sold - @st0to30Sold) >= @st0to30Sold AND (@st0to60Sold - @st0to30Sold) >= (@st0to90Sold - @st0to60Sold) THEN (@st0to60Sold - @st0to30Sold)
								WHEN (@st0to90Sold - @st0to60Sold) >= @st0to30Sold AND (@st0to90Sold - @st0to60Sold) >= (@st0to60Sold - @st0to30Sold) THEN (@st0to90Sold - @st0to60Sold)
								ELSE  @st0to30Sold END) 

						SET @stLowestRunSold =	(CASE
								WHEN @st0to30Sold <= (@st0to60Sold - @st0to30Sold) AND @st0to30Sold <= (@st0to90Sold - @st0to60Sold) THEN @st0to30Sold
								WHEN (@st0to60Sold - @st0to30Sold) <= @st0to30Sold AND (@st0to60Sold - @st0to30Sold) <= (@st0to90Sold - @st0to60Sold) THEN (@st0to60Sold - @st0to30Sold)
								WHEN (@st0to90Sold - @st0to60Sold) <= @st0to30Sold AND (@st0to90Sold - @st0to60Sold) <= (@st0to60Sold - @st0to30Sold) THEN (@st0to90Sold - @st0to60Sold)
								ELSE  @st0to30Sold END)

						SET @stOrderBasedOnSold =  (CASE WHEN (Ceiling(((Cast(@stHighestRunSold + @stHighestRunMissed AS decimal(10,2))/30) * @pTargetDays)) + @stPendingFBARecursive) - (@stBackorders + @stCurrentSKUStock) < 0 THEN 0 
							  ELSE (Ceiling(((Cast(@stHighestRunSold + @stHighestRunMissed AS decimal(10,2))/30) * @pTargetDays)) + @stPendingFBARecursive) - (@stBackorders + @stCurrentSKUStock) END)
							  

						SET @stHighestRunRemoved = (CASE
								WHEN @st0to30Removed >= (@st0to60Removed - @st0to30Removed) AND @st0to30Removed >= (@st0to90Removed - @st0to60Removed) THEN @st0to30Removed
								WHEN (@st0to60Removed - @st0to30Removed) >= @st0to30Removed AND (@st0to60Removed - @st0to30Removed) >= (@st0to90Removed - @st0to60Removed) THEN (@st0to60Removed - @st0to30Removed)
								WHEN (@st0to90Removed - @st0to60Removed) >= @st0to30Removed AND (@st0to90Removed - @st0to60Removed) >= (@st0to60Removed - @st0to30Removed) THEN (@st0to90Removed - @st0to60Removed)
								ELSE  @st0to30Removed END)

						SET @stLowestRunRemoved = (CASE
								WHEN @st0to30Removed <= (@st0to60Removed - @st0to30Removed) AND @st0to30Removed <= (@st0to90Removed - @st0to60Removed) THEN @st0to30Removed
								WHEN (@st0to60Removed - @st0to30Removed) <= @st0to30Removed AND (@st0to60Removed - @st0to30Removed) <= (@st0to90Removed - @st0to60Removed) THEN (@st0to60Removed - @st0to30Removed)
								WHEN (@st0to90Removed - @st0to60Removed) <= @st0to30Removed AND (@st0to90Removed - @st0to60Removed) <= (@st0to60Removed - @st0to30Removed) THEN (@st0to90Removed - @st0to60Removed)
								ELSE  @st0to30Removed END)

						SET @stOrderBasedOnRemoved = (CASE WHEN (Ceiling(((Cast(@stHighestRunRemoved + @stHighestRunMissed AS decimal(10,2))/30) * @pTargetDays)) + @stPendingFBARecursive) - (@stBackorders + @stCurrentSKUStock) < 0 THEN 0
							   ELSE (Ceiling(((Cast(@stHighestRunRemoved + @stHighestRunMissed AS decimal(10,2))/30) * @pTargetDays)) + @stPendingFBARecursive) - (@stBackorders + @stCurrentSKUStock) END) 
							  



						INSERT INTO [Inventory].[dbo].[InventoryAnalyticsRecursive] ([SKU], [Description], [0-30DayMissedOpportunities], [31-60DayMissedOpportunities], [61-90DayMissedOpportunities], [0-30DaySold], [31-60DaySold], [61-90DaySold], [0-30DayRemoved], [31-60DayRemoved], [61-90DayRemoved], [QOH],
						[vQOH], [tQOH], [BackOrders], [PendingFBARecursive], [TargetDays], [HighestRunMissed], [HighestRunSold], [SoldVariance], [OrderBasedOnSold], [HighestRunRemoved], [RemovedVariance], [OrderBasedOnRemoved], [OrderVariance], [WeMakeIt?], [LowestCost], [LowestCostSupplier], [ERPUnitCost], [DateStamp]) 
						SELECT
							  PC.[ID] AS 'SKU',
							  PC.[Name] AS 'Description',

							  @st0to30MissedOpportunities AS '0-30DayMissedOpportunities',
							  @st0to60MissedOpportunities - @st0to30MissedOpportunities AS '31-60DaysMissedOpportunities',
							  @st0to90MissedOpportunities - @st0to60MissedOpportunities AS '61-90DaysMissedOpportunities',

							  @st0to30Sold AS '0-30DaySold',
							  @st0to60Sold - @st0to30Sold  AS '31-60DaySold',
							  @st0to90Sold - @st0to60Sold AS '61-90DaySold',

							  @st0to30Removed AS '0-30DayRemoved',
							  @st0to60Removed - @st0to30Removed AS '31-60DaysRemoved',
							  @st0to90Removed - @st0to60Removed AS '61-90DaysRemoved',

							  CAST(GS.[GlobalStock] AS INT) AS 'QOH',
							  CAST(GS.[VirtualStock] AS INT) AS 'vQOH',
							  CAST(GS.[TotalStock] AS INT) AS 'tQOH',

							  @stBackorders AS 'BackOrders',

							  @stPendingFBARecursive AS 'PendingFBARecursive',


							  @pTargetDays AS 'TargetDays',
				  
							  @stHighestRunMissed AS 'HighestRunMissed',

							  CAST(@stHighestRunSold AS INT)  AS 'HighestRunSold',
							  CAST((CASE WHEN @stHighestRunSold = 0 THEN ((@stHighestRunSold - @stLowestRunSold) / 0.1) * 100
							  ELSE ((@stHighestRunSold - @stLowestRunSold) / (@stHighestRunSold)) * 100 END) AS INT) AS 'RemovedVarience',

							  CAST(ROUND(@stOrderBasedOnSold,0) AS INT) AS 'OrderBasedOnSold',
							  CAST(@stHighestRunRemoved AS INT) AS 'HighestRunRemoved',
							  CAST((CASE WHEN @stHighestRunRemoved = 0 THEN ((@stHighestRunRemoved - @stLowestRunRemoved) / 0.1) * 100
							  ELSE ((@stHighestRunRemoved - @stLowestRunRemoved) / (@stHighestRunRemoved)) * 100 END) AS INT) AS 'RemovedVarience',

							  CAST(ROUND(@stOrderBasedOnRemoved,0) AS INT) AS 'OrderBasedOnRemoved',
							  CAST((CASE WHEN @stOrderBasedOnSold = 0 THEN ((@stOrderBasedOnSold - @stOrderBasedOnRemoved) / 0.1) * 100
							   ELSE ((@stOrderBasedOnSold - @stOrderBasedOnRemoved) / (@stOrderBasedOnSold)) * 100 END) AS INT) AS 'OrderVariance',

							  (CASE WHEN PC.[Name] LIKE '%MI Technologies%' THEN 'Yes' ELSE 'No' END) AS 'WeMakeIt?',
	  
							  IsNull((SELECT DISTINCT Price FROM [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTableV2](PC.[ID])),999) AS 'LowestCost', 
							  IsNull((SELECT DISTINCT Supplier FROM [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTableV2](PC.[ID])), 'NoSupplier') AS 'LowestCostSupplier',

							  [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PC.[ID]) AS 'ERPUnitCost',
							  GETDATE() AS 'DateStamp'
	  
						  FROM [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK)
						  LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS (NOLOCK) ON (PC.[ID] = GS.[ProductCatalogId])
						  WHERE PC.[ID] = @stCurrentSKU AND PC.[ID] NOT IN (SELECT [SKU] FROM [Inventory].[dbo].[InventoryAnalyticsRecursive] (NOLOCK))


					FETCH NEXT FROM MovementsByCategory_Cursor  INTO @stCurrentSKU
			END TRY

			BEGIN CATCH
					
					SET @ErrorCatch = @ErrorCatch + ', ' + @stCurrentSKU
					FETCH NEXT FROM MovementsByCategory_Cursor  INTO @stCurrentSKU
											
			END CATCH

			CLOSE MovementsByCategory_Cursor;  
			DEALLOCATE MovementsByCategory_Cursor;  

			SET @stEndTime = GETDATE()

			SET @stUserEmail = (SELECT [Email] FROM [Inventory].[dbo].[Users] (NOLOCK) WHERE [ID] = @pUserID)

			SET @CategorySKUCount = (SELECT COUNT([ID]) FROM [Inventory].[dbo].[ProductCatalog] (NOLOCK) WHERE CategoryID = @pCategory)
			SET @ProcessedSKUCount = (SELECT COUNT(IAR.[SKU]) FROM [Inventory].[dbo].[InventoryAnalyticsRecursive] AS IAR (NOLOCK)
										LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) ON (IAR.[SKU] = PC.[ID])
										WHERE PC.[CategoryID] = @pCategory)

			--SEND DBMAIL SAYING ITS DONE
			DECLARE @body NVARCHAR(MAX)
			DECLARE @date VARCHAR(12)
			DECLARE @subtext VARCHAR(50)
			DECLARE @subject VARCHAR(62)
			DECLARE @recipients VARCHAR(255)
			DECLARE @stTimeDiff NVARCHAR(MAX)

			SET @stTimeDiff = convert(varchar(5),DateDiff(s, @stStartTime, @stEndTime)/3600)+':'+convert(varchar(5),DateDiff(s, @stStartTime, @stEndTime)%3600/60)+':'+convert(varchar(5),(DateDiff(s, @stStartTime, @stEndTime)%60))
			
			UPDATE [Inventory].[dbo].[Categories] SET [RIALastRunDate] = GETDATE() WHERE [ID] = @pCategory
			UPDATE [Inventory].[dbo].[Categories] SET [RIALastRunDuration] = @stTimeDiff WHERE [ID] = @pCategory

			SET @subtext = 'Recursive Calculation - ' + @CategoryName + ' '
			SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
			SET @subject = @subtext + @date
			SET @recipients = 'purchasing@mitechnologiesinc.com;'+@stUserEmail
			SET @body ='<html><body><br>Recursive Inventory Calculation Finished for Category: ' + @CategoryName + 
			'<br><br>Duration: '+ CAST(@stTimeDiff AS NVARCHAR(MAX)) +
			'<br>The following SKUs had errors: ' + IsNull(@ErrorCatch,0) +
			'<br>Category SKU Count: ' + @CategorySKUCount + 
			'<br>Processed SKU Count: ' + @ProcessedSKUCount +
			'<br><br>You can view the results here: http://apps2.mitechnologiesinc.com/index.php/Reports/invangenerator/    ' + CAST(@pCategory AS NVARCHAR(MAX)) + '<br><br></body></html>'

			If @body is not null BEGIN

			EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

			@recipients = @recipients,
			@subject = @subject,
			@body = @body,
			@body_format ='HTML'


			END
END
go

