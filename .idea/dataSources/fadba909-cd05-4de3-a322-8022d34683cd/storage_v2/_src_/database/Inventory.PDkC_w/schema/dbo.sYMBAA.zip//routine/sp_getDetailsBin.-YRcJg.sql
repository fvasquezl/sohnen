-- =============================================
-- Author:		Luis
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_getDetailsBin]
	@plant varchar(20),
	@WH_ID varchar(30),
	@binId varchar(15)
AS
BEGIN
	SELECT A.ProductCatalog_Id, A.Counter, SUBSTRING(C.Name,1,55) AS DESCRIPTION, CONVERT(NVARCHAR,A.LastStamp,109) AS CREATE_DATE, A.Counter AS STOCK_QTY, DATEDIFF(DAY, A.LastStamp, GETDATE()) + 1 AS AGING_DAYS
	FROM Inventory.dbo.Bin_Content A
	INNER JOIN Inventory.dbo.WH_LOCATIONS B
	ON B.S_LOCATION = A.Bin_Id
	LEFT OUTER JOIN Inventory.dbo.ProductCatalog C
	ON C.ID = A.ProductCatalog_Id
	WHERE B.DELETE_FLAG = 0 AND A.Counter > 0 AND B.PLANT = @plant AND B.WH_ID LIKE @WH_ID AND A.Bin_Id = @binId
			
END
go

