-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date,,>
-- Description:	Kills all process 
-- =============================================
CREATE PROCEDURE [dbo].[sp_Proccess_Killer]
	
AS
BEGIN
			DECLARE @v_spid INT;
			DECLARE c_Users CURSOR
				FAST_FORWARD FOR
				SELECT 
						req.session_id
						
				FROM sys.dm_exec_requests req
						CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS sqltext
				WHERE 
						(DB_NAME(req.database_id) = 'Inventory')
						OR (DB_NAME(req.database_id) = 'ShoeMagoo')
						
						AND (req.session_id >50)
						AND (req.session_id<> @@spid)
						AND  (req.total_elapsed_time > 300000);

OPEN c_Users

FETCH NEXT FROM c_Users INTO @v_spid;

WHILE (@@FETCH_STATUS=0)
BEGIN
	BEGIN TRY
    -- Generate divide-by-zero error.
			IF @@spid != @v_spid BEGIN
			EXEC('KILL '+@v_spid)
			END
	END TRY
	BEGIN CATCH
    -- Execute error retrieval routine.
			BEGIN TRY
					-- try to kill again 2nd time.
					IF @@spid != @v_spid BEGIN
					EXEC('KILL '+@v_spid)
					END
			END TRY
			BEGIN CATCH
				-- try to kill again 3 time.
					IF @@spid != @v_spid BEGIN
					EXEC('KILL '+@v_spid);
					END
			END CATCH; 
	END CATCH; 

   
  FETCH NEXT FROM c_Users INTO @v_spid
END

CLOSE c_Users;
DEALLOCATE c_Users;    
END
go

