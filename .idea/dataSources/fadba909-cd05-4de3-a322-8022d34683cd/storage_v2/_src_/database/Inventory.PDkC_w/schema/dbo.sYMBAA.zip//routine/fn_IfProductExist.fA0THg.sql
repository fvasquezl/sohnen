-- =============================================
-- Author:		Luis Bautista
-- Create date: Feb-18-2013
-- Description:	Returns 1 if SKU exist in ProductCatalog table.
-- =============================================
CREATE FUNCTION [dbo].[fn_IfProductExist]
(
		@ProductId int
)
RETURNS int	
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar INT ;
	
	SET @ResultVar = 0;

	-- Add the T-SQL statements to compute the return value here
	SET @ResultVar = (SELECT count(id) FROM ProductCatalog WHERE id = @ProductId);

	IF @resultvar is null
	BEGIN
		SET @resultvar = 0;
	END
	-- Return the result of the function
	RETURN @ResultVar;

END
go

