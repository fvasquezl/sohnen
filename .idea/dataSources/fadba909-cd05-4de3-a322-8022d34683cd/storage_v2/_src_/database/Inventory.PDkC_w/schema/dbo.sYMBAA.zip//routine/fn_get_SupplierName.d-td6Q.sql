
CREATE FUNCTION fn_get_SupplierName
(
	@pSupplierId as INT
)
RETURNS varchar(250)
AS
BEGIN
	
	DECLARE @ResultVar as  VARCHAR(250);

	-- Add the T-SQL statements to compute the return value here
	SET @ResultVar = (SELECT SupplierName FROM SupplierInfo WHERE SupplierId = @pSupplierId );

	-- Return the result of the function
	RETURN @ResultVar;

END
go

