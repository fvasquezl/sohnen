CREATE VIEW dbo.CostOfInventoryDetail
AS
SELECT        PC.ID AS SKU, PC.Name AS Item, CAST(GS.GlobalStock AS Int) AS QOH, CAST(PC.UnitCost AS money) AS [Cost X1], CAST(GS.GlobalStock * PC.UnitCost AS money) 
                         AS [Cost ALL], CAT.Name AS Category
FROM            dbo.ProductCatalog AS PC LEFT OUTER JOIN
                         dbo.Global_Stocks AS GS ON PC.ID = GS.ProductCatalogId LEFT OUTER JOIN
                         dbo.Categories AS CAT ON PC.CategoryID = CAT.ID
go

