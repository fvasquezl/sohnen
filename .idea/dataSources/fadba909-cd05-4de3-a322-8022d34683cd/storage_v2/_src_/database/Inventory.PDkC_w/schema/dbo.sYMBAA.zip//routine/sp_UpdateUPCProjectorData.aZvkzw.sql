-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-07-06
-- Description:	Update ProjectorData UPC
-- =============================================
CREATE PROCEDURE sp_UpdateUPCProjectorData
AS
BEGIN
    DECLARE @CURSOR_UPC		CURSOR,
			@ID					INT,
			@CatalogID			NVARCHAR(12),
			@GenericBareUPC		NVARCHAR(20),
			@GenericModuleUPC	NVARCHAR(20),
			@OEMBareUPC			NVARCHAR(20),
			@OEMModuleUPC		NVARCHAR(20),
			@UPC				NVARCHAR(20)

	SET NOCOUNT ON;

	SET @CURSOR_UPC = CURSOR FOR 

		SELECT ID, CatalogID, GenericBareUPC, GenericModuleUPC, OEMBareUPC, OEMModuleUPC
		FROM MITDB.dbo.ProjectorData (NOLOCK)
		WHERE ISNULL(GenericBareUPC,'') = '' OR ISNULL(GenericModuleUPC,'') = '' OR ISNULL(OEMBareUPC,'') = '' OR ISNULL(OEMModuleUPC,'') = ''

	OPEN @CURSOR_UPC 
	FETCH NEXT FROM @CURSOR_UPC 
	INTO @ID, @CatalogID, @GenericBareUPC, @GenericModuleUPC, @OEMBareUPC, @OEMModuleUPC
	   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--GenericBareUPC
			SET @UPC = ISNULL((SELECT TOP 1 UPC FROM Inventory.dbo.ProjectorDataUPCList (NOLOCK) WHERE ISNULL(InUse,0) = 0),'')
		
			IF(ISNULL(@UPC,'') <> '' AND ISNULL(@GenericBareUPC,'') = '')
			BEGIN
				UPDATE MITDB.dbo.ProjectorData SET GenericBareUPC = @UPC WHERE ID = @ID
				UPDATE Inventory.dbo.ProjectorDataUPCList SET InUse = 1, InUseStamp = GETDATE(), CatalogID = @CatalogID, CatalogIDField = 'GenericBareUPC' WHERE UPC = @UPC
			END

			--GenericModuleUPC
			SET @UPC = ISNULL((SELECT TOP 1 UPC FROM Inventory.dbo.ProjectorDataUPCList (NOLOCK) WHERE ISNULL(InUse,0) = 0),'')
		
			IF(ISNULL(@UPC,'') <> '' AND ISNULL(@GenericModuleUPC,'') = '')
			BEGIN
				UPDATE MITDB.dbo.ProjectorData SET GenericModuleUPC = @UPC WHERE ID = @ID
				UPDATE Inventory.dbo.ProjectorDataUPCList SET InUse = 1, InUseStamp = GETDATE(), CatalogID = @CatalogID, CatalogIDField = 'GenericModuleUPC' WHERE UPC = @UPC
			END

			--OEMBareUPC
			SET @UPC = ISNULL((SELECT TOP 1 UPC FROM Inventory.dbo.ProjectorDataUPCList (NOLOCK) WHERE ISNULL(InUse,0) = 0),'')
		
			IF(ISNULL(@UPC,'') <> '' AND ISNULL(@OEMBareUPC,'') = '')
			BEGIN
				UPDATE MITDB.dbo.ProjectorData SET OEMBareUPC = @UPC WHERE ID = @ID
				UPDATE Inventory.dbo.ProjectorDataUPCList SET InUse = 1, InUseStamp = GETDATE(), CatalogID = @CatalogID, CatalogIDField = 'OEMBareUPC' WHERE UPC = @UPC
			END

			--OEMModuleUPC
			SET @UPC = ISNULL((SELECT TOP 1 UPC FROM Inventory.dbo.ProjectorDataUPCList (NOLOCK) WHERE ISNULL(InUse,0) = 0),'')
		
			IF(ISNULL(@UPC,'') <> '' AND ISNULL(@OEMBareUPC,'') = '')
			BEGIN
				UPDATE MITDB.dbo.ProjectorData SET OEMModuleUPC = @UPC WHERE ID = @ID
				UPDATE Inventory.dbo.ProjectorDataUPCList SET InUse = 1, InUseStamp = GETDATE(), CatalogID = @CatalogID, CatalogIDField = 'OEMModuleUPC' WHERE UPC = @UPC
			END

			NEXT_FETCH:
			FETCH NEXT FROM @CURSOR_UPC
			INTO @ID, @CatalogID, @GenericBareUPC, @GenericModuleUPC, @OEMBareUPC, @OEMModuleUPC
		END
	CLOSE      @CURSOR_UPC
	DEALLOCATE @CURSOR_UPC
END
go

