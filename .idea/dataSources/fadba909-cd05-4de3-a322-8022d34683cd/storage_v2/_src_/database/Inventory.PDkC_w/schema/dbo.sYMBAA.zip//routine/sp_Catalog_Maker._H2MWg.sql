-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date,,>
-- Description:	Recreate the catalog table, run every week or when needed
-- =============================================
CREATE PROCEDURE [dbo].[sp_Catalog_Maker]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @ItemsPerPage Int ;
	DECLARE @ItemCounter Int;
	DECLARE @ItemCount int;
	DECLARE @I int;
	DECLARE @PageCounter int;
	DECLARE @PreviusBrand nvarchar(50);
	DECLARE @CurrentBrand nvarchar(50);
	DECLARE @SKU int;

	SET  @ItemsPerPage = 6;

	IF OBJECT_ID('Inventory.dbo.Catalog_Pager', 'U') IS NOT NULL
	BEGIN
				DROP TABLE Inventory.dbo.Catalog_Pager;
	END

    CREATE TABLE Inventory.dbo.Catalog_Pager(Id int identity(1,1)
							, CatalogId int
							, Brand nvarchar(50)
							, [Type] nvarchar(50)
							, [PartNumber] nvarchar(50)
							, [PartNumberV2] nvarchar(50)
							, [PartNumberV3] nvarchar(50)
							, PriceGeneric decimal(10,2)
							, PricePremium decimal(10,2)
							, EncSKU nvarchar(15)
							, EncSKUPH nvarchar(15)
							, BareSKU nvarchar(15)
							, BareSKUPH nvarchar(15)
							, BareSKUOS nvarchar(15)
							, CatalogID_O varchar(15)
							, CatalogID_G varchar(15)
							, Warranty_O varchar(25)
							, Warranty_G varchar(25)
							, tbImage nvarchar(250)
							, BigImage nvarchar(250)
							, Models varchar(1000)
							, Models_Slash varchar(1000)
							, PageNo Int default 0
							, PN_List varchar(1000)
							, BrandInitial varchar(1)
							, ItemCounter int
							, sku int
							);


	INSERT INTO Inventory.dbo.Catalog_Pager(
	 CatalogId
							, Brand
							, [Type]
							, [PartNumber] 
							, [PartNumberV2] 
							, [PartNumberV3] 
							, PriceGeneric
							, PricePremium 
							, EncSKU 
							, EncSKUPH
							, BareSKU
							, BareSKUPH
							, BareSKUOS
							, CatalogID_O 
							, CatalogID_G 
							, Warranty_O 
							, Warranty_G 
							, tbImage 
							, BigImage 
							, Models 
							, Models_Slash
							, PN_List
							, PageNo 
							, sku
							
	) 	
			SELECT			CatalogId
							, PD.[Brand]
							, PD.[Type]
							, PD.[PartNumber]
							, PD.[PartNumberV2]
							, PD.[PartNumberV3]
							, PD.[PriceGeneric]
							, PD.[PricePremium]
							, PD.[EncSKU] as SKU
							, PD.EncSKUPH
							, PD.BareSKU
							, PD.BareSKUPH
							, PD.BareSKUOS
							, cast(CatalogID as varchar(20)) + '-O' as CatalogID_O 
							, cast(CatalogID as varchar(20)) + '-G' as CatalogID_G
						    , '6 Months'   as Warranty_O
							, '3 Months'   as Warranty_G
							, 'http://photos.discount-merchant.com/photos/sku/' + PD.[EncSKU] + '/th/' + PD.[EncSKU] +'-1.jpg' as tbImage
							, 'http://photos.discount-merchant.com/photos/sku/' + PD.[EncSKU] + '/' + PD.[EncSKU] +'-1.jpg' as BigImage
							,  inventory.[dbo].[fn_Catalog_Maker_Models_HTML](PD.Brand, PD.Partnumber) as HTMLmodels
							,  inventory.[dbo].[fn_Catalog_Maker_Models_Slash](PD.Brand, PD.Partnumber) as modelsSlash
							, '' as PN_List
							, 0
							, EncSKU
				 FROM  [MITDB].[dbo].[ProjectorData] PD
				 Order By PD.Brand


	SELECT @ItemCount = max(id) FROM Inventory.dbo.Catalog_Pager;

	SET @I = 1;
	SET @PageCounter = 0;

	Set @PreviusBrand = '@';
	SET @PreviusBrand = '';
	SET @ItemCounter = 0;
	
	WHILE @I <= @ItemCount
	BEGIN
		SET @ItemCounter = @ItemCounter + 1;

		IF @ItemCounter >= 6
		BEGIN
			SET @PageCounter = @PageCounter + 1;
			SET @ItemCounter = 0;
		END


		SELECT @CurrentBrand = Brand FROM Inventory.dbo.Catalog_Pager 	WHERE Inventory.dbo.Catalog_Pager.ID = @I;

		SET @CurrentBrand = SUBSTRING(@CurrentBrand,1,1);

		IF @CurrentBrand > @PreviusBrand
		BEGIN
			IF @ItemCounter <> 0
			BEGIN
				SET @PageCounter = @PageCounter + 1;
				SET @ItemCounter = 0;
			END
			SET  @PreviusBrand =  @CurrentBrand;

		END


		UPDATE Inventory.dbo.Catalog_Pager SET PageNo = @PageCounter
						   ,BrandInitial = @CurrentBrand
						   ,ItemCounter = @ItemCounter
						    WHERE ID = @I;
		SET @I = @I + 1;
	END

	select * from Inventory.dbo.Catalog_Pager;

END
go

