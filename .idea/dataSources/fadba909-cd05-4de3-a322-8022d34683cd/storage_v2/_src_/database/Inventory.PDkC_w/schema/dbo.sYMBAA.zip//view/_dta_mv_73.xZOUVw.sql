CREATE VIEW [dbo]._dta_mv_73   AS SELECT  count_big(*) as _col_1 FROM  [dbo].[ProductCatalog],  [dbo].[Global_Stocks]   WHERE  [dbo].[ProductCatalog].[ID] = [dbo].[Global_Stocks].[ProductCatalogId]  AND  [dbo].[ProductCatalog].[ID] like '%133731%'
go

