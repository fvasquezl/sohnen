-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-06-03
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_UpdateEANSalesRankAliasSKU]
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE OrderManager.dbo.AliasSKUs SET EAN = NULL

	DECLARE @TBL_SalesRank TABLE (WebSKU NVARCHAR(150), QuantityOrdered INT)
	DECLARE @TBL_SR TABLE (AliasSKU NVARCHAR(150), SalesRank INT, TotalOrdered INT)

----FBM USA	
	INSERT INTO @TBL_SalesRank (WebSKU, QuantityOrdered)
	SELECT	OD.WebSKU, 
			SUM(OD.QuantityOrdered) AS QuantityOrdered
	FROM [OrderManager].[dbo].[Order Details] AS OD
	LEFT OUTER JOIN OrderManager.dbo.[Orders] AS O ON (OD.OrderNumber = O.[OrderNumber])
	INNER JOIN Inventory.dbo.AmazonMerchantSKU AS AMSKU ON (OD.[WebSKU] = AMSKU.[DARTFBMSKU])  --Only Doing USA
	WHERE O.CartID IN (48,53) 
	AND CONVERT(NVARCHAR,O.OrderDate,112) > GETDATE()-90 
	AND OD.Adjustment = 0
	GROUP BY OD.WebSKU

----MFP USA
	INSERT INTO @TBL_SalesRank (WebSKU, QuantityOrdered)
	SELECT	OD.WebSKU, 
			SUM(OD.QuantityOrdered) AS QuantityOrdered
	FROM [OrderManager].[dbo].[Order Details] AS OD
	LEFT OUTER JOIN OrderManager.dbo.[Orders] AS O ON (OD.OrderNumber = O.[OrderNumber])
	INNER JOIN Inventory.dbo.AmazonMerchantSKU AS AMSKU ON (OD.[WebSKU] = AMSKU.[DARTMFPSKU])  --Only Doing USA
	WHERE O.CartID IN (48,53) 
	AND CONVERT(NVARCHAR,O.OrderDate,112) > GETDATE()-90 
	AND OD.Adjustment = 0
	GROUP BY OD.WebSKU

----FBA USA
	INSERT INTO @TBL_SalesRank (WebSKU, QuantityOrdered)
	SELECT	OD.WebSKU, 
			SUM(OD.QuantityOrdered) AS QuantityOrdered
	FROM [OrderManager].[dbo].[Order Details] AS OD
	LEFT OUTER JOIN OrderManager.dbo.[Orders] AS O ON (OD.OrderNumber = O.[OrderNumber])
	INNER JOIN Inventory.dbo.AmazonMerchantSKU AS AMSKU ON (OD.[WebSKU] = AMSKU.[DARTFBASKU])  --Only Doing USA
	WHERE O.CartID IN (48,53) 
	AND CONVERT(NVARCHAR,O.OrderDate,112) > GETDATE()-90
	AND OD.Adjustment = 0
	GROUP BY OD.WebSKU

----FLX USA
	INSERT INTO @TBL_SalesRank (WebSKU, QuantityOrdered)
	SELECT	OD.WebSKU, 
			SUM(OD.QuantityOrdered) AS QuantityOrdered
	FROM [OrderManager].[dbo].[Order Details] AS OD
	LEFT OUTER JOIN OrderManager.dbo.[Orders] AS O ON (OD.OrderNumber = O.[OrderNumber])
	INNER JOIN Inventory.dbo.AmazonMerchantSKU AS AMSKU ON (OD.[WebSKU] = AMSKU.[DARTFBMSKU]+'FLX')  --Only Doing USA
	WHERE O.CartID IN (48,53) 
	AND CONVERT(NVARCHAR,O.OrderDate,112) > GETDATE()-90
	AND OD.Adjustment = 0
	GROUP BY OD.WebSKU


	INSERT INTO @TBL_SR (AliasSKU, SalesRank, TotalOrdered)
	SELECT	WebSKU, 
			ROW_NUMBER () OVER (ORDER BY QuantityOrdered DESC ) AS SalesRank,
			QuantityOrdered AS TotalOrdered
	FROM @TBL_SalesRank
	GROUP BY WebSKU, QuantityOrdered

	UPDATE A SET EAN = SR.SalesRank
	FROM OrderManager.dbo.AliasSKUs A (NOLOCK)
	INNER JOIN @TBL_SR SR ON (SR.AliasSKU = A.AliasSKU)

	SELECT * FROM @TBL_SR


END
go

