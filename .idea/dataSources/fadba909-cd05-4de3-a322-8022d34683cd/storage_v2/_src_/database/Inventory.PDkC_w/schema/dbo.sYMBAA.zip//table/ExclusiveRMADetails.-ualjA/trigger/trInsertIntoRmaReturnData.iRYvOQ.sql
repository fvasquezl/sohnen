-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trInsertIntoRmaReturnData] 
   ON  [Inventory].[dbo].[ExclusiveRMADetails]
   AFTER INSERT
AS 
BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

     -- Insert statements for trigger here
	DECLARE @top INT = (SELECT QuantityAuthorized FROM inserted);
	DECLARE @loop INT = 0;

	WHILE @loop < @top
	BEGIN
		DECLARE @sku INT = (SELECT WrongSKU FROM inserted);
		DECLARE @rma INT = (SELECT RMAnumber FROM inserted);
		INSERT INTO Inventory.dbo.RMAReturnData(RMAnumber,SKU,isExclusiveBulbs) VALUES (@rma,@sku,1);
		set @loop = @loop + 1;
	END

END
go

