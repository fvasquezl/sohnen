-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-22-2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonFLEXUpdateWeights] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
		DECLARE @selectstatement NVARCHAR(2000)
		DECLARE @cmd NVARCHAR(2000)



		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed1'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed1]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed2'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed2]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed3'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed3]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed4'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed4]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed5'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed5]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed6'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed6]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed7'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed7]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed8'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed8]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed9'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed9]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed10'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed10]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed11'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed11]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed12'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed12]
			END


		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed13'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed13]
			END




		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed14'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed14]
			END




		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed15'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed15]
			END

			--END CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED


		CREATE TABLE [Inventory].[dbo].[tmpWeightsFeed] (
		[ID] INT identity(1,1),
		[item_sku] NVARCHAR(MAX),
		[external_product_id] NVARCHAR(MAX),
		[external_product_id_type] NVARCHAR(MAX),
		[gtin_exemption_reason] NVARCHAR(MAX),
		[related_product_id] NVARCHAR(MAX),
		[related_product_id_type] NVARCHAR(MAX),
		[item_name] NVARCHAR(MAX),
		[brand_name] NVARCHAR(MAX),
		[manufacturer] NVARCHAR(MAX),
		[product_description] NVARCHAR(MAX),
		[item_type] NVARCHAR(MAX),
		[feed_product_type] NVARCHAR(MAX),
		[part_number] NVARCHAR(MAX),
		[model] NVARCHAR(MAX),
		[update_delete] NVARCHAR(MAX),
		[standard_price] NVARCHAR(MAX),
		[list_price] NVARCHAR(MAX),
		[currency] NVARCHAR(MAX),
		[quantity] NVARCHAR(MAX),
		[condition_type] NVARCHAR(MAX),
		[condition_note] NVARCHAR(MAX),
		[sale_price] NVARCHAR(MAX),
		[sale_from_date] NVARCHAR(MAX),
		[sale_end_date] NVARCHAR(MAX),
		[number_of_items] NVARCHAR(MAX),
		[product_tax_code] NVARCHAR(MAX),
		[product_site_launch_date] NVARCHAR(MAX),
		[merchant_release_date] NVARCHAR(MAX),
		[fulfillment_latency] NVARCHAR(MAX),
		[restock_date] NVARCHAR(MAX),
		[max_aggregate_ship_quantity] NVARCHAR(MAX),
		[offering_can_be_gift_messaged] NVARCHAR(MAX),
		[offering_can_be_giftwrapped] NVARCHAR(MAX),
		[is_discontinued_by_manufacturer] NVARCHAR(MAX),
		[missing_keyset_reason] NVARCHAR(MAX),
		[rebate_start_at1] NVARCHAR(MAX),
		[rebate_start_at2] NVARCHAR(MAX),
		[rebate_end_at1] NVARCHAR(MAX),
		[rebate_end_at2] NVARCHAR(MAX),
		[rebate_description1] NVARCHAR(MAX),
		[rebate_description2] NVARCHAR(MAX),
		[rebate_name1] NVARCHAR(MAX),
		[rebate_name2] NVARCHAR(MAX),
		[delivery_schedule_group_id] NVARCHAR(MAX),
		[item_display_diameter] NVARCHAR(MAX),
		[item_display_diameter_unit_of_measure] NVARCHAR(MAX),
		[website_shipping_weight] NVARCHAR(MAX),
		[website_shipping_weight_unit_of_measure] NVARCHAR(MAX),
		[item_length] NVARCHAR(MAX),
		[item_width] NVARCHAR(MAX),
		[item_height] NVARCHAR(MAX),
		[item_length_unit_of_measure] NVARCHAR(MAX),
		[item_weight] NVARCHAR(MAX),
		[item_weight_unit_of_measure] NVARCHAR(MAX),
		[bullet_point1] NVARCHAR(MAX),
		[bullet_point2] NVARCHAR(MAX),
		[bullet_point3] NVARCHAR(MAX),
		[bullet_point4] NVARCHAR(MAX),
		[bullet_point5] NVARCHAR(MAX),
		[generic_keywords1] NVARCHAR(MAX),
		[generic_keywords2] NVARCHAR(MAX),
		[generic_keywords3] NVARCHAR(MAX),
		[generic_keywords4] NVARCHAR(MAX),
		[generic_keywords5] NVARCHAR(MAX),
		[platinum_keywords1] NVARCHAR(MAX),
		[platinum_keywords2] NVARCHAR(MAX),
		[platinum_keywords3] NVARCHAR(MAX),
		[platinum_keywords4] NVARCHAR(MAX),
		[platinum_keywords5] NVARCHAR(MAX),
		[main_image_url] NVARCHAR(MAX),
		[other_image_url1] NVARCHAR(MAX),
		[other_image_url2] NVARCHAR(MAX),
		[other_image_url3] NVARCHAR(MAX),
		[other_image_url4] NVARCHAR(MAX),
		[other_image_url5] NVARCHAR(MAX),
		[other_image_url6] NVARCHAR(MAX),
		[other_image_url7] NVARCHAR(MAX),
		[other_image_url8] NVARCHAR(MAX),
		[swatch_image_url] NVARCHAR(MAX),
		[fulfillment_center_id] NVARCHAR(MAX),
		[package_height] NVARCHAR(MAX),
		[package_width] NVARCHAR(MAX),
		[package_length] NVARCHAR(MAX),
		[package_length_unit_of_measure] NVARCHAR(MAX),
		[package_weight] NVARCHAR(MAX),
		[package_weight_unit_of_measure] NVARCHAR(MAX),
		[country_of_origin] NVARCHAR(MAX),
		[legal_disclaimer_description] NVARCHAR(MAX),
		[prop_65] NVARCHAR(MAX),
		[safety_warning] NVARCHAR(MAX),
		[cpsia_cautionary_statement1] NVARCHAR(MAX),
		[cpsia_cautionary_statement2] NVARCHAR(MAX),
		[cpsia_cautionary_statement3] NVARCHAR(MAX),
		[cpsia_cautionary_statement4] NVARCHAR(MAX),
		[cpsia_cautionary_description] NVARCHAR(MAX),
		[connector_quantity] NVARCHAR(MAX),
		[cable_length] NVARCHAR(MAX),
		[secure_digital_association_speed_class] NVARCHAR(MAX),
		[read_speed] NVARCHAR(MAX),
		[read_speed_unit_of_measure] NVARCHAR(MAX),
		[write_speed_unit_of_measure] NVARCHAR(MAX),
		[write_speed] NVARCHAR(MAX),
		[data_transfer_rate_units] NVARCHAR(MAX),
		[hard_drive_size_unit_of_measure] NVARCHAR(MAX),
		[special_features] NVARCHAR(MAX),
		[connector_type] NVARCHAR(MAX),
		[digital_audio_capacity] NVARCHAR(MAX),
		[communication_interface] NVARCHAR(MAX),
		[input_type] NVARCHAR(MAX),
		[movement_detection_technology] NVARCHAR(MAX),
		[recording_capacity] NVARCHAR(MAX),
		[voltage] NVARCHAR(MAX),
		[wattage] NVARCHAR(MAX),
		[memory_storage_capacity] NVARCHAR(MAX),
		[memory_storage_capacity_unit_of_measure] NVARCHAR(MAX),
		[audio_output_mode] NVARCHAR(MAX),
		[graphics_ram_size_unit_of_measure] NVARCHAR(MAX),
		[maximum_simultaneous_sessions] NVARCHAR(MAX),
		[total_sata_ports] NVARCHAR(MAX),
		[main_power_connector] NVARCHAR(MAX),
		[external_bay_type_units] NVARCHAR(MAX),
		[hotswap_bay_type_units] NVARCHAR(MAX),
		[internal_bay_type_units] NVARCHAR(MAX),
		[hardware_interface1] NVARCHAR(MAX),
		[hardware_interface2] NVARCHAR(MAX),
		[hardware_interface3] NVARCHAR(MAX),
		[hardware_interface4] NVARCHAR(MAX),
		[hardware_interface5] NVARCHAR(MAX),
		[wireless_comm_standard1] NVARCHAR(MAX),
		[wireless_comm_standard2] NVARCHAR(MAX),
		[wireless_comm_standard3] NVARCHAR(MAX),
		[are_batteries_included] NVARCHAR(MAX),
		[batteries_required] NVARCHAR(MAX),
		[power_source_type] NVARCHAR(MAX),
		[battery_type] NVARCHAR(MAX),
		[number_of_batteries] NVARCHAR(MAX),
		[battery_average_life] NVARCHAR(MAX),
		[battery_average_life_standby] NVARCHAR(MAX),
		[battery_charge_time] NVARCHAR(MAX),
		[lithium_battery_energy_content] NVARCHAR(MAX),
		[lithium_battery_packaging] NVARCHAR(MAX),
		[lithium_battery_voltage] NVARCHAR(MAX),
		[lithium_battery_weight] NVARCHAR(MAX),
		[number_of_lithium_ion_cells] NVARCHAR(MAX),
		[number_of_lithium_metal_cells] NVARCHAR(MAX),
		[mfg_warranty_description_type] NVARCHAR(MAX),
		[mfg_warranty_description_labor] NVARCHAR(MAX),
		[mfg_warranty_description_parts] NVARCHAR(MAX),
		[seller_warranty_description] NVARCHAR(MAX),
		[microphone_form_factor] NVARCHAR(MAX),
		[photo_sensor_technology] NVARCHAR(MAX),
		[photo_sensor_resolution] NVARCHAR(MAX),
		[photo_sensor_resolution_unit_of_measure] NVARCHAR(MAX),
		[effective_video_resolution] NVARCHAR(MAX),
		[effective_video_resolution_unit_of_measure] NVARCHAR(MAX),
		[communication_standard] NVARCHAR(MAX),
		[network_interface_description] NVARCHAR(MAX),
		[effective_still_resolution] NVARCHAR(MAX),
		[effective_still_resolution_unit_of_measure] NVARCHAR(MAX),
		[effective_video_comm_resolution] NVARCHAR(MAX),
		[effective_video_comm_resolution_unit_of_measure] NVARCHAR(MAX),
		[minimum_system_requirement_description] NVARCHAR(MAX),
		[maximum_upstream_data_transfer_rate] NVARCHAR(MAX),
		[maximum_upstream_data_transfer_rate_unit_of_measure] NVARCHAR(MAX),
		[maximum_downstream_data_transfer_rate] NVARCHAR(MAX),
		[maximum_downstream_data_transfer_rate_unit_of_measure] NVARCHAR(MAX),
		[modem_type] NVARCHAR(MAX),
		[networking_feature1] NVARCHAR(MAX),
		[networking_feature2] NVARCHAR(MAX),
		[networking_feature3] NVARCHAR(MAX),
		[networking_feature4] NVARCHAR(MAX),
		[total_lan_ports] NVARCHAR(MAX),
		[lan_port_bandwidth] NVARCHAR(MAX),
		[connectivity_technology] NVARCHAR(MAX),
		[radio_bands_supported] NVARCHAR(MAX),
		[security_protocol] NVARCHAR(MAX),
		[form_factor] NVARCHAR(MAX),
		[wireless_communication_technology] NVARCHAR(MAX),
		[optical_storage_device] NVARCHAR(MAX),
		[amplifier_type] NVARCHAR(MAX),
		[chipset_type] NVARCHAR(MAX),
		[format] NVARCHAR(MAX),
		[effective_input_area] NVARCHAR(MAX),
		[hand_orientation] NVARCHAR(MAX),
		[has_auto_focus] NVARCHAR(MAX),
		[is_programmable] NVARCHAR(MAX),
		[disc_holder_capacity] NVARCHAR(MAX),
		[keyboard_description] NVARCHAR(MAX),
		[number_of_ports] NVARCHAR(MAX),
		[output_wattage] NVARCHAR(MAX),
		[resolution_base] NVARCHAR(MAX),
		[output_channel_quantity] NVARCHAR(MAX),
		[surround_sound_channel_configuration] NVARCHAR(MAX),
		[speed_rating] NVARCHAR(MAX),
		[optical_storage_write_speed] NVARCHAR(MAX),
		[maximum_operating_distance] NVARCHAR(MAX),
		[maximum_operating_distance_unit_of_measure] NVARCHAR(MAX),
		[speakers_maximum_output_power] NVARCHAR(MAX),
		[compatible_processor_types1] NVARCHAR(MAX),
		[compatible_processor_types2] NVARCHAR(MAX),
		[compatible_processor_types3] NVARCHAR(MAX),
		[compatible_processor_types4] NVARCHAR(MAX),
		[memory_slots_available] NVARCHAR(MAX),
		[speakers_nominal_output_power] NVARCHAR(MAX),
		[cooling_method] NVARCHAR(MAX),
		[fan_count] NVARCHAR(MAX),
		[fan_size] NVARCHAR(MAX),
		[fan_size_unit_of_measure] NVARCHAR(MAX),
		[maximum_rotational_speed] NVARCHAR(MAX),
		[maximum_rotational_speed_unit_of_measure] NVARCHAR(MAX),
		[air_flow_capacity] NVARCHAR(MAX),
		[air_flow_capacity_unit_of_measure] NVARCHAR(MAX),
		[noise_level_unit_of_measure] NVARCHAR(MAX),
		[light_type] NVARCHAR(MAX),
		[power_connector_type] NVARCHAR(MAX),
		[cooler_heatsink_material] NVARCHAR(MAX),
		[cooler_heatsink_compatibility1] NVARCHAR(MAX),
		[cooler_heatsink_compatibility2] NVARCHAR(MAX),
		[cooler_heatsink_compatibility3] NVARCHAR(MAX),
		[cooler_heatsink_compatibility4] NVARCHAR(MAX),
		[cooler_heatsink_compatibility5] NVARCHAR(MAX),
		[cooler_heatsink_compatibility6] NVARCHAR(MAX),
		[cooler_heatsink_compatibility7] NVARCHAR(MAX),
		[cooler_heatsink_compatibility8] NVARCHAR(MAX),
		[cooler_heatsink_compatibility9] NVARCHAR(MAX),
		[cooler_heatsink_compatibility10] NVARCHAR(MAX),
		[cooler_heatsink_compatibility11] NVARCHAR(MAX),
		[cooler_heatsink_compatibility12] NVARCHAR(MAX),
		[cooler_heatsink_compatibility13] NVARCHAR(MAX),
		[cooler_heatsink_compatibility14] NVARCHAR(MAX),
		[cooler_heatsink_compatibility15] NVARCHAR(MAX),
		[cooler_heatsink_compatibility16] NVARCHAR(MAX),
		[cooler_heatsink_compatibility17] NVARCHAR(MAX),
		[cooler_heatsink_compatibility18] NVARCHAR(MAX),
		[cooler_heatsink_compatibility19] NVARCHAR(MAX),
		[cooler_heatsink_compatibility20] NVARCHAR(MAX),
		[noise_level] NVARCHAR(MAX),
		[sensor_technology] NVARCHAR(MAX),
		[button_quantity] NVARCHAR(MAX),
		[headphones_form_factor] NVARCHAR(MAX),
		[specific_uses_for_product] NVARCHAR(MAX),
		[ram_memory_installed_size] NVARCHAR(MAX),
		[ram_memory_installed_size_unit_of_measure] NVARCHAR(MAX),
		[range] NVARCHAR(MAX),
		[range_unit_of_measure] NVARCHAR(MAX),
		[laser_color] NVARCHAR(MAX),
		[total_ethernet_ports] NVARCHAR(MAX),
		[multi_gpu_technology] NVARCHAR(MAX),
		[motherboard_type] NVARCHAR(MAX),
		[processor_socket] NVARCHAR(MAX),
		[system_bus_speed] NVARCHAR(MAX),
		[chipset_northbridge_description] NVARCHAR(MAX),
		[chipset_southbridge_description] NVARCHAR(MAX),
		[number_of_pins] NVARCHAR(MAX),
		[ram_memory_technology] NVARCHAR(MAX),
		[ram_memory_maximum_size] NVARCHAR(MAX),
		[ram_memory_maximum_size_unit_of_measure] NVARCHAR(MAX),
		[onboard_video_chipset_description] NVARCHAR(MAX),
		[system_bus_standard_supported1] NVARCHAR(MAX),
		[system_bus_standard_supported2] NVARCHAR(MAX),
		[system_bus_standard_supported3] NVARCHAR(MAX),
		[raid_level] NVARCHAR(MAX),
		[total_pci_e_ports] NVARCHAR(MAX),
		[total_ide_ports] NVARCHAR(MAX),
		[number_of_integrated_audio_channels] NVARCHAR(MAX),
		[spdif_connector_type] NVARCHAR(MAX),
		[total_hdmi_ports] NVARCHAR(MAX),
		[total_usb_2_0_ports] NVARCHAR(MAX),
		[total_firewire_800_ports] NVARCHAR(MAX),
		[total_esata_ports] NVARCHAR(MAX),
		[video_output_interface1] NVARCHAR(MAX),
		[video_output_interface2] NVARCHAR(MAX),
		[video_output_interface3] NVARCHAR(MAX),
		[video_output_interface4] NVARCHAR(MAX),
		[video_output_interface5] NVARCHAR(MAX),
		[video_output_format] NVARCHAR(MAX),
		[total_usb_ports] NVARCHAR(MAX),
		[pressure_sensitivity] NVARCHAR(MAX),
		[pressure_sensitivity_unit_of_measure] NVARCHAR(MAX),
		[maximum_input_resolution] NVARCHAR(MAX),
		[maximum_input_resolution_unit_of_measure] NVARCHAR(MAX),
		[cable_length_unit_of_measure] NVARCHAR(MAX),
		[cache_memory_installed_size] NVARCHAR(MAX),
		[cache_memory_installed_size_unit_of_measure] NVARCHAR(MAX),
		[computer_memory_size] NVARCHAR(MAX),
		[computer_cpu_manufacturer] NVARCHAR(MAX),
		[computer_cpu_speed] NVARCHAR(MAX),
		[computer_cpu_speed_unit_of_measure] NVARCHAR(MAX),
		[processor_count] NVARCHAR(MAX),
		[graphics_ram_type] NVARCHAR(MAX),
		[graphics_coprocessor] NVARCHAR(MAX),
		[optical_storage_installed_quantity] NVARCHAR(MAX),
		[notebook_display_technology] NVARCHAR(MAX),
		[computer_memory_size_unit_of_measure] NVARCHAR(MAX),
		[system_ram_type1] NVARCHAR(MAX),
		[system_ram_type2] NVARCHAR(MAX),
		[system_ram_type3] NVARCHAR(MAX),
		[system_ram_type4] NVARCHAR(MAX),
		[system_ram_type5] NVARCHAR(MAX),
		[system_ram_type6] NVARCHAR(MAX),
		[system_ram_type7] NVARCHAR(MAX),
		[system_ram_type8] NVARCHAR(MAX),
		[system_ram_type9] NVARCHAR(MAX),
		[system_ram_type10] NVARCHAR(MAX),
		[additional_drives1] NVARCHAR(MAX),
		[additional_drives2] NVARCHAR(MAX),
		[additional_drives3] NVARCHAR(MAX),
		[additional_drives4] NVARCHAR(MAX),
		[additional_drives5] NVARCHAR(MAX),
		[additional_drives6] NVARCHAR(MAX),
		[additional_drives7] NVARCHAR(MAX),
		[additional_drives8] NVARCHAR(MAX),
		[additional_drives9] NVARCHAR(MAX),
		[additional_drives10] NVARCHAR(MAX),
		[u_rack_size] NVARCHAR(MAX),
		[graphics_description1] NVARCHAR(MAX),
		[graphics_description2] NVARCHAR(MAX),
		[model_name] NVARCHAR(MAX),
		[total_dmi_ports] NVARCHAR(MAX),
		[total_microphone_ports] NVARCHAR(MAX),
		[total_ps2_ports] NVARCHAR(MAX),
		[total_lpt1_printer_ports] NVARCHAR(MAX),
		[total_serial_ports] NVARCHAR(MAX),
		[total_firewire_ports] NVARCHAR(MAX),
		[total_gaming_ports] NVARCHAR(MAX),
		[audio_output_type] NVARCHAR(MAX),
		[speaker_description] NVARCHAR(MAX),
		[wireless_provider1] NVARCHAR(MAX),
		[wireless_provider2] NVARCHAR(MAX),
		[wireless_provider3] NVARCHAR(MAX),
		[human_interface_input1] NVARCHAR(MAX),
		[human_interface_input2] NVARCHAR(MAX),
		[human_interface_input3] NVARCHAR(MAX),
		[human_interface_input4] NVARCHAR(MAX),
		[human_interface_input5] NVARCHAR(MAX),
		[computer_cpu_type] NVARCHAR(MAX),
		[native_resolution] NVARCHAR(MAX),
		[display_resolution_maximum] NVARCHAR(MAX),
		[display_size] NVARCHAR(MAX),
		[display_size_unit_of_measure] NVARCHAR(MAX),
		[has_color_screen] NVARCHAR(MAX),
		[tuner_technology] NVARCHAR(MAX),
		[hard_disk_rotational_speed] NVARCHAR(MAX),
		[hardware_platform] NVARCHAR(MAX),
		[hard_disk_description] NVARCHAR(MAX),
		[hard_disk_size1] NVARCHAR(MAX),
		[hard_disk_size2] NVARCHAR(MAX),
		[hard_disk_size3] NVARCHAR(MAX),
		[hard_disk_size4] NVARCHAR(MAX),
		[hard_disk_size5] NVARCHAR(MAX),
		[hard_disk_size6] NVARCHAR(MAX),
		[hard_disk_size7] NVARCHAR(MAX),
		[hard_disk_size8] NVARCHAR(MAX),
		[software_included] NVARCHAR(MAX),
		[graphics_ram1] NVARCHAR(MAX),
		[graphics_ram2] NVARCHAR(MAX),
		[graphics_processor_manufacturer] NVARCHAR(MAX),
		[memory_clock_speed] NVARCHAR(MAX),
		[memory_clock_speed_unit_of_measure] NVARCHAR(MAX),
		[operating_system1] NVARCHAR(MAX),
		[operating_system2] NVARCHAR(MAX),
		[hard_disk_interface1] NVARCHAR(MAX),
		[hard_disk_interface2] NVARCHAR(MAX),
		[hard_disk_interface3] NVARCHAR(MAX),
		[hard_disk_interface4] NVARCHAR(MAX),
		[hard_disk_interface5] NVARCHAR(MAX),
		[total_audio_out_ports] NVARCHAR(MAX),
		[front_photo_sensor_resolution] NVARCHAR(MAX),
		[front_photo_sensor_resolution_unit_of_measure] NVARCHAR(MAX),
		[battery_average_life_recharge] NVARCHAR(MAX),
		[memory_speed] NVARCHAR(MAX),
		[column_address_strobe_latency] NVARCHAR(MAX),
		[nominal_voltage] NVARCHAR(MAX),
		[nominal_voltage_unit_of_measure] NVARCHAR(MAX),
		[number_of_channels] NVARCHAR(MAX),
		[maximum_sample_rate] NVARCHAR(MAX),
		[maximum_sample_rate_unit_of_measure] NVARCHAR(MAX),
		[audio_input] NVARCHAR(MAX),
		[speaker_connectivity] NVARCHAR(MAX),
		[optical_digital_output] NVARCHAR(MAX),
		[optical_digital_input] NVARCHAR(MAX),
		[material_type] NVARCHAR(MAX),
		[compatible_devices1] NVARCHAR(MAX),
		[compatible_devices2] NVARCHAR(MAX),
		[compatible_devices3] NVARCHAR(MAX),
		[compatible_devices4] NVARCHAR(MAX),
		[compatible_devices5] NVARCHAR(MAX),
		[compatible_devices6] NVARCHAR(MAX),
		[capacity_name] NVARCHAR(MAX),
		[external_testing_certification] NVARCHAR(MAX),
		[memory_bus_width] NVARCHAR(MAX),
		[memory_bus_width_unit_of_measure] NVARCHAR(MAX),
		[memory_module_type] NVARCHAR(MAX),
		[supported_graphics_specification1] NVARCHAR(MAX),
		[supported_graphics_specification2] NVARCHAR(MAX),
		[supported_graphics_specification3] NVARCHAR(MAX),
		[total_s_video_out_ports] NVARCHAR(MAX),
		[total_mini_hdmi_ports] NVARCHAR(MAX),
		[total_dvi_ports] NVARCHAR(MAX),
		[total_composite_ports] NVARCHAR(MAX),
		[gpu_clock_speed] NVARCHAR(MAX),
		[gpu_clock_speed_unit_of_measure] NVARCHAR(MAX),
		[maximum_external_resolution] NVARCHAR(MAX),
		[display_technology] NVARCHAR(MAX),
		[image_contrast_ratio] NVARCHAR(MAX),
		[analog_video_format1] NVARCHAR(MAX),
		[analog_video_format2] NVARCHAR(MAX),
		[analog_video_format3] NVARCHAR(MAX),
		[minimum_horizontal_refresh_rate] NVARCHAR(MAX),
		[maximum_horizontal_refresh_rate] NVARCHAR(MAX),
		[minimum_vertical_refresh_rate] NVARCHAR(MAX),
		[maximum_vertical_refresh_rate] NVARCHAR(MAX),
		[light_source_wattage] NVARCHAR(MAX),
		[light_source_operating_life] NVARCHAR(MAX),
		[light_source_operating_life_unit_of_measure] NVARCHAR(MAX),
		[image_brightness] NVARCHAR(MAX),
		[image_brightness_unit_of_measure] NVARCHAR(MAX),
		[optimal_image_size] NVARCHAR(MAX),
		[minimum_image_size] NVARCHAR(MAX),
		[maximum_image_size] NVARCHAR(MAX),
		[minimum_throw_distance] NVARCHAR(MAX),
		[maximum_throw_distance] NVARCHAR(MAX),
		[minimum_effective_throw_ratio] NVARCHAR(MAX),
		[maximum_effective_throw_ratio] NVARCHAR(MAX),
		[zoom_ratio] NVARCHAR(MAX),
		[zoom_type] NVARCHAR(MAX),
		[focal_length_description] NVARCHAR(MAX),
		[image_aspect_ratio] NVARCHAR(MAX),
		[media_type_base] NVARCHAR(MAX),
		[vertical_keystone_correction] NVARCHAR(MAX),
		[_3d_transmission_format] NVARCHAR(MAX),
		[remote_control_description] NVARCHAR(MAX),
		[trigger_voltage] NVARCHAR(MAX),
		[trigger_voltage_unit_of_measure] NVARCHAR(MAX),
		[gps_navigation] NVARCHAR(MAX),
		[shielding_type] NVARCHAR(MAX),
		[external_bay_height1] NVARCHAR(MAX),
		[external_bay_height2] NVARCHAR(MAX),
		[external_bay_height3] NVARCHAR(MAX),
		[external_bay_height4] NVARCHAR(MAX),
		[external_bay_height5] NVARCHAR(MAX),
		[external_bays_quantity] NVARCHAR(MAX),
		[hot_swap_bay_height1] NVARCHAR(MAX),
		[hot_swap_bay_height2] NVARCHAR(MAX),
		[hot_swap_bay_height3] NVARCHAR(MAX),
		[hot_swap_bay_height4] NVARCHAR(MAX),
		[hot_swap_bay_height5] NVARCHAR(MAX),
		[hot_swap_bays_quantity] NVARCHAR(MAX),
		[internal_bay_height1] NVARCHAR(MAX),
		[internal_bay_height2] NVARCHAR(MAX),
		[internal_bay_height3] NVARCHAR(MAX),
		[internal_bay_height4] NVARCHAR(MAX),
		[internal_bay_height5] NVARCHAR(MAX),
		[internal_bays_quantity] NVARCHAR(MAX),
		[power_supply_mounting_type] NVARCHAR(MAX),
		[power_supply_maximum_output] NVARCHAR(MAX),
		[power_supply_maximum_output_unit_of_measure] NVARCHAR(MAX),
		[total_usb_1_0_ports] NVARCHAR(MAX),
		[total_usb_1_1_ports] NVARCHAR(MAX),
		[total_audio_in_ports] NVARCHAR(MAX),
		[supported_motherboard] NVARCHAR(MAX),
		[air_duct_location] NVARCHAR(MAX),
		[total_expansion_slots_quantity] NVARCHAR(MAX),
		[window_location] NVARCHAR(MAX),
		[buffer_size] NVARCHAR(MAX),
		[buffer_size_unit_of_measure] NVARCHAR(MAX),
		[external_hardware_interface] NVARCHAR(MAX),
		[average_seek_time] NVARCHAR(MAX),
		[hard_disk_average_latency] NVARCHAR(MAX),
		[total_internal_bays_free] NVARCHAR(MAX),
		[total_external_bays_free] NVARCHAR(MAX),
		[total_firewire_1600_ports] NVARCHAR(MAX),
		[total_firewire_3200_ports] NVARCHAR(MAX),
		[number_of_hard_drives] NVARCHAR(MAX),
		[material_composition] NVARCHAR(MAX),
		[hard_disk_form_factor1] NVARCHAR(MAX),
		[hard_disk_form_factor2] NVARCHAR(MAX),
		[hard_disk_form_factor3] NVARCHAR(MAX),
		[hard_disk_form_factor4] NVARCHAR(MAX),
		[hard_disk_form_factor5] NVARCHAR(MAX),
		[flash_memory_type] NVARCHAR(MAX),
		[optical_storage_read_speed] NVARCHAR(MAX),
		[data_transfer_rate1] NVARCHAR(MAX),
		[data_transfer_rate2] NVARCHAR(MAX),
		[data_transfer_rate3] NVARCHAR(MAX),
		[data_transfer_rate_unit_of_measure] NVARCHAR(MAX),
		[power_factor_correction] NVARCHAR(MAX),
		[system_bus_connector_type] NVARCHAR(MAX),
		[component_power_connector_quantity] NVARCHAR(MAX),
		[power_supply_design] NVARCHAR(MAX),
		[efficiency] NVARCHAR(MAX),
		[cache_memory_per_processor] NVARCHAR(MAX),
		[cache_memory_per_processor_unit_of_measure] NVARCHAR(MAX),
		[included_components] NVARCHAR(MAX),
		[maximum_current] NVARCHAR(MAX),
		[maximum_current_unit_of_measure] NVARCHAR(MAX),
		[privacy_screen_type] NVARCHAR(MAX),
		[monitor_connector_quantity] NVARCHAR(MAX),
		[max_horizontal_resolution] NVARCHAR(MAX),
		[max_vertical_resolution] NVARCHAR(MAX),
		[core_material_type] NVARCHAR(MAX),
		[connection_speed] NVARCHAR(MAX),
		[connection_speed_unit_of_measure] NVARCHAR(MAX),
		[frequency_response_curve] NVARCHAR(MAX))

		INSERT INTO [Inventory].[dbo].[tmpWeightsFeed]
		SELECT 		
		AMSKU.[DARTFBMSKU]+'FLX' AS 'item_sku',
		AZ.[ASIN] AS 'external_product_id',
		'ASIN' AS 'external_product_id_type',
		'' AS 'gtin_exemption_reason',
		'' AS 'related_product_id',
		'' AS 'related_product_id_type',
		'' AS 'item_name',
		'' AS 'brand_name',
		'' AS 'manufacturer',
		'' AS 'product_description',
		'' AS 'item_type',
		'' AS 'feed_product_type',
		'' AS 'part_number',
		'' AS 'model',
		'PartialUpdate' AS 'update_delete',
		'' AS 'standard_price',
		'' AS 'list_price',
		'' AS 'currency',
		'' AS 'quantity',
		'' AS 'condition_type',
		'' AS 'condition_note',
		'' AS 'sale_price',
		'' AS 'sale_from_date',
		'' AS 'sale_end_date',
		'' AS 'number_of_items',
		'' AS 'product_tax_code',
		'' AS 'product_site_launch_date',
		'' AS 'merchant_release_date',
		'' AS 'fulfillment_latency',
		'' AS 'restock_date',
		'' AS 'max_aggregate_ship_quantity',
		'' AS 'offering_can_be_gift_messaged',
		'' AS 'offering_can_be_giftwrapped',
		'' AS 'is_discontinued_by_manufacturer',
		'' AS 'missing_keyset_reason',
		'' AS 'rebate_start_at1',
		'' AS 'rebate_start_at2',
		'' AS 'rebate_end_at1',
		'' AS 'rebate_end_at2',
		'' AS 'rebate_description1',
		'' AS 'rebate_description2',
		'' AS 'rebate_name1',
		'' AS 'rebate_name2',
		'' AS 'delivery_schedule_group_id',
		'' AS 'item_display_diameter',
		'' AS 'item_display_diameter_unit_of_measure',
		ISNULL(CAST(PC.[BoxWeightOz]/16 AS decimal(10,2)),0.8) AS 'website_shipping_weight',
		'LB' AS 'website_shipping_weight_unit_of_measure',
		IsNull(PC.[BoxLength],5) AS 'item_length',
		IsNull(PC.[BoxWidth],5) AS 'item_width',
		IsNull(PC.[BoxHeight],5) AS 'item_height',
		'IN' AS 'item_length_unit_of_measure',
		ISNULL(CAST(PC.[BoxWeightOz]/16 AS decimal(10,2)),0.8) AS 'item_weight',
		'LB' AS 'item_weight_unit_of_measure',
		'' AS 'bullet_point1',
		'' AS 'bullet_point2',
		'' AS 'bullet_point3',
		'' AS 'bullet_point4',
		'' AS 'bullet_point5',
		'' AS 'generic_keywords1',
		'' AS 'generic_keywords2',
		'' AS 'generic_keywords3',
		'' AS 'generic_keywords4',
		'' AS 'generic_keywords5',
		'' AS 'platinum_keywords1',
		'' AS 'platinum_keywords2',
		'' AS 'platinum_keywords3',
		'' AS 'platinum_keywords4',
		'' AS 'platinum_keywords5',
		'' AS 'main_image_url',
		'' AS 'other_image_url1',
		'' AS 'other_image_url2',
		'' AS 'other_image_url3',
		'' AS 'other_image_url4',
		'' AS 'other_image_url5',
		'' AS 'other_image_url6',
		'' AS 'other_image_url7',
		'' AS 'other_image_url8',
		'' AS 'swatch_image_url',
		'' AS 'fulfillment_center_id',
		IsNull(PC.[BoxHeight],5) AS 'package_height',
		IsNull(PC.[BoxWidth],5) AS 'package_width',
		IsNull(PC.[BoxLength],5) AS 'package_length',
		'IN' AS 'package_length_unit_of_measure',
		IsNull(CAST(PC.[BoxWeightOz]/16 AS decimal(10,2)),0.8) AS 'package_weight',
		'LB' AS 'package_weight_unit_of_measure',
		'' AS 'country_of_origin',
		'' AS 'legal_disclaimer_description',
		'' AS 'prop_65',
		'' AS 'safety_warning',
		'' AS 'cpsia_cautionary_statement1',
		'' AS 'cpsia_cautionary_statement2',
		'' AS 'cpsia_cautionary_statement3',
		'' AS 'cpsia_cautionary_statement4',
		'' AS 'cpsia_cautionary_description',
		'' AS 'connector_quantity',
		'' AS 'cable_length',
		'' AS 'secure_digital_association_speed_class',
		'' AS 'read_speed',
		'' AS 'read_speed_unit_of_measure',
		'' AS 'write_speed_unit_of_measure',
		'' AS 'write_speed',
		'' AS 'data_transfer_rate_units',
		'' AS 'hard_drive_size_unit_of_measure',
		'' AS 'special_features',
		'' AS 'connector_type',
		'' AS 'digital_audio_capacity',
		'' AS 'communication_interface',
		'' AS 'input_type',
		'' AS 'movement_detection_technology',
		'' AS 'recording_capacity',
		'' AS 'voltage',
		'' AS 'wattage',
		'' AS 'memory_storage_capacity',
		'' AS 'memory_storage_capacity_unit_of_measure',
		'' AS 'audio_output_mode',
		'' AS 'graphics_ram_size_unit_of_measure',
		'' AS 'maximum_simultaneous_sessions',
		'' AS 'total_sata_ports',
		'' AS 'main_power_connector',
		'' AS 'external_bay_type_units',
		'' AS 'hotswap_bay_type_units',
		'' AS 'internal_bay_type_units',
		'' AS 'hardware_interface1',
		'' AS 'hardware_interface2',
		'' AS 'hardware_interface3',
		'' AS 'hardware_interface4',
		'' AS 'hardware_interface5',
		'' AS 'wireless_comm_standard1',
		'' AS 'wireless_comm_standard2',
		'' AS 'wireless_comm_standard3',
		'' AS 'are_batteries_included',
		'' AS 'batteries_required',
		'' AS 'power_source_type',
		'' AS 'battery_type',
		'' AS 'number_of_batteries',
		'' AS 'battery_average_life',
		'' AS 'battery_average_life_standby',
		'' AS 'battery_charge_time',
		'' AS 'lithium_battery_energy_content',
		'' AS 'lithium_battery_packaging',
		'' AS 'lithium_battery_voltage',
		'' AS 'lithium_battery_weight',
		'' AS 'number_of_lithium_ion_cells',
		'' AS 'number_of_lithium_metal_cells',
		'' AS 'mfg_warranty_description_type',
		'' AS 'mfg_warranty_description_labor',
		'' AS 'mfg_warranty_description_parts',
		'' AS 'seller_warranty_description',
		'' AS 'microphone_form_factor',
		'' AS 'photo_sensor_technology',
		'' AS 'photo_sensor_resolution',
		'' AS 'photo_sensor_resolution_unit_of_measure',
		'' AS 'effective_video_resolution',
		'' AS 'effective_video_resolution_unit_of_measure',
		'' AS 'communication_standard',
		'' AS 'network_interface_description',
		'' AS 'effective_still_resolution',
		'' AS 'effective_still_resolution_unit_of_measure',
		'' AS 'effective_video_comm_resolution',
		'' AS 'effective_video_comm_resolution_unit_of_measure',
		'' AS 'minimum_system_requirement_description',
		'' AS 'maximum_upstream_data_transfer_rate',
		'' AS 'maximum_upstream_data_transfer_rate_unit_of_measure',
		'' AS 'maximum_downstream_data_transfer_rate',
		'' AS 'maximum_downstream_data_transfer_rate_unit_of_measure',
		'' AS 'modem_type',
		'' AS 'networking_feature1',
		'' AS 'networking_feature2',
		'' AS 'networking_feature3',
		'' AS 'networking_feature4',
		'' AS 'total_lan_ports',
		'' AS 'lan_port_bandwidth',
		'' AS 'connectivity_technology',
		'' AS 'radio_bands_supported',
		'' AS 'security_protocol',
		'' AS 'form_factor',
		'' AS 'wireless_communication_technology',
		'' AS 'optical_storage_device',
		'' AS 'amplifier_type',
		'' AS 'chipset_type',
		'' AS 'format',
		'' AS 'effective_input_area',
		'' AS 'hand_orientation',
		'' AS 'has_auto_focus',
		'' AS 'is_programmable',
		'' AS 'disc_holder_capacity',
		'' AS 'keyboard_description',
		'' AS 'number_of_ports',
		'' AS 'output_wattage',
		'' AS 'resolution_base',
		'' AS 'output_channel_quantity',
		'' AS 'surround_sound_channel_configuration',
		'' AS 'speed_rating',
		'' AS 'optical_storage_write_speed',
		'' AS 'maximum_operating_distance',
		'' AS 'maximum_operating_distance_unit_of_measure',
		'' AS 'speakers_maximum_output_power',
		'' AS 'compatible_processor_types1',
		'' AS 'compatible_processor_types2',
		'' AS 'compatible_processor_types3',
		'' AS 'compatible_processor_types4',
		'' AS 'memory_slots_available',
		'' AS 'speakers_nominal_output_power',
		'' AS 'cooling_method',
		'' AS 'fan_count',
		'' AS 'fan_size',
		'' AS 'fan_size_unit_of_measure',
		'' AS 'maximum_rotational_speed',
		'' AS 'maximum_rotational_speed_unit_of_measure',
		'' AS 'air_flow_capacity',
		'' AS 'air_flow_capacity_unit_of_measure',
		'' AS 'noise_level_unit_of_measure',
		'' AS 'light_type',
		'' AS 'power_connector_type',
		'' AS 'cooler_heatsink_material',
		'' AS 'cooler_heatsink_compatibility1',
		'' AS 'cooler_heatsink_compatibility2',
		'' AS 'cooler_heatsink_compatibility3',
		'' AS 'cooler_heatsink_compatibility4',
		'' AS 'cooler_heatsink_compatibility5',
		'' AS 'cooler_heatsink_compatibility6',
		'' AS 'cooler_heatsink_compatibility7',
		'' AS 'cooler_heatsink_compatibility8',
		'' AS 'cooler_heatsink_compatibility9',
		'' AS 'cooler_heatsink_compatibility10',
		'' AS 'cooler_heatsink_compatibility11',
		'' AS 'cooler_heatsink_compatibility12',
		'' AS 'cooler_heatsink_compatibility13',
		'' AS 'cooler_heatsink_compatibility14',
		'' AS 'cooler_heatsink_compatibility15',
		'' AS 'cooler_heatsink_compatibility16',
		'' AS 'cooler_heatsink_compatibility17',
		'' AS 'cooler_heatsink_compatibility18',
		'' AS 'cooler_heatsink_compatibility19',
		'' AS 'cooler_heatsink_compatibility20',
		'' AS 'noise_level',
		'' AS 'sensor_technology',
		'' AS 'button_quantity',
		'' AS 'headphones_form_factor',
		'' AS 'specific_uses_for_product',
		'' AS 'ram_memory_installed_size',
		'' AS 'ram_memory_installed_size_unit_of_measure',
		'' AS 'range',
		'' AS 'range_unit_of_measure',
		'' AS 'laser_color',
		'' AS 'total_ethernet_ports',
		'' AS 'multi_gpu_technology',
		'' AS 'motherboard_type',
		'' AS 'processor_socket',
		'' AS 'system_bus_speed',
		'' AS 'chipset_northbridge_description',
		'' AS 'chipset_southbridge_description',
		'' AS 'number_of_pins',
		'' AS 'ram_memory_technology',
		'' AS 'ram_memory_maximum_size',
		'' AS 'ram_memory_maximum_size_unit_of_measure',
		'' AS 'onboard_video_chipset_description',
		'' AS 'system_bus_standard_supported1',
		'' AS 'system_bus_standard_supported2',
		'' AS 'system_bus_standard_supported3',
		'' AS 'raid_level',
		'' AS 'total_pci_e_ports',
		'' AS 'total_ide_ports',
		'' AS 'number_of_integrated_audio_channels',
		'' AS 'spdif_connector_type',
		'' AS 'total_hdmi_ports',
		'' AS 'total_usb_2_0_ports',
		'' AS 'total_firewire_800_ports',
		'' AS 'total_esata_ports',
		'' AS 'video_output_interface1',
		'' AS 'video_output_interface2',
		'' AS 'video_output_interface3',
		'' AS 'video_output_interface4',
		'' AS 'video_output_interface5',
		'' AS 'video_output_format',
		'' AS 'total_usb_ports',
		'' AS 'pressure_sensitivity',
		'' AS 'pressure_sensitivity_unit_of_measure',
		'' AS 'maximum_input_resolution',
		'' AS 'maximum_input_resolution_unit_of_measure',
		'' AS 'cable_length_unit_of_measure',
		'' AS 'cache_memory_installed_size',
		'' AS 'cache_memory_installed_size_unit_of_measure',
		'' AS 'computer_memory_size',
		'' AS 'computer_cpu_manufacturer',
		'' AS 'computer_cpu_speed',
		'' AS 'computer_cpu_speed_unit_of_measure',
		'' AS 'processor_count',
		'' AS 'graphics_ram_type',
		'' AS 'graphics_coprocessor',
		'' AS 'optical_storage_installed_quantity',
		'' AS 'notebook_display_technology',
		'' AS 'computer_memory_size_unit_of_measure',
		'' AS 'system_ram_type1',
		'' AS 'system_ram_type2',
		'' AS 'system_ram_type3',
		'' AS 'system_ram_type4',
		'' AS 'system_ram_type5',
		'' AS 'system_ram_type6',
		'' AS 'system_ram_type7',
		'' AS 'system_ram_type8',
		'' AS 'system_ram_type9',
		'' AS 'system_ram_type10',
		'' AS 'additional_drives1',
		'' AS 'additional_drives2',
		'' AS 'additional_drives3',
		'' AS 'additional_drives4',
		'' AS 'additional_drives5',
		'' AS 'additional_drives6',
		'' AS 'additional_drives7',
		'' AS 'additional_drives8',
		'' AS 'additional_drives9',
		'' AS 'additional_drives10',
		'' AS 'u_rack_size',
		'' AS 'graphics_description1',
		'' AS 'graphics_description2',
		'' AS 'model_name',
		'' AS 'total_dmi_ports',
		'' AS 'total_microphone_ports',
		'' AS 'total_ps2_ports',
		'' AS 'total_lpt1_printer_ports',
		'' AS 'total_serial_ports',
		'' AS 'total_firewire_ports',
		'' AS 'total_gaming_ports',
		'' AS 'audio_output_type',
		'' AS 'speaker_description',
		'' AS 'wireless_provider1',
		'' AS 'wireless_provider2',
		'' AS 'wireless_provider3',
		'' AS 'human_interface_input1',
		'' AS 'human_interface_input2',
		'' AS 'human_interface_input3',
		'' AS 'human_interface_input4',
		'' AS 'human_interface_input5',
		'' AS 'computer_cpu_type',
		'' AS 'native_resolution',
		'' AS 'display_resolution_maximum',
		'' AS 'display_size',
		'' AS 'display_size_unit_of_measure',
		'' AS 'has_color_screen',
		'' AS 'tuner_technology',
		'' AS 'hard_disk_rotational_speed',
		'' AS 'hardware_platform',
		'' AS 'hard_disk_description',
		'' AS 'hard_disk_size1',
		'' AS 'hard_disk_size2',
		'' AS 'hard_disk_size3',
		'' AS 'hard_disk_size4',
		'' AS 'hard_disk_size5',
		'' AS 'hard_disk_size6',
		'' AS 'hard_disk_size7',
		'' AS 'hard_disk_size8',
		'' AS 'software_included',
		'' AS 'graphics_ram1',
		'' AS 'graphics_ram2',
		'' AS 'graphics_processor_manufacturer',
		'' AS 'memory_clock_speed',
		'' AS 'memory_clock_speed_unit_of_measure',
		'' AS 'operating_system1',
		'' AS 'operating_system2',
		'' AS 'hard_disk_interface1',
		'' AS 'hard_disk_interface2',
		'' AS 'hard_disk_interface3',
		'' AS 'hard_disk_interface4',
		'' AS 'hard_disk_interface5',
		'' AS 'total_audio_out_ports',
		'' AS 'front_photo_sensor_resolution',
		'' AS 'front_photo_sensor_resolution_unit_of_measure',
		'' AS 'battery_average_life_recharge',
		'' AS 'memory_speed',
		'' AS 'column_address_strobe_latency',
		'' AS 'nominal_voltage',
		'' AS 'nominal_voltage_unit_of_measure',
		'' AS 'number_of_channels',
		'' AS 'maximum_sample_rate',
		'' AS 'maximum_sample_rate_unit_of_measure',
		'' AS 'audio_input',
		'' AS 'speaker_connectivity',
		'' AS 'optical_digital_output',
		'' AS 'optical_digital_input',
		'' AS 'material_type',
		'' AS 'compatible_devices1',
		'' AS 'compatible_devices2',
		'' AS 'compatible_devices3',
		'' AS 'compatible_devices4',
		'' AS 'compatible_devices5',
		'' AS 'compatible_devices6',
		'' AS 'capacity_name',
		'' AS 'external_testing_certification',
		'' AS 'memory_bus_width',
		'' AS 'memory_bus_width_unit_of_measure',
		'' AS 'memory_module_type',
		'' AS 'supported_graphics_specification1',
		'' AS 'supported_graphics_specification2',
		'' AS 'supported_graphics_specification3',
		'' AS 'total_s_video_out_ports',
		'' AS 'total_mini_hdmi_ports',
		'' AS 'total_dvi_ports',
		'' AS 'total_composite_ports',
		'' AS 'gpu_clock_speed',
		'' AS 'gpu_clock_speed_unit_of_measure',
		'' AS 'maximum_external_resolution',
		'' AS 'display_technology',
		'' AS 'image_contrast_ratio',
		'' AS 'analog_video_format1',
		'' AS 'analog_video_format2',
		'' AS 'analog_video_format3',
		'' AS 'minimum_horizontal_refresh_rate',
		'' AS 'maximum_horizontal_refresh_rate',
		'' AS 'minimum_vertical_refresh_rate',
		'' AS 'maximum_vertical_refresh_rate',
		'' AS 'light_source_wattage',
		'' AS 'light_source_operating_life',
		'' AS 'light_source_operating_life_unit_of_measure',
		'' AS 'image_brightness',
		'' AS 'image_brightness_unit_of_measure',
		'' AS 'optimal_image_size',
		'' AS 'minimum_image_size',
		'' AS 'maximum_image_size',
		'' AS 'minimum_throw_distance',
		'' AS 'maximum_throw_distance',
		'' AS 'minimum_effective_throw_ratio',
		'' AS 'maximum_effective_throw_ratio',
		'' AS 'zoom_ratio',
		'' AS 'zoom_type',
		'' AS 'focal_length_description',
		'' AS 'image_aspect_ratio',
		'' AS 'media_type_base',
		'' AS 'vertical_keystone_correction',
		'' AS '_3d_transmission_format',
		'' AS 'remote_control_description',
		'' AS 'trigger_voltage',
		'' AS 'trigger_voltage_unit_of_measure',
		'' AS 'gps_navigation',
		'' AS 'shielding_type',
		'' AS 'external_bay_height1',
		'' AS 'external_bay_height2',
		'' AS 'external_bay_height3',
		'' AS 'external_bay_height4',
		'' AS 'external_bay_height5',
		'' AS 'external_bays_quantity',
		'' AS 'hot_swap_bay_height1',
		'' AS 'hot_swap_bay_height2',
		'' AS 'hot_swap_bay_height3',
		'' AS 'hot_swap_bay_height4',
		'' AS 'hot_swap_bay_height5',
		'' AS 'hot_swap_bays_quantity',
		'' AS 'internal_bay_height1',
		'' AS 'internal_bay_height2',
		'' AS 'internal_bay_height3',
		'' AS 'internal_bay_height4',
		'' AS 'internal_bay_height5',
		'' AS 'internal_bays_quantity',
		'' AS 'power_supply_mounting_type',
		'' AS 'power_supply_maximum_output',
		'' AS 'power_supply_maximum_output_unit_of_measure',
		'' AS 'total_usb_1_0_ports',
		'' AS 'total_usb_1_1_ports',
		'' AS 'total_audio_in_ports',
		'' AS 'supported_motherboard',
		'' AS 'air_duct_location',
		'' AS 'total_expansion_slots_quantity',
		'' AS 'window_location',
		'' AS 'buffer_size',
		'' AS 'buffer_size_unit_of_measure',
		'' AS 'external_hardware_interface',
		'' AS 'average_seek_time',
		'' AS 'hard_disk_average_latency',
		'' AS 'total_internal_bays_free',
		'' AS 'total_external_bays_free',
		'' AS 'total_firewire_1600_ports',
		'' AS 'total_firewire_3200_ports',
		'' AS 'number_of_hard_drives',
		'' AS 'material_composition',
		'' AS 'hard_disk_form_factor1',
		'' AS 'hard_disk_form_factor2',
		'' AS 'hard_disk_form_factor3',
		'' AS 'hard_disk_form_factor4',
		'' AS 'hard_disk_form_factor5',
		'' AS 'flash_memory_type',
		'' AS 'optical_storage_read_speed',
		'' AS 'data_transfer_rate1',
		'' AS 'data_transfer_rate2',
		'' AS 'data_transfer_rate3',
		'' AS 'data_transfer_rate_unit_of_measure',
		'' AS 'power_factor_correction',
		'' AS 'system_bus_connector_type',
		'' AS 'component_power_connector_quantity',
		'' AS 'power_supply_design',
		'' AS 'efficiency',
		'' AS 'cache_memory_per_processor',
		'' AS 'cache_memory_per_processor_unit_of_measure',
		'' AS 'included_components',
		'' AS 'maximum_current',
		'' AS 'maximum_current_unit_of_measure',
		'' AS 'privacy_screen_type',
		'' AS 'monitor_connector_quantity',
		'' AS 'max_horizontal_resolution',
		'' AS 'max_vertical_resolution',
		'' AS 'core_material_type',
		'' AS 'connection_speed',
		'' AS 'connection_speed_unit_of_measure',
		'' AS 'frequency_response_curve'
	  
		  FROM [Inventory].[dbo].[Amazon] AS AZ
		  LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AMSKU ON (AZ.[ASIN] = AMSKU.[ASIN])
		  LEFT OUTER JOIN [Inventory].[dbo].[AmazonBrands] AS AMZBRAND ON (AZ.[BrandMentioned] = AMZBRAND.[Brand])
		  LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (AZ.[ProductCatalogId] = PC.[ID])  
		  LEFT OUTER JOIN [Mitech].[amz].[AmazonFeeds] AS AZF ON (AMSKU.[DARTFBMSKU] = AZF.[MerchantSKU])
		  LEFT OUTER JOIN [AmazonExclusiveBulbs].[dbo].[InventoryFBAManage] AS AZFBA ON (AMSKU.[DARTFBMSKU]+'FLX' = AZFBA.[sku])
		  WHERE AZ.[CountryCode] = 'US'
		  AND AMSKU.[DARTFBMSKU] IS NOT NULL
		  AND AZF.[IsSFP] = 1
		  AND AZFBA.[afn_fulfillable_quantity] = 0
		  AND AZFBA.[sku] IS NOT NULL



		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed1] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 1 AND 20000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed1] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed1]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed2] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 20000 AND 40000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed2] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed2]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed3] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 40000 AND 60000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed3] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed3]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed4] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 60000 AND 80000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed4] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed4]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed5] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 80000 AND 100000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed5] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed5]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed6] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 100000 AND 120000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed6] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed6]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed7] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 120000 AND 140000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed7] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed7]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed8] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 140000 AND 160000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed8] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed8]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed9] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 160000 AND 180000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed9] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed9]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed10] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 180000 AND 200000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed10] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed10]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed11] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 200000 AND 220000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed11] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed11]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed12] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 220000 AND 240000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed12] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed12]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed13] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 240000 AND 260000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed13] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed13]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed14] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 260000 AND 280000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed14] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed14]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'

		SELECT * INTO [Inventory].[dbo].[tmpWeightsFeed15] FROM [Inventory].[dbo].[tmpWeightsFeed] WHERE [ID] BETWEEN 280000 AND 300000
		ALTER TABLE [Inventory].[dbo].[tmpWeightsFeed15] DROP COLUMN [ID]

		SET @selectstatement = 'SELECT * FROM [Inventory].[dbo].[tmpWeightsFeed15]'
		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebweights-body.txt" -SMITSQL -Usa -PZ91bM473 -c -t"\t" -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendweights.bat"'


		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed1'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed1]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed2'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed2]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed3'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed3]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed4'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed4]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed5'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed5]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed6'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed6]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed7'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed7]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed8'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed8]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed9'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed9]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed10'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed10]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed11'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed11]
			END

		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed12'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed12]
			END


		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed13'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed13]
			END




		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed14'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed14]
			END




		IF (EXISTS (SELECT * 
							 FROM INFORMATION_SCHEMA.TABLES 
							 WHERE TABLE_CATALOG = 'Inventory' 
							 AND  TABLE_NAME = 'tmpWeightsFeed15'))
			BEGIN
				DROP TABLE [Inventory].[dbo].[tmpWeightsFeed15]
			END







END
go

