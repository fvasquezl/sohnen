CREATE VIEW [dbo]._dta_mv_37 WITH SCHEMABINDING AS SELECT  [dbo].[CustomerSpecificPricing].[ProductCatalogID] as _col_1,  [dbo].[CustomerSpecificPricing].[CustomerID] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[CustomerSpecificPricing]   GROUP BY  [dbo].[CustomerSpecificPricing].[ProductCatalogID],  [dbo].[CustomerSpecificPricing].[CustomerID]
go

