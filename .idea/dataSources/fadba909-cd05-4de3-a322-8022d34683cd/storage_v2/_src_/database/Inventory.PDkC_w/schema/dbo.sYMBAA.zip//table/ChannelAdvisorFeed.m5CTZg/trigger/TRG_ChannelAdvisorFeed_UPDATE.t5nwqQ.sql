-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-03-12
-- Description:	Update ChannelAdvisorFeed Table to Insert Modified Column
-- =============================================
CREATE TRIGGER [dbo].[TRG_ChannelAdvisorFeed_UPDATE]
   ON  dbo.ChannelAdvisorFeed
   AFTER UPDATE
AS 
	DECLARE 
		@FeedID		INT,
		@Modified	CHAR(1)
BEGIN
	SET NOCOUNT ON;

	SELECT @FeedID = FeedID,
		@Modified = Modified
	FROM INSERTED

	IF(ISNULL(@Modified,'M')='M')
	BEGIN
		UPDATE Inventory.dbo.ChannelAdvisorFeed SET Modified = 'S' WHERE FeedID = @FeedID
	END
	ELSE IF (@Modified='U')
	BEGIN
		UPDATE Inventory.dbo.ChannelAdvisorFeed SET Modified = 'M' WHERE FeedID = @FeedID
	END
END
go

