-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Excess_Inventory]
	
 @pDateStart date, @pDateEnd date, @pCategoryID int
AS
BEGIN

	DECLARE @temtable table (
	SKU  int,
	Manufacturer  varchar(100),
	InvStart int,
	InvTotalAdded  int,
	InvTotalRemoved int,
	InvCurrent int,
	AvgRemovedperDay decimal(10,2),
	TargetStockInDays int,
	DaysUntilWeRunOut int,
	AddedDetails varchar(30),
	InvAddedAuditInput int,
	InvAddedLampProduction int,
	InvAddedAssembly int,
	InvAddedRMAReturn int,
	InvAddedFBAReturn int,
	InvAddedPurchaseOrder int,
	InvAddedOther int,
	RemovedDetails varchar(30),
	InvRemovedAuditAdj int,
	InvRemovedOrder int,
	InvRemovedAssembly int,
	InvRemovedRMAExchange int,
	InvRemovedFBAShipment int,
	InvRemovedPOAdjustment int,
	InvRemovedOther int
)

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @SKU int;
	DECLARE SKU_cursor CURSOR FOR 
SELECT a.id
FROM ProductCatalog a
WHERE a.CategoryID = @pCategoryID
ORDER BY a.ID

OPEN sKU_cursor

FETCH NEXT FROM SKU_cursor INTO @SKU

WHILE @@FETCH_STATUS = 0
BEGIN

    
    insert into @temtable 
    SELECT  * FROM Inventory.dbo.fn_Bin_Excess_Inventory( @SKU, @pDateStart, @pDateEnd);
    
    FETCH NEXT FROM SKU_cursor INTO @SKU
END

CLOSE SKU_cursor;
DEALLOCATE SKU_cursor;
    
SELECT * FROM @temtable;


END
go

