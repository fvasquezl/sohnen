
-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <12-3-2014>
-- Description:	<Generate Quotation Sheet>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Email_QuotationSheet]
@pCategory NVARCHAR(MAX), @pSupplierID NVARCHAR(MAX), @pEmail NVARCHAR(MAX)
AS
BEGIN


DECLARE @sql NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
DECLARE @categoryname NVARCHAR(MAX)
DECLARE @suppliername NVARCHAR(MAX)
DECLARE @filename NVARCHAR(MAX)
DECLARE @subtext VARCHAR(50)
DECLARE @subject VARCHAR(62)
DECLARE @recipients VARCHAR(255)

SET @categoryname = (Select Top(1) Name FROM Inventory.dbo.Categories WHERE ID = @pCategory)
SET @suppliername = Replace(Replace(RTRIM(LTRIM((Select Top(1) SupplierName FROM Inventory.dbo.SupplierInfo WHERE SupplierId = @pSupplierID))),',',' '),' ','-')


SET @sql = 'SELECT [PC].[ID] AS ''sep=,' + CHAR(13) + CHAR(10) + 'MITSKU''
      ,CASE WHEN '+@pCategory+' IN (''59'',''60'') THEN REPLACE(REPLACE(PC.[Name],'' by Moldgate'',''''),'' by MI Technologies, Inc.'','''')
	  WHEN '+@pCategory+' IN (''24'') THEN LEFT(PC.[Name], CHARINDEX(''(Compatible)'',PC.[Name])+11)
	   ELSE PC.[Name] END AS ''Item''
	  ,''0.00'' AS ''OfferPrice''
	  ,''-'' AS ''DeliveryTime''
	  ,''-'' AS ''SupplierPN''
      ,Replace(CAT.[Name],'','','' '') AS ''Category''
	  ,SI.SupplierName AS ''Supplier''
	  ,Cast(IsNull(SUP.UnitCost,''0.00'') AS money) AS ''PreviousQuote''
	  ,IsNull(SUP.DeliveryTimeDays,''-'') AS ''PreviousDeliveryTime''
	  ,IsNull(SUP.SupplierSKU,''-'') AS ''PreviousSupplierPN''
  FROM [Inventory].[dbo].[ProductCatalog] AS PC
  LEFT OUTER JOIN [Inventory].[dbo].[Categories] AS CAT ON (PC.CategoryID = CAT.ID)
  LEFT OUTER JOIN [Inventory].[dbo].[Suppliers] AS SUP ON (PC.ID = SUP.ProductCatalogID)
  LEFT OUTER JOIN [Inventory].[dbo].[SupplierInfo] AS SI ON (SUP.SupplierID = SI.SupplierID)
  WHERE CategoryID = '+@pCategory+' AND SUP.SupplierID = '+@pSupplierID

SET @subtext = 'Quote - '+@categoryname
SET @filename = 'QuoteSheet-'+@pCategory+'-'+@suppliername+'.csv'
SET @subject = @subtext
SET @recipients = @pEmail
SET @body ='<html><center><H1>Quotation Sheet - <br>' + @categoryname + '</H1><br><br> <body bgcolor=yellow><br><br>Regards,<br>AutoBot by MI Technologies, Inc</body></html>'



If @body is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',
@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML',
@query =  @sql,
@query_attachment_filename = @filename,
@query_result_separator = ',',
@query_result_no_padding = 1,
@attach_query_result_as_file = 1


END

--CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED

IF (EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'Inventory' 
                 AND  TABLE_NAME = 'TempReport'))
BEGIN
	DROP TABLE [Inventory].[dbo].[TempReport]
END
--END CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED

END

go

