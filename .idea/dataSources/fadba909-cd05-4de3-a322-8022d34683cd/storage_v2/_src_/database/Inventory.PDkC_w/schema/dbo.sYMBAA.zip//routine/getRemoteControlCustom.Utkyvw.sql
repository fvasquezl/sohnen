
CREATE FUNCTION [dbo].[getRemoteControlCustom](@ID nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @myString nVarchar(max);
	
	SET @myString = (Select '<STRONG>Batteries: </STRONG>'+cast(CustomField02 as varchar(50))+' '+Cast(CustomField01 as varchar(50))+'<BR><BR><STRONG>Buttons Included:</STRONG> '+cast(CustomField03 as varchar(MAX)) as INFO from Inventory.dbo.productcatalog where ID like @ID)

	RETURN @myString
  
END

go

