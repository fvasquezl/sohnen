-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-05-23
-- Description:	Update Web SKU for Portal Orders
-- =============================================
CREATE PROCEDURE [dbo].[sp_UpdateWebSKUPortal]
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE OD SET OD.WebSKU = OD.Option01
	--SELECT OD.*
	FROM OrderManager.dbo.[Order Details] OD
	INNER JOIN OrderManager.dbo.Orders O
	ON O.OrderNumber = OD.OrderNumber
	WHERE convert(nvarchar,O.OrderDate,112) = CONVERT(NVARCHAR,GETDATE(),112) 
	AND ISNULL(OD.Option01,'') <> ''
	AND OD.WebSKU IS NULL 
	AND OD.Adjustment = 0
	AND O.CustomerID IN (
	SELECT customerid FROM Inventory.dbo.Users WHERE ISNULL(customerid,0) <> 0
	GROUP BY customerid
	)
END
go

