-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Total_Inbounds]
(
	@sku int, @d1 date, @d2 date
)
RETURNS real
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar real;

	SET  @ResultVar = (Select  SUM( b.Quantity)
						FROM Inventory.dbo.InventoryAdjustments a 
							left join Inventory.dbo.InventoryAdjustmentDetails b
								on (a.id = b.InventoryAdjustmentsID)
							WHERE
								 (b.ProductCatalogId = @sku)
								and (a.Date between @d1 and @d2)
								and (flow = 1));
	
	
	IF @resultvar is null
	BEGIN
		SET @ResultVar = 0;
	END;
	
	RETURN @ResultVar

END
go

