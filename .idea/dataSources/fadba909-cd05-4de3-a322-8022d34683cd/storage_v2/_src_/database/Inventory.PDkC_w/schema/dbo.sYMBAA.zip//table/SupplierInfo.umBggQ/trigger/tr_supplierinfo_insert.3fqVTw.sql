-- =============================================
-- Author:		Luis Batista
-- Create date: 05/05/2014
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER tr_supplierinfo_insert
   ON  dbo.SupplierInfo
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here

	DECLARE @lsupllierID int;
	
	
	SET @lsupllierID = (select SupplierID From inserted);
	
	insert into Inventory.dbo.Suppliers(SupplierID, ProductCatalogId, Enabled)
	SELECT  @lsupllierID, a.ID,1 FROM Inventory.dbo.ProductCatalog a;  -- Insert statements for trigger here

END
go

