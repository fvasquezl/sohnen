CREATE VIEW [dbo]._dta_mv_58 WITH SCHEMABINDING AS SELECT  [dbo].[Global_Stocks].[ProductCatalogId] as _col_1,  [dbo].[Global_Stocks].[VirtualStock] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[Global_Stocks]  GROUP BY  [dbo].[Global_Stocks].[ProductCatalogId],  [dbo].[Global_Stocks].[VirtualStock]
go

