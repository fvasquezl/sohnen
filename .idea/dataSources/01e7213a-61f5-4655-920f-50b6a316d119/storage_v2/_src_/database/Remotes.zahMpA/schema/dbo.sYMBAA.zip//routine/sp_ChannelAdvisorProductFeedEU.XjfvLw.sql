-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-8-2018
-- Description:	ChannelAdvisor Product Feed
-- =============================================
CREATE PROCEDURE [dbo].[sp_ChannelAdvisorProductFeedEU-NEW] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
		--SELECT * FROM [Remotes].[dbo].[vw_ChannelAdvisorProductFeedEU] WHERE [Quantity] > 0	AND	([Attribute4Value] LIKE '%REMOTE%'	OR [Attribute4Value] LIKE '%CABLE%')

		DECLARE @selectstatement NVARCHAR(3000)
		DECLARE @cmd NVARCHAR(3000)

		--START SELECT STATEMENT
		SET @selectstatement = 'SELECT * FROM [Remotes].[dbo].[vw_ChannelAdvisorProductFeedEU] WHERE [Quantity] > 0	AND	([Attribute4Value] LIKE ''%REMOTE%''	OR [Attribute4Value] LIKE ''%CABLE%'')'
		--END SELECT STATEMENT

		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\BSQLShares\ChannelAdvisorEU\ca-body.csv" -SBSQL -Usa -PZ91bM473 -c -C ACP -t"," -r"\n"'
		EXEC master..xp_cmdshell @cmd

		EXEC master..xp_cmdshell '"C:\BSQLShares\ChannelAdvisorEU\cafeed.bat"'


END
go

