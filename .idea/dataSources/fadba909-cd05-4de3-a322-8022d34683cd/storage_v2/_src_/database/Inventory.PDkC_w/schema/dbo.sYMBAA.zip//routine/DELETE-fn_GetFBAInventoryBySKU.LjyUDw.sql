-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 9-14-2015
-- Description:	Get FBA Inventory by SKU
-- =============================================
CREATE FUNCTION [dbo].[fn_GetFBAInventoryBySKU] 
(
	-- Add the parameters for the function here
	@pSKU int
)
RETURNS @Result TABLE (FBAQty INT,FBAInboundQty INT, FBAPendingQty INT)
AS
BEGIN
	BEGIN
		INSERT INTO @Result
		SELECT IsNull(SUM(FBAQty),0) AS [FBAQty],
		IsNull(SUM(FBAInboundQty),0) AS [FBAInboundQty],
			(SELECT IsNull(SUM([OrderQty]),0) FROM [Inventory].[dbo].[AmazonFBAOrders] AS AZFBAO  
			LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ ON (AZFBAO.[ASIN] = AZ.[ASIN])
			WHERE AZFBAO.[Completed] = 'No' AND AZ.[CountryCode] = 'US' AND AZ.[ProductCatalogId] = @pSKU)
		FROM [Inventory].[dbo].[AmazonFBA] WHERE [MITSKU] = @pSKU
	
	END 

	RETURN;

END
go

