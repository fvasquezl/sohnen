CREATE VIEW dbo.AmazonFlexActivate
AS
SELECT        AMSKU.DARTFBMSKU + 'FLX' AS sku, AZ.ASIN AS [product-id], '1' AS [product-id-type], '' AS price, '' AS [minimum-seller-allowed-price], '' AS [maximum-seller-allowed-price], '11' AS [item-condition], 
                         (CASE WHEN (PC.[TotalStock] > 1 OR
                         PC.[AlwaysInStock] = 1) AND AZ.[IsActive] = 1 THEN '' WHEN PC.[TotalStock] <= 1 AND AZ.[IsActive] = 1 THEN CAST(PC.[TotalStock] AS INT) WHEN AZ.[IsActive] = 0 THEN 0 ELSE '' END) AS quantity, 
                         (CASE WHEN (PC.[TotalStock] > 1 OR
                         PC.[AlwaysInStock] = 1) AND AZ.[IsActive] = 1 THEN 'a' WHEN PC.[TotalStock] <= 1 THEN 'd' ELSE 'd' END) AS [add-delete], '' AS [will-ship-internationally], '' AS [expedited-shipping], '' AS [standard-plus], '' AS [item-note], 
                         (CASE WHEN (PC.[TotalStock] > 1 OR
                         PC.[AlwaysInStock] = 1) AND AZ.[IsActive] = 1 THEN 'AMAZON_NA' WHEN PC.[TotalStock] <= 1 AND AZ.[IsActive] = 1 THEN '' ELSE '' END) AS [fulfillment-center-id], '' AS [product-tax-code], '' AS [leadtime-to-ship], 
                         (CASE WHEN (PC.[TotalStock] > 1 OR
                         PC.[AlwaysInStock] = 1) AND AZ.[IsActive] = 1 THEN '' WHEN PC.[TotalStock] <= 1 AND AZ.[IsActive] = 1 THEN 'Prime' ELSE 'Prime' END) AS merchant_shipping_group_name, 'No' AS batteries_required, 
                         'No' AS are_batteries_included, 'not_applicable' AS supplier_declared_dg_hz_regulation1
FROM            dbo.Amazon AS AZ WITH (NOLOCK) INNER JOIN
                         dbo.AmazonMerchantSKU AS AMSKU WITH (NOLOCK) ON AZ.ASIN = AMSKU.ASIN INNER JOIN
                         AmazonExclusiveBulbs.dbo.InventoryFBAManage AS IFM WITH (NOLOCK) ON IFM.sku = AMSKU.DARTFBMSKU + 'FLX' LEFT OUTER JOIN
                         dbo.Global_Stocks AS GS WITH (NOLOCK) ON AZ.ProductCatalogId = GS.ProductCatalogId LEFT OUTER JOIN
                         dbo.ProductCatalog AS PC WITH (NOLOCK) ON AZ.ProductCatalogId = PC.ID
WHERE        (AZ.CountryCode = 'US') AND (AZ.FLXActive = 1) AND (AZ.IsActive = 1)
go

