-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-07-17
-- Description:	Get Login Hash
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetLoginHash] 
	@UserName NVARCHAR(100)
AS
BEGIN
	DECLARE @RETURN NVARCHAR(100) = 'Authentication Fail',
			@RPASS	NVARCHAR(20)

	SET NOCOUNT ON;

	UPDATE Remotes.dbo.Account SET HashDate = GETDATE() WHERE Deleted = 0 AND Username = @UserName

	SET @RPASS = ISNULL((SELECT Remotes.dbo.fn_Year_Month_Day(DATEPART(YYYY,A.HashDate),DATEPART(MM,A.HashDate),DATEPART(DD,A.HashDate)) + (SELECT Item FROM Remotes.dbo.fnSplit(A.Id, '-') WHERE ItemId = 1) AS KeyPass 
	FROM Remotes.dbo.Account A WHERE Deleted = 0 AND Username = @UserName),'')
    
	SELECT CONVERT(BIT,(CASE WHEN @RPASS <> '' THEN 1 ELSE 0 END)) AS IsValid, @RPASS AS NewPassword, (CASE WHEN @RPASS <> '' THEN '' ELSE @RETURN END) AS ReturnMessage

END
go

