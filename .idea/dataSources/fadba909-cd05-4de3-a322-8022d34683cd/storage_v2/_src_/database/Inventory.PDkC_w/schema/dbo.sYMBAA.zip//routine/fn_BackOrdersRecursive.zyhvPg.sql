-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-06-30
-- Description:	Get Back Orders Recursive by SKU
-- =============================================
CREATE FUNCTION [dbo].[fn_BackOrdersRecursive]
(
	@SKU INT
)
RETURNS INT
AS
BEGIN
	DECLARE @QtyOrdered INT

	DECLARE @tblAssembly TABLE (SKU INT, SubSKU1 INT, SubSKU2 INT, CategoryID INT, QtyOrdered INT, Seq INT)

	INSERT INTO @tblAssembly (SKU, CategoryID, QtyOrdered, Seq)
	SELECT POD.SKU, PC.CategoryID, SUM(CONVERT(INT,POD.QtyBackOrdered)) AS QtyOrdered, 1
	FROM [Inventory].[dbo].PurchaseOrderData POD (NOLOCK) 
	INNER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
	ON PC.ID = POD.SKU 
	AND ISNULL(PC.CategoryID,0) IN ( 5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,20,21,22,23,64,10,11,12,13,62,24,14 )
	WHERE ISNULL(POD.QtyBackOrdered,0) > 0
	GROUP BY POD.SKU, PC.CategoryID

	INSERT INTO @tblAssembly (SKU, SubSKU1, CategoryID, QtyOrdered, Seq)
	SELECT A.SKU, AD.SubSKU, PC.CategoryID, A.QtyOrdered, 2
	FROM @tblAssembly A
	INNER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
	ON AD.ProductCatalogID = A.SKU
	INNER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
	ON PC.ID = AD.SubSKU
	WHERE A.Seq = 1

	INSERT INTO @tblAssembly (SKU, SubSKU1, SubSKU2, CategoryID, QtyOrdered, Seq)
	SELECT A.SKU, A.SubSKU1, AD.SubSKU, PC.CategoryID, A.QtyOrdered, 3
	FROM @tblAssembly A
	INNER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
	ON AD.ProductCatalogID = A.SubSKU1
	INNER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
	ON PC.ID = AD.SubSKU
	WHERE A.Seq = 2

	SET @QtyOrdered = ISNULL(
		(SELECT SUM(QtyOrdered)
			FROM (
			SELECT SKU, QtyOrdered FROM @tblAssembly
			WHERE SKU = @SKU OR SubSKU1 = @SKU OR SubSKU2 = @SKU
			GROUP BY SKU, QtyOrdered
		) TBL),0)

	RETURN @QtyOrdered

END
go

