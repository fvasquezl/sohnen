-- =============================================
-- Author:		<Luis Alberto Bautista (MI Technologies, Inc.)>
-- Create date: <2011-02-02>
-- Description:	<>
-- =============================================
CREATE FUNCTION [dbo].[fn_StockInLocationAtDate]
(
	@SKU as int, @AccountId as int, @AtDate as varchar(100)
)
RETURNS real
AS
BEGIN
	-- Declare the return variable here
	DECLARE @MyQtty as real
	DECLARE @tins as real
	DECLARE @touts as real
	DECLARE @tintrans real
	DECLARE @toutTrans as real
	

	-- Add the T-SQL statements to compute the return value here
	-- Select all imputs
	SELECT @tins =  sum (b.quantity)
		  FROM InventoryAdjustments a,  InventoryAdjustmentDetails b 
             WHERE ( a.ID = b.InventoryAdjustmentsID )	
             and (Flow = 1)
             AND (a.Origin = @AccountId)
             AND ( b.ProductCatalogID = @sku)  and (a.date <= @Atdate )
            

	SELECT @touts =  sum (b.quantity)
		  FROM InventoryAdjustments a,  InventoryAdjustmentDetails b 
             WHERE ( a.ID = b.InventoryAdjustmentsID )	
             and (Flow = 2)
             AND (a.Origin = @AccountId)
             AND ( b.ProductCatalogID = @sku)  and (a.date <= @Atdate )
            
	

	SELECT @tintrans =  sum (b.quantity)
		  FROM InventoryAdjustments a,  InventoryAdjustmentDetails b 
             WHERE ( a.ID = b.InventoryAdjustmentsID )	
             and (Flow = 3)
             AND (a.Destination = @AccountId)
             AND ( b.ProductCatalogID = @sku)  and (a.date <= @Atdate )
             
             
          SELECT @touttrans =  sum (b.quantity)
		  FROM InventoryAdjustments a,  InventoryAdjustmentDetails b 
             WHERE ( a.ID = b.InventoryAdjustmentsID )	
             and (Flow = 3)
             AND (a.Origin = @AccountId)
             AND ( b.ProductCatalogID = @sku)  and (a.date <= @Atdate )
             
         
	-- Return the result of the function
	SET @MyQtty = @tins + @tintrans - @touts - @toutTrans
	
	if @myQtty is null
	BEGIN
		SET @MyQtty = 0
	END
	
	RETURN @MyQtty

END
go

