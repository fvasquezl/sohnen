-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-14-2018
-- Description:	Get Bin Breakdown by SKU
-- =============================================
CREATE FUNCTION [dbo].[fn_GetBinDetailsBySKU] 
(	
	-- Add the parameters for the function here
	@pSKU nvarchar(10)	 
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT BS.[BinID], BS.[StockQty], BS.[ScanCode] FROM [Remotes].[dbo].[BinStock] AS BS WITH (NOLOCK)
	LEFT OUTER JOIN [Remotes].[dbo].[BinMaster] AS BM WITH(NOLOCK) ON (BS.[BinID] = BM.[BinID])
	WHERE [SKU] = @pSKU AND  BM.[WarehouseID] NOT LIKE '%GY%'
)
go

