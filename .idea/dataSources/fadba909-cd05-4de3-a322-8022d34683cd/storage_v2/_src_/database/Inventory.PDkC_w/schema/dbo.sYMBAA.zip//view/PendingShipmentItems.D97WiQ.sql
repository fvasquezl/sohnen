CREATE VIEW dbo.PendingShipmentItems
AS
SELECT        OD.SKU, OD.Product, ISNULL(ISNULL(dbo.fn_getBinLocation(OD.SKU), dbo.fn_getAssemblyDetails(OD.SKU)), '') AS 'Location', PST.OrderDate, PST.OrderNumber, PST.ShippingMethod, PST.Company, PST.Name, 
                         PST.Cart
FROM            dbo.PendingShipmentsTable AS PST LEFT OUTER JOIN
                         OrderManager.dbo.[Order Details] AS OD ON PST.OrderNumber = OD.OrderNumber
WHERE        (OD.Adjustment = '0')
go

