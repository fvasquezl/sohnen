-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 9-1-2018
-- Description:	MoveToShelf Autobots
-- =============================================
CREATE PROCEDURE [dbo].[sp_MoveToShelfAutobots] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	---DROP EXISTING TABLE
	IF OBJECT_ID('Remotes.dbo.RunRateAnalysis', 'U') IS NOT NULL 
	DROP TABLE [Remotes].[dbo].[RunRateAnalysis]; 

	CREATE TABLE [Remotes].[dbo].[RunRateAnalysis] ([SKU] NVARCHAR(MAX),
	[Manufacturer] NVARCHAR(MAX), [PartNumber] NVARCHAR(MAX), [QtySold] INT, AvgSalesPrices Decimal(10,2), 
	[Qty] INT, [CategoryName] NVARCHAR(MAX), [DaysCalculated] INT, [ShelfQty] INT, [PalletQty] INT)
		
	INSERT INTO [Remotes].[dbo].[RunRateAnalysis]  ([SKU], [Manufacturer], [PartNumber], [QtySold], 
	[AvgSalesPrices], [Qty], [CategoryName])
	EXECUTE [Remotes].[dbo].[sp_GetRunRates] '7','ALL'
	UPDATE [Remotes].[dbo].[RunRateAnalysis] SET [DaysCalculated] = '7' WHERE [DaysCalculated] IS NULL

	INSERT INTO [Remotes].[dbo].[RunRateAnalysis]  ([SKU], [Manufacturer], [PartNumber], [QtySold], 
	[AvgSalesPrices], [Qty], [CategoryName])
	EXECUTE [Remotes].[dbo].[sp_GetRunRates] '30','ALL'
	UPDATE [Remotes].[dbo].[RunRateAnalysis] SET [DaysCalculated] = '30' WHERE [DaysCalculated] IS NULL

	INSERT INTO [Remotes].[dbo].[RunRateAnalysis]  ([SKU], [Manufacturer], [PartNumber], [QtySold], 
	[AvgSalesPrices], [Qty], [CategoryName])
	EXECUTE [Remotes].[dbo].[sp_GetRunRates] '60','ALL'
	UPDATE [Remotes].[dbo].[RunRateAnalysis] SET [DaysCalculated] = '60' WHERE [DaysCalculated] IS NULL

	INSERT INTO [Remotes].[dbo].[RunRateAnalysis]  ([SKU], [Manufacturer], [PartNumber], [QtySold], 
	[AvgSalesPrices], [Qty], [CategoryName])
	EXECUTE [Remotes].[dbo].[sp_GetRunRates] '90','ALL'
	UPDATE [Remotes].[dbo].[RunRateAnalysis] SET [DaysCalculated] = '90' WHERE [DaysCalculated] IS NULL

	INSERT INTO [Remotes].[dbo].[RunRateAnalysis]  ([SKU], [Manufacturer], [PartNumber], [QtySold], 
	[AvgSalesPrices], [Qty], [CategoryName])
	EXECUTE [Remotes].[dbo].[sp_GetRunRates] '9999','ALL'
	UPDATE [Remotes].[dbo].[RunRateAnalysis] SET [DaysCalculated] = '9999' WHERE [DaysCalculated] IS NULL

	--Update Shelf/Pallet Quantities	
	UPDATE RRA SET 
	[ShelfQty] =  	IsNull((SELECT SUM(BS.[StockQty]) FROM [Remotes].[dbo].[BinStock] AS BS
	LEFT OUTER JOIN [Remotes].[dbo].[BinMaster] AS BM ON (BS.[BinID] = BM.[BinID])
	 WHERE BS.[SKU] = LEFT(RRA.[SKU],9) AND BS.[ScanCode] = SUBSTRING(RRA.[SKU], CHARINDEX('-', RRA.[SKU]) + 1, LEN([SKU])) AND BM.[Location] = 'Shelves'),0),
	
	[PalletQty] =  	IsNull((SELECT SUM(BS.[StockQty]) FROM [Remotes].[dbo].[BinStock] AS BS
	LEFT OUTER JOIN [Remotes].[dbo].[BinMaster] AS BM ON (BS.[BinID] = BM.[BinID])
	 WHERE BS.[SKU] = LEFT(RRA.[SKU],9) AND BS.[ScanCode] = SUBSTRING(RRA.[SKU], CHARINDEX('-', RRA.[SKU]) + 1, LEN(RRA.[SKU])) AND BM.[Location] = 'Pallet'),0)

	 FROM [Remotes].[dbo].[RunRateAnalysis] AS RRA

	SELECT * FROM [Remotes].[dbo].[RunRateAnalysis]

	DECLARE @xml NVARCHAR(MAX)
	DECLARE @body NVARCHAR(MAX)
	DECLARE @date VARCHAR(12)
	DECLARE @subtext VARCHAR(50)
	DECLARE @subject VARCHAR(62)
	DECLARE @recipients VARCHAR(255)	
	
	--MOVE TO SHELF
	SET @xml =CAST(( 
	SELECT DISTINCT RR.[SKU] AS 'td',''
		  ,RR.[Manufacturer] AS 'td',''
		  ,RR.[PartNumber] AS 'td',''
		  ,RR9999.[QtySold] AS 'td',''
		  ,RR7.[QtySold] AS 'td',''
		  ,RR.[ShelfQty] AS 'td',''
		  ,RR.[PalletQty] AS 'td',''
		  ,(CASE 
		  WHEN RR.[ShelfQty] < RR7.[QtySold] AND RR.[PalletQty] > 0 AND RR.[PalletQty] > (RR7.[QtySold]-RR.[ShelfQty]) THEN RR7.[QtySold]-RR.[ShelfQty]
		  WHEN RR.[ShelfQty] < RR7.[QtySold] AND RR.[PalletQty] > 0 AND RR.[PalletQty] < (RR7.[QtySold]-RR.[ShelfQty]) THEN RR.[PalletQty]
		  ELSE 0 END) AS 'td'
	  FROM [Remotes].[dbo].[RunRateAnalysis] AS RR
	  LEFT OUTER JOIN [Remotes].[dbo].[RunRateAnalysis] AS RR7 ON (RR.[SKU] = RR7.[SKU] AND RR7.[DaysCalculated] = 7)
	  LEFT OUTER JOIN [Remotes].[dbo].[RunRateAnalysis] AS RR9999 ON (RR.[SKU] = RR9999.[SKU] AND RR9999.[DaysCalculated] = 9999)	   
	  WHERE RR7.[QtySold] > 0
	  AND (CASE 
		  WHEN RR.[ShelfQty] < RR7.[QtySold] AND RR.[PalletQty] > 0 AND RR.[PalletQty] > (RR7.[QtySold]-RR.[ShelfQty]) THEN RR7.[QtySold]-RR.[ShelfQty]
		  WHEN RR.[ShelfQty] < RR7.[QtySold] AND RR.[PalletQty] > 0 AND RR.[PalletQty] < (RR7.[QtySold]-RR.[ShelfQty]) THEN RR.[PalletQty]
		  ELSE 0 END) > 0
	 ORDER BY (CASE 
		  WHEN RR.[ShelfQty] < RR7.[QtySold] AND RR.[PalletQty] > 0 AND RR.[PalletQty] > (RR7.[QtySold]-RR.[ShelfQty]) THEN RR7.[QtySold]-RR.[ShelfQty]
		  WHEN RR.[ShelfQty] < RR7.[QtySold] AND RR.[PalletQty] > 0 AND RR.[PalletQty] < (RR7.[QtySold]-RR.[ShelfQty]) THEN RR.[PalletQty]
		  ELSE 0 END) DESC
	 FOR XML PATH('tr'), ELEMENTS 
	) AS NVARCHAR(MAX))

	SET @subtext = 'Move To Shelf - '
	SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
	SET @subject = @subtext + @date
	SET @recipients = 'inventory@boughts.com'
	SET @body ='<html><center><H1>Move To Shelf - <br>' + @date + '</H1><br><br>Autobot ha detectado inventario que deben de mover desde pallets a shelves para accessor rapido:<br><br><br> <body bgcolor=yellow><table border = 2><tr>
	<th>SKU</th><th>Manufacturer</th><th>PartNumber</th><th>TotalSold</th><th>7DayRunRate</th><th>ShelfQty</th><th>PalletQty</th><th>MoveToShelf</th></tr>' 
	SET @body = @body + @xml +'</center></table><br><br>Regards,<br>AutoBot by MI Technologies, Inc</body></html>'


	If @body is not null BEGIN

	EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',
	@recipients = @recipients,
	@subject = @subject,
	@body = @body,
	@body_format ='HTML'

	END



	---LOW INVENTORY AUTOBOT
	
	SELECT * FROM [Remotes].[dbo].[RunRateAnalysis]
	--NEW ORIGINAL
	SET @xml =CAST(( 
	SELECT RR.[SKU] AS 'td',''
      ,IsNull(RR.[Manufacturer],'N/A') AS 'td',''
      ,IsNull(RR.[PartNumber],'N/A') AS 'td',''
	  ,RR.[QtySold] AS 'td',''
      ,[dbo].[fn_GetQtyByScanCode](LEFT(RR.[SKU],9),REPLACE(REPLACE(RIGHT(RR.[SKU],3),'-',''),'SED','USED'))  AS 'td',''
	  ,CAST((CAST(RR.[QtySold] AS decimal(10,2))/7) AS decimal(10,2))  AS 'td',''
	  ,CAST((CASE WHEN CAST((CAST(RR.[QtySold] AS decimal(10,2))/7) AS decimal(10,2)) = 0 THEN 0
	  ELSE ([dbo].[fn_GetQtyByScanCode](LEFT(RR.[SKU],9),REPLACE(REPLACE(RIGHT(RR.[SKU],3),'-',''),'SED','USED'))/CAST((CAST(RR.[QtySold] AS decimal(10,2))/7) AS decimal(10,2))) END) AS decimal(10,2))  AS 'td'
  FROM [Remotes].[dbo].[RunRateAnalysis] AS RR
  WHERE RR.[QtySold] > 0
  AND RR.[DaysCalculated] = 7
  AND ((CASE WHEN CAST((CAST(RR.[QtySold] AS decimal(10,2))/7) AS decimal(10,2)) = 0 THEN 0
	  ELSE ([dbo].[fn_GetQtyByScanCode](LEFT(RR.[SKU],9),REPLACE(REPLACE(RIGHT(RR.[SKU],3),'-',''),'SED','USED'))/CAST((CAST(RR.[QtySold] AS decimal(10,2))/7) AS decimal(10,2))) END) < 10)

	 FOR XML PATH('tr'), ELEMENTS 
	) AS NVARCHAR(MAX))

	SET @subtext = 'Low Quantity Alert '
	SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
	SET @subject = @subtext + @date
	SET @recipients = 'inventory@boughts.com'
	SET @body ='<html><center><H1>Low Quantity Alert <br>' + @date + '</H1><br><br>Autobot ha detectado inventario con bajo stock:<br><br><br> <body bgcolor=yellow><table border = 2><tr>
	<th>SKU</th>
	<th>Manufacturer</th>
	<th>PartNumber</th>
	<th>7DayRunRate</th>
	<th>QtyInStock</th>
	<th>DailyRunRate</th>
	<th>DaysInv</th>
	</tr>' 
	SET @body = @body + @xml +'</center></table><br><br>Regards,<br>AutoBot by MI Technologies, Inc</body></html>'


	If @body is not null BEGIN

	EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',
	@recipients = @recipients,
	@subject = @subject,
	@body = @body,
	@body_format ='HTML'

	END



END
go

