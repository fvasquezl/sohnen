-- =============================================
-- Author:		Luis Alberto Bautista Gallardo for MI Technologies, Inc.
-- Create date: NOV-17-2010
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_IsValidUserName]
(
	-- Add the parameters for the function here
	@UserName as varchar(50), @FunctionID as int
)
RETURNS bit	--Equals to Boolean
AS
BEGIN
	-- Declare the return variable here
	DECLARE @myValidUSer as BIT
	DECLARE @myGroupID as INT

	SET @MyValidUser = 0
	SET @myGroupID = 0
	
	-- Add the T-SQL statements to compute the return value here
	SELECT @MyGroupID =  a.GroupID from Inventory.dbo.Users a
	where a.USR = @UserName

	SELECT @MyValidUser = permission FROM Inventory.dbo.GroupPermissions t
	WHERE ( t.GroupID = @MyGroupID )  AND ( t.FunctionID = @FunctionID )
	
	-- Return the result of the function
	--RETURN @myValidUser
	RETURN @myGroupID
	
END
go

