
-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <1-1-2015>
-- Description:	<Generate Inventory Analizer Report>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Email_InventoryAnalizer]
@pCategory NVARCHAR(MAX), @pTargetQOHinDays INT, @pEmail NVARCHAR(MAX)
AS
BEGIN


DECLARE @sql NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
DECLARE @categoryname NVARCHAR(MAX)
DECLARE @suppliername NVARCHAR(MAX)
DECLARE @filename NVARCHAR(MAX)
DECLARE @subtext VARCHAR(50)
DECLARE @subject VARCHAR(62)
DECLARE @recipients VARCHAR(255)


SET @categoryname = (Select Top(1) Name FROM Inventory.dbo.Categories WHERE ID = @pCategory)

SET @sql = 'SELECT OD.[SKU] AS ''sep=,' + CHAR(13) + CHAR(10) + 'MITSKU''
      ,PC.Name AS ''Description''
	  
	  ,IsNull((SELECT SUM(OD2A.[QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] AS OD2A LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2A ON (OD2A.OrderNumber = O2A.OrderNumber)  where OD2A.Adjustment = 0 AND (OD2A.SKU = OD.SKU)  AND Cast(O2A.OrderDate as date) between (GetDate()-15) AND GetDate()), 0) As ''Last 15 Days''
	  ,IsNull((SELECT Cast(SUM(OD2B.[PricePerUnit]*OD2B.[QuantityOrdered])/SUM(OD2B.QuantityOrdered) as decimal(10,2))  FROM [OrderManager].[dbo].[Order Details] AS OD2B LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2B ON (OD2B.OrderNumber = O2B.OrderNumber) where OD2B.Adjustment = 0 AND (OD2B.SKU = OD.SKU) AND Cast(O2B.OrderDate as date) between (GetDate()-15) AND GetDate()), 0) AS ''AvgPrice 15 Days''

	  ,IsNull((SELECT SUM(OD2C.[QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] AS OD2C LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2C ON (OD2C.OrderNumber = O2C.OrderNumber)  where OD2C.Adjustment = 0 AND (OD2C.SKU = OD.SKU)  AND Cast(O2C.OrderDate as date) between (GetDate()-30) AND GetDate()), 0) As ''Last 30 Days''
	  ,IsNull((SELECT Cast(SUM(OD2D.[PricePerUnit]*OD2D.[QuantityOrdered])/SUM(OD2D.QuantityOrdered) as decimal(10,2))  FROM [OrderManager].[dbo].[Order Details] AS OD2D LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2D ON (OD2D.OrderNumber = O2D.OrderNumber) where OD2D.Adjustment = 0 AND (OD2D.SKU = OD.SKU) AND Cast(O2D.OrderDate as date) between (GetDate()-30) AND GetDate()), 0) AS ''AvgPrice 30 Days''

	  ,IsNull((SELECT SUM(OD2E.[QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] AS OD2E LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2E ON (OD2E.OrderNumber = O2E.OrderNumber)  where OD2E.Adjustment = 0 AND (OD2E.SKU = OD.SKU)  AND Cast(O2E.OrderDate as date) between (GetDate()-60) AND GetDate()), 0) As ''Last 60 Days''
	  ,IsNull((SELECT Cast(SUM(OD2F.[PricePerUnit]*OD2F.[QuantityOrdered])/SUM(OD2F.QuantityOrdered) as decimal(10,2))  FROM [OrderManager].[dbo].[Order Details] AS OD2F LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2F ON (OD2F.OrderNumber = O2F.OrderNumber) where OD2F.Adjustment = 0 AND (OD2F.SKU = OD.SKU) AND Cast(O2F.OrderDate as date) between (GetDate()-60) AND GetDate()), 0) AS ''AvgPrice 60 Days''

	  ,IsNull((SELECT SUM(OD2G.[QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] AS OD2G LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2G ON (OD2G.OrderNumber = O2G.OrderNumber)  where OD2G.Adjustment = 0 AND (OD2G.SKU = OD.SKU)  AND Cast(O2G.OrderDate as date) between (GetDate()-90) AND GetDate()), 0) As ''Last 90 Days''
	  ,IsNull((SELECT Cast(SUM(OD2H.[PricePerUnit]*OD2H.[QuantityOrdered])/SUM(OD2H.QuantityOrdered) as decimal(10,2))  FROM [OrderManager].[dbo].[Order Details] AS OD2H LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2H ON (OD2H.OrderNumber = O2H.OrderNumber) where OD2H.Adjustment = 0 AND (OD2H.SKU = OD.SKU) AND Cast(O2H.OrderDate as date) between (GetDate()-90) AND GetDate()), 0) AS ''AvgPrice 90 Days''
	  
	  ,IsNull((SELECT SUM(OD2K.[QuantityOrdered]) FROM [OrderManager].[dbo].[Order Details] AS OD2K LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2K ON (OD2K.OrderNumber = O2K.OrderNumber)  where OD2K.Adjustment = 0 AND (OD2K.SKU = OD.SKU)  AND Cast(O2K.OrderDate as date) between (GetDate()-180) AND GetDate()), 0) As ''Last 180 Days''
	  ,IsNull((SELECT Cast(SUM(OD2L.[PricePerUnit]*OD2L.[QuantityOrdered])/SUM(OD2L.QuantityOrdered) as decimal(10,2))  FROM [OrderManager].[dbo].[Order Details] AS OD2L LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2L ON (OD2L.OrderNumber = O2L.OrderNumber) where OD2L.Adjustment = 0 AND (OD2L.SKU = OD.SKU) AND Cast(O2L.OrderDate as date) between (GetDate()-180) AND GetDate()), 0) AS ''AvgPrice 180 Days''

	  ,Cast(GS.GlobalStock as int) AS ''QOH''
	  ,Cast(GS.VirtualStock as int) AS ''vQOH''
	  ,Cast(GS.TotalStock as int) AS ''tQOH''

	  ,Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AA LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-15) AND GetDate()), 0) / 15) * 45) as Decimal(10,1)) AS ''RecomendedQOHBasedOn15Days''
	  ,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AA LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-15) AND GetDate()), 0) / 15) * 45) as Decimal(10,1))) AS ''15DayShortOrOver''

	  ,Cast(((IsNull((SELECT Cast(SUM(OD2AB.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AB LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AB ON (OD2AB.OrderNumber = O2AB.OrderNumber)  where OD2AB.Adjustment = 0 AND (OD2AB.SKU = OD.SKU)  AND Cast(O2AB.OrderDate as date) between (GetDate()-30) AND GetDate()), 0) / 30) * 45) as Decimal(10,1)) AS ''RecomendedQOHBasedOn30Days''
	  ,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AA LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-30) AND GetDate()), 0) / 30) * 45) as Decimal(10,1))) AS ''30DayShortOrOver''
	  
	  ,Cast(((IsNull((SELECT Cast(SUM(OD2AC.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AC LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AC ON (OD2AC.OrderNumber = O2AC.OrderNumber)  where OD2AC.Adjustment = 0 AND (OD2AC.SKU = OD.SKU)  AND Cast(O2AC.OrderDate as date) between (GetDate()-60) AND GetDate()), 0) / 60) * 45) as Decimal(10,1)) AS ''RecomendedQOHBasedOn60Days''
	  ,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AA LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-60) AND GetDate()), 0) / 60) * 45) as Decimal(10,1))) AS ''60DayShortOrOver''
	  
	  
	  ,Cast(((IsNull((SELECT Cast(SUM(OD2AD.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AD LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AD ON (OD2AD.OrderNumber = O2AD.OrderNumber)  where OD2AD.Adjustment = 0 AND (OD2AD.SKU = OD.SKU)  AND Cast(O2AD.OrderDate as date) between (GetDate()-90) AND GetDate()), 0) / 90) * 45) as Decimal(10,1)) AS ''RecomendedQOHBasedOn90Days''
	  ,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AA LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-90) AND GetDate()), 0) / 90) * 45) as Decimal(10,1))) AS ''90DayShortOrOver''
	  
	  
	  ,Cast(((IsNull((SELECT Cast(SUM(OD2AD.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AD LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AD ON (OD2AD.OrderNumber = O2AD.OrderNumber)  where OD2AD.Adjustment = 0 AND (OD2AD.SKU = OD.SKU)  AND Cast(O2AD.OrderDate as date) between (GetDate()-180) AND GetDate()), 0) / 180) * 45) as Decimal(10,1)) AS ''RecomendedQOHBasedOn180Days''
	  ,(Cast(GS.GlobalStock as int) - Cast(((IsNull((SELECT Cast(SUM(OD2AA.[QuantityOrdered]) AS Decimal(10,3)) FROM [OrderManager].[dbo].[Order Details] AS OD2AA LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O2AA ON (OD2AA.OrderNumber = O2AA.OrderNumber)  where OD2AA.Adjustment = 0 AND (OD2AA.SKU = OD.SKU)  AND Cast(O2AA.OrderDate as date) between (GetDate()-180) AND GetDate()), 0) / 180) * 45) as Decimal(10,1))) AS ''180DayShortOrOver''

  FROM [OrderManager].[dbo].[Order Details] AS OD
  LEFT OUTER JOIN [Inventory].dbo.[ProductCatalog] AS PC ON (OD.SKU = Cast(PC.ID AS NVARCHAR(MAX)))
  LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PC.ID = GS.ProductCatalogId)
  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O ON (OD.OrderNumber = O.OrderNumber)
  where OD.Adjustment = 0 AND PC.CategoryID IN ('+@pCategory+')
  group by OD.[SKU]
      ,PC.Name
	  ,GS.GlobalStock
	  ,GS.VirtualStock
	  ,GS.TotalStock'



SET @subtext = 'Inventory Analizer - '+@categoryname
SET @filename = 'InvAnalizer-'+@pCategory+'.csv'
SET @subject = @subtext
SET @recipients = @pEmail
SET @body ='<html><center><H1>Inventory Analizer Report - <br>' + @categoryname + '</H1><br><br> <body bgcolor=yellow><br><br>Regards,<br>AutoBot by MI Technologies, Inc</body></html>'


If @body is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',
@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML',
@query =  @sql,
@query_attachment_filename = @filename,
@query_result_separator = ',',
@query_result_no_padding = 1,
@attach_query_result_as_file = 1


END

--CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED

IF (EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'Inventory' 
                 AND  TABLE_NAME = 'TempReport'))
BEGIN
	DROP TABLE [Inventory].[dbo].[TempReport]
END
--END CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED

END

go

