CREATE VIEW [dbo]._dta_mv_24   AS SELECT  [dbo].[ProductCatalog].[ID] as _col_1,  count_big(*) as _col_2 FROM  [dbo].[ProductCatalog],  [dbo].[Global_Stocks]   WHERE  [dbo].[ProductCatalog].[ID] = [dbo].[Global_Stocks].[ProductCatalogId]  GROUP BY  [dbo].[ProductCatalog].[ID]
go

