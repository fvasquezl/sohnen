-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-10-23
-- Description:	Get Real Stock by SKU and Date
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_RealStockbyDate]
(
	@DATE1	NVARCHAR(8),
	@DATE2	NVARCHAR(8),
	@SKU	INT,
	@DRRate	INT
)
RETURNS INT
AS
BEGIN
	DECLARE @STOCK_DAYS INT

	SET @STOCK_DAYS = ISNULL((
	SELECT SUM(CASE WHEN (ISNULL(Global_Stock,0) + ISNULL(Virtual_Stock,0)) > @DRRate THEN 1 ELSE 0 END) AS STOCK_DAYS
	FROM Inventory.dbo.BinMovement (NOLOCK)
	WHERE SKU = @SKU AND CONVERT(NVARCHAR,Activity_Date,112) BETWEEN @DATE1 AND @DATE2
	GROUP BY SKU
	),0)
	
	RETURN @STOCK_DAYS

END
go

