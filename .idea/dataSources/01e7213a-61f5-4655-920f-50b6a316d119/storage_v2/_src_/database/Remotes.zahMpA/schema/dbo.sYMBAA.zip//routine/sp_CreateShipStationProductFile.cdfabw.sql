-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-6-2017
-- Description:	Create Shipstation Product File
-- =============================================
CREATE PROCEDURE sp_CreateShipStationProductFile 

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT SKUD.[SKU] AS [SKU]
		  ,SKUD.[Manufacturer]+' '+SKUD.[PartNumber] AS [Name]
		  ,'MexicoWarehouse' AS [WarehouseLocation]
		  ,'4' AS [WeightOz]
		  ,'Remotes' AS [Category]
		  ,'' AS [Tag1]
		  ,'' AS [Tag2]
		  ,'' AS [Tag3]
		  ,'' AS [Tag4]
		  ,'' AS [Tag5]
		  ,'Remote Control' AS [CustomsDescription]
		  ,'9.95' AS [CustomsValue]
		  ,'' AS [CustomsTarrifNo]
		  ,'US' AS [CustomsCountry]
		  ,'' AS [ThumbnailURL]
		  ,'' AS [UPC]
		  ,'' AS [FillSKU]
		  ,'6' AS [Length]
		  ,'4' AS [Width]
		  ,'1' AS [Height]
		  ,'' AS [UseProductName]
		  ,'TRUE' AS [Active]
		  ,'' AS [ParentSKU]
	  FROM [Remotes].[dbo].[SKUData] AS SKUD

	  UNION ALL

	  SELECT SKUD.[SKU]+'-CN' AS [SKU]
		  ,SKUD.[Manufacturer]+' '+SKUD.[PartNumber] AS [Name]
		  ,'MexicoWarehouse' AS [WarehouseLocation]
		  ,'4' AS [WeightOz]
		  ,'Remotes' AS [Category]
		  ,'' AS [Tag1]
		  ,'' AS [Tag2]
		  ,'' AS [Tag3]
		  ,'' AS [Tag4]
		  ,'' AS [Tag5]
		  ,'Remote Control' AS [CustomsDescription]
		  ,'9.95' AS [CustomsValue]
		  ,'' AS [CustomsTarrifNo]
		  ,'US' AS [CustomsCountry]
		  ,'' AS [ThumbnailURL]
		  ,'' AS [UPC]
		  ,'' AS [FillSKU]
		  ,'6' AS [Length]
		  ,'4' AS [Width]
		  ,'1' AS [Height]
		  ,'' AS [UseProductName]
		  ,'TRUE' AS [Active]
		  ,'' AS [ParentSKU]
	  FROM [Remotes].[dbo].[SKUData] AS SKUD
	  WHERE SKUD.[Manufacturer] IS NOT NULL OR SKUD.[Manufacturer] != ''

END
go

