-- =============================================
-- Update by:	Eduardo Gutierrez
-- Create date: 2018-12-19
-- Description:	Get VirtStock by Bulbs Category
-- =============================================
CREATE PROCEDURE [dbo].[sp_Update_VirtStock_Bulbs]
AS 
BEGIN
Declare @MITSKU	       AS Varchar(10)
Declare @VirtualStock  AS INT
Declare @QOH  AS INT

SET @VirtualStock = 0

DECLARE GetItemsInCategory_cursor CURSOR
FOR
--Select all of the projector lamps SKUs
--RPTV Bare Lamp Categories:  '5','6','7','8','9','61'
--FP Bare Lamp Categories:  '15','16','17','18','19','63
--STAGE Bare Lamp Categories:  '88','89','90','91'

SELECT ID FROM Inventory.dbo.ProductCatalog WITH(NOLOCK) WHERE CategoryID IN (
--RPTV Bare Lamps
'5','6','7','8','9','61',
--FP Bare Lamps
'15','16','17','18','19','63',
--STAGE Bare Lamps
'88','89','90','91'
)


OPEN GetItemsInCategory_cursor
FETCH NEXT FROM GetItemsInCategory_cursor INTO @MITSKU

WHILE @@FETCH_STATUS = 0
BEGIN
	/* Last Code
			-- Query to check seperable quantity for this SKU in cursor
			SELECT @VirtualStock =  SUM(GS.GlobalStock) FROM [Inventory].[dbo].[Global_Stocks] AS GS
			INNER JOIN [Inventory].[dbo].[AssemblyDetails] AS AD ON (GS.ProductCatalogID = AD.ProductCatalogId)	
			WHERE AD.SubSKU = @MITSKU  --AND AD3.IsRequired = '1'
	*/
	
	--Update by Assembly
	SET @VirtualStock = ISNULL((
		SELECT SUM(BC.Counter)
		FROM [Inventory].[dbo].[AssemblyDetails] AS AD WITH(NOLOCK)
		INNER JOIN Inventory.dbo.Bin_Content BC WITH(NOLOCK)
		ON BC.ProductCatalog_Id = AD.ProductCatalogID AND Inventory.dbo.fn_Get_Bin_WarehouseID(BC.Bin_Id) <> 'DF' 
		WHERE AD.SubSKU = @MITSKU
	),0)

	--SET @VirtualStock = ISNULL(@VirtualStock,0) + ISNULL((
	--	SELECT MIN(R.QtyStock)
	--	FROM (
	--		SELECT T.SubSKU, CONVERT(INT,(T.Counter / T.SubSKUQTYRequired)) AS QtyStock
	--		FROM (
	--			SELECT AD.SubSKU, AD.SubSKUQTYRequired, SUM(ISNULL(BC.Counter,0)) AS Counter
	--			FROM [Inventory].[dbo].[AssemblyDetails] AS AD WITH(NOLOCK)
	--			LEFT OUTER JOIN Inventory.dbo.Bin_Content BC WITH(NOLOCK)
	--			ON BC.ProductCatalog_Id = AD.SubSKU AND Inventory.dbo.fn_Get_Bin_WarehouseID(BC.Bin_Id) <> 'DF' 
	--			WHERE AD.ProductCatalogID = @MITSKU
	--			GROUP BY AD.SubSKU, AD.SubSKUQTYRequired
	--		) T
	--	) R
	--),0)

	SET @VirtualStock = ISNULL(@VirtualStock,0) + ISNULL((
		SELECT MIN(R.QtyStock)
		FROM (
			SELECT U.SubSKU, SUM(U.QtyStock) AS QtyStock
			FROM (
				SELECT T.SubSKU, CONVERT(INT,(T.Counter / T.SubSKUQTYRequired)) AS QtyStock
				FROM (
					SELECT AD1.ProductCatalogID AS SubSKU, AD1.SubSKUQTYRequired, SUM(ISNULL(BC.Counter,0)) AS Counter
					FROM [Inventory].[dbo].[AssemblyDetails] AS AD1 WITH(NOLOCK)
					LEFT OUTER JOIN Inventory.dbo.Bin_Content BC WITH(NOLOCK)
					ON BC.ProductCatalog_Id = AD1.SubSKU AND Inventory.dbo.fn_Get_Bin_WarehouseID(BC.Bin_Id) <> 'DF' 
					WHERE AD1.ProductCatalogID IN (
						SELECT AD.SubSKU
						FROM [Inventory].[dbo].[AssemblyDetails] AS AD WITH(NOLOCK)
						WHERE AD.ProductCatalogID = @MITSKU
					)
					GROUP BY AD1.ProductCatalogID, AD1.SubSKUQTYRequired
				) T
				UNION ALL		
				SELECT T.SubSKU, CONVERT(INT,(T.Counter / T.SubSKUQTYRequired)) AS QtyStock
				FROM (
					SELECT AD.SubSKU, AD.SubSKUQTYRequired, SUM(ISNULL(BC.Counter,0)) AS Counter
					FROM [Inventory].[dbo].[AssemblyDetails] AS AD WITH(NOLOCK)
					LEFT OUTER JOIN Inventory.dbo.Bin_Content BC WITH(NOLOCK)
					ON BC.ProductCatalog_Id = AD.SubSKU AND Inventory.dbo.fn_Get_Bin_WarehouseID(BC.Bin_Id) <> 'DF' 
					WHERE AD.ProductCatalogID = @MITSKU
					GROUP BY AD.SubSKU, AD.SubSKUQTYRequired
				) T
			) U
			GROUP BY U.SubSKU
		) R
	),0)

	UPDATE Inventory.dbo.Global_Stocks WITH(UPDLOCK) SET VirtualStock = ISNULL(@VirtualStock,0) WHERE ProductCatalogId = @MITSKU

	PRINT @MITSKU
	PRINT @VirtualStock

	SET @VirtualStock = 0


FETCH NEXT FROM GetItemsInCategory_cursor INTO @MITSKU

END

CLOSE GetItemsInCategory_cursor
DEALLOCATE GetItemsInCategory_cursor

END

go

