-- =============================================
-- Author:		MI Technologies, Inc.
-- Create date: 11/11/2010
-- Description:	Adds a new user group an update the relationships with other tables
-- =============================================
CREATE PROCEDURE [dbo].[sp_Add_New_UsersGroup]
	-- Add the parameters for the stored procedure here
	@GroupName as varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	----Insert into groups table
	INSERT INTO Groups (name) values (@GroupName) ;
	---- Get GroupId
	declare @ThisId as int
	SELECT @ThisId=SCOPE_IDENTITY() FROM inventory.dbo.Groups;
	--- insert into UserPermission table
	insert into GroupPermissions (id, GroupID, FunctionID, ParentID, Permission, FunctionName) 
				SELECT id, @ThisId, FunctionID, ParentID, 0, FunctionName FROM PermissionsPattern
	
END
go

