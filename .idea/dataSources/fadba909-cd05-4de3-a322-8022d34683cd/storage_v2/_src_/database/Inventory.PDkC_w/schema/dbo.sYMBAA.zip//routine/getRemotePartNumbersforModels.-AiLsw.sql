


CREATE FUNCTION [dbo].[getRemotePartNumbersforModels](@Model nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @myString nVarchar(max);
	DECLARE @RemotePN nVarchar(max);
	
	SET @myString = '';
	DECLARE model_cursor CURSOR 
	FOR 
	SELECT PartNumber FROM [Inventory].[dbo].[CompatibilityDetails] cd where cd.Model = @Model;
	
	OPEN model_cursor; 
	FETCH NEXT FROM model_cursor INTO @RemotePN;
	
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		SET @myString = @myString + @RemotePN + ', '
		
	FETCH NEXT FROM model_cursor INTO @RemotePN;
	END
	
	CLOSE model_cursor 
	DEALLOCATE model_cursor 
	
	IF @myString  <> '' 
	BEGIN
		SET @myString = LEFT(@myString, LEN(@myString)-1 )
	End
	
	
  RETURN @myString
  
END



go

