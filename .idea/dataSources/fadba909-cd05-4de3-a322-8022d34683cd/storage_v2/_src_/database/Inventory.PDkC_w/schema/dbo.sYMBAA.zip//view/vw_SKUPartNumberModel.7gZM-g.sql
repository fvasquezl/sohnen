CREATE VIEW dbo.vw_SKUPartNumberModel
AS
WITH PNModelsCTE AS (SELECT DISTINCT cm.Manufacturer, cm.PartNumber, cmd.Model
                                                      FROM            dbo.Compatibility AS cm LEFT OUTER JOIN
                                                                               dbo.CompatibilityDetails AS cmd ON cm.PartNumber = cmd.PartNumber AND cm.Manufacturer = cmd.OriginalManufacturer
                                                      WHERE        (cm.ProductCatalogID IN
                                                                                   (SELECT        pc.ID
                                                                                     FROM            dbo.ProductCatalog AS pc LEFT OUTER JOIN
                                                                                                               dbo.Categories AS ctg ON pc.CategoryID = ctg.ID
                                                                                     WHERE        (ctg.ParentID IN ('1', '2', '3', '4')))) AND (cm.PartNumber NOT LIKE '%SML')
                                                      UNION ALL
                                                      SELECT DISTINCT cm.Manufacturer, cm.PartNumber, cma.AlternativePN AS Model
                                                      FROM            dbo.Compatibility AS cm LEFT OUTER JOIN
                                                                               dbo.CompatibilityAlternativePN AS cma ON cm.PartNumber = cma.PartNumber AND cm.Manufacturer = cma.OriginalManufacturer
                                                      WHERE        (cm.ProductCatalogID IN
                                                                                   (SELECT        pc.ID
                                                                                     FROM            dbo.ProductCatalog AS pc LEFT OUTER JOIN
                                                                                                               dbo.Categories AS ctg ON pc.CategoryID = ctg.ID
                                                                                     WHERE        (ctg.ParentID IN ('1', '2', '3', '4')))) AND (cm.PartNumber NOT LIKE '%SML'))
    SELECT        Manufacturer, PartNumber, Model,
                                  (SELECT        TOP (1) tb1.ProductCatalogID
                                    FROM            dbo.Compatibility AS tb1 LEFT OUTER JOIN
                                                              dbo.ProductCatalog AS tb2 ON tb1.ProductCatalogID = tb2.ID
                                    WHERE        (tb1.Manufacturer = cm.Manufacturer) AND (tb1.PartNumber = cm.PartNumber) AND (tb2.CategoryID IN ('5', '6', '7', '8', '15', '16', '17', '18'))
                                    ORDER BY tb2.CategoryID) AS OEMBare,
                                  (SELECT        TOP (1) tb1.ProductCatalogID
                                    FROM            dbo.Compatibility AS tb1 LEFT OUTER JOIN
                                                              dbo.ProductCatalog AS tb2 ON tb1.ProductCatalogID = tb2.ID
                                    WHERE        (tb1.Manufacturer = cm.Manufacturer) AND (tb1.PartNumber = cm.PartNumber) AND (tb2.CategoryID IN ('61', '63'))
                                    ORDER BY tb2.CategoryID) AS OEMBoxBare,
                                  (SELECT        TOP (1) tb1.ProductCatalogID
                                    FROM            dbo.Compatibility AS tb1 LEFT OUTER JOIN
                                                              dbo.ProductCatalog AS tb2 ON tb1.ProductCatalogID = tb2.ID
                                    WHERE        (tb1.Manufacturer = cm.Manufacturer) AND (tb1.PartNumber = cm.PartNumber) AND (tb2.CategoryID IN ('9', '19'))) AS GenericBare,
                                  (SELECT        TOP (1) tb1.ProductCatalogID
                                    FROM            dbo.Compatibility AS tb1 LEFT OUTER JOIN
                                                              dbo.ProductCatalog AS tb2 ON tb1.ProductCatalogID = tb2.ID
                                    WHERE        (tb1.Manufacturer = cm.Manufacturer) AND (tb1.PartNumber = cm.PartNumber) AND (tb2.CategoryID IN ('10', '11', '12', '13', '20', '21', '22', '23'))
                                    ORDER BY tb2.CategoryID) AS OEMHousing,
                                  (SELECT        TOP (1) tb1.ProductCatalogID
                                    FROM            dbo.Compatibility AS tb1 LEFT OUTER JOIN
                                                              dbo.ProductCatalog AS tb2 ON tb1.ProductCatalogID = tb2.ID
                                    WHERE        (tb1.Manufacturer = cm.Manufacturer) AND (tb1.PartNumber = cm.PartNumber) AND (tb2.CategoryID IN ('62', '64'))
                                    ORDER BY tb2.CategoryID) AS OEMBoxHousing,
                                  (SELECT        TOP (1) tb1.ProductCatalogID
                                    FROM            dbo.Compatibility AS tb1 LEFT OUTER JOIN
                                                              dbo.ProductCatalog AS tb2 ON tb1.ProductCatalogID = tb2.ID
                                    WHERE        (tb1.Manufacturer = cm.Manufacturer) AND (tb1.PartNumber = cm.PartNumber) AND (tb2.CategoryID IN ('14', '24'))) AS GenericHousing
     FROM            PNModelsCTE AS cm
go

