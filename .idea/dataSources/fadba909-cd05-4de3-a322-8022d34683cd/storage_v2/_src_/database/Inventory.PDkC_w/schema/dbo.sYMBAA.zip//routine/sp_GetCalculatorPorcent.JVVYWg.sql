-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetCalculatorPorcent]
	-- Add the parameters for the stored procedure here
	@platform NVARCHAR(20),
	@advertisingtype NVARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;
END
go

