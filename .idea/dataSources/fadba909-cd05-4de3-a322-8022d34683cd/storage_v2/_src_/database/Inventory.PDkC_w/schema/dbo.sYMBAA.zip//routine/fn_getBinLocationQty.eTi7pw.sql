

CREATE FUNCTION [dbo].[fn_getBinLocationQty](@pSKU nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @listStr VARCHAR(MAX)
	DECLARE @returnstring VARCHAR(MAX)
	SELECT @listStr = COALESCE(@listStr+';','') + BM.WarehouseID + ' ' + CONVERT(NVARCHAR,BC.Counter) + ' ' + BC.Bin_Id
	FROM [Inventory].[dbo].[Bin_Content] AS BC 
	LEFT JOIN [Inventory].[dbo].[Bins] BM
	ON BM.Bin_id = BC.Bin_Id
	WHERE BC.ProductCatalog_Id = @pSKU
	
	
	SET @returnstring = @listStr
	

	RETURN @returnstring

END



go

