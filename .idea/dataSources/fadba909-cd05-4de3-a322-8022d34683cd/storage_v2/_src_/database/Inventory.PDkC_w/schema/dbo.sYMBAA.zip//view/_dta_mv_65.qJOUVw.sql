CREATE VIEW [dbo]._dta_mv_65   AS SELECT  [dbo].[AmazonSearchDATA].[ASIN] as _col_1,  [dbo].[AmazonSearchDATA].[CountryCode] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[AmazonSearchDATA]   WHERE  [dbo].[AmazonSearchDATA].[Brand] = N'3M'  GROUP BY  [dbo].[AmazonSearchDATA].[ASIN],  [dbo].[AmazonSearchDATA].[CountryCode]
go

