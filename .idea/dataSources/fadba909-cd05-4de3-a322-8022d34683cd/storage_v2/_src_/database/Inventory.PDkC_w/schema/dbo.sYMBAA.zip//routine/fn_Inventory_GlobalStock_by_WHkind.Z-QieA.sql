-- =============================================
-- Author:		Luis Bautista
-- Create date: Novenber 27, 2013
-- Description: Display all ProductCatalog list and the global stock filter by wharehouse kind or type.
-- =============================================
CREATE FUNCTION [dbo].[fn_Inventory_GlobalStock_by_WHkind]
(	

	@pWarehouseKind varchar(100)
	-- Valid values for param: All | Associated | Own  
)
RETURNS
	@stocks TABLE (ProductCatalogId int
					, ProductCatalogName varchar(255)
					, quantity real)
AS
BEGIN
	

		INSERT INTO @stocks (ProductCatalogId, ProductCatalogName, quantity )
					SELECT a.ID , a.name, Inventory.dbo.fn_Inventory_ItemStock_By_WHKind(a.ID, @pWarehouseKind) 
					FROM ProductCatalog a ORDER BY ID;

	
	
	RETURN
END
go

