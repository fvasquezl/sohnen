
-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <2-16-2015>
-- Description:	<Import CSV Purchase Order History from Quickbooks>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ImportResellerShipStation] 
		@FilePath NVARCHAR(2000), @CustomerID NVARCHAR(20), @CustomerPO NVARCHAR(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[Inventory].[dbo].[ResellerShipstationImport_tmp]') AND type in (N'U'))
DROP TABLE [Inventory].[dbo].[ResellerShipstationImport_tmp]



DECLARE @FileLocation VARCHAR(200);
DECLARE @FirstImportRow VARCHAR(200);

--Set File Location and Starting Row
SET @FileLocation = @FilePath
SET @FirstImportRow = '2';

--Set Variables for CustomerID
	DECLARE @ShipFromName varchar(255);
	DECLARE @ShipFromCompany varchar(255);
	DECLARE @ShipFromAddressLine1 varchar(255);
	DECLARE @ShipFromAddressLine2 varchar(255);
	DECLARE @ShipFromCity varchar(255);
	DECLARE @ShipFromState varchar(255);
	DECLARE @ShipFromZipCode varchar(255);
	DECLARE @ShipFromCountry varchar(255);
	DECLARE @ShipFromPhone varchar(255);
	DECLARE @ShipFromEmail varchar(255);
	DECLARE @countrycode varchar(255);
		
	---Get values from order manager	
    SELECT 
		@ShipFromName = OMC.[FullName]
		, @ShipFromCompany = OMC.[Company]
		, @ShipFromAddressLine1 = OMC.[Address]
		, @ShipFromAddressLine2	 = OMC.[Address2]
		, @ShipFromCity = OMC.[City]
		, @ShipFromState = OMC.[State]
		, @ShipFromZipCode = OMC.[Zip]
		, @ShipFromCountry = OMC.[Country]
		, @ShipFromPhone = OMC.[Phone]
		, @ShipFromEmail = OMC.[Email]
	FROM OrderManager.dbo.Customers AS OMC WHERE OMC.CustomerID = @CustomerID;  
		
	-- Get the country code
	SELECT @countrycode = code from [OrderManager].[dbo].[Countries] 
			WHERE  Country =  @ShipFromCountry;
		-- Set default ShippingMethod




--Create Temp Table
CREATE TABLE [Inventory].[dbo].[ResellerShipstationImport_tmp]
(
[LineID] [int] IDENTITY(1,1) NOT NULL,
[Order - Number] NVARCHAR(MAX),
[Item - Qty] NVARCHAR(MAX),
[Item - SKU] NVARCHAR(MAX),
[Ship To - Name] NVARCHAR(MAX),
[Ship To - Company] NVARCHAR(MAX),
[Ship To - Address 1] NVARCHAR(MAX),
[Ship To - Address 2] NVARCHAR(MAX),
[Ship To - City] NVARCHAR(MAX),
[Ship To - Country] NVARCHAR(MAX),
[Ship To - Phone] NVARCHAR(MAX),
[Ship To - Postal Code] NVARCHAR(MAX),
[Ship To - State] NVARCHAR(MAX),
[Carrier - Service Selected] NVARCHAR(MAX),

)

--Insert and Convert the CSV file into temp table
INSERT [Inventory].[dbo].[ResellerShipstationImport_tmp]
EXEC [Inventory].[dbo].[SSP_CSVToTable]
     @InputFile = @FileLocation
    ,@FirstLine = @FirstImportRow



---Spit out email about SKU's not in mapping
---Begin Email Errors
DECLARE @xml NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
DECLARE @date VARCHAR(12)
DECLARE @subtext VARCHAR(50)
DECLARE @subject VARCHAR(62)
DECLARE @recipients VARCHAR(255)
DECLARE @datestart date

SET @xml =CAST(( 
SELECT RSSItmp.[Order - Number] AS 'td','',
RSSItmp.[Item - Qty] AS 'td','',
RSSItmp.[Item - SKU] AS 'td','',
RSSItmp.[Ship To - Name] AS 'td','',
RSSItmp.[Ship To - Company] AS 'td','',
RSSItmp.[Ship To - Address 1] AS 'td','',
RSSItmp.[Ship To - Address 2] AS 'td','',
RSSItmp.[Ship To - City] AS 'td','',
RSSItmp.[Ship To - Country] AS 'td','',
RSSItmp.[Ship To - Phone] AS 'td','',
RSSItmp.[Ship To - Postal Code] AS 'td','',
RSSItmp.[Ship To - State] AS 'td','',
RSSItmp.[Carrier - Service Selected] AS 'td','',
@CustomerPO AS 'td'
FROM [ResellerShipstationImport_tmp] AS RSSItmp
WHERE RSSItmp.[Item - SKU] NOT IN (SELECT CSSM.[CustomerSKU] FROM [Inventory].[dbo].[CustomerSpecificSKUMapping] AS CSSM WHERE CSSM.CustomerID = @CustomerID)
FOR XML PATH('tr'), ELEMENTS 
) AS NVARCHAR(MAX))

/** FIX HTML **/
 SET @xml = replace(@xml, '&amp;', '&')
 SET @xml = replace(@xml, '&lt;' , '<')
 SET @xml = replace(@xml, '&gt;' , '>')
/** FIX HTML END**/

SET @subtext = 'Partner Portal Alert - '
SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
SET @subject = @subtext + @date
SET @recipients = @ShipFromEmail+';neworder@mitechnologiesinc.com'
SET @body ='<html><center><H1>Reseller Portal Order Alert - <br>' + @date + '</H1><br><br></Center>Portal User,<br>AutoBot has detected errors with your import and the below orders have not been imported into the system because Autobot could not find any mapping for the CustomerSKU presented in the import file.  Below is the list of item(s) that could not be imported: <Center><body bgcolor=yellow><table border = 2><tr>
<th>OrderNumber</th>
<th>ItemQty</th>
<th>SKU</th>
<th>ShipToName</th>
<th>ShipToCompany</th>
<th>ShipToAddress1</th>
<th>ShipToAddress2</th>
<th>ShipToCity</th>
<th>ShipToCountry</th>
<th>ShipToPhone</th>
<th>ShipToZip</th>
<th>ShipToState</th>
<th>ShippingService</th>
<th>PONumber</th>
</tr>' 
SET @body = @body + @xml +'</center></table><br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'

PRINT @body

If @xml is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML'

END


---Email orders that already existed and will not be imported

SET @xml =CAST(( 
SELECT RSSItmp.[Order - Number] AS 'td','',
RSSItmp.[Item - Qty] AS 'td','',
RSSItmp.[Item - SKU] AS 'td','',
RSSItmp.[Ship To - Name] AS 'td','',
RSSItmp.[Ship To - Company] AS 'td','',
RSSItmp.[Ship To - Address 1] AS 'td','',
RSSItmp.[Ship To - Address 2] AS 'td','',
RSSItmp.[Ship To - City] AS 'td','',
RSSItmp.[Ship To - Country] AS 'td','',
RSSItmp.[Ship To - Phone] AS 'td','',
RSSItmp.[Ship To - Postal Code] AS 'td','',
RSSItmp.[Ship To - State] AS 'td','',
RSSItmp.[Carrier - Service Selected] AS 'td','',
@CustomerPO AS 'td'
FROM [ResellerShipstationImport_tmp] AS RSSItmp
WHERE RSSItmp.[Order - Number] IN (SELECT RO.OrderNumber FROM [Resellers].[dbo].[ResellerOrders] AS RO WHERE CustomerID = @CustomerID)

FOR XML PATH('tr'), ELEMENTS 
) AS NVARCHAR(MAX))

/** FIX HTML **/
 SET @xml = replace(@xml, '&amp;', '&')
 SET @xml = replace(@xml, '&lt;' , '<')
 SET @xml = replace(@xml, '&gt;' , '>')
/** FIX HTML END**/

SET @subtext = 'Partner Portal Duplicates - '
SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
SET @subject = @subtext + @date
SET @recipients = @ShipFromEmail+';neworder@mitechnologiesinc.com'
SET @body ='<html><center><H1>Reseller Portal Orders Duplicates - <br>' + @date + '</H1><br><br></Center>Portal User,<br>AutoBot has detected that the following order(s) were not unique and were imported previously: <Center><body bgcolor=yellow><table border = 2><tr>
<th>OrderNumber</th>
<th>ItemQty</th>
<th>SKU</th>
<th>ShipToName</th>
<th>ShipToCompany</th>
<th>ShipToAddress1</th>
<th>ShipToAddress2</th>
<th>ShipToCity</th>
<th>ShipToCountry</th>
<th>ShipToPhone</th>
<th>ShipToZip</th>
<th>ShipToState</th>
<th>ShippingService</th>
<th>PONumber</th>
</tr>' 
SET @body = @body + @xml +'</center></table><br>The above order(s) were not imported.<br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'

PRINT @body

If @xml is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML'

END


---Email orders that ship mapping was not found

SET @xml =CAST(( 
SELECT RSSItmp.[Order - Number] AS 'td','',
RSSItmp.[Item - Qty] AS 'td','',
RSSItmp.[Item - SKU] AS 'td','',
RSSItmp.[Ship To - Name] AS 'td','',
RSSItmp.[Ship To - Company] AS 'td','',
RSSItmp.[Ship To - Address 1] AS 'td','',
RSSItmp.[Ship To - Address 2] AS 'td','',
RSSItmp.[Ship To - City] AS 'td','',
RSSItmp.[Ship To - Country] AS 'td','',
RSSItmp.[Ship To - Phone] AS 'td','',
RSSItmp.[Ship To - Postal Code] AS 'td','',
RSSItmp.[Ship To - State] AS 'td','',
RSSItmp.[Carrier - Service Selected] AS 'td','',
@CustomerPO AS 'td'
FROM [ResellerShipstationImport_tmp] AS RSSItmp
WHERE RSSItmp.[Carrier - Service Selected] NOT IN (SELECT CSSHM.[CustomerShippingMethod] FROM [Inventory].[dbo].[CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerID = @CustomerID)

FOR XML PATH('tr'), ELEMENTS 
) AS NVARCHAR(MAX))

/** FIX HTML **/
 SET @xml = replace(@xml, '&amp;', '&')
 SET @xml = replace(@xml, '&lt;' , '<')
 SET @xml = replace(@xml, '&gt;' , '>')
/** FIX HTML END**/

SET @subtext = 'Partner Portal Ship Mapping Error - '
SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
SET @subject = @subtext + @date
SET @recipients = @ShipFromEmail+';neworder@mitechnologiesinc.com'
SET @body ='<html><center><H1>Reseller Portal Ship Mapping Error - <br>' + @date + '</H1><br><br></Center>Portal User,<br>AutoBot has detected that the following order shipping method(s) were had no mapping in the Ship Mapping table: <Center><body bgcolor=yellow><table border = 2><tr>
<th>OrderNumber</th>
<th>ItemQty</th>
<th>SKU</th>
<th>ShipToName</th>
<th>ShipToCompany</th>
<th>ShipToAddress1</th>
<th>ShipToAddress2</th>
<th>ShipToCity</th>
<th>ShipToCountry</th>
<th>ShipToPhone</th>
<th>ShipToZip</th>
<th>ShipToState</th>
<th>ShippingService</th>
<th>PONumber</th>
</tr>' 
SET @body = @body + @xml +'</center></table><br>The above order(s) were imported but the shipping method was set to "Shipping Label Attached."  Please review these orders and adjust shipping accordingly.<br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'

PRINT @body

If @xml is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML'

END


---End Email Errors


--Email Orders that will be imported perfectly
SET @xml =CAST(( 
SELECT RSSItmp.[Order - Number] AS 'td','',
RSSItmp.[Item - Qty] AS 'td','',
RSSItmp.[Item - SKU] AS 'td','',
RSSItmp.[Ship To - Name] AS 'td','',
RSSItmp.[Ship To - Company] AS 'td','',
RSSItmp.[Ship To - Address 1] AS 'td','',
RSSItmp.[Ship To - Address 2] AS 'td','',
RSSItmp.[Ship To - City] AS 'td','',
RSSItmp.[Ship To - Country] AS 'td','',
RSSItmp.[Ship To - Phone] AS 'td','',
RSSItmp.[Ship To - Postal Code] AS 'td','',
RSSItmp.[Ship To - State] AS 'td','',
RSSItmp.[Carrier - Service Selected] AS 'td','',
@CustomerPO AS 'td'
FROM [ResellerShipstationImport_tmp] AS RSSItmp
WHERE RSSItmp.[Order - Number] NOT IN (SELECT RO.OrderNumber FROM [Resellers].[dbo].[ResellerOrders] AS RO WHERE CustomerID = @CustomerID)
AND RSSItmp.[Item - SKU] IN (SELECT CSSM.[CustomerSKU] FROM [Inventory].[dbo].[CustomerSpecificSKUMapping] AS CSSM WHERE CSSM.CustomerID = @CustomerID)

FOR XML PATH('tr'), ELEMENTS 
) AS NVARCHAR(MAX))

/** FIX HTML **/
 SET @xml = replace(@xml, '&amp;', '&')
 SET @xml = replace(@xml, '&lt;' , '<')
 SET @xml = replace(@xml, '&gt;' , '>')
/** FIX HTML END**/

SET @subtext = 'Partner Portal Orders Inserted - '
SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
SET @subject = @subtext + @date
SET @recipients = @ShipFromEmail+';neworder@mitechnologiesinc.com'
SET @body ='<html><center><H1>Reseller Portal Orders Inserted - <br>' + @date + '</H1><br><br></Center>Portal User,<br>AutoBot has successfully processed the following orders into the partner portal for your account: <Center><body bgcolor=yellow><table border = 2><tr>
<th>OrderNumber</th>
<th>ItemQty</th>
<th>SKU</th>
<th>ShipToName</th>
<th>ShipToCompany</th>
<th>ShipToAddress1</th>
<th>ShipToAddress2</th>
<th>ShipToCity</th>
<th>ShipToCountry</th>
<th>ShipToPhone</th>
<th>ShipToZip</th>
<th>ShipToState</th>
<th>ShippingService</th>
<th>PONumber</th>
</tr>' 
SET @body = @body + @xml +'</center></table><br>Thank you for using our bulk import tool and thank you for your order(s).<br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'

PRINT @body

If @xml is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML'

END



--Drop Existing Final Table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[Inventory].[dbo].[ResellerShipstationImport]') AND type in (N'U'))
DROP TABLE [Inventory].[dbo].[ResellerShipstationImport]

----ReCreate Final Table
CREATE TABLE [Inventory].[dbo].[ResellerShipstationImport]
(	  
	[CustomerID] [nvarchar](25) NULL,
	[BillToName] [nvarchar](255) NULL,
	[BillToCompany] [nvarchar](255) NULL,
	[BillToEmail] [nvarchar](255) NULL,
	[BillToAddress] [nvarchar](255) NULL,
	[BillToCity] [nvarchar](50) NULL,
	[BillToState] [nvarchar](5) NULL,
	[BillToZip] [nvarchar](15) NULL,
	[BillToCountry] [nvarchar](50) NULL,
	[OrderNumber] [nvarchar](50) NULL,
	[OrderDate] [datetime] NULL,
	[LocalSKU] [nvarchar](10) NULL,
	[CustomerSKU] [nvarchar](50) NULL,
	[Title] [nvarchar](255) NULL,
	[LineItem] [nvarchar](3) NULL,
	[ItemUnitPrice] [decimal](19, 4) NULL,
	[ItemUnitShippingCharge] [decimal](19, 4) NULL,
	[QuantityOrdered] [nvarchar](3) NULL,
	[ShippingTotal] [decimal](19, 4) NULL,
	[OrderTotal] [decimal](19, 4) NULL,
	[ShipToName] [nvarchar](255) NULL,
	[ShipToCompany] [nvarchar](255) NULL,
	[ShipToAddressLine1] [nvarchar](255) NULL,
	[ShipToAddressLine2] [nvarchar](255) NULL,
	[ShipToCity] [nvarchar](50) NULL,
	[ShipToState] [nvarchar](25) NULL,
	[ShipToZipCode] [nvarchar](15) NULL,
	[ShipToCountry] [nvarchar](50) NULL,
	[ShipToPhoneNumber] [nvarchar](15) NULL,
	[ShippingMethod] [nvarchar](max) NULL,
	[OMPaymentMethod] [nvarchar](50) NULL,
	[PONumber] [nvarchar](50) NULL,
	[OrderInstructions] [nvarchar](max) NULL,
	[OMComments] [nvarchar](max) NULL
)


--Insert from Temp Table to Final Table - This is where all the translations of SKU and Carrier Happen
INSERT INTO [Inventory].[dbo].[ResellerShipstationImport] (
	   [CustomerID]
      ,[BillToName]
      ,[BillToCompany]
      ,[BillToEmail]
      ,[BillToAddress]
      ,[BillToCity]
      ,[BillToState]
      ,[BillToZip]
      ,[BillToCountry]
      ,[OrderNumber]
      ,[OrderDate]
      ,[LocalSKU]
	  ,[CustomerSKU]
      ,[Title]
      ,[LineItem]
      ,[ItemUnitPrice]
      ,[ItemUnitShippingCharge]
      ,[QuantityOrdered]
      ,[ShippingTotal]
      ,[OrderTotal]
      ,[ShipToName]
      ,[ShipToCompany]
      ,[ShipToAddressLine1]
      ,[ShipToAddressLine2]
      ,[ShipToCity]
      ,[ShipToState]
      ,[ShipToZipCode]
      ,[ShipToCountry]
      ,[ShipToPhoneNumber]
      ,[ShippingMethod]
      ,[OMPaymentMethod]
      ,[PONumber]
      ,[OrderInstructions]
      ,[OMComments] )
SELECT 
		 	 @CustomerID AS 'CustomerID'
			,@ShipFromName AS 'BillToName'
			,@ShipFromCompany AS 'BillToCompany'
			,@ShipFromEmail AS 'BillToEmail'
			,@ShipFromAddressLine1 AS 'BillToAddress'
			,@ShipFromCity AS 'BillToCity'
			,@ShipFromState AS 'BillToState'
			,@ShipFromZipCode AS 'BillToZip'
			,@ShipFromCountry AS 'BillToCountry'
			,RSSItmp.[Order - Number] AS 'OrderNumber'
			,GETDATE() AS 'OrderDate'
			,([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID)) AS 'LocalSKU'
			,RSSItmp.[Item - SKU] AS 'CustomerSKU'
			,(SELECT PC.Name FROM Inventory.dbo.ProductCatalog AS PC WHERE PC.ID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) AS 'Title'
			,ROW_NUMBER() OVER (PARTITION BY [Order - Number] ORDER BY [LineID] ASC) AS 'LineItem'

			,(SELECT CSP.SalePrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) 
			AS 'ItemUnitPrice'
			
			,(CASE WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = 'Economy' THEN (SELECT CSP.DSEconomyPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = '2Day' THEN (SELECT CSP.DS2ndDayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = '1Day' THEN (SELECT CSP.DS1DayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = 'ShippingLabelAttached' THEN '0'
			ELSE '0' END)
			AS 'ItemUnitShippingCharge'
			
			,RSSItmp.[Item - Qty] AS 'QuantityOrdered'
			
			,(CASE WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = 'Economy' THEN (CAST((SELECT CSP.DSEconomyPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = '2Day' THEN (CAST((SELECT CSP.DS2ndDayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = '1Day' THEN (CAST((SELECT CSP.DS1DayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = 'ShippingLabelAttached' THEN '0'
			ELSE '0' END)
			AS 'ShippingTotal'
			
			,((SELECT CSP.SalePrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID)))*RSSItmp.[Item - Qty])
			+
			(CASE WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = 'Economy' THEN (CAST((SELECT CSP.DSEconomyPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = '2Day' THEN (CAST((SELECT CSP.DS2ndDayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = '1Day' THEN (CAST((SELECT CSP.DS1DayPrice FROM [Inventory].[dbo].[CustomerSpecificPricing] AS CSP WHERE CSP.CustomerID = @CustomerID AND CSP.ProductCatalogID = ([Inventory].[dbo].[fn_GetSKUfromCustomerSpecificMapping](RSSItmp.[Item - SKU],@CustomerID))) AS Decimal(10,2))*RSSItmp.[Item - Qty]) 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = 'ShippingLabelAttached' THEN '0'
			ELSE '0' END)
			AS 'OrderTotal'

			,RSSItmp.[Ship To - Name] AS 'ShipToName'
			,RSSItmp.[Ship To - Company] AS 'ShipToCompany'
			,RSSItmp.[Ship To - Address 1]  AS 'ShipToAddressLine1'
			,RSSItmp.[Ship To - Address 2] AS 'ShipToAddressLine2'
			,RSSItmp.[Ship To - City] AS 'ShipToCity'
			,RSSItmp.[Ship To - State] AS 'ShipToState'
			,RSSItmp.[Ship To - Postal Code] AS 'ShipToZipCode'
			,RSSItmp.[Ship To - Country] AS 'ShipToCountry'
			,RSSItmp.[Ship To - Phone] AS 'ShipToPhoneNumber'
			
			,(CASE WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = 'Economy' THEN 'Standard (5-7 Business Days)' 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = '2Day' THEN 'Two-Day (No Saturday Delivery)' 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = '1Day' THEN 'One-Day (No Saturday Delivery)' 
			WHEN IsNull((SELECT CSSHM.MITShippingMethod FROM [CustomerSpecificShipMapping] AS CSSHM WHERE CSSHM.CustomerShippingMethod = RSSItmp.[Carrier - Service Selected] AND CSSHM.CustomerID = @CustomerID),'N/A') = 'ShippingLabelAttached' THEN 'Shipping Label Attached'
			ELSE 'Shipping Label Attached' END) AS 'ShippingMethod'

			,'Integration' AS 'OMPaymentMethod'
			,@CustomerPO AS 'PONumber'
			--,CASE WHEN len(CAST(RSSItmp.[Order - Number] AS NVARCHAR(50))) - len(replace(CAST(RSSItmp.[Order - Number] AS NVARCHAR(50)), '-', '')) > 0  THEN CAST(RSSItmp.[Order - Number] AS NVARCHAR(50)) ELSE '' END AS 'OrderInstructions'
			,RSSItmp.[Order - Number] AS 'OrderInstructions'
			,'' AS 'OMComments'
FROM [Inventory].[dbo].[ResellerShipstationImport_tmp] AS RSSItmp
--Update WHERE NOT EXISTS INSTEAD OF NOT IN -- sometimes same order number, different skus come on different lines... this was only improting the first line so we made this correction.
WHERE NOT EXISTS (SELECT 1 FROM [Resellers].[dbo].[ResellerOrders] AS RO WHERE RSSItmp.[Order - Number] = RO.[OrderNumber] AND RSSItmp.[Item - SKU] = RO.[CustomerSKU])
--WHERE RSSItmp.[Order - Number] NOT IN (SELECT RO.OrderNumber FROM [Resellers].[dbo].[ResellerOrders] AS RO WHERE CustomerID = @CustomerID)
AND RSSItmp.[Item - SKU] IN (SELECT CSSM.[CustomerSKU] FROM [Inventory].[dbo].[CustomerSpecificSKUMapping] AS CSSM WHERE CSSM.[CustomerID] = @CustomerID)

--Update Shipping Total and Order Total for Order Manager import
--First we set the shipping price for orders with greater than 2 line items and greater than 1 quantity
UPDATE RSSI SET RSSI.[ShippingTotal] = (CASE WHEN RSSI.LineItem > 1 THEN (RSSI.[ItemUnitShippingCharge]/2)
WHEN RSSI.LineItem = 1 AND RSSI.QuantityOrdered > 1 THEN (RSSI.QuantityOrdered*(RSSI.[ItemUnitShippingCharge]/2)) + (RSSI.[ItemUnitShippingCharge]/2)
ELSE RSSI.[ItemUnitShippingCharge] END)
FROM [ResellerShipstationImport] AS RSSI

--We update the shipping total again to sum up all the shipping totals calculated in previous query.. and injuect this into all the rows for this order
UPDATE RSSI SET RSSI.[ShippingTotal] = (SELECT SUM(RSSI2.[ShippingTotal]) FROM [ResellerShipstationImport] AS RSSI2 WHERE RSSI2.OrderNumber = RSSI.OrderNumber)
FROM [ResellerShipstationImport] AS RSSI

--We sum all the item totals for the particular order then we add a single shipping total we received from the previous update.. and inject this into all the rows for this order
UPDATE RSSI SET RSSI.[OrderTotal] = (SELECT SUM(RSSI2.[ItemUnitPrice]*RSSI2.[QuantityOrdered]) FROM [ResellerShipstationImport] AS RSSI2 WHERE RSSI2.[OrderNumber] = RSSI.[OrderNumber])+RSSI.ShippingTotal
FROM [ResellerShipstationImport] AS RSSI


--FINAL IMPORT INTO ResellerOrders Table
INSERT INTO [Resellers].[dbo].[ResellerOrders] (
	   [CustomerID]
      ,[BillToName]
      ,[BillToCompany]
      ,[BillToEmail]
      ,[BillToAddress]
      ,[BillToCity]
      ,[BillToState]
      ,[BillToZip]
      ,[BillToCountry]
      ,[OrderNumber]
      ,[OrderDate]
      ,[LocalSKU]
	  ,[CustomerSKU]
      ,[Title]
      ,[LineItem]
      ,[ItemUnitPrice]
      ,[ItemUnitShippingCharge]
      ,[QuantityOrdered]
      ,[ShippingTotal]
      ,[OrderTotal]
      ,[ShipToName]
      ,[ShipToCompany]
      ,[ShipToAddressLine1]
      ,[ShipToAddressLine2]
      ,[ShipToCity]
      ,[ShipToState]
      ,[ShipToZipCode]
      ,[ShipToCountry]
      ,[ShipToPhoneNumber]
      ,[ShippingMethod]
      ,[OMPaymentMethod]
      ,[PONumber]
      ,[OrderInstructions]
      ,[OMComments] )

SELECT [CustomerID]
      ,[BillToName]
      ,[BillToCompany]
      ,[BillToEmail]
      ,[BillToAddress]
      ,[BillToCity]
      ,[BillToState]
      ,[BillToZip]
      ,[BillToCountry]
      --Changed to SourceOrderID for imports instead of SourceOrderNumber
	  --,CASE WHEN len(CAST([OrderNumber] AS NVARCHAR(50))) - len(replace(CAST([OrderNumber] AS NVARCHAR(50)), '-', '')) > 1  THEN RIGHT(REPLACE(CAST([OrderNumber] AS NVARCHAR(50)),'-',''),7)  ELSE replace(CAST([OrderNumber] AS NVARCHAR(50)),'-','') END AS [OrderNumber]
	  ,[OrderNumber]
      ,[OrderDate]
      ,[LocalSKU]
	  ,[CustomerSKU]
      ,[Title]
      ,[LineItem]
      ,[ItemUnitPrice]
      ,[ItemUnitShippingCharge]
      ,[QuantityOrdered]
      ,[ShippingTotal]
      ,[OrderTotal]
      ,[ShipToName]
      ,[ShipToCompany]
      ,[ShipToAddressLine1]
      ,[ShipToAddressLine2]
      ,[ShipToCity]
      ,[ShipToState]
      ,[ShipToZipCode]
      ,[ShipToCountry]
      ,[ShipToPhoneNumber]
      ,[ShippingMethod]
      ,[OMPaymentMethod]
      ,[PONumber]
      ,[OrderInstructions]
      ,[OMComments]
FROM [Inventory].[dbo].[ResellerShipstationImport]


--Let user know his file has been imported
SET @subtext = 'Partner Portal Orders Process Complete - '
SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
SET @subject = @subtext + @date
SET @recipients = @ShipFromEmail+';neworder@mitechnologiesinc.com'
SET @body ='<html><center><H1>Reseller Portal Orders Process Complete - <br>' + @date + '</H1><br><br></Center>Portal User,<br>AutoBot has successfully processed your file ' + RIGHT(@FilePath,(LEN(@FilePath)-23)) + '... <Center><body bgcolor=yellow><table border = 2>' 
SET @body = @body + @xml +'</center></table><br>Thank you for using our bulk import tool and thank you for your order(s).<br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'

PRINT @body

If @xml is not null BEGIN

EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

@recipients = @recipients,
@subject = @subject,
@body = @body,
@body_format ='HTML'

END



IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[Inventory].[dbo].[ResellerShipstationImport_tmp]') AND type in (N'U'))
DROP TABLE [Inventory].[dbo].[ResellerShipstationImport_tmp]

EXEC master..xp_cmdshell 'C:\sharedb\orderimport\archive\archive.bat'


END

go

