-- =============================================
-- Author:		Luis Bautista
-- Create date: Feb-21-2014
-- Description:	Make a list of alternative partnumbers of agiven brans and original partnumber
-- =============================================
CREATE FUNCTION [dbo].[fn_Catalog_Maker_AlternativePN_Slash]
(
	@pBrand nvarchar(50), @pPartnumber nvarchar(50)
)
RETURNS  varchar(1000)
AS
BEGIN
		-- Declare the return variable here
	DECLARE @ResultVar varchar(1000);
	DECLARE @AltPartnumber varchar(50);
	DECLARE @MaxCols int;
	DECLARE @CurrCol int;
	DECLARE @Exist int;

	DECLARE lcursor CURSOR FOR 
					SELECT ALPN.[AlternativePN]
						FROM [MITDB].[dbo].[ProjectorData] AS PD
						LEFT OUTER JOIN [Inventory].[dbo].[CompatibilityAlternativePN] AS ALPN 
								ON ((PD.PartNumber = ALPN.[PartNumber]) AND (PD.Brand = ALPN.OriginalManufacturer))
						WHERE (PD.Brand = @pBrand) and (PD.PartNumber = @pPartnumber)
						Order By ALPN.AlternativePN;



	SET @Exist = 0;
	SET @MaxCols = 3;
	SET @CurrCol = 1;
	SET @ResultVar = '';


	SET @ResultVar = @ResultVar + '';
	

	OPEN lcursor
	
	FETCH NEXT FROM lcursor	INTO @AltPartnumber;



	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @ResultVar = @ResultVar + @AltPartnumber+',';
	
		FETCH NEXT FROM lcursor	INTO @AltPartnumber;
	END

	CLOSE lcursor;
	DEALLOCATE lcursor;
	

	
	-- Return the result of the function
	RETURN @ResultVar;
END
go

