
-- =======================================================================================================================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-01-18
-- Description:	Get Invoice By CustomerID
-- =======================================================================================================================================
CREATE PROCEDURE [dbo].[sp_GetInvoiceByCustomerID]
	@CustomerID INT
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (SELECT 1 FROM tempdb..SYSOBJECTS WHERE name LIKE '#TMP_StatementByCustomerID') BEGIN
		DROP TABLE #TMP_StatementByCustomerID
	END

	CREATE TABLE #TMP_StatementByCustomerID (CustomerID INT, OrderNumber INT, OrderSource NVARCHAR(2), OrderReference NVARCHAR(255), PONumber NVARCHAR(50), ShipDate NVARCHAR(10), OrderDate NVARCHAR(10), SKU NVARCHAR(100), WebSKU NVARCHAR(255), Product NVARCHAR(255), QuantityShipped INT, PricePerUnit DECIMAL(13,2), LineTotal DECIMAL(13,2), STATEMENTDAY INT, FullName NVARCHAR(255), Company NVARCHAR(255), [Address] NVARCHAR(255), Address2 NVARCHAR(255), City NVARCHAR(255), State NVARCHAR(255), Zip NVARCHAR(255), Country NVARCHAR(255), Phone NVARCHAR(50), Phone2 NVARCHAR(50), Email NVARCHAR(255), ShipName NVARCHAR(255), ShipCompany NVARCHAR(255), ShipAddress NVARCHAR(255), ShipAddress2 NVARCHAR(255), ShipCity NVARCHAR(255), ShipState NVARCHAR(255), ShipZip NVARCHAR(255), ShipCountry NVARCHAR(255), ShipPhone NVARCHAR(255), OrderStatus NVARCHAR(50), TrackingNum NVARCHAR(50), [ProductTotal] DECIMAL(13,2), [TaxTotal] DECIMAL(13,2), [ShippingTotal] DECIMAL(13,2), [GrandTotal] DECIMAL(13,2), [NumItems] INT, [Shipping] NVARCHAR(150), [Discount] DECIMAL(13,2), [RevisedDiscount] DECIMAL(13,2), [FinalProductTotal] DECIMAL(13,2), [FinalTaxTotal] DECIMAL(13,2), [FinalShippingTotal] DECIMAL(13,2), [FinalGrandTotal] DECIMAL(13,2),[BalanceDue] DECIMAL(13,2))
	
	
	INSERT INTO #TMP_StatementByCustomerID (CustomerID, OrderNumber, OrderSource, OrderReference, PONumber, ShipDate, OrderDate, SKU, WebSKU, [Product], [QuantityShipped], [PricePerUnit], LineTotal, STATEMENTDAY, FullName, Company, [Address], Address2, City, [State], Zip, Country, Phone, Phone2, Email, ShipName, ShipCompany, ShipAddress, ShipAddress2, ShipCity, ShipState, ShipZip, ShipCountry, ShipPhone, OrderStatus, TrackingNum, ProductTotal, TaxTotal, ShippingTotal, GrandTotal, NumItems, Shipping, Discount, RevisedDiscount, FinalProductTotal, FinalTaxTotal, FinalShippingTotal, FinalGrandTotal, BalanceDue)
	SELECT O.CustomerID, O.[OrderNumber], O.[OrderSource] , ISNULL(O.[SourceOrderID], ISNULL(CAST(O.[SourceOrderNumber] AS NVARCHAR(MAX)),'')) AS 'OrderReference', ISNULL(O.[PONumber],'') AS 'PONumber',CAST((SELECT TOP(1) TRK2.[DateAdded] FROM [OrderManager].[dbo].[Tracking] AS TRK2 (NOLOCK) WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS DATE) AS 'ShipDate', CAST(O.[OrderDate] AS date) AS 'OrderDate',(CASE WHEN OD.[Option01] IS NOT NULL AND OD.[Option01] != '' THEN OD.[Option01] ELSE OD.[SKU] END) AS 'SKU', OD.WebSKU, OD.[Product], OD.[QuantityShipped], OD.[PricePerUnit], (OD.[QuantityShipped]*OD.[PricePerUnit]) AS 'LineTotal'
		,0, CUST.[FullName], CUST.[Company], CUST.[Address], CUST.[Address2], CUST.[City], CUST.[State], CUST.[Zip], CUST.[Country], CUST.[Phone], CUST.[Phone2], CUST.[Email], O.[ShipName], O.[ShipCompany], O.[ShipAddress], ISNULL(O.[ShipAddress2], '') [ShipAddress2], O.[ShipCity], O.[ShipState], O.[ShipZip], O.[ShipCountry], O.[ShipPhone], O.[OrderStatus], (SELECT TOP(1) TRK2.[TrackingID] FROM [OrderManager].[dbo].[Tracking] AS TRK2 (NOLOCK) WHERE TRK2.[NumericKey] = O.[OrderNumber]) AS [TrackingNum], O.[ProductTotal], O.[TaxTotal], O.[ShippingTotal], O.[GrandTotal], O.[NumItems], O.[Shipping], O.[Discount], O.[RevisedDiscount], O.[FinalProductTotal], O.[FinalTaxTotal], O.[FinalShippingTotal], O.[FinalGrandTotal], O.[BalanceDue]
	FROM [OrderManager].[dbo].[Orders] AS O (NOLOCK)
		--LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] AS TRK ON (O.[OrderNumber] = TRK.[NumericKey])
		LEFT OUTER JOIN [OrderManager].[dbo].[Order Details] AS OD (NOLOCK) ON (O.[OrderNumber] = OD.[OrderNumber])
		LEFT OUTER JOIN [OrderManager].[dbo].[Customers] AS CUST (NOLOCK) ON (O.CustomerID = CUST.[CustomerID])
	WHERE --O.[Approved] = '1'
		--AND O.[Cancelled] = '0'
		--AND O.[BalanceDue] > '1.00'
		--AND OD.Adjustment = '0'
		--AND TRK.[TrackingID] IS NOT NULL
		--AND 
		O.CustomerID = @CustomerID
		-- AND O.OrderNumber IN ( 6456042 )
		AND O.OrderNumber IN (SELECT OrderId FROM Inventory.dbo.InvoiceRequest WHERE CustomerID = @CustomerID GROUP BY OrderId)
		AND O.CartID IN (SELECT CartID FROM Inventory.dbo.InvoiceRequest WHERE CustomerID = @CustomerID GROUP BY CartID)
		--AND (SELECT TOP(1) TRK2.DateAdded FROM OrderManager.dbo.Tracking AS TRK2 (NOLOCK) WHERE TRK2.NumericKey = O.OrderNumber) BETWEEN GETDATE()-@INT2 AND GETDATE()-@INT1
	ORDER BY 'ShipDate' ASC, O.OrderDate ASC, OD.ItemNumber ASC

	DELETE FROM Inventory.dbo.InvoiceRequest WHERE CustomerID = @CustomerID

	SELECT * FROM #TMP_StatementByCustomerID 
	GROUP BY CustomerID,OrderNumber,OrderSource,OrderReference,PONumber,ShipDate,OrderDate,SKU, WebSKU,[Product],[QuantityShipped],[PricePerUnit],LineTotal,STATEMENTDAY,FullName,Company,[Address],Address2,City,[State],Zip,Country,Phone,Phone2,Email,ShipName,ShipCompany,ShipAddress,ShipAddress2,ShipCity,ShipState,ShipZip,ShipCountry,ShipPhone,OrderStatus,TrackingNum,ProductTotal, TaxTotal, ShippingTotal, GrandTotal, NumItems, Shipping, Discount, RevisedDiscount, FinalProductTotal, FinalTaxTotal, FinalShippingTotal, FinalGrandTotal, BalanceDue
	ORDER BY ShipDate ASC

END



go

