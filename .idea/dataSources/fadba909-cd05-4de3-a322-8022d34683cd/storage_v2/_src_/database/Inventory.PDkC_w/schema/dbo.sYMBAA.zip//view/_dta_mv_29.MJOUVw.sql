CREATE VIEW [dbo]._dta_mv_29 WITH SCHEMABINDING AS SELECT  [dbo].[Bins].[Bin_Id] as _col_1,  [dbo].[Bins].[Location] as _col_2,  [dbo].[Bins].[WarehouseID] as _col_3,  count_big(*) as _col_4 FROM  [dbo].[Bins]  GROUP BY  [dbo].[Bins].[Bin_Id],  [dbo].[Bins].[Location],  [dbo].[Bins].[WarehouseID]
go

