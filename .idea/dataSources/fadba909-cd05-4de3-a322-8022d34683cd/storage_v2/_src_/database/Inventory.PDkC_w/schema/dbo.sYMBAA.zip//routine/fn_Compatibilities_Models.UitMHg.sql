-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Compatibilities_Models]
(
	@Ppn varchar(50), @Pmanufacturer varchar(50)
)
RETURNS varchar(max)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Resultvar varchar(max);
	DECLARE @html varchar(max);
	declare @pntable varchar(max);
	
	set @Resultvar = '';
	declare @maxcols int;
	declare @currentcol int;
	declare @model  varchar(100);

	DECLARE  mod_cursor CURSOR
		for	SELECT model
			FROM [Inventory].[dbo].[CompatibilityDetails]
			WHERE  ([OriginalManufacturer] = @Pmanufacturer) and ([PartNumber] =  @Ppn );

		open mod_cursor;

		FETCH NEXT FROM mod_cursor INTO @model;

		SET @currentcol = 1;
		SET @pntable = '';
		WHILE @@FETCH_STATUS = 0
			BEGIN

					IF @currentcol = 1
					BEGIN
							SET @pntable = @pntable + '<TR>'
					END

					SET @pntable = @pntable + '<TD>' + @model + '</TD>';

				
						
				

					

					SET @currentcol = @currentcol + 1;

					IF @currentcol >= 5 
					BEGIN
						SET @pntable = @pntable + '</TR>'
						SET @currentcol = 1;
					END

					FETCH NEXT FROM mod_cursor INTO @model;
			END; /* Ends pn table while*/

	IF @currentcol < 5 
					BEGIN
						SET @pntable = @pntable + '</TR>'
					END

		CLOSE mod_cursor;
		DEALLOCATE mod_cursor;

		if NOT (@pntable IS NULL) AND (@pntable > '')
		begin
			set @ResultVar = @pntable
		end

		
	-- Return the result of the function
	RETURN @ResultVar;

END
go

