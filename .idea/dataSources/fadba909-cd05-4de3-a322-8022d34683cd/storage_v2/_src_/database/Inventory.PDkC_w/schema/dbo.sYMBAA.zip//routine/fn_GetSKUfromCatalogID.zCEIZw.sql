-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 3-8-2016
-- Description:	Get SKU from CatalogID
-- =============================================
CREATE FUNCTION fn_GetSKUfromCatalogID 
(
	-- Add the parameters for the function here
	@pCatalogID nvarchar(50)
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	-- Add the T-SQL statements to compute the return value here
	SELECT TOP(1) @Result = (CASE WHEN @pCatalogID LIKE '%-G' THEN (SELECT PJD.[EncSKU] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			WHEN RIGHT(@pCatalogID,3) LIKE '%-OP' THEN (SELECT PJD.[EncSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			WHEN RIGHT(@pCatalogID,3) LIKE '%-OO' THEN (SELECT PJD.[EncSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			WHEN RIGHT(@pCatalogID,3) LIKE '%-OX' THEN (SELECT PJD.[EncSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			WHEN RIGHT(@pCatalogID,3) LIKE '%-OU' THEN (SELECT PJD.[EncSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			WHEN RIGHT(@pCatalogID,3) LIKE '%-BG' THEN (SELECT PJD.[BareSKU] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			WHEN RIGHT(@pCatalogID,4) LIKE '%-BOP' THEN (SELECT PJD.[BareSKUPH] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			WHEN RIGHT(@pCatalogID,4) LIKE '%-BOO' THEN (SELECT PJD.[BareSKUOS] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			WHEN RIGHT(@pCatalogID,4) LIKE '%-BOX' THEN (SELECT PJD.[BareSKUPX] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			WHEN RIGHT(@pCatalogID,4) LIKE '%-BOU' THEN (SELECT PJD.[BareSKUUSH] FROM [MITDB].[dbo].[ProjectorData] AS PJD WHERE PJD.[CatalogID] = LEFT(@pCatalogID,5))
			ELSE @pCatalogID END)

	-- Return the result of the function
	RETURN @Result

END
go

