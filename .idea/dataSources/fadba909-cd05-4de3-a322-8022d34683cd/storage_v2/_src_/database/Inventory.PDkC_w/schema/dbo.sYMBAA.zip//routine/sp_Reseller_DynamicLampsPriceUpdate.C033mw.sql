
--This procedure is created to update the selling price for Dynamic Lamps customer.

CREATE PROCEDURE [dbo].[sp_Reseller_DynamicLampsPriceUpdate]
AS 
BEGIN
Declare @MITSKU	      AS Varchar(10)
Declare @SubSKU	      AS Varchar(10)
Declare @MinCost   AS Float
Declare @ResellerPrice   AS Float
Declare @SubSKUQTYRequired AS INT

SET @MinCost = 0


--- INSERT Missing FP Housing SKUs in the CustomerSpecificPricing table 
INSERT INTO  Inventory.dbo.CustomerSpecificPricing
(ProductCatalogID,CustomerID, DSEconomyPrice, DS2ndDayPrice,DS1DayPrice, SalePrice,Rebate)
SELECT  ID , '469498', '9', '14' , '19' , '999', '0'
FROM Inventory.dbo.ProductCatalog
WHERE ID NOT IN  (Select ProductCatalogID FROM Inventory.dbo.CustomerSpecificPricing)
AND CategoryID IN ('20','21','22','23','24','64')

--- INSERT Missing FP Bare SKUs in the CustomerSpecificPricing table 
INSERT INTO  Inventory.dbo.CustomerSpecificPricing
(ProductCatalogID,CustomerID, DSEconomyPrice, DS2ndDayPrice, DS1DayPrice,SalePrice,Rebate)
SELECT  ID , '469498', '7', '12' , '17' , '999', '0'
FROM Inventory.dbo.ProductCatalog
WHERE ID NOT IN    (Select ProductCatalogID FROM Inventory.dbo.CustomerSpecificPricing)
AND CategoryID IN ('15','16','17','18','19','63')



------------------------------------------------------------------------------------------------ 
------------------------ Enclosure GENERIC ----------------------------------------------------- 
------------------------------------------------------------------------------------------------ 

DECLARE FPGeneric_cursor CURSOR
FOR
-- FP Generic - Select the Lowest Cost among all the suppliers.
Select ProductCatalogId, ISNULL(MIN( CASE WHEN [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ProductCatalogId)=0 THEN 999 Else [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ProductCatalogId) END),'999') AS Cost 
FROM Inventory.dbo.Suppliers 
WHERE ProductCatalogId IN (
	Select pc.ID FROM Inventory.dbo.ProductCatalog pc
	LEFT JOIN Inventory.dbo.Categories ctg
	ON pc.CategoryID = ctg.ID
	WHERE ctg.ID = '24'
)
--AND SupplierID <> '11' --Exclude GrandBulb Prices
--AND ProductCatalogId = '135005'
GROUP BY ProductCatalogId
ORDER BY ProductCatalogId

 
OPEN FPGeneric_cursor
FETCH NEXT FROM FPGeneric_cursor INTO @MITSKU, @MinCost

WHILE @@FETCH_STATUS = 0
BEGIN
	IF ( @MinCost = '999')	 
	BEGIN
		SET @MinCost = ( Select ISNULL(MIN( CASE WHEN [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ProductCatalogId)=0 THEN 999 Else [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ProductCatalogId) END),'999') FROM Inventory.dbo.Suppliers WHERE ProductCatalogId = @MITSKU)
	END

	-- Formula to set Selling Price for Dynamic Lamps
	SET @ResellerPrice   = (@MinCost + 5) * 1.2
			
	-- Update the CustomerSpecificPricing Table for Dynamic Lamps
	UPDATE Inventory.dbo.CustomerSpecificPricing with(UPDLOCK) 
	SET SalePrice = @ResellerPrice
	WHERE CustomerID = '469498'  -- Dynamic Lamps Customer ID
	AND [ProductCatalogID] = @MITSKU		

FETCH NEXT FROM FPGeneric_cursor INTO @MITSKU, @MinCost

END

CLOSE FPGeneric_cursor
DEALLOCATE FPGeneric_cursor

-- For Kit SKUs 137001 etc
DECLARE FPGenericPackage_cursor CURSOR
FOR
-- FP Generic - Select all the SKUs for 
SELECT asd.ProductCatalogID, asd.SubSKU, [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](PC.[ID]) , asd.SubSKUQTYRequired FROM Inventory.dbo.AssemblyDetails asd
LEFT JOIN Inventory.dbo.ProductCatalog pc
ON asd.SubSKU = pc.ID 
WHERE SubSKU IN (SELECT ID FROM Inventory.dbo.ProductCatalog WHERE CategoryID = '24' ) 

 
OPEN FPGenericPackage_cursor
FETCH NEXT FROM FPGenericPackage_cursor INTO @MITSKU, @SubSKU, @MinCost, @SubSKUQTYRequired

WHILE @@FETCH_STATUS = 0
BEGIN
	-- Formula to set the Floor & Ceiling Prices
	SET @ResellerPrice   = (@MinCost + 5) * 1.2 * @SubSKUQTYRequired
		
	-- Update the CustomerSpecificPricing Table for Dynamic Lamps
	UPDATE Inventory.dbo.CustomerSpecificPricing with(UPDLOCK) 
	SET SalePrice = @ResellerPrice
	WHERE CustomerID = '469498'  -- Dynamic Lamps Customer ID
	AND [ProductCatalogID] = @MITSKU

FETCH NEXT FROM FPGenericPackage_cursor INTO @MITSKU, @SubSKU, @MinCost, @SubSKUQTYRequired

END

CLOSE FPGenericPackage_cursor
DEALLOCATE FPGenericPackage_cursor

------------------------------------------------------------------------------------------------ 
------------------------ Enclosure OEM ----------------------------------------------------- 
------------------------------------------------------------------------------------------------ 

DECLARE FPOEM_cursor CURSOR
FOR
-- FP OEM - Select the Unit Cost of each FP SKU (Non Generic)
Select ID, CASE WHEN [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ID)=0 THEN 999 Else [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ID) END AS Cost 
FROM Inventory.dbo.ProductCatalog
--All Categories EXECPT GENERIC
WHERE CategoryID IN ('20','21','22','23','64')

 
OPEN FPOEM_cursor
FETCH NEXT FROM FPOEM_cursor INTO @MITSKU, @MinCost

WHILE @@FETCH_STATUS = 0
BEGIN
	-- Formula to set Selling Price for Dynamic Lamps
	SET @ResellerPrice   = (@MinCost + 10) * 1.2
			
	-- Update the CustomerSpecificPricing Table for Dynamic Lamps
	UPDATE Inventory.dbo.CustomerSpecificPricing with(UPDLOCK) 
	SET SalePrice = @ResellerPrice
	WHERE CustomerID = '469498'  -- Dynamic Lamps Customer ID
	AND [ProductCatalogID] = @MITSKU		

FETCH NEXT FROM FPOEM_cursor INTO @MITSKU, @MinCost

END
------------------------------------------------------------------------------------------------ 

------------------------------------------------------------------------------------------------ 
------------------------ FP Bare ----------------------------------------------------- 
------------------------------------------------------------------------------------------------ 

DECLARE FPBare_cursor CURSOR
FOR
-- FP OEM - Select the Unit Cost of each FP SKU (Non Generic)
Select ID, CASE WHEN [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ID)=0 THEN 999 Else [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ID) END AS Cost 
FROM Inventory.dbo.ProductCatalog
--All FP bare categories EXCEPT GENERIC
WHERE CategoryID IN ('15','16','17','18','63')
 
OPEN FPBare_cursor
FETCH NEXT FROM FPBare_cursor INTO @MITSKU, @MinCost

WHILE @@FETCH_STATUS = 0
BEGIN
	-- Formula to set Selling Price for Dynamic Lamps
	SET @ResellerPrice   = (@MinCost + 10) * 1.2
			
	-- Update the CustomerSpecificPricing Table for Dynamic Lamps
	UPDATE Inventory.dbo.CustomerSpecificPricing with(UPDLOCK) 
	SET SalePrice = @ResellerPrice
	WHERE CustomerID = '469498'  -- Dynamic Lamps Customer ID
	AND [ProductCatalogID] = @MITSKU		

FETCH NEXT FROM FPBare_cursor INTO @MITSKU, @MinCost

END
------------------------------------------------------------------------------------------------ 

--PRICE OVERRIDES
--UPDATE Inventory.dbo.CustomerSpecificPricing
--SET SalePrice = '93'
--WHERE ProductCatalogID LIKE '107302'
--AND CustomerID = '469498'

--UPDATE Inventory.dbo.CustomerSpecificPricing
--SET SalePrice = '85.8'
--WHERE ProductCatalogID LIKE '135005'
--AND CustomerID = '469498'  


END

go

