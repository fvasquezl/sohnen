CREATE VIEW dbo.[MLMexico-Order]
AS
SELECT        A.id AS order_id, A.Buyer_id, A.date_created, A.date_closed, A.status, A.ispaid, A.isdelivered, A.payment_id, A.total_amount, B.fname, B.lname, B.company_name, 
                         B.nickname, B.email, B.phone1_area, B.phone1_number, B.phone1_ext, B.phone2_area, B.phone2_number, B.phone2_ext, B.shipping_address, B.billing_address, 
                         C.amount, C.status AS payment_status, C.date_created AS payment_date_created, C.date_last_modified, C.installments, C.card_id, C.status_detail, C.transaction_id, 
                         C.total_paid, C.transaction_amount, C.shipping_cost, C.payment_method_id, C.marketplace_fee, D.items_id AS MLMexicoListingID
FROM            dbo.MLOrder AS A LEFT OUTER JOIN
                         dbo.MLBuyer AS B ON B.id = A.Buyer_id LEFT OUTER JOIN
                         dbo.MLPayment AS C ON C.id = A.payment_id LEFT OUTER JOIN
                         dbo.MLOrder_has_items AS D ON D.order_id = A.id
go

