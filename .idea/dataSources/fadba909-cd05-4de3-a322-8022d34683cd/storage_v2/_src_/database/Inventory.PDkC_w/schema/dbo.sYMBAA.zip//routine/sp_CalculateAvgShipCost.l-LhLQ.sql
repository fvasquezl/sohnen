-- =============================================
-- Author:		Ankit Gulati
-- Create date: 12-4-2014
-- Description:	Calculate Average Shipping Cost for each SKU and update ProductCatalog table.
-- =============================================
CREATE PROCEDURE [dbo].[sp_CalculateAvgShipCost] 
AS


BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

DECLARE @AvgShipCost as decimal(10,2)
DECLARE @AvgWeight as decimal(10,4)
DECLARE @MITSKU as int

--*******************************  Average Standard Shipping Cost Calculation ***********************************************
DECLARE StandardShip_cursor CURSOR
FOR 
 /** Selecting Average Cost and Weight from OM **/
SELECT ord.SKU, 
AVG((Case When Isnumeric(trk.Cost)=1 Then Convert(decimal(10,2),trk.Cost) else 0 end)) AS "Average Shipping Cost",
--AVG(trk.Pounds) AS "Avg Pounds", AVG(trk.Ounces) AS "Avg Ounces",
CONVERT(DECIMAL(10,4), AVG(trk.Pounds) + (CONVERT(DECIMAL(10,4),AVG(trk.Ounces))/16)) AS "Avg Weight"
FROM OrderManager.dbo.Tracking trk
LEFT JOIN OrderManager.dbo.[Order Details] ord
ON trk.OrderNum =  ord.OrderNumber
LEFT JOIN OrderManager.dbo.Orders o
ON ord.OrderNumber = o.OrderNumber
WHERE ord.Adjustment = '0'
AND ord.OrderNumber IN ( Select OrderNumber FROM OrderManager.dbo.[Order Details]	WHERE Adjustment = '0' 	GROUP BY OrderNumber HAVING SUM(ItemNumber) < '2' )
AND ord.SKU IN ( SELECT CAST(ID AS varchar) FROM Inventory.dbo.ProductCatalog)
AND DATEDIFF(month, Cast(ord.DetailDate AS DateTime), GETDATE()) <= '3' 
AND ord.QuantityOrdered = '1'
AND trk.Cost IS NOT NULL
AND trk.Cost <> '0'
AND trk.Pounds IS NOT NULL
AND trk.Ounces IS NOT NULL
--AND LEN(ord.SKU) = '6'
--AND ord.OrderNumber = '5594204'
AND (trk.ShippersMethod = 'FIRST' OR
trk.ShippersMethod = 'PARCELPOST' OR
trk.ShippersMethod = 'PRIORITY' OR
trk.ShippersMethod = 'Priority Mail' OR
trk.ShippersMethod = 'FEDEXEXPRESSSAVER' OR
trk.ShippersMethod = 'FEDEXEXPRESSSAVER' OR
trk.ShippersMethod = 'Ground' OR
trk.ShippersMethod = 'UPS Express Saver' OR
trk.ShippersMethod = 'FIRST' OR
trk.ShippersMethod = 'STANDARDPOST' OR
trk.ShippersMethod = 'GROUNDHOMEDELIVERY' OR
trk.ShippersMethod = 'FEDEXGROUND' OR
trk.ShippersMethod = 'UPS Standard' OR
trk.ShippersMethod = 'First Class Mail')
GROUP BY ord.SKU

OPEN StandardShip_cursor
FETCH NEXT FROM StandardShip_cursor INTO @MITSKU, @AvgShipCost, @AvgWeight
WHILE @@FETCH_STATUS = 0  
BEGIN
	-- Update Catalog table with the extracted variables.
	UPDATE [Inventory].[dbo].[ProductCatalog] WITH (UPDLOCK)
	SET AvgStandardShipCost = @AvgShipCost , AvgWeightPounds = @AvgWeight
	WHERE ID = @MITSKU

	FETCH NEXT FROM StandardShip_cursor  INTO @MITSKU, @AvgShipCost, @AvgWeight
END 

CLOSE StandardShip_cursor;  
DEALLOCATE StandardShip_cursor;

--*******************************  Average One Day Shipping Cost Calculation ***********************************************
DECLARE OneDayShip_cursor CURSOR
FOR 
/** Selecting Average Cost and Weight from OM **/
SELECT ord.SKU, 
AVG((Case When Isnumeric(trk.Cost)=1 Then Convert(decimal(10,2),trk.Cost) else 0 end)) AS "Average Shipping Cost"
FROM OrderManager.dbo.Tracking trk
LEFT JOIN OrderManager.dbo.[Order Details] ord
ON trk.OrderNum =  ord.OrderNumber
LEFT JOIN OrderManager.dbo.Orders o
ON ord.OrderNumber = o.OrderNumber
WHERE ord.Adjustment = '0'
AND ord.OrderNumber IN ( Select OrderNumber FROM OrderManager.dbo.[Order Details]	WHERE Adjustment = '0' 	GROUP BY OrderNumber HAVING SUM(ItemNumber) < '2' )
AND ord.SKU IN ( SELECT CAST(ID AS varchar) FROM Inventory.dbo.ProductCatalog)
AND DATEDIFF(month, Cast(ord.DetailDate AS DateTime), GETDATE()) <= '3' 
AND ord.QuantityOrdered = '1'
AND trk.Cost IS NOT NULL
AND trk.Cost <> '0'
AND trk.Pounds IS NOT NULL
AND trk.Ounces IS NOT NULL
AND (trk.ShippersMethod = 'STANDARDOVERNIGHT' OR
trk.ShippersMethod = 'FIRSTOVERNIGHT' OR
trk.ShippersMethod = 'PRIORITYOVERNIGHT' OR
trk.ShippersMethod = 'PRIORITYOVERNIGHT' OR
trk.ShippersMethod = 'STANDARDOVERNIGHT' OR
trk.ShippersMethod = 'Next Day Air' OR
trk.ShippersMethod = 'Next Day Air Early AM' OR
trk.ShippersMethod = 'Next Day Air Saver')
GROUP BY ord.SKU

OPEN OneDayShip_cursor
FETCH NEXT FROM OneDayShip_cursor INTO @MITSKU, @AvgShipCost 
WHILE @@FETCH_STATUS = 0  
BEGIN
	-- Update Catalog table with the extracted variables.
	UPDATE [Inventory].[dbo].[ProductCatalog] WITH (UPDLOCK) 
	SET Avg1DayShipCost = @AvgShipCost
	WHERE ID = @MITSKU

	FETCH NEXT FROM OneDayShip_cursor  INTO @MITSKU, @AvgShipCost 
END 

CLOSE OneDayShip_cursor;  
DEALLOCATE OneDayShip_cursor;

--*******************************  Average Two Day Shipping Cost Calculation ***********************************************
DECLARE TwoDayShip_cursor CURSOR
FOR 
/** Selecting Average Cost and Weight from OM **/
SELECT ord.SKU, 
AVG((Case When Isnumeric(trk.Cost)=1 Then Convert(decimal(10,2),trk.Cost) else 0 end)) AS "Average Shipping Cost"
FROM OrderManager.dbo.Tracking trk
LEFT JOIN OrderManager.dbo.[Order Details] ord
ON trk.OrderNum =  ord.OrderNumber
LEFT JOIN OrderManager.dbo.Orders o
ON ord.OrderNumber = o.OrderNumber
WHERE ord.Adjustment = '0'
AND ord.OrderNumber IN ( Select OrderNumber FROM OrderManager.dbo.[Order Details]	WHERE Adjustment = '0' 	GROUP BY OrderNumber HAVING SUM(ItemNumber) < '2' )
AND ord.SKU IN ( SELECT CAST(ID AS varchar) FROM Inventory.dbo.ProductCatalog)
AND DATEDIFF(month, Cast(ord.DetailDate AS DateTime), GETDATE()) <= '3' 
AND ord.QuantityOrdered = '1'
AND trk.Cost IS NOT NULL
AND trk.Cost <> '0'
AND trk.Pounds IS NOT NULL
AND trk.Ounces IS NOT NULL
AND (trk.ShippersMethod = 'FEDEX2DAY' OR
trk.ShippersMethod = '2nd Day Air AM' OR
trk.ShippersMethod = '2nd Day Air' OR
trk.ShippersMethod = 'FEDEX2DAY')
GROUP BY ord.SKU

OPEN TwoDayShip_cursor
FETCH NEXT FROM TwoDayShip_cursor INTO @MITSKU, @AvgShipCost 
WHILE @@FETCH_STATUS = 0  
BEGIN
	-- Update Catalog table with the extracted variables.
	UPDATE [Inventory].[dbo].[ProductCatalog] WITH (UPDLOCK)
	SET Avg2DayShipCost = @AvgShipCost
	WHERE ID = @MITSKU

	FETCH NEXT FROM TwoDayShip_cursor  INTO @MITSKU, @AvgShipCost
END 

CLOSE TwoDayShip_cursor;  
DEALLOCATE TwoDayShip_cursor;

--*******************************  Average International Economy Shipping Cost Calculation *********************************************
DECLARE IntEconomyShip_cursor CURSOR
FOR 

SELECT ord.SKU, 
AVG((Case When Isnumeric(trk.Cost)=1 Then Convert(decimal(10,2),trk.Cost) else 0 end)) AS "Average Shipping Cost"
FROM OrderManager.dbo.Tracking trk
LEFT JOIN OrderManager.dbo.[Order Details] ord
ON trk.OrderNum =  ord.OrderNumber
LEFT JOIN OrderManager.dbo.Orders o
ON ord.OrderNumber = o.OrderNumber
WHERE ord.Adjustment = '0'
AND ord.OrderNumber IN ( Select OrderNumber FROM OrderManager.dbo.[Order Details]	WHERE Adjustment = '0' 	GROUP BY OrderNumber HAVING SUM(ItemNumber) < '2' )
AND ord.SKU IN ( SELECT CAST(ID AS varchar) FROM Inventory.dbo.ProductCatalog)
AND DATEDIFF(month, Cast(ord.DetailDate AS DateTime), GETDATE()) <= '3' 
AND ord.QuantityOrdered = '1'
AND trk.Cost IS NOT NULL
AND trk.Cost <> '0'
AND trk.Pounds IS NOT NULL
AND trk.Ounces IS NOT NULL
AND (trk.ShippersMethod = 'INTERNATIONALECONOMY' OR
trk.ShippersMethod = 'INTERNATIONALECONOMY' OR
trk.ShippersMethod = 'International First Class' OR
trk.ShippersMethod = 'INTLFIRST')
GROUP BY ord.SKU

OPEN IntEconomyShip_cursor
FETCH NEXT FROM IntEconomyShip_cursor INTO @MITSKU, @AvgShipCost 
WHILE @@FETCH_STATUS = 0  
BEGIN
	-- Update Catalog table with the extracted variables.
	UPDATE [Inventory].[dbo].[ProductCatalog] WITH (UPDLOCK)
	SET AvgIntEconomyShipCost = @AvgShipCost
	WHERE ID = @MITSKU

	FETCH NEXT FROM IntEconomyShip_cursor  INTO @MITSKU, @AvgShipCost
END 

CLOSE IntEconomyShip_cursor;  
DEALLOCATE IntEconomyShip_cursor;


--*******************************  Average International Economy Shipping Cost Calculation *********************************************
DECLARE IntPriorityShip_cursor CURSOR
FOR 

SELECT ord.SKU, 
AVG((Case When Isnumeric(trk.Cost)=1 Then Convert(decimal(10,2),trk.Cost) else 0 end)) AS "Average Shipping Cost"
FROM OrderManager.dbo.Tracking trk
LEFT JOIN OrderManager.dbo.[Order Details] ord
ON trk.OrderNum =  ord.OrderNumber
LEFT JOIN OrderManager.dbo.Orders o
ON ord.OrderNumber = o.OrderNumber
WHERE ord.Adjustment = '0'
AND ord.OrderNumber IN ( Select OrderNumber FROM OrderManager.dbo.[Order Details]	WHERE Adjustment = '0' 	GROUP BY OrderNumber HAVING SUM(ItemNumber) < '2' )
AND ord.SKU IN ( SELECT CAST(ID AS varchar) FROM Inventory.dbo.ProductCatalog)
AND DATEDIFF(month, Cast(ord.DetailDate AS DateTime), GETDATE()) <= '3' 
AND ord.QuantityOrdered = '1'
AND trk.Cost IS NOT NULL
AND trk.Cost <> '0'
AND trk.Pounds IS NOT NULL
AND trk.Ounces IS NOT NULL
AND (trk.ShippersMethod = 'INTERNATIONALECONOMY' OR
trk.ShippersMethod = 'INTERNATIONALECONOMY' OR
trk.ShippersMethod = 'International First Class' OR
trk.ShippersMethod = 'INTLFIRST')
GROUP BY ord.SKU

OPEN IntPriorityShip_cursor
FETCH NEXT FROM IntPriorityShip_cursor INTO @MITSKU, @AvgShipCost 
WHILE @@FETCH_STATUS = 0  
BEGIN
	-- Update Catalog table with the extracted variables.
	UPDATE [Inventory].[dbo].[ProductCatalog] WITH (UPDLOCK)
	SET AvgIntPriorityShipCost = @AvgShipCost
	WHERE ID = @MITSKU

	FETCH NEXT FROM IntPriorityShip_cursor  INTO @MITSKU, @AvgShipCost
END 

CLOSE IntPriorityShip_cursor;  
DEALLOCATE IntPriorityShip_cursor;



END


go

