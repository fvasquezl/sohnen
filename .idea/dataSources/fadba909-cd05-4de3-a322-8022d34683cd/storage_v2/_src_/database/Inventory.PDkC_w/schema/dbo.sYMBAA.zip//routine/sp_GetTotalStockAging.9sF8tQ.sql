-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-10-13
-- Description:	Get Total Stock by Aging
-- =============================================
CREATE PROCEDURE sp_GetTotalStockAging
AS
BEGIN
	DECLARE @CURSOR_KIT		CURSOR,
			@SKU_ID			INT,
			@SKU_Kit		INT,
			@SKU_KitQty		INT,
			@SKU_Lamp		INT,
			@SKU_LampQty	INT,
			@COLUMNQTY		INT,
			@IROW			INT,
			@SQL			NVARCHAR(1000),
			@SUB_SKU		INT,
			@SUB_SKU_Qty	INT

	SET NOCOUNT ON;

	CREATE TABLE #tmpAging (SKU INT, Description NVARCHAR(2000), StockQty INT, AgingDays INT, CategoryID INT, SKU_Kit INT, SKU_KitQty INT, SKU_Lamp INT, SKU_LampQty INT)
	CREATE NONCLUSTERED INDEX IDX_tmpSKUHistory ON #tmpAging ( SKU )

	DECLARE @tmpAssembly TABLE (SKU INT, SubSKU INT, CategoryID INT, SKUQty INT)
	DECLARE @tmpSubAssembly TABLE (SKU INT, SubSKU INT)

	INSERT INTO #tmpAging (SKU, Description, StockQty, AgingDays, CategoryID)
    SELECT A.ProductCatalog_Id, C.Name, SUM(A.Counter) AS STOCK_QTY,
		(SELECT TOP 1 MAX(DATEDIFF(DAY, CONVERT(DATE,A.LastStamp), GETDATE()) + 1) FROM Inventory.dbo.Bin_Content WHERE ProductCatalog_Id = A.ProductCatalog_Id) AS AGING_DAYS, C.CategoryID
	FROM Inventory.dbo.Bin_Content A (NOLOCK)
	INNER JOIN Inventory.dbo.Bins B (NOLOCK)
	ON B.Bin_Id = A.Bin_Id AND SUBSTRING(B.Bin_id,1,2) NOT IN ('DF','RC','TM') 
	LEFT OUTER JOIN Inventory.dbo.ProductCatalog C (NOLOCK)
	ON C.ID = A.ProductCatalog_Id
	WHERE A.Counter > 0
	GROUP BY A.ProductCatalog_Id, C.Name, C.CategoryID	

	SET @CURSOR_KIT = CURSOR FOR 

	SELECT TMP.SKU
	FROM #tmpAging TMP
	WHERE CategoryID NOT IN (59,60,30,33)
	GROUP BY TMP.SKU

	OPEN @CURSOR_KIT 
	FETCH NEXT FROM @CURSOR_KIT 
	INTO @SKU_ID
	   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			DELETE FROM @tmpAssembly
			SET @SKU_Kit = NULL
			SET @SKU_Lamp = NULL
			SET @SKU_KitQty = NULL
			SET @SKU_LampQty = NULL

			INSERT INTO @tmpAssembly (SKU, SubSKU, CategoryID, SKUQty)
			SELECT AD.ProductCatalogID, AD.SubSKU, PC.CategoryID, SUM(TA.StockQty)
			FROM Inventory.dbo.AssemblyDetails AD (NOLOCK)
			LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
			ON PC.ID = AD.SubSKU
			LEFT OUTER JOIN #tmpAging TA
			ON TA.SKU = AD.SubSKU
			WHERE AD.ProductCatalogID = @SKU_ID
			GROUP BY AD.ProductCatalogID, AD.SubSKU, PC.CategoryID

			SELECT @SKU_Kit = SubSKU, @SKU_KitQty = ISNULL(SKUQty,0)
			FROM @tmpAssembly WHERE SKU = @SKU_ID AND CategoryID IN (59,60,30,33)

			SELECT @SKU_Lamp = TA.SubSKU, @SKU_LampQty = ISNULL(SKUQty,0)
			FROM @tmpAssembly TA 
			LEFT OUTER JOIN Inventory.dbo.Categories C
			ON C.ID = TA.CategoryID
			WHERE TA.SKU = @SKU_ID AND C.ParentID IN (1,3)

			UPDATE #tmpAging SET SKU_Kit = @SKU_Kit, SKU_Lamp = @SKU_Lamp, SKU_KitQty = @SKU_KitQty, SKU_LampQty = @SKU_LampQty WHERE SKU = @SKU_ID

			NEXT_FETCH:
			FETCH NEXT FROM @CURSOR_KIT
			INTO @SKU_ID
		END
	CLOSE      @CURSOR_KIT
	DEALLOCATE @CURSOR_KIT
	
	INSERT INTO @tmpSubAssembly (SKU, SubSKU)
	SELECT TA.SKU, AD.SubSKU
	FROM #tmpAging TA
	INNER JOIN Inventory.dbo.AssemblyDetails AD (NOLOCK)
	ON AD.ProductCatalogID = TA.SKU_Lamp
	WHERE TA.SKU_Lamp IS NOT NULL
	GROUP BY TA.SKU, AD.SubSKU
	
	SET @COLUMNQTY = ISNULL((SELECT TOP 1 COUNT(*) FROM @tmpSubAssembly GROUP BY SKU ORDER BY COUNT(*) DESC),0)
	SET @IROW = 0
	
	WHILE(@IROW < @COLUMNQTY)
	BEGIN
		SET @IROW = @IROW + 1
		
		SET @SQL = ' ALTER TABLE #tmpAging ADD SubSKU'+ CONVERT(NVARCHAR,@IROW) +' INT '
		EXECUTE(@SQL)

		SET @SQL = ' ALTER TABLE #tmpAging ADD SubSKUQty'+ CONVERT(NVARCHAR,@IROW) +' INT '
		EXECUTE(@SQL)

	END

	SET @CURSOR_KIT = CURSOR FOR 

	SELECT SKU, COUNT(*)
	FROM @tmpSubAssembly
	GROUP BY SKU

	OPEN @CURSOR_KIT 
	FETCH NEXT FROM @CURSOR_KIT 
	INTO @SKU_ID, @COLUMNQTY
	   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			SET @IROW = 0
			WHILE(@IROW < @COLUMNQTY)
			BEGIN
				SET @IROW = @IROW + 1
				SET @SUB_SKU = NULL
				SET @SUB_SKU_Qty = NULL
				SET @SUB_SKU = (SELECT TOP 1 SubSKU FROM @tmpSubAssembly WHERE SKU = @SKU_ID)
				IF(ISNULL(@SUB_SKU,0) <> 0)
				BEGIN
					SET @SUB_SKU_Qty = (SELECT SUM(StockQty) FROM #tmpAging WHERE SKU = @SUB_SKU)

					SET @SQL = ' UPDATE #tmpAging SET SubSKU'+ CONVERT(NVARCHAR,@IROW) +' = '+CONVERT(NVARCHAR,@SUB_SKU) + ', SubSKUQty'+ CONVERT(NVARCHAR,@IROW) +' = '+ CONVERT(NVARCHAR,ISNULL(@SUB_SKU_Qty,0)) + ' WHERE SKU = ' + CONVERT(NVARCHAR,@SKU_ID)
					 
					EXECUTE(@SQL)
					DELETE FROM @tmpSubAssembly WHERE SKU = @SKU_ID AND SubSKU = @SUB_SKU
				END
			END

			NEXT_FETCH2:
			FETCH NEXT FROM @CURSOR_KIT
			INTO @SKU_ID, @COLUMNQTY
		END
	CLOSE      @CURSOR_KIT
	DEALLOCATE @CURSOR_KIT

	SELECT * FROM #tmpAging
END
go

