-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[Get_Partnumber]
(
	@pProductCatalogID int
)
RETURNS varchar(50)
AS
BEGIN
DECLARE @lresult varchar(50);

	SET @lresult = '';

			select @lresult =  a.manufacturerpn from ProductCatalog a
			where a.ID = @pProductCatalogID ;
	
	-- Return the result of the function
	RETURN (@lresult)
END
go

