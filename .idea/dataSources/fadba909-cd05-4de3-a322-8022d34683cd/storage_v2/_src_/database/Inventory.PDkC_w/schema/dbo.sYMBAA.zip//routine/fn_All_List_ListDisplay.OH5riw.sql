-- =============================================
-- Author:		Luis Bautista
-- Create date: JUL 09 2014
-- Description:	Get the Scanned reason name
-- =============================================
CREATE FUNCTION [dbo].[fn_All_List_ListDisplay]
(
	@pCode as varchar(20)	
)
RETURNS varchar(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar as varchar(100)

	-- Add the T-SQL statements to compute the return value here
	SELECT  @ResultVar = listdisplay from Inventory.dbo.All_List (NOLOCK) where listvalue = @pCode;

	-- Return the result of the function
	RETURN @ResultVar;

END
go

