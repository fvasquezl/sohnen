-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ExplodeReBuildFPLamp] 
	-- Add the parameters for the stored procedure here
	@pSKU int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

Select  @pSKU AS 'ToBuild'
		,AD.SubSKU AS 'ParentSKU'
        ,PC.Name AS 'Item'
         ,Cast((Select GS2.GlobalStock FROM Inventory.dbo.Global_Stocks AS GS2 Where GS2.ProductCatalogId = (Select AD2.SubSKU FROM Inventory.dbo.AssemblyDetails AS AD2
        LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC2 ON (AD2.SubSKU = PC2.ID)
        WHERE PC2.CategoryID IN ('5','6','7','8','9','15','16','17','18','19') AND (AD2.ProductCatalogID = AD.ProductCatalogID))) AS Int) AS 'QOH'  
       
        ,Cast((Select GS2.VirtualStock FROM Inventory.dbo.Global_Stocks AS GS2 Where GS2.ProductCatalogId = (Select AD2.SubSKU FROM Inventory.dbo.AssemblyDetails AS AD2
        LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC2 ON (AD2.SubSKU = PC2.ID)
        WHERE PC2.CategoryID IN ('5','6','7','8','9','15','16','17','18','19') AND (AD2.ProductCatalogID = AD.ProductCatalogID))) - GS.GlobalStock AS Int) AS 'vQOH'
       
       
        ,Cast((Select GS2.TotalStock FROM Inventory.dbo.Global_Stocks AS GS2 Where GS2.ProductCatalogId = (Select AD2.SubSKU FROM Inventory.dbo.AssemblyDetails AS AD2
        LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC2 ON (AD2.SubSKU = PC2.ID)
        WHERE PC2.CategoryID IN ('5','6','7','8','9','15','16','17','18','19') AND (AD2.ProductCatalogID = AD.ProductCatalogID))) - GS.GlobalStock AS Int) AS 'tQOH'  

FROM [Inventory].[dbo].AssemblyDetails AS AD
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (AD.SubSKU = PC.ID)
LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (AD.ProductCatalogID = GS.ProductCatalogId)
WHERE AD.ProductCatalogID = @pSKU AND PC.CategoryID IN ('5','6','7','8','9','15','16','17','18','19')

UNION

Select  @pSKU AS 'ToBuild'
		,AD.SubSKU AS 'ParentSKU'
        ,PC.Name AS 'Item'
        ,Cast((Select GS2.GlobalStock FROM Inventory.dbo.Global_Stocks AS GS2 Where GS2.ProductCatalogId = (Select AD2.SubSKU FROM Inventory.dbo.AssemblyDetails AS AD2
        LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC2 ON (AD2.SubSKU = PC2.ID)
        WHERE PC2.CategoryID IN ('59','60') AND (AD2.ProductCatalogID = AD.ProductCatalogID))) AS Int) AS 'QOH'
        ,Cast((Select GS2.VirtualStock FROM Inventory.dbo.Global_Stocks AS GS2 Where GS2.ProductCatalogId = (Select AD2.SubSKU FROM Inventory.dbo.AssemblyDetails AS AD2
        LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC2 ON (AD2.SubSKU = PC2.ID)
        WHERE PC2.CategoryID IN ('59','60') AND (AD2.ProductCatalogID = AD.ProductCatalogID))) - GS.GlobalStock AS Int) AS 'vQOH'
        ,Cast((Select GS2.TotalStock FROM Inventory.dbo.Global_Stocks AS GS2 Where GS2.ProductCatalogId = (Select AD2.SubSKU FROM Inventory.dbo.AssemblyDetails AS AD2
        LEFT OUTER JOIN Inventory.dbo.ProductCatalog AS PC2 ON (AD2.SubSKU = PC2.ID)
        WHERE PC2.CategoryID IN ('59','60') AND (AD2.ProductCatalogID = AD.ProductCatalogID))) - GS.GlobalStock AS Int) AS 'tQOH'
FROM [Inventory].[dbo].AssemblyDetails AS AD
LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (AD.SubSKU = PC.ID)
LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (AD.ProductCatalogID = GS.ProductCatalogId)
WHERE AD.ProductCatalogID = @pSKU  AND PC.CategoryID IN ('59','60')

ORDER BY QOH DESC
END
go

