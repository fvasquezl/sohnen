-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tr_files_delete]
   ON [Inventory].[dbo].[files]
   AFTER dELEte
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    DECLARE @lweborder varchar(250);
    DECLARE @lindex int;
    DECLARE @lcount int;
    DECLARE @lwhere varchar(250);
    
    
    SET @lweborder = (SELECT deleted.filename FROM deleted);
    SET @lindex = CHARINDEX('-',@lweborder);
    SET @lweborder = LEFT(@lweborder,@lindex-1);
    SET @lwhere  = LEFT(@lweborder,@lindex-1) + '%';
    
    SET @lcount = (SELECT COUNT(a.filename) FROM Inventory.dbo.files a WHERE a.filename like @lwhere) ;
    
    UPDATE Inventory.dbo.ResellerPortalOrder SET LabelStatus = @lcount WHERE WebOrderNumber = @lweborder;
    

END
go

