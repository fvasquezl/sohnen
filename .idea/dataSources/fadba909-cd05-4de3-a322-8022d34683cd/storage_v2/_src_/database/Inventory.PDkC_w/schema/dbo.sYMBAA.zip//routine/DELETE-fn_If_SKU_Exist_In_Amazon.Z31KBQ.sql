-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_If_SKU_Exist_In_Amazon
(
	@SKU int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar int;

	SET @ResultVar = 0;

	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = count(id) FROM [Inventory].[dbo].[Amazon] WHERE (ProductCatalogId = @sku);

	-- Return the result of the function
	RETURN @ResultVar;

END
go

