-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonSparcPriceUpdate] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Just to see the table 
   --SELECT * FROM [Inventory].[dbo].[AmazonSparc]  where partnumber = 'xl-2400' or partnumber = 'elplp42' order by mitsku asc

  --GENERIC
  UPDATE ASPC SET [price] = FLOOR(IsNull(PC.[PriceFloorFBA],'0')*1.5)-0.01 
  FROM [Inventory].[dbo].[AmazonSparc] AS ASPC
  LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (ASPC.[MITSKU] = PC.[ID])
  WHERE [CategoryID] IN ('9','14','19','24')

  
  --OEM
  UPDATE ASPC SET [price] = CEILING(PC.[PriceFloorFBA]*1.25)-0.01
  FROM [Inventory].[dbo].[AmazonSparc] AS ASPC
  LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (ASPC.[MITSKU] = PC.[ID])
  WHERE [CategoryID] IN ('5','6','7','8','10','11','12','13','15','16','17','18','20','21','22','23','24','25','26','61','62','63','64')


END
go

