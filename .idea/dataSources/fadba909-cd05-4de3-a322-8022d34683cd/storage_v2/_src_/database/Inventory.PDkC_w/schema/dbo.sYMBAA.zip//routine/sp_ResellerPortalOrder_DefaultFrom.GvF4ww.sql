-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ResellerPortalOrder_DefaultFrom]
	@pWebOrderNumber int, @pCustomerID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @ShipFromName varchar(255);
	DECLARE @ShipFromCompany varchar(255);
	DECLARE @ShipFromAddressLine1 varchar(255);
	DECLARE @ShipFromAddressLine2 varchar(255);
	DECLARE @ShipFromCity varchar(255);
	DECLARE @ShipFromState varchar(255);
	DECLARE @ShipFromZipCode varchar(255);
	DECLARE @ShipFromCountry varchar(255);
	DECLARE @ShipFromPhone varchar(255);
	DECLARE @InternalNotes varchar(255);
	DECLARE @PackingSlipNotes varchar(255);
	DECLARE @cid integer;
	DECLARE @woid integer;
	DECLARE @countrycode varchar(255);
	
    SELECT 
		@ShipFromName = a.FullName
		, @ShipFromCompany = a.Company
		, @ShipFromAddressLine1 = a.Address
		, @ShipFromAddressLine2	 = a.Address2
		, @ShipFromCity = a.City
		, @ShipFromState = a.State
		, @ShipFromZipCode = a.Zip
		, @ShipFromCountry = a.Country
		, @ShipFromPhone = a.Phone
	FROM OrderManager.dbo.Customers a WHERE a.CustomerID = @pCustomerID; 
	
	
	-- Get the country code
	SELECT @countrycode = code from [OrderManager].[dbo].[Countries] 
			WHERE  Country =  @ShipFromCountry;
			
			
	UPDATE inventory.dbo.ResellerPortalOrder SET
		  ShipFromName = @ShipFromName 
		, ShipFromCompany =  @ShipFromCompany
		, ShipFromAddressLine1 =  @ShipFromAddressLine1 
	    , ShipFromAddressLine2 = @ShipFromAddressLine2
	    , ShipFromCity = @ShipFromCity
	    , ShipFromState = @ShipFromState
	    , ShipFromZipCode = @ShipFromZipCode
	    , ShipFromCountry = @countrycode 
	    , ShipFromPhone = @ShipFromPhone
	    
	WHERE WebOrderNumber = @pWebOrderNumber;
END
go

