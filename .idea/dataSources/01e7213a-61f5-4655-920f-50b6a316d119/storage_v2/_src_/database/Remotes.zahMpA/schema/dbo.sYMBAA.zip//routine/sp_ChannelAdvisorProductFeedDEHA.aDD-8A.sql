-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 10-11-2018
-- Description:	DEHA ChannelAdvisor Launch Products
-- =============================================
CREATE PROCEDURE [dbo].[sp_ChannelAdvisorProductFeedDEHA] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


		------------------USCommerce Updates------------------
		  UPDATE USCOM SET	USCOM.[Buy It Now Price] = '"'+CAST(CA.[Buy It Now Price] AS NVARCHAR(MAX))+'"',
							USCOM.[Retail Price] = '"'+CAST(CA.[Retail Price] AS NVARCHAR(MAX))+'"',
							USCOM.[Quantity] = '"'+CAST(CA.[Quantity] AS NVARCHAR(MAX))+'"',
							USCOM.[Length] = '"'+CAST(CA.[Length] AS NVARCHAR(MAX))+'"',
							USCOM.[Width] = '"'+CAST(CA.[Width] AS NVARCHAR(MAX))+'"',
							USCOM.[Height] = '"'+CAST(CA.[Height] AS NVARCHAR(MAX))+'"',
							USCOM.[Weight] = '"'+CAST(CA.[Weight] AS NVARCHAR(MAX))+'"'
		  FROM [Remotes].[dbo].[ChannelAdvisorUSComm] AS USCOM
		  LEFT OUTER JOIN [Remotes].[dbo].[ChannelAdvisor] AS CA ON (REPLACE(REPLACE(USCOM.[Inventory Number],'"',''),'DEHA','RMTC') = CA.[Inventory Number])
		  WHERE CA.[Inventory Number] IS NOT NULL

		------------------USCommerce Updates END------------------

		IF OBJECT_ID('[Remotes].[dbo].[ChannelAdvisorUSComm]') IS NOT NULL DROP TABLE [Remotes].[dbo].[ChannelAdvisorUSComm]
		

		---FINAL SELECT FOR FEED
		CREATE TABLE [Remotes].[dbo].[ChannelAdvisorUSComm] ([Inventory Number] nvarchar(max),[Auction Title] nvarchar(max)
		,[Quantity Update Type] nvarchar(max),[Quantity] nvarchar(max)
		,[Length] nvarchar(max),[Height] nvarchar(max),[Width] nvarchar(max),[Weight] nvarchar(max)
		,[MPN] nvarchar(max),[Short Description] nvarchar(max),[Description] nvarchar(max)
		,[Manufacturer] nvarchar(max),[Brand] nvarchar(max),[Condition] nvarchar(max),[Warranty] nvarchar(max)
		,[Seller Cost] nvarchar(max),[Buy It Now Price] nvarchar(max),[Retail Price] nvarchar(max)
		,[Picture URLs] nvarchar(max),[Description Template Name] nvarchar(max)
		,[Posting Template Name] nvarchar(max),[Schedule Name] nvarchar(max),[eBay Category List] nvarchar(max)
		,[eBay Store Category Name] nvarchar(max),[Labels] nvarchar(max),[Classification] nvarchar(max)
		,[Attribute1Name] nvarchar(max),[Attribute1Value] nvarchar(max),[Attribute2Name] nvarchar(max)
		,[Attribute2Value] nvarchar(max),[Attribute3Name] nvarchar(max),[Attribute3Value] nvarchar(max)
		,[Attribute4Name] nvarchar(max),[Attribute4Value] nvarchar(max),[Attribute5Name] nvarchar(max)
		,[Attribute5Value] nvarchar(max),[Attribute6Name] nvarchar(max),[Attribute6Value] nvarchar(max)
		,[Attribute7Name] nvarchar(max),[Attribute7Value] nvarchar(max),[Attribute8Name] nvarchar(max)
		,[Attribute8Value] nvarchar(max),[Attribute9Name] nvarchar(max),[Attribute9Value] nvarchar(max)
		,[Attribute10Name] nvarchar(max),[Attribute10Value] nvarchar(max),[Attribute11Name] nvarchar(max)
		,[Attribute11Value] nvarchar(max),[Attribute12Name] nvarchar(max),[Attribute12Value] nvarchar(max)
		,[Attribute13Name] nvarchar(max),[Attribute13Value] nvarchar(max),[Attribute14Name] nvarchar(max)
		,[Attribute14Value] nvarchar(max),[Attribute15Name] nvarchar(max),[Attribute15Value] nvarchar(max))

		INSERT INTO [Remotes].[dbo].[ChannelAdvisorUSComm]
		SELECT  
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Inventory Number],'RMTC','DEHA') ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Inventory Number], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Auction Title],'Original Remote Control for','DEHA Remote Control for'),'Replacement ','DEHA '),'Original ','DEHA ') ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Auction Title], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Quantity Update Type] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Quantity Update Type], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Quantity] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Quantity], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Length] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Length], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Height] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Height], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Width] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Width], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Weight] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Weight], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([MPN]+'-DEHA' ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [MPN], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Short Description],'Original Remote Control for','DEHA Remote Control for'),'Replacement ','DEHA '),'Original ','DEHA ') ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Short Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Description],'Original Remote Control for','DEHA Remote Control for'),'Replacement ','DEHA '),'Original ','DEHA ') ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Description], 
		'"' + 'DEHA'+ '"' AS [Manufacturer], 
		'"' + 'DEHA'+ '"' AS [Brand], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Condition] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Condition], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Warranty] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Warranty], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Seller Cost] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Seller Cost], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Buy It Now Price] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Buy It Now Price], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Retail Price],'-0.01','89.99') ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Retail Price], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Picture URLs],'d2tmwtn0gh4496.cloudfront.net','d3n0q5t1lvm3bm.cloudfront.net') ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Picture URLs],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Description Template Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Description Template Name],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Posting Template Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Posting Template Name],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Schedule Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Schedule Name],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([eBay Category List] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [eBay Category List],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([eBay Store Category Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [eBay Store Category Name], 
		'"' + 'All Inventory, Amazon Marketplace - US'+ '"' AS [Labels], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Classification] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Classification], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute1Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute1Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute1Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute1Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute2Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute2Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE('UPCGoesHere' ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute2Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute3Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute3Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute3Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute3Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute4Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute4Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute4Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute4Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute5Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute5Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute5Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute5Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute6Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute6Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute6Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute6Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute7Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute7Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute7Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute7Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute8Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute8Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Value],
		'""' AS [Attribute9Name], 
		'""' AS [Attribute9Value], 
		'""' AS [Attribute10Name], 
		'""' AS [Attribute10Value], 
		'""' AS [Attribute11Name], 
		'""' AS [Attribute11Value], 
		'""' AS [Attribute12Name], 
		'""' AS [Attribute12Value], 
		'""' AS [Attribute13Name], 
		'""' AS [Attribute13Value], 
		'""' AS [Attribute14Name], 
		'""' AS [Attribute14Value], 
		'""' AS [Attribute15Name], 
		'""' AS [Attribute15Value]

		FROM [Remotes].[dbo].[ChannelAdvisor] WITH (NOLOCK)
		WHERE [Condition] = 'New' 
		AND [Classification] = 'Remote Control' 
		AND [Quantity] > 10
		AND '"'+REPLACE([Inventory Number],'RMTC','DEHA')+'"' NOT IN (SELECT DISTINCT [Inventory Number] FROM [Remotes].[dbo].[ChannelAdvisorUSComm])
		ORDER BY [ID] ASC


		--------------------------
		--ADD UPC CODES
		
		DROP TABLE IF EXISTS #TempUPC
		DROP TABLE IF EXISTS #TempCA
		DROP TABLE IF EXISTS #TempFinal

		CREATE TABLE #TempUPC ([RowID] INT, [UPC] NVARCHAR(MAX))
		CREATE TABLE #TempCA ([RowID] INT, [Inventory Number] NVARCHAR(MAX))
		CREATE TABLE #TempFinal ([UPC] NVARCHAR(MAX), [Inventory Number] NVARCHAR(MAX))

		INSERT INTO #TempUPC
		SELECT DISTINCT ROW_NUMBER() OVER(ORDER BY UPC.[ID] ASC) AS [RowID], UPC.[UPC] FROM [Remotes].[dbo].[UPCUSComm] AS UPC WHERE UPC.[Inventory Number] IS NULL ORDER BY [RowID] ASC

		INSERT INTO #TempCA
		SELECT DISTINCT ROW_NUMBER() OVER(ORDER BY CA.[Inventory Number] ASC) AS [RowID], REPLACE(CA.[Inventory Number],'"','') AS [Inventory Number] FROM [Remotes].[dbo].[ChannelAdvisorUSComm] AS CA 
		WHERE (REPLACE(CA.[Inventory Number],'"','') NOT IN (SELECT DISTINCT IsNull([Inventory Number],0) FROM [Remotes].[dbo].[UPCUSComm]))

		INSERT INTO #TempFinal
		SELECT UPC.[UPC], CA.[Inventory Number] FROM #TempCA AS CA
		LEFT OUTER JOIN #TempUPC AS UPC ON (CA.[RowID] = UPC.RowID)
		
		SELECT * FROM #TempFinal

		UPDATE UPCFINAL SET [Inventory Number] = TMP.[Inventory Number]
		FROM [Remotes].[dbo].[UPCUSComm] AS UPCFINAL
		LEFT OUTER JOIN #TempFinal AS TMP ON (UPCFINAL.[UPC] = TMP.[UPC])
		WHERE TMP.[UPC] IS NOT NULL
		
		UPDATE CAFINAL SET [Attribute2Value] = '"'+UPC.[UPC]+'"'
		FROM [Remotes].[dbo].[ChannelAdvisorUSComm] AS CAFINAL
		LEFT OUTER JOIN [Remotes].[dbo].[UPCUSComm] AS UPC ON (CAFINAL.[Inventory Number] = '"'+UPC.[Inventory Number]+'"')
		WHERE UPC.[Inventory Number] IS NOT NULL
		
		
	  

		--------------------------

		SELECT * FROM [Remotes].[dbo].[ChannelAdvisorUSComm]

		DECLARE @selectstatement NVARCHAR(3000)
		DECLARE @cmd NVARCHAR(3000)

		--START SELECT STATEMENT
		SET @selectstatement = 'SELECT * FROM [Remotes].[dbo].[ChannelAdvisorUSComm]'
		--END SELECT STATEMENT


		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\BSQLShares\ChannelAdvisorUSComm\ca-body.csv" -SBSQL -Usa -PZ91bM473 -c -t"," -r"\n"'
		EXEC master..xp_cmdshell @cmd

		EXEC master..xp_cmdshell '"C:\BSQLShares\ChannelAdvisorUSComm\cafeed.bat"'

END
go

