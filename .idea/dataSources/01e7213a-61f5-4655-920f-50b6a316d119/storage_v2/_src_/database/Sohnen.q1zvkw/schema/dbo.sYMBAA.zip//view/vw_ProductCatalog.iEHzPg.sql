/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.vw_ProductCatalog
AS
SELECT        SKUD.ID, SKUD.SKU, SKUD.Brand, SKUD.Model, SKUD.Description, SKUD.EstimatedRetail, SKUD.AvgCost, INV.QtyNew, CAST(SKUD.EstimatedRetail * 0.9 AS decimal(10, 2)) AS SalePriceNew, INV.QtyGradeB, 
                         CAST(SKUD.EstimatedRetail * 0.8 AS decimal(10, 2)) AS SalePriceGradeB, INV.QtyGradeC, CAST(SKUD.EstimatedRetail * 0.7 AS decimal(10, 2)) AS SalePriceGradeC, INV.QtyGradeX, 
                         CAST(SKUD.EstimatedRetail * 0.6 AS decimal(10, 2)) AS SalePriceGradeX, CAST(SKUD.AddedDate AS date) AS AddedDate,
                             (SELECT        SUM(Qty) AS Expr1
                               FROM            dbo.Purchases AS P
                               WHERE        (SKUD.Model = MFGSKU)) AS TotalQtyPurchased,
                             (SELECT        TOP (1) LoadDate
                               FROM            dbo.Purchases AS P
                               WHERE        (SKUD.Model = MFGSKU)
                               ORDER BY AddedDate) AS FirstPurchaseDate
FROM            dbo.SKUData AS SKUD LEFT OUTER JOIN
                         dbo.Inventory AS INV ON SKUD.SKU = INV.SKU
go

