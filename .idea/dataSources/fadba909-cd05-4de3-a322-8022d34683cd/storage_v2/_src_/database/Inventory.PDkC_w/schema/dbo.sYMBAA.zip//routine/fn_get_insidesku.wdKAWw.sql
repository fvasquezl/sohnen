-- =============================================
-- Author:		luis bautista
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_get_insidesku
(
	
	@pSKU int
)
RETURNS int	
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar int;

	-- Add the T-SQL statements to compute the return value here
	SET @ResultVar  = (SELECT ZASSY.SubSKU 
                        FROM [Inventory].[dbo].[AssemblyDetails] AS ZASSY
                        LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS ZPC ON (ZASSY.ProductCatalogID = ZPC.ID)
                        LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS QPC ON (ZASSY.SubSKU = QPC.ID)                        
                        WHERE 
                        (QPC.CategoryID IN (5,9,15,19)) AND 
                        (ZASSY.ProductCatalogID = @pSKU) 
                       )
       

	-- Return the result of the function
	RETURN @ResultVar;

END
go

