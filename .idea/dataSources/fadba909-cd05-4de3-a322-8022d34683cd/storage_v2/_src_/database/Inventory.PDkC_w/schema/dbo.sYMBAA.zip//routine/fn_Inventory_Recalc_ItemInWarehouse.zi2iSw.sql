-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_Inventory_Recalc_ItemInWarehouse
(
	@pProductCatalogID int, @pAccountID int
)
RETURNS REAL
AS
BEGIN
	

	-- interfering with SELECT statements.
	
	-- Declare the return variable here
	DECLARE @ResultVar real
	DECLARE @Inputs real
	DECLARE @Outputs real
	
	SET @Inputs = 0;
	SET @Outputs = 0;
	
    -- Insert statements for procedure here
	
	SELECT @Inputs = SUM(a.Quantity) from vw_InventoryDetails a 
			WHERE (a.ProductCatalogID = @pProductCatalogID)
					AND (
							(
								(a.Origin = @pAccountID) AND (a.Flow = 1)
							)
							OR
							(
								(a.Destination = @pAccountID ) AND (a.Flow = 3)
							)
						);
					
	SELECT @Outputs = SUM(a.Quantity) from vw_InventoryDetails a 
			WHERE (a.ProductCatalogID = @pProductCatalogID)
					AND (
							(
								(a.Origin = @pAccountID) AND (a.Flow > 1)
							)
							
						);			

	SET @ResultVar = @Inputs - @Outputs;
	
	Return @ResultVar;
END
go

