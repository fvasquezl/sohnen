-- =============================================
-- Author:		Luis Bautista
-- Create date: Jun-07-2014
-- Description:	Update bin content
-- =============================================
CREATE PROCEDURE [dbo].[sp_Bin_Content_Update]
	(
	@pBin varchar(10), @pSKU int, @pQty int, @pUserId int
	, @pFlow int, @pScanCode varchar(10), @pComments varchar(500)
	
	)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar int;
	DECLARE @Exist int;
	DECLARE @Bin_Counter int;
	DECLARE @History_id int;
	DECLARE @GlobalStock int;
	DECLARE	@OrderNumber NVARCHAR(50);

	SET @ResultVar = 0;
	SET @Exist = 0;
	SET @Bin_Counter = 0;

	/*Check for a valid qty*/
	IF @pQty <=0
	BEGIN
		SET @ResultVar = -1
	END;
	
	
	IF @ResultVar = 0
	BEGIN
			/* CHECK IF IS VALID BIN*/
			SET @Exist = (SELECT top 1 a.id FROM Inventory.dbo.Bins a WHERE a.Bin_Id = @pBin);
			IF @Exist is null 
			BEGIN
					SET		@Exist = 0;
			END;
	
			IF @Exist < 1
			BEGIN
				SET @ResultVar = -2
			END
	END;
	
	IF @ResultVar = 0
	BEGIN
		/* CHECK IF IS VALID SKU*/		
		SET @Exist = 0;
	

		SET @Exist = (SELECT top 1 a.id FROM Inventory.dbo.ProductCatalog a 
						WHERE a.id = @pSKU);
		IF @Exist is null 
		BEGIN
				SET @Exist = 0;
		END;
		
		IF @Exist < 1
		BEGIN
			SET @ResultVar = -3
		END

		
	END

	IF @ResultVar = 0
	BEGIN
		/* UPDATE THE BIN*/
		/* CHECK IF SKU exist in bin*/	
		SET @Exist = 0;	
		SELECT top 1 
				 @Bin_Counter = a.Counter 
				,@Exist = a.id
				FROM Inventory.dbo.Bin_Content a 
				WHERE (a.Bin_Id = @pBin) AND (a.ProductCatalog_Id = @pSKU);
		
		IF @Exist is null 
		BEGIN
				SET @Exist = 0;
		END;
		
		
		IF @pFlow = 1
		BEGIN
			IF @Exist < 1
			BEGIn
				INSERT INTO inventory.dbo.Bin_Content(Bin_Id, ProductCatalog_Id,Counter,LastUser_Id)
				values (@pBin, @pSKU, @pQty,@pUserId);
				
				SET @ResultVar = 10;
			END;
			
			IF @Exist > 0
			BEGIN
				UPDATE inventory.dbo.Bin_Content SET Counter = Counter + @pQty
										, LastUser_Id = @pUserId
										, LastStamp = GETDATE()
					WHERE (Bin_Id = @pBin) AND (ProductCatalog_Id = @pSKU);
					
					SET @ResultVar = 11;
			END;

			SET @OrderNumber = ISNULL((SELECT TOP 1 OrderNumber From OrderManager.dbo.Orders WHERE OrderNumber LIKE @pComments),'')
			
			--history
			IF(@OrderNumber='')
			BEGIN
						INSERT INTO Bins_History(Bin_Id, Product_Catalog_ID, Qty, Flow, ScanCode, User_Id, comments)
						VALUES (@pBin, @pSKU, @pQty, @pFlow, @pScanCode, @pUserId, @pComments);
			END
			ELSE
			BEGIN
				INSERT INTO Bins_History(Bin_Id, Product_Catalog_ID, Qty, Flow, ScanCode, User_Id, comments,OrderNumber)
						VALUES (@pBin, @pSKU, @pQty, @pFlow, @pScanCode, @pUserId, @pComments,CONVERT(INT,@OrderNumber));
			END
		END;
		
		IF @pFlow = 2
		BEGIN
			IF @pQty > @Bin_Counter
				BEGIN
					SET @ResultVar = 1;
				END
			ELSE
				BEGIN
					UPDATE inventory.dbo.Bin_Content SET Counter = Counter - @pQty
										, LastUser_Id = @pUserId
										, LastStamp = GETDATE()
					WHERE (Bin_Id = @pBin) AND (ProductCatalog_Id = @pSKU);
						
					SET @ResultVar = 12;
				
					SET @OrderNumber = ISNULL((SELECT TOP 1 OrderNumber From OrderManager.dbo.Orders WHERE OrderNumber LIKE @pComments),'')
			
					--history
					IF(@OrderNumber='')
					BEGIN
						INSERT INTO Bins_History(Bin_Id, Product_Catalog_ID, Qty, Flow, ScanCode, User_Id, comments)
						VALUES (@pBin, @pSKU, @pQty, @pFlow, @pScanCode, @pUserId, @pComments);
					END
					ELSE
					BEGIN
						INSERT INTO Bins_History(Bin_Id, Product_Catalog_ID, Qty, Flow, ScanCode, User_Id, comments,OrderNumber)
						VALUES (@pBin, @pSKU, @pQty, @pFlow, @pScanCode, @pUserId, @pComments,CONVERT(INT,@OrderNumber));
					END

					IF @pQty = @Bin_Counter
					BEGIN
						DELETE FROM inventory.dbo.Bin_Content 
							WHERE (Bin_Id = @pBin) AND (ProductCatalog_Id = @pSKU);
					END;
				END;
		END;
		
		
	END;
	--- update global stocks
	SELECT  @GlobalStock = sum(a.Counter) 
	FROM Inventory.dbo.Bin_Content a 
	WHERE (a.ProductCatalog_Id = @pSKU)
			
			and Inventory.dbo.fn_Get_Bin_WarehouseID(a.Bin_Id) <> 'DF'
	Group By a.ProductCatalog_Id ;
	
	if @GlobalStock is null
	BEGIN
		SET @GlobalStock = 0;
	END
	
	
	UPDATE Inventory.dbo.Global_Stocks SET GlobalStock = @GlobalStock WHERE ProductCatalogId = @pSKU; 
	UPDATE [Inventory].[dbo].[MercadoLibreListings] SET Stock = @GlobalStock WHERE ProductCatalogId = @pSKU; 
	
	-- Return the result of the procedure
	SELECT @ResultVar as result;
END
go

