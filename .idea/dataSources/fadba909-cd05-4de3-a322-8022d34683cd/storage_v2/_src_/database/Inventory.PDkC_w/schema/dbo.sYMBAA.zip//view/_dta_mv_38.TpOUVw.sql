CREATE VIEW [dbo]._dta_mv_38 WITH SCHEMABINDING AS SELECT  [dbo].[CustomerSpecificPricing].[ProductCatalogID] as _col_1,  count_big(*) as _col_2 FROM  [dbo].[CustomerSpecificPricing]   WHERE  [dbo].[CustomerSpecificPricing].[CustomerID] = 469498  GROUP BY  [dbo].[CustomerSpecificPricing].[ProductCatalogID]
go

