-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-06-14
-- Description:	Get Bin Stock by SKU and Type
-- =============================================
CREATE FUNCTION [dbo].[fn_GetBinDetailsByScanCode]
(	
	@SKU		NVARCHAR(10),
	@ScanCode	NVARCHAR(20)
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT [BinID], [StockQty], [ScanCode], DATEDIFF(DAY,[CreateDate],GETDATE()) AS AgingDays
	FROM [Remotes].[dbo].[BinStock] WITH(NOLOCK)
	WHERE [SKU] = @SKU AND [ScanCode] = @ScanCode
)
go

