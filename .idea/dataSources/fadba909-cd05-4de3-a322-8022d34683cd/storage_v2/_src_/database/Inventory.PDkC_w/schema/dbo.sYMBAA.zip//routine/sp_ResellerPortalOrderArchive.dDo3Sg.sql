-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 5-9-2017
-- Description:	
-- =============================================
CREATE PROCEDURE sp_ResellerPortalOrderArchive 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
		INSERT INTO [Inventory].[dbo].[ResellerPortalOrderArchive] 
		(
			  [WebOrderNumber]
			  ,[ResellerCustomerID]
			  ,[PONumber]
			  ,[OrderDate]
			  ,[OrderShippingTotal]
			  ,[OrderTotal]
			  ,[ShipToName]
			  ,[ShipToCompany]
			  ,[ShipToAddressLine1]
			  ,[ShipToAddressLine2]
			  ,[ShipToCity]
			  ,[ShipToState]
			  ,[ShipToZipCode]
			  ,[ShipToCountry]
			  ,[ShipToPhone]
			  ,[ShippingMethod]
			  ,[ShipFromName]
			  ,[ShipFromCompany]
			  ,[ShipFromAddressLine1]
			  ,[ShipFromAddressLine2]
			  ,[ShipFromCity]
			  ,[ShipFromState]
			  ,[ShipFromZipCode]
			  ,[ShipFromCountry]
			  ,[ShipFromPhone]
			  ,[InternalNotes]
			  ,[PackingSlipNotes]
			  ,[OrderStatus]
			  ,[AttachmentPath]
			  ,[ShipToEmail]
			  ,[CartId]
			  ,[LabelStatus]
			  ,[CancelRequest]
		)

		SELECT [WebOrderNumber]
			  ,[ResellerCustomerID]
			  ,[PONumber]
			  ,[OrderDate]
			  ,[OrderShippingTotal]
			  ,[OrderTotal]
			  ,[ShipToName]
			  ,[ShipToCompany]
			  ,[ShipToAddressLine1]
			  ,[ShipToAddressLine2]
			  ,[ShipToCity]
			  ,[ShipToState]
			  ,[ShipToZipCode]
			  ,[ShipToCountry]
			  ,[ShipToPhone]
			  ,[ShippingMethod]
			  ,[ShipFromName]
			  ,[ShipFromCompany]
			  ,[ShipFromAddressLine1]
			  ,[ShipFromAddressLine2]
			  ,[ShipFromCity]
			  ,[ShipFromState]
			  ,[ShipFromZipCode]
			  ,[ShipFromCountry]
			  ,[ShipFromPhone]
			  ,[InternalNotes]
			  ,[PackingSlipNotes]
			  ,[OrderStatus]
			  ,[AttachmentPath]
			  ,[ShipToEmail]
			  ,[CartId]
			  ,[LabelStatus]
			  ,[CancelRequest]
		  FROM [Inventory].[dbo].[ResellerPortalOrder] 
		  WHERE [OrderDate] BETWEEN GETDATE()-9999 AND GETDATE()
		  AND [WebOrderNumber] NOT IN (SELECT [WebOrderNumber] FROM [Inventory].[dbo].[ResellerPortalOrderArchive])

  
		  INSERT INTO [Inventory].[dbo].[ResellerPortalOrderDetailsArchive] 
		  (
			  [WebOrderNumber]
			  ,[Id]
			  ,[ItemNumber]
			  ,[ItemLocalSKU]
			  ,[ItemTitle]
			  ,[ItemUnitPrice]
			  ,[ItemUnitShipping]
			  ,[ItemQuantityOrdered]
			  ,[ItemTotalShipping]
			  ,[ItemTotal]
			  ,[CustomerSKU]
			  ,[ResellerCustomerID]
			  ,[DSEconomyPrice]
			  ,[DS2ndDayPrice]
			  ,[DS1DayPrice]
		  )

		  SELECT [WebOrderNumber]
			  ,[Id]
			  ,[ItemNumber]
			  ,[ItemLocalSKU]
			  ,[ItemTitle]
			  ,[ItemUnitPrice]
			  ,[ItemUnitShipping]
			  ,[ItemQuantityOrdered]
			  ,[ItemTotalShipping]
			  ,[ItemTotal]
			  ,[CustomerSKU]
			  ,[ResellerCustomerID]
			  ,[DSEconomyPrice]
			  ,[DS2ndDayPrice]
			  ,[DS1DayPrice]
		  FROM [Inventory].[dbo].[ResellerPortalOrderDetails]
		  WHERE [WebOrderNumber] IN (SELECT [WebOrderNumber] FROM [Inventory].[dbo].[ResellerPortalOrderArchive])
		  AND [WebOrderNumber] NOT IN (SELECT [WebOrderNumber] FROM [Inventory].[dbo].[ResellerPortalOrderDetailsArchive])



		  --Delete from ResellerPortalOrder
		  DELETE FROM [Inventory].[dbo].[ResellerPortalOrder] 
		  WHERE [OrderDate] BETWEEN GETDATE()-9999 AND GETDATE()-60
		  AND [WebOrderNumber] IN (SELECT [WebOrderNumber] FROM [Inventory].[dbo].[ResellerPortalOrderArchive])
  
		  --Delete from ResellerPortalOrderDetails
		  DELETE RPOD FROM [Inventory].[dbo].[ResellerPortalOrderDetails] AS RPOD
		  LEFT OUTER JOIN [Inventory].[dbo].[ResellerPortalOrder] AS RPO ON (RPOD.[WebOrderNumber] = RPO.[WebOrderNumber])
		  WHERE RPOD.[WebOrderNumber] NOT IN (SELECT [WebOrderNumber] FROM [Inventory].[dbo].[ResellerPortalOrder])

END
go

