-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-10-14
-- Description:	Get History by FBA qty
-- =============================================
CREATE TRIGGER [dbo].[tr_AmazonFBA]
   ON [dbo].[AmazonFBA]
   AFTER INSERT,UPDATE
AS 
BEGIN
	DECLARE @MerchantSKU	NVARCHAR(50),
			@ASIN			NVARCHAR(50),
			@FNSKU			NVARCHAR(50),
			@MITSKU			INT,
			@FBAQty			INT,
			@FBAInboundQty	INT,
			@EnteredTime	DATE
	SET NOCOUNT ON;

    SELECT @MerchantSKU = MerchantSKU, @ASIN = ASIN, @FNSKU = FNSKU, @FBAQty = FBAQty, @FBAInboundQty = FBAInboundQty, @MITSKU = MITSKU, @EnteredTime = EnteredTime
	FROM inserted

	IF((SELECT COUNT(*) FROM Inventory.dbo.AmazonFBAHistory WITH(NOLOCK) WHERE MerchantSKU = @MerchantSKU AND ASIN = @ASIN AND FNSKU = @FNSKU AND EnteredTime = @EnteredTime AND MITSKU = @MITSKU) > 0)
	BEGIN
		IF(ISNULL(@MerchantSKU,'') <> '' AND ISNULL(@ASIN,'') <> '' AND ISNULL(@FNSKU,'') <> '' AND ISNULL(@MITSKU,0) <> 0 AND @EnteredTime IS NOT NULL AND @FBAQty IS NOT NULL AND @FBAInboundQty IS NOT NULL)
		BEGIN
			UPDATE Inventory.dbo.AmazonFBAHistory SET FBAQty = @FBAQty, FBAInboundQty = @FBAInboundQty
			WHERE MerchantSKU = @MerchantSKU AND ASIN = @ASIN AND FNSKU = @FNSKU AND EnteredTime = @EnteredTime AND MITSKU = @MITSKU
		END
	END
	ELSE
	BEGIN
		IF(ISNULL(@MerchantSKU,'') <> '' AND ISNULL(@ASIN,'') <> '' AND ISNULL(@FNSKU,'') <> '' AND ISNULL(@MITSKU,0) <> 0 AND @EnteredTime IS NOT NULL AND @FBAQty IS NOT NULL AND @FBAInboundQty IS NOT NULL)
		BEGIN
			INSERT INTO Inventory.dbo.AmazonFBAHistory (MerchantSKU,ASIN,FNSKU,FBAQty,FBAInboundQty,EnteredTime,MITSKU) VALUES (@MerchantSKU,@ASIN,@FNSKU,@FBAQty,@FBAInboundQty,@EnteredTime,@MITSKU)
		END
	END
END
go

disable trigger tr_AmazonFBA on [DELETE-AmazonFBA]
go

