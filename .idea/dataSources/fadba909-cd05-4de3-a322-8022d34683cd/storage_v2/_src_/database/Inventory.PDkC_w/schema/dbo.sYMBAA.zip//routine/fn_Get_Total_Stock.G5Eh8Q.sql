-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_Get_Total_Stock(@ProductId INT)
RETURNS decimal(18,6)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar decimal(18,6);

	-- Add the T-SQL statements to compute the return value here
	SET @ResultVar =  (SELECT TotalStock FROM Global_Stocks WHERE PRoductCatalogID = @productId);

	if @ResultVar is null
	BEGIN
		SET @ResultVar = 0;
	END

	-- Return the result of the function
	RETURN @ResultVar;
END
go

