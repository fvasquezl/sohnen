-- =============================================
-- Author:		Araceli Sánchez
-- Create date: 2016-03-30
-- Description:	Scan By Hour and Between Dates version to linq
-- =============================================
CREATE PROCEDURE [dbo].[sp_LampProductionScanByHourIILinq]
	@PROD_DATE	NVARCHAR(8)
AS
BEGIN
	SELECT 
	UPPER(REPLACE(PROD_LINE,'/','_')) PROD_LINE, 
	CONVERT(NVARCHAR(2),SCAN_DATETIME,108) HOUR, 
	COUNT(*) PIECES
	FROM 
	Inventory.dbo.LampProductionScan
	WHERE 
	CONVERT(NVARCHAR,SCAN_DATETIME,112) = @PROD_DATE
	GROUP BY PROD_LINE, 
	CONVERT(NVARCHAR(2),SCAN_DATETIME,108)
	ORDER BY PROD_LINE
END
go

