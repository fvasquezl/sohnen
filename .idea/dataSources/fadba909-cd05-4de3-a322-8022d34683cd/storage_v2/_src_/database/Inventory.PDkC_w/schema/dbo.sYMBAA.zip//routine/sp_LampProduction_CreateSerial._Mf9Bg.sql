-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_LampProduction_CreateSerial]
	@pSKU as varchar(10),@pLot as varchar(100), @pVendor as varchar(30), @pBurner as varchar(100), @pUserId as integer
AS
BEGIN
	
	SET NOCOUNT ON;
	DECLARE @lMITSerial as varchar(30);
	DECLARE @Length int;
	DECLARE @CharPool varchar(200);
	DECLARE @PoolLength int;
	DECLARE @RandomString varchar(200);
	DECLARE @LoopCount int;
	DECLARE @CMDstr varchar(200);
	DECLARE @ExistSTR int;
	DECLARE @LockCount int;
	DECLARE @MaxLoops2PreventServerLock int;
	DECLARE @PoolCharIndex int;
	DECLARe @LastID int;
	


	/* INIT All Variables*/
	SET @Length = 8;
	SET @LockCount = 0;
	SET @MaxLoops2PreventServerLock = 1000;
	SET @CharPool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
	SET @PoolLength = DataLength(@CharPool);
	SET @ExistSTR = 1;
	SET @RandomString = '';
	SET @LastID = 0;
	
	/*Generate the random serial number*/
	WHILE (@ExistSTR <> 0) and (@LockCount <  @MaxLoops2PreventServerLock  )
	BEGIN
			SET @LoopCount = 0
			WHILE (@LoopCount < @Length) 
			BEGIN
				SET @PoolCharIndex = CONVERT(int, RAND() * @PoolLength);
				IF @PoolCharIndex = 0
				BEGIN
					SET @PoolCharIndex = 1;
				END
				
				SELECT @RandomString = @RandomString + 	SUBSTRING(@Charpool,@PoolCharIndex , 1);
				SET @LoopCount = @LoopCount + 1
			END
	
			SET @ExistSTR = 0;
			SET @ExistSTR = (SELECT count(MITSerial)  FROM [Inventory].[dbo].[LampProduction] WHERE convert(varchar,MITSerial) =  @RandomString );
				
			IF @ExistSTR is null
			BEGIN
				SET @ExistSTR  = 0;
			END
			
			IF @ExistSTR > 0
			BEGIN
				SET @RandomString = '';
			END

			SET @LockCount = @LockCount + 1;
	END
	

	/* Insert the new lamp record*/
	IF @RandomString <> ''
	BEGIN
		INSERT INTO Inventory.dbo.LampProduction (ProductCatalogId, BurnerVendor, BurnerSerial, MITSerial, LotNumber, UserID, [date]) 
			VALUES (@psku, @pVendor, @pBurner, @RandomString, @pLot, @pUserID, getdate());

		SET @LastID = SCOPE_IDENTITY();


	END

	SELECT @LastID as LastID;
    
END
go

