
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[TRG_AmazonCompBelowMin_LOG]
   ON  [Inventory].[dbo].[AmazonCompBelowMin]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	insert into WebData.dbo.LogData (TimeStamp, OperationCode, Message)
	select getdate(), 5, 'INSERTED DATA FOR ASIN:' + ASIN from INSERTED
    -- Insert statements for trigger here

END

go

