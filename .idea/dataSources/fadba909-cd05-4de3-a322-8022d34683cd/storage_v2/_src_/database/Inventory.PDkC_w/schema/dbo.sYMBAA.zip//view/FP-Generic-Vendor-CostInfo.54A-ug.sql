CREATE VIEW dbo.[FP-Generic-Vendor-CostInfo]
AS
SELECT        dbo.ProductCatalog.ID, dbo.ProductCatalog.Name, dbo.Suppliers.SupplierSKU AS ArcliteSKU, dbo.Suppliers.UnitCost AS ArcLiteUnitCost, 
                         Suppliers_1.SupplierSKU AS GlorySKU, Suppliers_1.UnitCost AS GloryUnitCost, Suppliers_2.SupplierSKU AS ClpSKU, Suppliers_2.UnitCost AS ClpUnitCost, 
                         Suppliers_3.SupplierSKU AS GrandBulbsSKU, Suppliers_3.UnitCost AS GrandBulbsCost, Suppliers_4.SupplierSKU AS LeaderCoSKU, 
                         Suppliers_4.UnitCost AS LeaderCoCost, Suppliers_5.SupplierSKU AS MiTechSKU, Suppliers_5.UnitCost AS MiTechCost, Suppliers_6.SupplierSKU AS YitaSKU, 
                         Suppliers_6.UnitCost AS YitaCost, SUM(CAST(dbo.PurchaseOrderData.QtyBackOrdered AS INT)) AS Backorders
FROM            dbo.ProductCatalog INNER JOIN
                         dbo.Suppliers ON dbo.ProductCatalog.ID = dbo.Suppliers.ProductCatalogId INNER JOIN
                         dbo.Suppliers AS Suppliers_1 ON dbo.ProductCatalog.ID = Suppliers_1.ProductCatalogId INNER JOIN
                         dbo.Suppliers AS Suppliers_2 ON dbo.ProductCatalog.ID = Suppliers_2.ProductCatalogId INNER JOIN
                         dbo.Suppliers AS Suppliers_3 ON dbo.ProductCatalog.ID = Suppliers_3.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_4 ON dbo.ProductCatalog.ID = Suppliers_4.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_5 ON dbo.ProductCatalog.ID = Suppliers_5.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_6 ON dbo.ProductCatalog.ID = Suppliers_6.ProductCatalogId LEFT OUTER JOIN
                         dbo.PurchaseOrderData ON LEFT(CAST(dbo.ProductCatalog.ID AS nvarchar), 6) = LEFT(CAST(dbo.PurchaseOrderData.SKU AS nvarchar), 6)
WHERE        (dbo.Suppliers.SupplierID = '3') AND (Suppliers_1.SupplierID = '5') AND (Suppliers_2.SupplierID = '10') AND (Suppliers_3.SupplierID = '11') AND 
                         (dbo.ProductCatalog.CategoryID = '24') AND (Suppliers_4.SupplierID = '16') AND (Suppliers_5.SupplierID = '14') AND (Suppliers_6.SupplierID = '17')
GROUP BY dbo.ProductCatalog.ID, dbo.ProductCatalog.Name, dbo.Suppliers.SupplierSKU, dbo.Suppliers.UnitCost, Suppliers_1.SupplierSKU, Suppliers_1.UnitCost, 
                         Suppliers_2.SupplierSKU, Suppliers_2.UnitCost, Suppliers_3.SupplierSKU, Suppliers_3.UnitCost, Suppliers_4.SupplierSKU, Suppliers_4.UnitCost, 
                         Suppliers_5.SupplierSKU, Suppliers_5.UnitCost, Suppliers_6.SupplierSKU, Suppliers_6.UnitCost
go

