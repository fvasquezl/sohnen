-- =============================================
-- Author:		Jonathan Amezcua A.
-- Create date: 2018-11-30
-- Description:	Get Adapter models for apps3 Adapter Models Report
-- =============================================
CREATE PROCEDURE [dbo].[SP_GETADAPTERMODELS] 
	@MODELORMPN NVARCHAR(250),
	@AMP_OP NVARCHAR(5), -- [0: --, 1: =, 2: >=, 3: <=]
	@AMP_VAL DECIMAL(10,1),
	@WATTAGE_OP NVARCHAR(5), -- [0: --, 1: =, 2: >=, 3: <=]
	@WATTAGE_VAL INT,
	@VOLTAGE_OP NVARCHAR(5), -- [0: --, 1: =, 2: >=, 3: <=]
	@VOLTAGE_VAL INT,
	@PLUG_TYPE NVARCHAR(150),
	@GENDER NVARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @QUERY NVARCHAR(500)


	SET @QUERY = 'SELECT *, ''Edit''[Editar] FROM DBO.ADAPTERMODELS WHERE 1 = 1'
	IF(@MODELORMPN = '0' AND @AMP_OP = '0' AND @WATTAGE_OP = '0' AND @VOLTAGE_OP = '0' AND @PLUG_TYPE = '0' AND @GENDER = '0')
	BEGIN

		EXEC(@QUERY)

	END
	ELSE
	BEGIN

		IF(@MODELORMPN <> '0')
			SET @QUERY = @QUERY + ' AND (MODEL LIKE ''%'+@MODELORMPN+'%'' OR ADAPTERMPN LIKE ''%'+@MODELORMPN+'%'')'

		IF(@AMP_OP <> '0')
			SET @QUERY = @QUERY + ' AND AMP ' + CAST(@AMP_OP AS NVARCHAR) + ' ' +CAST(@AMP_VAL AS NVARCHAR)

		IF(@WATTAGE_OP <> '0')
			SET @QUERY = @QUERY + ' AND WATTAGE ' + CAST(@WATTAGE_OP AS NVARCHAR) + ' ' +CAST(@WATTAGE_VAL AS NVARCHAR)

		IF(@VOLTAGE_OP <> '0')
			SET @QUERY = @QUERY + ' AND VOLTAGE ' + CAST(@VOLTAGE_OP AS NVARCHAR) + ' ' +CAST(@VOLTAGE_VAL AS NVARCHAR)

		IF(@PLUG_TYPE <> '0')
			SET @QUERY = @QUERY + ' AND PLUGTYPE = ''' + @PLUG_TYPE + ''''

		IF(@GENDER <> '0')
			SET @QUERY = @QUERY + ' AND GENDER = ''' + @GENDER + ''''

		EXEC(@QUERY)
	END

END
go

