CREATE VIEW [dbo]._dta_mv_68   AS SELECT  [dbo].[AmazonSearchDATA].[ASIN] as _col_1,  [dbo].[AmazonSearchDATA].[StatusUserID] as _col_2,  [dbo].[AmazonSearchDATA].[Brand] as _col_3,  [dbo].[AmazonSearchDATA].[CountryCode] as _col_4,  [dbo].[AmazonSearchDATA].[Status] as _col_5,  count_big(*) as _col_6 FROM  [dbo].[AmazonSearchDATA]   GROUP BY  [dbo].[AmazonSearchDATA].[ASIN],  [dbo].[AmazonSearchDATA].[StatusUserID],  [dbo].[AmazonSearchDATA].[Brand],  [dbo].[AmazonSearchDATA].[CountryCode],  [dbo].[AmazonSearchDATA].[Status]
go

