CREATE VIEW [dbo]._dta_mv_103   AS SELECT  [dbo].[Global_Stocks].[GlobalStock] as _col_1,  [dbo].[Global_Stocks].[VirtualStock] as _col_2,  [dbo].[ProductCatalog].[ID] as _col_3,  [dbo].[ProductCatalog].[Manufacturer] as _col_4,  [dbo].[ProductCatalog].[Name] as _col_5,  [dbo].[Global_Stocks].[TotalStock] as _col_6,  [dbo].[Global_Stocks].[id] as _col_7 FROM  [dbo].[ProductCatalog],  [dbo].[Global_Stocks]   WHERE  [dbo].[ProductCatalog].[ID] = [dbo].[Global_Stocks].[ProductCatalogId]  AND  [dbo].[ProductCatalog].[ID] like '%104014%'
go

