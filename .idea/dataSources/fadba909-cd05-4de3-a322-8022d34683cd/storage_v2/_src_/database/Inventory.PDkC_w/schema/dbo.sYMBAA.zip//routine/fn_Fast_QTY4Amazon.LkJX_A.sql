-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date, ,>
-- Description:	Returns stock  quantity (Or 500 when AlwaysInStock and some categories compliant conditions)
-- =============================================
CREATE FUNCTION [dbo].[fn_Fast_QTY4Amazon]
(
	@pSKU varchar(255)
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @SetQuantity int;
	DECLARE @ParentID int;
	DECLARE @AlwaysInStock as int;
	DECLARE @TotalStock as int;

	SET @SetQuantity = 0;
	SET @AlwaysInStock = 0;



	SET @ParentID = inventory.dbo.fn_GetCategories_ParentID(@pSKU);
	
	SET @TotalStock = inventory.dbo.fn_Get_Total_Stock(@pSKU);
	
	SELECT @AlwaysInStock =  a.AlwaysInStock from Inventory.dbo.ProductCatalog a
	where a.id =@pSKU
	


	IF  @AlwaysInStock is null
	BEGIN
			SET @AlwaysInStock = 0;
	END
	


	SELECT  @SetQuantity =
							(CASE 
								WHEN @ParentID IN (1,2,3,4)   AND @AlwaysInStock = 1 THEN '500' 
								WHEN @ParentID IN (0,1,2,3,4) AND @AlwaysInStock = 0 THEN  @TotalStock
	
						
								ELSE
									 @TotalStock
								END
							) ;

	-- Return the result of the function
	RETURN @SetQuantity

END
go

