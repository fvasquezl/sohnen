-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-05-21
-- Description:	Convert to HTML UTF8 and send to dbo.fn_convert_utf8
-- =============================================
CREATE FUNCTION fn_return_convert_utf8
(@Text NVARCHAR(1))
RETURNS
@tblconvert_utf8 TABLE 
(
	HTMLNUmber NVARCHAR(MAX), TextOrSimbol NVARCHAR(MAX) 
) 
AS
BEGIN	
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&aacute;','á')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&eacute;','é')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&iacute;','í')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&oacute;','ó')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&uacute;','ú')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&ntilde;','ñ')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&Aacute;','Á')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&Eacute;','É')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&Iacute;','Í')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&Oacute;','Ó')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&Uacute;','Ú')
	INSERT INTO @tblconvert_utf8 (HTMLNUmber,TextOrSimbol)
	VALUES ('&Ntilde;','Ñ')

	RETURN
END
go

