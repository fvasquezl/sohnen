-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tr_ResellerPortalOrder_Insert]
   ON  [dbo].[ResellerPortalOrder]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @ShipFromName varchar(255);
	DECLARE @ShipFromCompany varchar(255);
	DECLARE @ShipFromAddressLine1 varchar(255);
	DECLARE @ShipFromAddressLine2 varchar(255);
	DECLARE @ShipFromCity varchar(255);
	DECLARE @ShipFromState varchar(255);
	DECLARE @ShipFromZipCode varchar(255);
	DECLARE @ShipFromCountry varchar(255);
	DECLARE @ShipFromPhone varchar(255);
	DECLARE @InternalNotes varchar(255);
	DECLARE @PackingSlipNotes varchar(255);
	DECLARE @cid integer;
	DECLARE @woid integer;
	DECLARE @countrycode varchar(255);
	DECLARE @ShippingMethod varchar(255);
	
    
    
    SELECT @cid = inserted.ResellerCustomerID
			, @woid = inserted.WebOrderNumber
     FROM inserted;
		
	---Get values from order manager	
    SELECT 
		@ShipFromName = a.FullName
		, @ShipFromCompany = a.Company
		, @ShipFromAddressLine1 = a.Address
		, @ShipFromAddressLine2	 = a.Address2
		, @ShipFromCity = a.City
		, @ShipFromState = a.State
		, @ShipFromZipCode = a.Zip
		, @ShipFromCountry = a.Country
		, @ShipFromPhone = a.Phone
	FROM OrderManager.dbo.Customers a WHERE a.CustomerID = @cid;  
	
	
	-- Get the country code
	SELECT @countrycode = code from [OrderManager].[dbo].[Countries] 
			WHERE  Country =  @ShipFromCountry;
	
	
	-- Set default ShippingMethod
	SET @ShippingMethod = 'Standard (5-7 Business Days)';
	
	UPDATE inventory.dbo.ResellerPortalOrder SET
		  ShippingMethod = @ShippingMethod	
		, ShipFromName = @ShipFromName 
		, ShipFromCompany =  @ShipFromCompany
		, ShipFromAddressLine1 =  @ShipFromAddressLine1 
	    , ShipFromAddressLine2 = @ShipFromAddressLine2
	    , ShipFromCity = @ShipFromCity
	    , ShipFromState = @ShipFromState
	    , ShipFromZipCode = @ShipFromZipCode
	    , ShipFromCountry = @countrycode 
	    , ShipFromPhone = @ShipFromPhone
	WHERE WebOrderNumber = @woid;
	
END
go

