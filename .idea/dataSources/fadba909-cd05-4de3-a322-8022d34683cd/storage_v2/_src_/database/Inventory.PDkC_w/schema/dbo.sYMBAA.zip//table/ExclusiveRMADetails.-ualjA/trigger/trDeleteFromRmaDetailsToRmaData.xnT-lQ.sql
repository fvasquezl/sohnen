-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trDeleteFromRmaDetailsToRmaData]
   ON [Inventory].[dbo].[ExclusiveRMADetails] 
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	DELETE FROM Inventory.dbo.RMAReturnData WHERE RMAnumber IN (select RMAnumber from deleted) AND SKU in (select WrongSKU from deleted) AND isExclusiveBulbs = 1;

END
go

