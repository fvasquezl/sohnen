CREATE VIEW [dbo]._dta_mv_64   AS SELECT  [dbo].[AmazonSearchDATA].[ASIN] as _col_1,  [dbo].[AmazonSearchDATA].[Brand] as _col_2,  [dbo].[AmazonSearchDATA].[CountryCode] as _col_3,  count_big(*) as _col_4 FROM  [dbo].[AmazonSearchDATA]   GROUP BY  [dbo].[AmazonSearchDATA].[ASIN],  [dbo].[AmazonSearchDATA].[Brand],  [dbo].[AmazonSearchDATA].[CountryCode]
go

