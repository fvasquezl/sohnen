CREATE VIEW [dbo]._dta_mv_16 WITH SCHEMABINDING AS SELECT  [dbo].[Global_Stocks].[ProductCatalogId] as _col_1,  count_big(*) as _col_2 FROM  [dbo].[Global_Stocks]  GROUP BY  [dbo].[Global_Stocks].[ProductCatalogId]
go

