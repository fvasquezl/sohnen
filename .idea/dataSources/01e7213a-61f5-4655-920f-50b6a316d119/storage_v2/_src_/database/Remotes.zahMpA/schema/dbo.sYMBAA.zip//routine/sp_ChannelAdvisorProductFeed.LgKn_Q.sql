-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-8-2018
-- Description:	ChannelAdvisor Product Feed
-- =============================================
CREATE PROCEDURE [dbo].[sp_ChannelAdvisorProductFeed] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		IF OBJECT_ID('tempdb..#TempTable') IS NOT NULL DROP TABLE #TempTable 
		IF OBJECT_ID('tempdb..#TempSKUData') IS NOT NULL DROP TABLE #TempSKUData 
		

		CREATE TABLE #TempTable ([ID] int, [Inventory Number] nvarchar(max),[Auction Title] nvarchar(255),[Quantity Update Type] nvarchar(max),[Quantity] int,[Length] decimal(10,2),[Height] decimal(10,2),[Width] decimal(10,2),[Weight] nvarchar(max), [MPN] nvarchar(255),[Short Description] nvarchar(max),[Description] nvarchar(max)
		,[Manufacturer] nvarchar(40),[Brand] nvarchar(40),[Condition] nvarchar(max),[Warranty] nvarchar(max),[Seller Cost] nvarchar(max),[Buy It Now Price] nvarchar(max),[Retail Price] nvarchar(max),[Picture URLs] nvarchar(max),[Description Template Name] nvarchar(max)
		,[Posting Template Name] nvarchar(max),[Schedule Name] nvarchar(max),[eBay Category List] nvarchar(max),[eBay Store Category Name] nvarchar(max),[Labels] nvarchar(max),[Classification] nvarchar(max),[Attribute1Name] nvarchar(max),[Attribute1Value] nvarchar(max)
		,[Attribute2Name] nvarchar(max),[Attribute2Value] nvarchar(max),[Attribute3Name] nvarchar(max),[Attribute3Value] nvarchar(max),[Attribute4Name] nvarchar(max),[Attribute4Value] nvarchar(max),[Attribute5Name] nvarchar(max),[Attribute5Value] nvarchar(max)
		,[Attribute6Name] nvarchar(max),[Attribute6Value] nvarchar(max),[Attribute7Name] nvarchar(max),[Attribute7Value] nvarchar(max),[Attribute8Name] nvarchar(max),[Attribute8Value] nvarchar(max),[Attribute9Name] nvarchar(max),[Attribute9Value] nvarchar(max)
		,[Attribute10Name] nvarchar(max),[Attribute10Value] nvarchar(max),[Attribute11Name] nvarchar(max),[Attribute11Value] nvarchar(max),[Attribute12Name] nvarchar(max),[Attribute12Value] nvarchar(max),[Attribute13Name] nvarchar(max),[Attribute13Value] nvarchar(max)
		,[Attribute14Name] nvarchar(max),[Attribute14Value] nvarchar(max),[Attribute15Name] nvarchar(max),[Attribute15Value] nvarchar(max))

		--I am storing SKUData Table with LeftJoin to Categories Table in memory so we don't keep calling it.
		CREATE TABLE #TempSKUData ([SKU] [nvarchar](50) NOT NULL,
				[Manufacturer] [nvarchar](50) NULL,
				[PartNumber] [nvarchar](250) NULL,
				[AlsoCompatibleWith] [nvarchar](max) NULL,
				[AlternatePN] [nvarchar](max) NULL,
				[ResearchComplete] [bit] NULL,
				[Length] [decimal](10, 2) NULL,
				[Width] [decimal](10, 2) NULL,
				[Height] [decimal](10, 2) NULL,
				[WeightOz] [decimal](10, 2) NULL,
				[FloorPrice] [decimal](10, 2) NULL,
				[CeilingPrice] [decimal](10, 2) NULL,
				[updated_at] [datetime] NULL,
				[deleted_at] [datetime] NULL,
				[created_at] [datetime] NULL,
				[Amazon] [bit] NULL,
				[eBay] [bit] NULL,
				[CategoryID] [int] NULL,
				[OriginallySuppliedWith] [nvarchar](max) NULL,
				[CanReplaceSKUs] [nvarchar](max) NULL,
				[HaveCNVariant] [bit] NULL,
				[UnitCost] [decimal](10, 2) NULL,
				[UnitCostCN] [decimal](10, 2) NULL,
				[UnitCostUSED] [decimal](10, 2) NULL,
				[FloorPriceCN] [decimal](10, 2) NULL,
				[CeilingPriceCN] [decimal](10, 2) NULL,
				[FloorPriceUSED] [decimal](10, 2) NULL,
				[CeilingPriceUSED] [decimal](10, 2) NULL,
				[FloorPriceEU] [decimal](10, 2) NULL,
				[CeilingPriceEU] [decimal](10, 2) NULL,
				[CategoryName] [nvarchar](100) NULL,
				[Sellable] [bit] NULL
				)

		INSERT INTO #TempSKUData
		SELECT	  SKUD.[SKU]
				  ,SKUD.[Manufacturer]
				  ,SKUD.[PartNumber]
				  ,SKUD.[AlsoCompatibleWith]
				  ,SKUD.[AlternatePN]
				  ,SKUD.[ResearchComplete]
				  ,SKUD.[Length]
				  ,SKUD.[Width]
				  ,SKUD.[Height]
				  ,SKUD.[WeightOz]
				  ,SKUD.[FloorPrice]
				  ,SKUD.[CeilingPrice]
				  ,SKUD.[updated_at]
				  ,SKUD.[deleted_at]
				  ,SKUD.[created_at]
				  ,SKUD.[Amazon]
				  ,SKUD.[eBay]
				  ,SKUD.[CategoryID]
				  ,SKUD.[OriginallySuppliedWith]
				  ,SKUD.[CanReplaceSKUs]
				  ,SKUD.[HaveCNVariant]
				  ,SKUD.[UnitCost]
				  ,SKUD.[UnitCostCN]
				  ,SKUD.[UnitCostUSED]
				  ,SKUD.[FloorPriceCN]
				  ,SKUD.[CeilingPriceCN]
				  ,SKUD.[FloorPriceUSED]
				  ,SKUD.[CeilingPriceUSED]
				  ,SKUD.[FloorPriceEU]
				  ,SKUD.[CeilingPriceEU]
				  ,CAT.[CategoryName]
				  ,CAT.[Sellable]
		FROM [Remotes].[dbo].[SKUData] AS SKUD  WITH (NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT ON (SKUD.[CategoryID] = CAT.[CategoryID])



		/**
		--CLEAR TABLE script - BE CAREFUL, DELETES EVERYTHING AND RESETS SEED.. WILL CAUSE STUFF TO NOT MATCH PREVIOUS DATA IF ALREADY LOADED TO CHANNEL ADVISOR!
		DELETE FROM [Remotes].[dbo].[ChannelAdvisor]
		DBCC CHECKIDENT ('[Remotes].[dbo].[ChannelAdvisor]', RESEED, 1)
		UPDATE [Remotes].[dbo].[UPC] SET [Inventory Number] = NULL
		**/


		DECLARE @Condition NVARCHAR(20)

		---------------------------
		------REMOTES - Part Specific CN-------
				SET @Condition = 'CN'

				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				[SKU]+'-'+LTRIM(RTRIM([PartNumber]))+'-'+@Condition AS [ItemNumber],

				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Replacement TV Remote Control  for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Television')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Replacement CD Player Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Replacement DVD Player Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Replacement BluRay Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Replacement Audio Receiver Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Replacement Sound Bar Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Replacement Home Theater Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + 'HTIB')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Replacement Air Conditioner Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' AC A/C')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Replacement Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				ELSE
				'Replacement Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				END
				)
				AS [Auction Title],
		
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) AS [Quantity],
				IsNull(SKUD.[Length],0) AS [Length],
				IsNull(SKUD.[Height],0) AS [Height],
				IsNull(SKUD.[Width],0) AS [Width],
				IsNull(SKUD.[WeightOz],0) AS [Weight],
				[PartNumber]+'-'+@Condition AS [MPN],

				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Replacement TV Remote Control  for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Television')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Replacement CD Player Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Replacement DVD Player Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Replacement BluRay Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Replacement Audio Receiver Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Replacement Sound Bar Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Replacement Home Theater Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + 'HTIB')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Replacement Air Conditioner Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' AC A/C')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Replacement Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				ELSE
				'Replacement Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				END
				)
				 AS [Short Description],
		
		
				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Replacement TV Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Television')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Replacement CD Player Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Replacement DVD Player Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Replacement BluRay Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Replacement Audio Receiver Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Replacement Sound Bar Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Replacement Home Theater Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + 'HTIB')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Replacement Air Conditioner Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' AC A/C')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Replacement Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				ELSE
				'Replacement Remote Control for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))
				END
				)
				AS [Description],
		
				'Aurabeam' AS [Manufacturer],
				'Aurabeam' AS [Brand],
				'New' AS [Condition],
				'1 Year' AS [Warranty],
				IsNull(SKUD.[UnitCostCN],0) AS [Seller Cost],
				IsNull(SKUD.[CeilingPriceCN],'89.99') AS [Buy It Now Price],
				IsNULL(CEILING(SKUD.[CeilingPriceCN]*2)-0.01,'89.99') AS [Retail Price],
				IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'07.jpg'
				OR RIGHT([name],'6') LIKE '%'+'08.jpg'
				OR RIGHT([name],'6') LIKE '%'+'09.jpg'
				OR RIGHT([name],'6') LIKE '%'+'10.jpg'
				OR RIGHT([name],'6') LIKE '%'+'11.jpg'
				OR RIGHT([name],'6') LIKE '%'+'12.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'Walmart Marketplace' AS [Labels],
				'Remote Control' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				SKUD.[SKU]+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'PartNumberSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				SKUD.CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				IsNull(SKUD.[FloorPriceCN], IsNull(SKUD.[CeilingPriceCN],'89.99')) AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				SKUD.[Manufacturer] AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				IsNull(SKUD.[OriginallySuppliedWith],'') AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				IsNull(SKUD.[AlsoCompatibleWith],'') AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]
				FROM #TempSKUData AS SKUD
				WHERE SKUD.[SKU] IS NOT NULL 
				AND SKUD.[PartNumber] IS NOT NULL
				--Remote Controls
				AND SKUD.[CategoryID] IN ('1101','1102','1103','1104','1105','1106','1107','1108','1109')
				AND SKUD.[HaveCNVariant] = '1'


				PRINT 'Remotes PartNumber Specific CN - Completed at '+CAST(GETDATE() AS NVARCHAR(50))

		---------------------------
		------REMOTES - Part Specific NEW OEM-------
				SET @Condition = 'NEW'

				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				[SKU]+'-'+LTRIM(RTRIM([PartNumber]))+'-'+@Condition AS [ItemNumber],

				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Remote Control Television')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' CD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' DVD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' BluRay Remote Control'
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Audio Receiver Remote Control'
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Sound Bar Remote Control'
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Home Theater Remote Control HTIB')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Air Conditioner Remote Control AC A/C')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				ELSE
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				END
				)
				AS [Auction Title],
		
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) AS [Quantity],
				IsNull(SKUD.[Length],0) AS [Length],
				IsNull(SKUD.[Height],0) AS [Height],
				IsNull(SKUD.[Width],0) AS [Width],
				IsNull(SKUD.[WeightOz],0) AS [Weight],
				[PartNumber]+'-'+@Condition AS [MPN],

				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Remote Control Television')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' CD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' DVD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' BluRay Remote Control'
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Audio Receiver Remote Control'
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Sound Bar Remote Control'
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Home Theater Remote Control HTIB')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Air Conditioner Remote Control AC A/C')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				ELSE
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				END
				)
				 AS [Short Description],
		
		
				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Remote Control Television')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' CD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' DVD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' BluRay Remote Control'
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Audio Receiver Remote Control'
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Sound Bar Remote Control'
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Home Theater Remote Control HTIB')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Air Conditioner Remote Control AC A/C')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				ELSE
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				END
				)
				AS [Description],
		
				SKUD.[Manufacturer] AS [Manufacturer],
				SKUD.[Manufacturer] AS [Brand],
				'New' AS [Condition],
				'1 Year' AS [Warranty],
				IsNull(SKUD.[UnitCost],0) AS [Seller Cost],
				IsNull([CeilingPrice],'89.99') AS [Buy It Now Price],
				IsNULL(CEILING([CeilingPrice]*2)-0.01,'89.99') AS [Retail Price],
				IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				)   ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'Walmart Marketplace' AS [Labels],
				'Remote Control' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				SKUD.[SKU]+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'PartNumberSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				SKUD.CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				IsNull(SKUD.[FloorPrice], IsNull(SKUD.[CeilingPrice],'89.99')) AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				SKUD.[Manufacturer] AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				IsNull(SKUD.[OriginallySuppliedWith],'') AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				IsNull(SKUD.[AlsoCompatibleWith],'') AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM #TempSKUData AS SKUD
				
				WHERE SKUD.[SKU] IS NOT NULL 
				AND SKUD.[PartNumber] IS NOT NULL
				--Remote Controls
				AND SKUD.[CategoryID] IN ('1101','1102','1103','1104','1105','1106','1107','1108','1109')
				AND [Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) > 0


				PRINT 'Remotes PartNumber Specific NEW OEM - Completed at '+CAST(GETDATE() AS NVARCHAR(50))

		---------------------------
		------REMOTES - Part Specific USED OEM-------
				SET @Condition = 'USED'

				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				[SKU]+'-'+LTRIM(RTRIM([PartNumber]))+'-'+@Condition AS [ItemNumber],

				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Remote Control Television')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' CD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' DVD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' BluRay Remote Control'
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Audio Receiver Remote Control'
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Sound Bar Remote Control'
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Home Theater Remote Control HTIB')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Air Conditioner Remote Control AC A/C')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				ELSE
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				END
				)
				AS [Auction Title],
		
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) AS [Quantity],
				IsNull(SKUD.[Length],0) AS [Length],
				IsNull(SKUD.[Height],0) AS [Height],
				IsNull(SKUD.[Width],0) AS [Width],
				IsNull(SKUD.[WeightOz],0) AS [Weight],
				[PartNumber]+'-'+@Condition AS [MPN],

				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Remote Control Television. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' CD Player Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' DVD Player Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' BluRay Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Audio Receiver Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Sound Bar Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Home Theater Remote Control HTIB. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Air Conditioner Remote Control AC A/C. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				ELSE
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				END
				)
				 AS [Short Description],
		
		
				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Remote Control Television. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' CD Player Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' DVD Player Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' BluRay Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Audio Receiver Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Sound Bar Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Home Theater Remote Control HTIB. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Air Conditioner Remote Control AC A/C. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				ELSE
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				END
				)
				AS [Description],
		
				SKUD.[Manufacturer] AS [Manufacturer],
				SKUD.[Manufacturer] AS [Brand],
				'USED' AS [Condition],
				'1 Year' AS [Warranty],
				IsNull(SKUD.[UnitCostUSED],0) AS [Seller Cost],
				IsNull([CeilingPriceUSED],'89.99') AS [Buy It Now Price],
				IsNULL(CEILING([CeilingPriceUSED]*2)-0.01,'89.99') AS [Retail Price],
				IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'' AS [Labels],
				'Remote Control' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				SKUD.[SKU]+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'PartNumberSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				SKUD.CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				IsNull(SKUD.[FloorPriceUSED], IsNull(SKUD.[CeilingPriceUSED],'89.99')) AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				SKUD.[Manufacturer] AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				IsNull(SKUD.[OriginallySuppliedWith],'') AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				IsNull(SKUD.[AlsoCompatibleWith],'') AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM #TempSKUData AS SKUD
				
				WHERE SKUD.[SKU] IS NOT NULL 
				AND SKUD.[PartNumber] IS NOT NULL
				--Remote Controls
				AND SKUD.[CategoryID] IN ('1101','1102','1103','1104','1105','1106','1107','1108','1109')
				AND [Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) > 0

				PRINT 'Remotes PartNumber Specific USED OEM - Completed at '+CAST(GETDATE() AS NVARCHAR(50))


		------REMOTES - Part Specific NO COVER OEM-------
				SET @Condition = 'NC'

				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				[SKU]+'-'+LTRIM(RTRIM([PartNumber]))+'-'+@Condition AS [ItemNumber],

				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Remote Control Television')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' CD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1103' THEN
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' DVD Player Remote Control'
				WHEN SKUD.[CategoryID] = '1104' THEN
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' BluRay Remote Control'
				WHEN SKUD.[CategoryID] = '1105' THEN
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Audio Receiver Remote Control'
				WHEN SKUD.[CategoryID] = '1106' THEN
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Sound Bar Remote Control'
				WHEN SKUD.[CategoryID] = '1107' THEN
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Home Theater Remote Control HTIB')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Air Conditioner Remote Control AC A/C')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				ELSE
				'(No Cover) Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control'
				END
				)
				AS [Auction Title],
		
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) AS [Quantity],
				IsNull(SKUD.[Length],0) AS [Length],
				IsNull(SKUD.[Height],0) AS [Height],
				IsNull(SKUD.[Width],0) AS [Width],
				IsNull(SKUD.[WeightOz],0) AS [Weight],
				[PartNumber]+'-'+@Condition AS [MPN],

				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Remote Control Television. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' CD Player Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' DVD Player Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' BluRay Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Audio Receiver Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Sound Bar Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Home Theater Remote Control HTIB. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Air Conditioner Remote Control AC A/C. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				ELSE
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				END
				)
				 AS [Short Description],
		
		
				(CASE 
				WHEN SKUD.[CategoryID] = '1101' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Remote Control Television. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN SKUD.[CategoryID] = '1102' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' CD Player Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1103' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' DVD Player Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1104' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' BluRay Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1105' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Audio Receiver Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1106' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) +  ' Sound Bar Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				WHEN SKUD.[CategoryID] = '1107' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Home Theater Remote Control HTIB. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN SKUD.[CategoryID] = '1108' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' Air Conditioner Remote Control AC A/C. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN SKUD.[CategoryID] = '1109' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				ELSE
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Remote Control. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'
				END
				)
				AS [Description],
		
				SKUD.[Manufacturer] AS [Manufacturer],
				SKUD.[Manufacturer] AS [Brand],
				'USED' AS [Condition],
				'1 Year' AS [Warranty],
				IsNull(SKUD.[UnitCostUSED],0) AS [Seller Cost],
				IsNull([CeilingPriceUSED]*0.75,'89.99') AS [Buy It Now Price],
				IsNULL(CEILING([CeilingPriceUSED]*2)-0.01,'89.99') AS [Retail Price],
				'http://remotespict.mitechnologiesinc.com/NOCOVER/nc.jpg,'+IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'' AS [Labels],
				'Remote Control' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				SKUD.[SKU]+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'PartNumberSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				SKUD.CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				IsNull(SKUD.[FloorPriceUSED], IsNull(SKUD.[CeilingPriceUSED],'89.99')) AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				SKUD.[Manufacturer] AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				IsNull(SKUD.[OriginallySuppliedWith],'') AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				IsNull(SKUD.[AlsoCompatibleWith],'') AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM #TempSKUData AS SKUD
				
				WHERE SKUD.[SKU] IS NOT NULL 
				AND SKUD.[PartNumber] IS NOT NULL
				--Remote Controls
				AND SKUD.[CategoryID] IN ('1101','1102','1103','1104','1105','1106','1107','1108','1109')
				AND [Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) > 0

				PRINT 'Remotes PartNumber Specific NO COVER OEM - Completed at '+CAST(GETDATE() AS NVARCHAR(50))
				
		---------------------------
		------TV STANDS - NEW-------
				SET @Condition = 'NEW'

				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				 --DECLARE @Condition NVARCHAR(MAX)
				 --SET @Condition = 'NEW'

				SELECT DISTINCT
				'' AS [ID],
				[SKU]+'-'+LTRIM(RTRIM([PartNumber]))+'-'+@Condition AS [ItemNumber],

				'Factory Original TV Stand for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))+ ' Television'
				AS [Auction Title],
		
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) AS [Quantity],
				IsNull(SKUD.[Length],0) AS [Length],
				IsNull(SKUD.[Height],0) AS [Height],
				IsNull(SKUD.[Width],0) AS [Width],
				IsNull(SKUD.[WeightOz],0) AS [Weight],
				[PartNumber]+'-'+@Condition AS [MPN],

				'Factory Original TV Stand for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))+ ' Television.  DOES NOT INCLUDE SCREWS OR INSTALLATION HARDWARE.  The screws are typically supplied with the Television and replacements can be found at your local hardware store.'
				 AS [Short Description],
		
		
				'Factory Original TV Stand for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))+ ' Television.  DOES NOT INCLUDE SCREWS OR INSTALLATION HARDWARE.  The screws are typically supplied with the Television and replacements can be found at your local hardware store.'
				AS [Description],
		
				SKUD.[Manufacturer] AS [Manufacturer],
				SKUD.[Manufacturer] AS [Brand],
				'New' AS [Condition],
				'1 Year' AS [Warranty],
				IsNull(SKUD.[UnitCost],0) AS [Seller Cost],
				IsNull(SKUD.[CeilingPrice],'89.99') AS [Buy It Now Price],
				IsNULL(CEILING(SKUD.[CeilingPrice]*2)-0.01,'89.99') AS [Retail Price],
				IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'Walmart Marketplace' AS [Labels],
				'TV Stand' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				SKUD.[SKU]+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'PartNumberSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				SKUD.CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				IsNull(SKUD.[FloorPrice], IsNull(SKUD.[CeilingPrice],'89.99')) AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				SKUD.[Manufacturer] AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				IsNull(SKUD.[OriginallySuppliedWith],'') AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				IsNull(SKUD.[AlsoCompatibleWith],'') AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM #TempSKUData AS SKUD
				
				WHERE SKUD.[SKU] IS NOT NULL 
				AND SKUD.[PartNumber] IS NOT NULL
				--TV STANDS
				AND SKUD.[CategoryID] IN ('1501')
				AND [Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) > 0


				PRINT 'TV Stands PartNumber NEW - Completed at '+CAST(GETDATE() AS NVARCHAR(50))

			---------------------------
			------TV STANDS - USED-------
				SET @Condition = 'USED'

				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])

				 --DECLARE @Condition NVARCHAR(MAX)
				 --SET @Condition = 'USED'

				SELECT DISTINCT
				'' AS [ID],
				[SKU]+'-'+LTRIM(RTRIM([PartNumber]))+'-'+@Condition AS [ItemNumber],

				'Factory Original TV Stand for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))+ ' Television'
				AS [Auction Title],
		
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) AS [Quantity],
				IsNull(SKUD.[Length],0) AS [Length],
				IsNull(SKUD.[Height],0) AS [Height],
				IsNull(SKUD.[Width],0) AS [Width],
				IsNull(SKUD.[WeightOz],0) AS [Weight],
				[PartNumber]+'-'+@Condition AS [MPN],

				'Factory Original TV Stand for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))+ ' Television.  DOES NOT INCLUDE SCREWS OR INSTALLATION HARDWARE.  The screws are typically supplied with the Television and replacements can be found at your local hardware store. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				 AS [Short Description],
		
		
				'Factory Original TV Stand for ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]))+ ' Television.  DOES NOT INCLUDE SCREWS OR INSTALLATION HARDWARE.  The screws are typically supplied with the Television and replacements can be found at your local hardware store. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'
				AS [Description],
		
				SKUD.[Manufacturer] AS [Manufacturer],
				SKUD.[Manufacturer] AS [Brand],
				'USED' AS [Condition],
				'1 Year' AS [Warranty],
				IsNull(SKUD.[UnitCostUSED],0) AS [Seller Cost],
				IsNull(SKUD.[CeilingPriceUSED],'89.99') AS [Buy It Now Price],
				IsNULL(CEILING(SKUD.[CeilingPriceUSED]*2)-0.01,'89.99') AS [Retail Price],
				IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'' AS [Labels],
				'TV Stand' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				SKUD.[SKU]+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'PartNumberSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				SKUD.CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				IsNull(SKUD.[FloorPriceUSED], IsNull(SKUD.[CeilingPriceUSED],'89.99')) AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				SKUD.[Manufacturer] AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				IsNull(SKUD.[OriginallySuppliedWith],'') AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				IsNull(SKUD.[AlsoCompatibleWith],'') AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM #TempSKUData AS SKUD
				
				WHERE SKUD.[SKU] IS NOT NULL 
				AND SKUD.[PartNumber] IS NOT NULL
				--TV STANDS
				AND SKUD.[CategoryID] IN ('1501')
				AND [Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) > 0

				PRINT 'TV Stands PartNumber USED - Completed at '+CAST(GETDATE() AS NVARCHAR(50))

	------------------------------
	------POWER ADAPTERS, CABLES, AND ONE CONNECT PARTNUMBER SPECIFIC - NEW -------
				SET @Condition = 'NEW'

				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				[SKU]+'-'+LTRIM(RTRIM([PartNumber]))+'-'+@Condition AS [ItemNumber],

				(CASE 
				WHEN SKUD.[CategoryID] = '1401' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV One Connect Box for Television (No Cable)')
				WHEN SKUD.[CategoryID] = '1305' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' TV One Connect Cable for Television'
				WHEN SKUD.[CategoryID] = '1201' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN SKUD.[CategoryID] = '1202' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN SKUD.[CategoryID] = '1203' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1204' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN SKUD.[CategoryID] = '1205' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1206' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1207' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1301' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Cable Cord'
				WHEN SKUD.[CategoryID] = '1302' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Audio Video Cable A/V Cord'
				WHEN SKUD.[CategoryID] = '1303' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Specialty Cable Cord'
				WHEN SKUD.[CategoryID] = '1304' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cable Cord'
				ELSE
				[Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' ' + CAT.[CategoryName]
				END
				)
				AS [Auction Title],
		
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) AS [Quantity],
				IsNull(SKUD.[Length],0) AS [Length],
				IsNull(SKUD.[Height],0) AS [Height],
				IsNull(SKUD.[Width],0) AS [Width],
				IsNull(SKUD.[WeightOz],0) AS [Weight],
				[PartNumber]+'-'+@Condition AS [MPN],

				(CASE 
				WHEN SKUD.[CategoryID] = '1401' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV One Connect Box for Television (No Cable)')
				WHEN SKUD.[CategoryID] = '1305' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' TV One Connect Cable for Television'
				WHEN SKUD.[CategoryID] = '1201' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN SKUD.[CategoryID] = '1202' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN SKUD.[CategoryID] = '1203' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1204' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN SKUD.[CategoryID] = '1205' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1206' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1207' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1301' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Cable Cord'
				WHEN SKUD.[CategoryID] = '1302' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Audio Video Cable A/V Cord'
				WHEN SKUD.[CategoryID] = '1303' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Specialty Cable Cord'
				WHEN SKUD.[CategoryID] = '1304' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cable Cord'
				ELSE
				[Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' ' + CAT.[CategoryName]
				END
				)
				 AS [Short Description],
		
		
				(CASE 
				WHEN SKUD.[CategoryID] = '1401' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV One Connect Box for Television (No Cable)')
				WHEN SKUD.[CategoryID] = '1305' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' TV One Connect Cable for Television'
				WHEN SKUD.[CategoryID] = '1201' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN SKUD.[CategoryID] = '1202' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN SKUD.[CategoryID] = '1203' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1204' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN SKUD.[CategoryID] = '1205' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1206' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1207' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1301' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Cable Cord'
				WHEN SKUD.[CategoryID] = '1302' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Audio Video Cable A/V Cord'
				WHEN SKUD.[CategoryID] = '1303' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Specialty Cable Cord'
				WHEN SKUD.[CategoryID] = '1304' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cable Cord'
				ELSE
				[Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' ' + CAT.[CategoryName]
				END
				)
				AS [Description],
		
				SKUD.[Manufacturer] AS [Manufacturer],
				SKUD.[Manufacturer] AS [Brand],
				'New' AS [Condition],
				'90 Day' AS [Warranty],
				IsNull(SKUD.[UnitCost],0) AS [Seller Cost],
				IsNull([CeilingPrice],'289.99') AS [Buy It Now Price],
				IsNULL(CEILING([CeilingPrice]*2)-0.01,'289.99') AS [Retail Price],
				IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'Walmart Marketplace' AS [Labels],
				
				(CASE
				WHEN SKUD.[CategoryID] = '1401' THEN 'Media Boxes - One Connect'
				WHEN SKUD.[CategoryID] = '1305' THEN 'Cables - One Connect'
				WHEN SKUD.[CategoryID] = '1201' THEN 'Power Adapter - TV'
				WHEN SKUD.[CategoryID] = '1202' THEN 'Power Adapter - Laptop'
				WHEN SKUD.[CategoryID] = '1203' THEN 'Power Adapter - Tablet'
				WHEN SKUD.[CategoryID] = '1204' THEN 'Power Adapter - Cell Phone'
				WHEN SKUD.[CategoryID] = '1205' THEN 'Power Adapter - Appliance'
				WHEN SKUD.[CategoryID] = '1206' THEN 'Power Adapter - Monitor'
				WHEN SKUD.[CategoryID] = '1207' THEN 'Power Adapter - Other'
				WHEN SKUD.[CategoryID] = '1301' THEN 'Cables - Power'
				WHEN SKUD.[CategoryID] = '1302' THEN 'Cables - Audio Video'
				WHEN SKUD.[CategoryID] = '1303' THEN 'Cables - Specialty'
				WHEN SKUD.[CategoryID] = '1304' THEN 'Cables - Other'
				ELSE '' END) AS [Classification],

				'BoughtsSKU' AS [Attribute1Name],
				SKUD.[SKU]+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'PartNumberSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				SKUD.CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				IsNull(SKUD.[FloorPrice], IsNull(SKUD.[CeilingPrice],'289.99')) AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				SKUD.[Manufacturer] AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				IsNull(SKUD.[OriginallySuppliedWith],'') AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				IsNull(SKUD.[AlsoCompatibleWith],'') AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM #TempSKUData AS SKUD
				LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT ON (SKUD.[CategoryID] = CAT.[CategoryID])
				WHERE SKUD.[SKU] IS NOT NULL 
				AND SKUD.[PartNumber] IS NOT NULL
				--One Connect Boxes and Cables, power adapters, cables
				AND SKUD.[CategoryID] IN ('1201','1202','1203','1204','1205','1206','1207','1301','1302','1303','1304','1305','1401',
				'1502','1601','1701','1801','1901','2101','2102','2103','2104','2105','2106','2107','2201','2202','2203','2204','2205','2301','2001')
				AND [Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) > 0

				PRINT 'Power Adapters, Cables, and OneConnect PartNumber NEW - Completed at '+CAST(GETDATE() AS NVARCHAR(50))
				
		---------------------------
		------POWER ADAPTERS, CABLES, AND ONE CONNECT PARTNUMBER SPECIFIC - USED-------
				SET @Condition = 'USED'

				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				[SKU]+'-'+LTRIM(RTRIM([PartNumber]))+'-'+@Condition AS [ItemNumber],

				(CASE 
				WHEN SKUD.[CategoryID] = '1401' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV One Connect Box for Television (No Cable)')
				WHEN SKUD.[CategoryID] = '1305' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' TV One Connect Cable for Television'
				WHEN SKUD.[CategoryID] = '1201' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN SKUD.[CategoryID] = '1202' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN SKUD.[CategoryID] = '1203' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1204' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN SKUD.[CategoryID] = '1205' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1206' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1207' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1301' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Cable Cord'
				WHEN SKUD.[CategoryID] = '1302' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Audio Video Cable A/V Cord'
				WHEN SKUD.[CategoryID] = '1303' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Specialty Cable Cord'
				WHEN SKUD.[CategoryID] = '1304' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cable Cord'
				ELSE
				[Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' ' + CAT.[CategoryName]
				END
				)
				AS [Auction Title],
		
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) AS [Quantity],
				IsNull(SKUD.[Length],0) AS [Length],
				IsNull(SKUD.[Height],0) AS [Height],
				IsNull(SKUD.[Width],0) AS [Width],
				IsNull(SKUD.[WeightOz],0) AS [Weight],
				[PartNumber]+'-'+@Condition AS [MPN],

				(CASE 
				WHEN SKUD.[CategoryID] = '1401' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV One Connect Box for Television (No Cable)')
				WHEN SKUD.[CategoryID] = '1305' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' TV One Connect Cable for Television'
				WHEN SKUD.[CategoryID] = '1201' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN SKUD.[CategoryID] = '1202' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN SKUD.[CategoryID] = '1203' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1204' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN SKUD.[CategoryID] = '1205' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1206' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1207' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1301' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Cable Cord'
				WHEN SKUD.[CategoryID] = '1302' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Audio Video Cable A/V Cord'
				WHEN SKUD.[CategoryID] = '1303' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Specialty Cable Cord'
				WHEN SKUD.[CategoryID] = '1304' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cable Cord'
				ELSE
				[Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' ' + CAT.[CategoryName]
				END
				)
				 AS [Short Description],
		
		
				(CASE 
				WHEN SKUD.[CategoryID] = '1401' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV One Connect Box for Television (No Cable)')
				WHEN SKUD.[CategoryID] = '1305' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' TV One Connect Cable for Television'
				WHEN SKUD.[CategoryID] = '1201' THEN 
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN SKUD.[CategoryID] = '1202' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN SKUD.[CategoryID] = '1203' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1204' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN SKUD.[CategoryID] = '1205' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1206' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1207' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN SKUD.[CategoryID] = '1301' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Power Cable Cord'
				WHEN SKUD.[CategoryID] = '1302' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Audio Video Cable A/V Cord'
				WHEN SKUD.[CategoryID] = '1303' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Specialty Cable Cord'
				WHEN SKUD.[CategoryID] = '1304' THEN
				'Original ' + [Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' Cable Cord'
				ELSE
				[Manufacturer] + ' ' + LTRIM(RTRIM([PartNumber])) + ' ' + CAT.[CategoryName]
				END
				)
				AS [Description],
		
				SKUD.[Manufacturer] AS [Manufacturer],
				SKUD.[Manufacturer] AS [Brand],
				'Used' AS [Condition],
				'30 Day' AS [Warranty],
				IsNull(SKUD.[UnitCost],0) AS [Seller Cost],
				IsNull([CeilingPrice],'289.99') AS [Buy It Now Price],
				IsNULL(CEILING([CeilingPrice]*2)-0.01,'289.99') AS [Retail Price],
				IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'' AS [Labels],
				
				(CASE
				WHEN SKUD.[CategoryID] = '1401' THEN 'Media Boxes - One Connect'
				WHEN SKUD.[CategoryID] = '1305' THEN 'Cables - One Connect'
				WHEN SKUD.[CategoryID] = '1201' THEN 'Power Adapter - TV'
				WHEN SKUD.[CategoryID] = '1202' THEN 'Power Adapter - Laptop'
				WHEN SKUD.[CategoryID] = '1203' THEN 'Power Adapter - Tablet'
				WHEN SKUD.[CategoryID] = '1204' THEN 'Power Adapter - Cell Phone'
				WHEN SKUD.[CategoryID] = '1205' THEN 'Power Adapter - Appliance'
				WHEN SKUD.[CategoryID] = '1206' THEN 'Power Adapter - Monitor'
				WHEN SKUD.[CategoryID] = '1207' THEN 'Power Adapter - Other'
				WHEN SKUD.[CategoryID] = '1301' THEN 'Cables - Power'
				WHEN SKUD.[CategoryID] = '1302' THEN 'Cables - Audio Video'
				WHEN SKUD.[CategoryID] = '1303' THEN 'Cables - Specialty'
				WHEN SKUD.[CategoryID] = '1304' THEN 'Cables - Other'
				ELSE '' END) AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				SKUD.[SKU]+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'PartNumberSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				SKUD.CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				IsNull(SKUD.[FloorPriceUSED], IsNull(SKUD.[CeilingPriceUSED],'289.99')) AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				SKUD.[Manufacturer] AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				IsNull(SKUD.[OriginallySuppliedWith],'') AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				IsNull(SKUD.[AlsoCompatibleWith],'') AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM #TempSKUData AS SKUD
				LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT ON (SKUD.[CategoryID] = CAT.[CategoryID])
				WHERE SKUD.[SKU] IS NOT NULL 
				AND SKUD.[PartNumber] IS NOT NULL
				--One Connect Boxes and Cables
				AND SKUD.[CategoryID] IN ('1201','1202','1203','1204','1205','1206','1207','1301','1302','1303','1304','1305','1401',
				'1502','1601','1701','1801','1901','2101','2102','2103','2104','2105','2106','2107','2201','2202','2203','2204','2205','2301','2001')
				AND [Remotes].[dbo].[fn_GetQtyByScanCode]([SKU],@Condition) > 0

				PRINT 'Power Adapters, Cables, and OneConnect PartNumber USED - Completed at '+CAST(GETDATE() AS NVARCHAR(50))

				PRINT 'All PartNumber Specific - Completed at '+CAST(GETDATE() AS NVARCHAR(50))
			

			SELECT * FROM #TempTable

---------------------------------------MODEL SPECIFIC STARTS HERE---------------------------------------------------------

		---------------------------
		------REMOTES - Model Specific CN-------
		DECLARE @SKU NVARCHAR(10)
		DECLARE @Manufacturer NVARCHAR(MAX)
		DECLARE @PartNumber NVARCHAR(MAX)
		DECLARE @Category NVARCHAR(MAX)
		DECLARE @CategoryName NVARCHAR(MAX)
		DECLARE @OriginallySuppliedWith NVARCHAR(MAX)
		DECLARE @AlsoCompatibleWith NVARCHAR(MAX)
		DECLARE @ModelList NVARCHAR(MAX)
		DECLARE @FloorPrice DECIMAL(10,2)
		DECLARE @CeilingPrice DECIMAL(10,2)
		DECLARE @ImageURLs NVARCHAR(MAX)
		DECLARE @Length NVARCHAR(MAX)
		DECLARE @Width NVARCHAR(MAX)
		DECLARE @Height NVARCHAR(MAX)
		DECLARE @Weight NVARCHAR(MAX)
		DECLARE @UnitCostCN NVARCHAR(MAX)
		DECLARE @UnitCostNEW NVARCHAR(MAX)
		DECLARE @UnitCostUSED NVARCHAR(MAX)

		SET @Condition = 'CN'

		DECLARE sku_cursor CURSOR FOR 
		SELECT [SKU] FROM [Remotes].[dbo].[SKUData]
		WHERE [SKU] IS NOT NULL
		AND [CategoryID] IN ('1101','1102','1103','1104','1105','1106','1107','1108','1109')
		AND 
		(([AlsoCompatibleWith] IS NOT NULL AND [AlsoCompatibleWith] != '')
		OR ([OriginallySuppliedWith] IS NOT NULL AND [OriginallySuppliedWith] != ''))
		AND
		[HaveCNVariant] = '1'

		OPEN sku_cursor  
		FETCH NEXT FROM sku_cursor INTO @SKU  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  

				PRINT 'Processing SKU: '+@SKU 
 
				--Put a cursor here for all Remote Control SKU's with CN Quantity
				SET @Condition = 'CN'
				SET @Manufacturer = (SELECT LTRIM(RTRIM([Manufacturer])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @PartNumber = (SELECT LTRIM(RTRIM([PartNumber])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Category = (SELECT [CategoryID] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CategoryName = (SELECT SKUD.[CategoryName] FROM #TempSKUData AS SKUD
				 WHERE SKUD.[SKU] = @SKU)

				SET @OriginallySuppliedWith = (SELECT [OriginallySuppliedWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @AlsoCompatibleWith = (SELECT [AlsoCompatibleWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ModelList = (IsNull(@OriginallySuppliedWith,'')+','+IsNull(@AlsoCompatibleWith,''))
				SET @FloorPrice = (SELECT LTRIM(RTRIM(IsNull([FloorPriceCN], IsNull([CeilingPriceCN],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CeilingPrice = (SELECT LTRIM(RTRIM(IsNull([CeilingPriceCN],'89.99'))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ImageURLs = IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = @SKU 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'07.jpg'
				OR RIGHT([name],'6') LIKE '%'+'08.jpg'
				OR RIGHT([name],'6') LIKE '%'+'09.jpg'
				OR RIGHT([name],'6') LIKE '%'+'10.jpg'
				OR RIGHT([name],'6') LIKE '%'+'11.jpg'
				OR RIGHT([name],'6') LIKE '%'+'12.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'')

				SET @Length = (SELECT CAST(LTRIM(RTRIM(IsNull([Length],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Width = (SELECT CAST(LTRIM(RTRIM(IsNull([Width],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Height = (SELECT CAST(LTRIM(RTRIM(IsNull([Height],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Weight = (SELECT CAST(LTRIM(RTRIM(IsNull([WeightOz],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostCN = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostCN],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostNEW = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCost],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostUSED = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				


				--Take off Extra Comma
				SET @ImageURLs = CASE WHEN RIGHT(@ImageURLs,1) = ',' THEN LEFT(@ImageURLs,(LEN(@ImageURLs))-1) ELSE @ImageURLs END




				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				@SKU+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [ItemNumber],
		
				(CASE 
				WHEN @Category = '1101' THEN 
				'Replacement TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television')
				WHEN @Category = '1102' THEN
				'Replacement CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1103' THEN
				'Replacement DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1104' THEN
				'Replacement BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1105' THEN
				'Replacement Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1106' THEN
				'Replacement Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1107' THEN
				'Replacement Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB')
				WHEN @Category = '1108' THEN
				'Replacement Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C')
				WHEN @Category = '1109' THEN
				'Replacement Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				ELSE
				'Replacement Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				END
				)
				AS [Auction Title],
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode](@SKU,@Condition) AS [Quantity],
				@Length AS [Length],
				@Height AS [Height],
				@Width AS [Width],
				@Weight AS [Weight],
				@PartNumber+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [MPN],

				(CASE 
				WHEN @Category = '1101' THEN 
				'Replacement TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television')
				WHEN @Category = '1102' THEN
				'Replacement CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1103' THEN
				'Replacement DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1104' THEN
				'Replacement BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1105' THEN
				'Replacement Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1106' THEN
				'Replacement Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1107' THEN
				'Replacement Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB')
				WHEN @Category = '1108' THEN
				'Replacement Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C')
				WHEN @Category = '1109' THEN
				'Replacement Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				ELSE
				'Replacement Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				END
				)
				AS [Short Description],
		
				(CASE 
				WHEN @Category = '1101' THEN 
				'Replacement TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television')
				WHEN @Category = '1102' THEN
				'Replacement CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1103' THEN
				'Replacement DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1104' THEN
				'Replacement BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1105' THEN
				'Replacement Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1106' THEN
				'Replacement Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1107' THEN
				'Replacement Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB')
				WHEN @Category = '1108' THEN
				'Replacement Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C')
				WHEN @Category = '1109' THEN
				'Replacement Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				ELSE
				'Replacement Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				END
				)
				AS [Description],
		
				'Aurabeam' AS [Manufacturer],
				'Aurabeam' AS [Brand],
				'New' AS [Condition],
				'1 Year' AS [Warranty],
				@UnitCostCN AS [Seller Cost],
				IsNull(@CeilingPrice,'89.99') AS [Buy It Now Price],
				IsNULL(CEILING(@CeilingPrice*2)-0.01,'89.99') AS [Retail Price],
				@ImageURLs AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'Walmart Marketplace' AS [Labels],
				'Remote Control' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				@SKU+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'ModelSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				@CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				@FloorPrice AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				@Manufacturer AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				@OriginallySuppliedWith AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				@AlsoCompatibleWith AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]
				FROM [Remotes].[dbo].[fn_SplitItem](@ModelList)

			  FETCH NEXT FROM sku_cursor INTO @SKU 
		END 

		CLOSE sku_cursor  
		DEALLOCATE sku_cursor 
		
		PRINT 'Remotes - Model Specific CN Completed at '+CAST(GETDATE() AS NVARCHAR(50))

		
		---------------------------------------------------------------------------
		--------------REMOTES - MODEL SPECIFIC ORIGINALS - NEW CONDITION----------------------
		SET @Condition = 'NEW'

		DECLARE sku_cursor CURSOR FOR 
		SELECT SKUD.[SKU]
		FROM #TempSKUData AS SKUD
		WHERE SKUD.[SKU] IS NOT NULL
		AND SKUD.[CategoryID] IN ('1101','1102','1103','1104','1105','1106','1107','1108','1109')
		AND 
		((SKUD.[AlsoCompatibleWith] IS NOT NULL AND SKUD.[AlsoCompatibleWith] != '')
		OR (SKUD.[OriginallySuppliedWith] IS NOT NULL AND SKUD.[OriginallySuppliedWith] != ''))

		OPEN sku_cursor  
		FETCH NEXT FROM sku_cursor INTO @SKU  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
 
				PRINT 'Processing SKU: '+@SKU 

				--Put a cursor here for all Remote Control SKU's with CN Quantity
				SET @Condition = 'NEW'
				SET @Manufacturer = (SELECT LTRIM(RTRIM([Manufacturer])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @PartNumber = (SELECT LTRIM(RTRIM([PartNumber])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Category = (SELECT [CategoryID] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CategoryName = (SELECT SKUD.[CategoryName] FROM #TempSKUData AS SKUD
				 WHERE SKUD.[SKU] = @SKU)

				SET @OriginallySuppliedWith = (SELECT [OriginallySuppliedWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @AlsoCompatibleWith = (SELECT [AlsoCompatibleWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ModelList = (IsNull(@OriginallySuppliedWith,'')+','+IsNull(@AlsoCompatibleWith,''))
				SET @FloorPrice = (SELECT LTRIM(RTRIM(IsNull([FloorPrice], IsNull([CeilingPrice],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CeilingPrice = (SELECT LTRIM(RTRIM(IsNull([CeilingPrice],'89.99'))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ImageURLs = IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = @SKU 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'')


				SET @Length = (SELECT CAST(LTRIM(RTRIM(IsNull([Length],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Width = (SELECT CAST(LTRIM(RTRIM(IsNull([Width],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Height = (SELECT CAST(LTRIM(RTRIM(IsNull([Height],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Weight = (SELECT CAST(LTRIM(RTRIM(IsNull([WeightOz],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostCN = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostCN],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostNEW = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCost],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostUSED = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				

				--Take off Extra Comma
				SET @ImageURLs = CASE WHEN RIGHT(@ImageURLs,1) = ',' THEN LEFT(@ImageURLs,(LEN(@ImageURLs))-1) ELSE @ImageURLs END


				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				@SKU+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [ItemNumber],
		
				(CASE 
				WHEN @Category = '1101' THEN 
				'Original TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television')
				WHEN @Category = '1102' THEN
				'Original CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1103' THEN
				'Original DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1104' THEN
				'Original BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1105' THEN
				'Original Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1106' THEN
				'Original Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1107' THEN
				'Original Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB')
				WHEN @Category = '1108' THEN
				'Original Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C')
				WHEN @Category = '1109' THEN
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				ELSE
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				END
				)
				AS [Auction Title],
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode](@SKU,@Condition) AS [Quantity],
				@Length AS [Length],
				@Height AS [Height],
				@Width AS [Width],
				@Weight AS [Weight],
				@PartNumber+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [MPN],

				(CASE 
				WHEN @Category = '1101' THEN 
				'Original TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television')
				WHEN @Category = '1102' THEN
				'Original CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1103' THEN
				'Original DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1104' THEN
				'Original BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1105' THEN
				'Original Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1106' THEN
				'Original Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1107' THEN
				'Original Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB')
				WHEN @Category = '1108' THEN
				'Original Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C')
				WHEN @Category = '1109' THEN
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				ELSE
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				END
				)
				AS [Short Description],
		
						(CASE 
				WHEN @Category = '1101' THEN 
				'Original TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television')
				WHEN @Category = '1102' THEN
				'Original CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1103' THEN
				'Original DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1104' THEN
				'Original BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1105' THEN
				'Original Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1106' THEN
				'Original Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1107' THEN
				'Original Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB')
				WHEN @Category = '1108' THEN
				'Original Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C')
				WHEN @Category = '1109' THEN
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				ELSE
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				END
				)
				AS [Description],
		
				@Manufacturer AS [Manufacturer],
				@Manufacturer AS [Brand],
				'New' AS [Condition],
				'1 Year' AS [Warranty],
				@UnitCostNEW AS [Seller Cost],
				IsNull(@CeilingPrice,'89.99') AS [Buy It Now Price],
				IsNULL(CEILING(@CeilingPrice*2)-0.01,'89.99') AS [Retail Price],
				@ImageURLs AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'Walmart Marketplace' AS [Labels],
				'Remote Control' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				@SKU+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'ModelSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				@CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				@FloorPrice AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				@Manufacturer AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				@OriginallySuppliedWith AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				@AlsoCompatibleWith AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM [Remotes].[dbo].[fn_SplitItem](@ModelList)

			  FETCH NEXT FROM sku_cursor INTO @SKU 
		END 

		CLOSE sku_cursor  
		DEALLOCATE sku_cursor 
		---------------------------------------------------------------------------

		PRINT 'Remotes - Model Specific NEW Completed at '+CAST(GETDATE() AS NVARCHAR(50))


		
		--------------REMOTES - MODEL SPECIFIC ORIGINALS - USED CONDITION----------------------
		SET @Condition = 'USED'

		DECLARE sku_cursor CURSOR FOR 
		SELECT SKUD.[SKU]
		FROM #TempSKUData AS SKUD
		WHERE SKUD.[SKU] IS NOT NULL
		AND SKUD.[CategoryID] IN ('1101','1102','1103','1104','1105','1106','1107','1108','1109')
		AND 
		((SKUD.[AlsoCompatibleWith] IS NOT NULL AND SKUD.[AlsoCompatibleWith] != '')
		OR (SKUD.[OriginallySuppliedWith] IS NOT NULL AND SKUD.[OriginallySuppliedWith] != ''))

		OPEN sku_cursor  
		FETCH NEXT FROM sku_cursor INTO @SKU  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
 
				PRINT 'Processing SKU: '+@SKU 

				--Put a cursor here for all Remote Control SKU's with CN Quantity
				SET @Condition = 'USED'
				SET @Manufacturer = (SELECT LTRIM(RTRIM([Manufacturer])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @PartNumber = (SELECT LTRIM(RTRIM([PartNumber])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Category = (SELECT [CategoryID] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CategoryName = (SELECT SKUD.[CategoryName] FROM #TempSKUData AS SKUD
				 WHERE SKUD.[SKU] = @SKU)

				SET @OriginallySuppliedWith = (SELECT [OriginallySuppliedWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @AlsoCompatibleWith = (SELECT [AlsoCompatibleWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ModelList = (IsNull(@OriginallySuppliedWith,'')+','+IsNull(@AlsoCompatibleWith,''))
				SET @FloorPrice = (SELECT LTRIM(RTRIM(IsNull([FloorPriceUSED], IsNull([CeilingPriceUSED],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CeilingPrice = (SELECT LTRIM(RTRIM(IsNull([CeilingPriceUSED],'89.99'))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ImageURLs = IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = @SKU 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'')

				SET @Length = (SELECT CAST(LTRIM(RTRIM(IsNull([Length],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Width = (SELECT CAST(LTRIM(RTRIM(IsNull([Width],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Height = (SELECT CAST(LTRIM(RTRIM(IsNull([Height],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Weight = (SELECT CAST(LTRIM(RTRIM(IsNull([WeightOz],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostCN = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostCN],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostNEW = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCost],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostUSED = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				


				--Take off Extra Comma
				SET @ImageURLs = CASE WHEN RIGHT(@ImageURLs,1) = ',' THEN LEFT(@ImageURLs,(LEN(@ImageURLs))-1) ELSE @ImageURLs END


				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				@SKU+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [ItemNumber],
		
				(CASE 
				WHEN @Category = '1101' THEN 
				'Original TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television')
				WHEN @Category = '1102' THEN
				'Original CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1103' THEN
				'Original DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1104' THEN
				'Original BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1105' THEN
				'Original Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1106' THEN
				'Original Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1107' THEN
				'Original Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB')
				WHEN @Category = '1108' THEN
				'Original Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C')
				WHEN @Category = '1109' THEN
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				ELSE
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				END
				)
				AS [Auction Title],
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode](@SKU,@Condition) AS [Quantity],
				@Length AS [Length],
				@Height AS [Height],
				@Width AS [Width],
				@Weight AS [Weight],
				@PartNumber+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [MPN],

				(CASE 
				WHEN @Category = '1101' THEN 
				'Original TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1102' THEN
				'Original CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1103' THEN
				'Original DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1104' THEN
				'Original BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1105' THEN
				'Original Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1106' THEN
				'Original Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.'))
				WHEN @Category = '1107' THEN
				'Original Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1108' THEN
				'Original Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1109' THEN
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				ELSE
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				END
				)
				AS [Short Description],
		
						(CASE 
				WHEN @Category = '1101' THEN 
				'Original TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1102' THEN
				'Original CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1103' THEN
				'Original DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1104' THEN
				'Original BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1105' THEN
				'Original Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1106' THEN
				'Original Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1107' THEN
				'Original Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1108' THEN
				'Original Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				WHEN @Category = '1109' THEN
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				ELSE
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.')
				END
				)
				AS [Description],
		
				@Manufacturer AS [Manufacturer],
				@Manufacturer AS [Brand],
				'Used' AS [Condition],
				'1 Year' AS [Warranty],
				@UnitCostUSED AS [Seller Cost],
				IsNull(@CeilingPrice,'89.99') AS [Buy It Now Price],
				IsNULL(CEILING(@CeilingPrice*2)-0.01,'89.99') AS [Retail Price],
				@ImageURLs AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'' AS [Labels],
				'Remote Control' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				@SKU+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'ModelSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				@CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				@FloorPrice AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				@Manufacturer AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				@OriginallySuppliedWith AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				@AlsoCompatibleWith AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM [Remotes].[dbo].[fn_SplitItem](@ModelList)

			  FETCH NEXT FROM sku_cursor INTO @SKU 
		END 


		CLOSE sku_cursor  
		DEALLOCATE sku_cursor 
		---------------------------------------------------------------------------

		PRINT 'Remotes - Model Specific USED Completed at '+CAST(GETDATE() AS NVARCHAR(50))
		
		---------------------------
		--------------REMOTES - MODEL SPECIFIC NO COVER - USED CONDITION----------------------
		SET @Condition = 'NC'

		DECLARE sku_cursor CURSOR FOR 
		SELECT SKUD.[SKU]
		FROM #TempSKUData AS SKUD
		WHERE SKUD.[SKU] IS NOT NULL
		AND SKUD.[CategoryID] IN ('1101','1102','1103','1104','1105','1106','1107','1108','1109')
		AND 
		((SKUD.[AlsoCompatibleWith] IS NOT NULL AND SKUD.[AlsoCompatibleWith] != '')
		OR (SKUD.[OriginallySuppliedWith] IS NOT NULL AND SKUD.[OriginallySuppliedWith] != ''))

		OPEN sku_cursor  
		FETCH NEXT FROM sku_cursor INTO @SKU  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
 
				PRINT 'Processing SKU: '+@SKU 

				--Put a cursor here for all Remote Control SKU's with CN Quantity
				SET @Condition = 'NC'
				SET @Manufacturer = (SELECT LTRIM(RTRIM([Manufacturer])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @PartNumber = (SELECT LTRIM(RTRIM([PartNumber])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Category = (SELECT [CategoryID] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CategoryName = (SELECT SKUD.[CategoryName] FROM #TempSKUData AS SKUD
				 WHERE SKUD.[SKU] = @SKU)

				SET @OriginallySuppliedWith = (SELECT [OriginallySuppliedWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @AlsoCompatibleWith = (SELECT [AlsoCompatibleWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ModelList = (IsNull(@OriginallySuppliedWith,'')+','+IsNull(@AlsoCompatibleWith,''))
				SET @FloorPrice = (SELECT LTRIM(RTRIM(IsNull([FloorPriceUSED], IsNull([CeilingPriceUSED],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CeilingPrice = (SELECT LTRIM(RTRIM(IsNull([CeilingPriceUSED]*0.75,'89.99'))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ImageURLs = 'http://remotespict.mitechnologiesinc.com/NOCOVER/nc.jpg,'+IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = @SKU 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'')

				SET @Length = (SELECT CAST(LTRIM(RTRIM(IsNull([Length],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Width = (SELECT CAST(LTRIM(RTRIM(IsNull([Width],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Height = (SELECT CAST(LTRIM(RTRIM(IsNull([Height],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Weight = (SELECT CAST(LTRIM(RTRIM(IsNull([WeightOz],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostCN = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostCN],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostNEW = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCost],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostUSED = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				


				--Take off Extra Comma
				SET @ImageURLs = CASE WHEN RIGHT(@ImageURLs,1) = ',' THEN LEFT(@ImageURLs,(LEN(@ImageURLs))-1) ELSE @ImageURLs END


				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				@SKU+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [ItemNumber],
		
				(CASE 
				WHEN @Category = '1101' THEN 
				'(No Cover) Original TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television')
				WHEN @Category = '1102' THEN
				'(No Cover) Original CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1103' THEN
				'(No Cover) Original DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1104' THEN
				'(No Cover) Original BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1105' THEN
				'(No Cover) Original Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1106' THEN
				'(No Cover) Original Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				WHEN @Category = '1107' THEN
				'(No Cover) Original Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB')
				WHEN @Category = '1108' THEN
				'(No Cover) Original Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C')
				WHEN @Category = '1109' THEN
				'(No Cover) Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				ELSE
				'(No Cover) Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]))
				END
				)
				AS [Auction Title],
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode](@SKU,@Condition) AS [Quantity],
				@Length AS [Length],
				@Height AS [Height],
				@Width AS [Width],
				@Weight AS [Weight],
				@PartNumber+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [MPN],

				(CASE 
				WHEN @Category = '1101' THEN 
				'Original TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1102' THEN
				'Original CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1103' THEN
				'Original DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1104' THEN
				'Original BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1105' THEN
				'Original Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1106' THEN
				'Original Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!'))
				WHEN @Category = '1107' THEN
				'Original Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1108' THEN
				'Original Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1109' THEN
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				ELSE
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				END
				)
				AS [Short Description],
		
						(CASE 
				WHEN @Category = '1101' THEN 
				'Original TV Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' Television. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1102' THEN
				'Original CD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1103' THEN
				'Original DVD Player Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1104' THEN
				'Original BluRay Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1105' THEN
				'Original Audio Receiver Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1106' THEN
				'Original Sound Bar Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1107' THEN
				'Original Home Theater Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + 'HTIB. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1108' THEN
				'Original Air Conditioner Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' AC A/C. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				WHEN @Category = '1109' THEN
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				ELSE
				'Original Remote Control for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])+'. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.  IMPORTANT NOTE: This product is missing the battery cover!')
				END
				)
				AS [Description],
		
				@Manufacturer AS [Manufacturer],
				@Manufacturer AS [Brand],
				'Used' AS [Condition],
				'1 Year' AS [Warranty],
				@UnitCostUSED AS [Seller Cost],
				IsNull(@CeilingPrice,'89.99') AS [Buy It Now Price],
				IsNULL(CEILING(@CeilingPrice*2)-0.01,'89.99') AS [Retail Price],
				@ImageURLs AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'' AS [Labels],
				'Remote Control' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				@SKU+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'ModelSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				@CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				@FloorPrice AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				@Manufacturer AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				@OriginallySuppliedWith AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				@AlsoCompatibleWith AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM [Remotes].[dbo].[fn_SplitItem](@ModelList)

			  FETCH NEXT FROM sku_cursor INTO @SKU 
		END 


		CLOSE sku_cursor  
		DEALLOCATE sku_cursor 
		---------------------------------------------------------------------------

		PRINT 'Remotes - Model Specific USED NO COVER Completed at '+CAST(GETDATE() AS NVARCHAR(50))
		
		---------------------------

		------TV STANDS MODEL SPECIFIC - NEW-------
		DECLARE sku_cursor CURSOR FOR 
		SELECT [SKU] FROM [Remotes].[dbo].[SKUData]
		WHERE [SKU] IS NOT NULL
		AND [CategoryID] IN ('1501')
		AND 
		(([AlsoCompatibleWith] IS NOT NULL AND [AlsoCompatibleWith] != '')
		OR ([OriginallySuppliedWith] IS NOT NULL AND [OriginallySuppliedWith] != ''))


		OPEN sku_cursor  
		FETCH NEXT FROM sku_cursor INTO @SKU  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  

				PRINT 'Processing SKU: '+@SKU 
 
				SET @Condition = 'NEW'
				SET @Manufacturer = (SELECT LTRIM(RTRIM([Manufacturer])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @PartNumber = (SELECT LTRIM(RTRIM([PartNumber])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Category = (SELECT [CategoryID] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CategoryName = (SELECT SKUD.[CategoryName] FROM #TempSKUData AS SKUD
				 WHERE SKUD.[SKU] = @SKU)

				SET @OriginallySuppliedWith = (SELECT [OriginallySuppliedWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @AlsoCompatibleWith = (SELECT [AlsoCompatibleWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ModelList = (IsNull(@OriginallySuppliedWith,'')+','+IsNull(@AlsoCompatibleWith,''))
				SET @FloorPrice = (SELECT LTRIM(RTRIM(IsNull([FloorPrice], IsNull([CeilingPrice],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CeilingPrice = (SELECT LTRIM(RTRIM(IsNull([CeilingPrice],'89.99'))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ImageURLs = IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = @SKU 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'')

				SET @Length = (SELECT CAST(LTRIM(RTRIM(IsNull([Length],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Width = (SELECT CAST(LTRIM(RTRIM(IsNull([Width],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Height = (SELECT CAST(LTRIM(RTRIM(IsNull([Height],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Weight = (SELECT CAST(LTRIM(RTRIM(IsNull([WeightOz],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostCN = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostCN],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostNEW = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCost],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostUSED = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)


				--Take off Extra Comma
				SET @ImageURLs = CASE WHEN RIGHT(@ImageURLs,1) = ',' THEN LEFT(@ImageURLs,(LEN(@ImageURLs))-1) ELSE @ImageURLs END


				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				@SKU+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [ItemNumber],
				'Replacement TV Stand for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Television' AS [Auction Title],
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode](@SKU,@Condition) AS [Quantity],
				@Length AS [Length],
				@Height AS [Height],
				@Width AS [Width],
				@Weight AS [Weight],
				@PartNumber+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [MPN],

				'Replacement TV Stand for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Television.  DOES NOT INCLUDE SCREWS OR INSTALLATION HARDWARE.  The screws are typically supplied with the Television and replacements can be found at your local hardware store.' AS [Short Description],
				'Replacement TV Stand for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Television.  DOES NOT INCLUDE SCREWS OR INSTALLATION HARDWARE.  The screws are typically supplied with the Television and replacements can be found at your local hardware store.' AS [Description],
				@Manufacturer AS [Manufacturer],
				@Manufacturer AS [Brand],
				'New' AS [Condition],
				'1 Year' AS [Warranty],
				@UnitCostNEW AS [Seller Cost],
				IsNull(@CeilingPrice,'89.99') AS [Buy It Now Price],
				IsNULL(CEILING(@CeilingPrice*2)-0.01,'89.99') AS [Retail Price],
				@ImageURLs AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'Walmart Marketplace' AS [Labels],
				'TV Stand' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				@SKU+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'ModelSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				@CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				@FloorPrice AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				@Manufacturer AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				@OriginallySuppliedWith AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				@AlsoCompatibleWith AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM [Remotes].[dbo].[fn_SplitItem](@ModelList)

			  FETCH NEXT FROM sku_cursor INTO @SKU 
		END 

		CLOSE sku_cursor  
		DEALLOCATE sku_cursor 
		---------------------------------------------------------------------------
		
		PRINT 'TV Stands - Model Specific NEW Completed at '+CAST(GETDATE() AS NVARCHAR(50))
		
		---------------------------
		------TV STANDS MODEL SPECIFIC - USED-------
		DECLARE sku_cursor CURSOR FOR 
		SELECT [SKU] FROM [Remotes].[dbo].[SKUData]
		WHERE [SKU] IS NOT NULL
		AND [CategoryID] IN ('1501')
		AND 
		(([AlsoCompatibleWith] IS NOT NULL AND [AlsoCompatibleWith] != '')
		OR ([OriginallySuppliedWith] IS NOT NULL AND [OriginallySuppliedWith] != ''))


		OPEN sku_cursor  
		FETCH NEXT FROM sku_cursor INTO @SKU  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
 
				PRINT 'Processing SKU: '+@SKU 

				SET @Condition = 'USED'
				SET @Manufacturer = (SELECT LTRIM(RTRIM([Manufacturer])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @PartNumber = (SELECT LTRIM(RTRIM([PartNumber])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Category = (SELECT [CategoryID] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CategoryName = (SELECT SKUD.[CategoryName] FROM #TempSKUData AS SKUD
				 WHERE SKUD.[SKU] = @SKU)

				SET @OriginallySuppliedWith = (SELECT [OriginallySuppliedWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @AlsoCompatibleWith = (SELECT [AlsoCompatibleWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ModelList = (IsNull(@OriginallySuppliedWith,'')+','+IsNull(@AlsoCompatibleWith,''))
				SET @FloorPrice = (SELECT LTRIM(RTRIM(IsNull([FloorPriceUSED], IsNull([CeilingPriceUSED],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CeilingPrice = (SELECT LTRIM(RTRIM(IsNull([CeilingPriceUSED],'89.99'))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ImageURLs = IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = @SKU 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'')

				SET @Length = (SELECT CAST(LTRIM(RTRIM(IsNull([Length],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Width = (SELECT CAST(LTRIM(RTRIM(IsNull([Width],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Height = (SELECT CAST(LTRIM(RTRIM(IsNull([Height],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Weight = (SELECT CAST(LTRIM(RTRIM(IsNull([WeightOz],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostCN = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostCN],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostNEW = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCost],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostUSED = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)


				--Take off Extra Comma
				SET @ImageURLs = CASE WHEN RIGHT(@ImageURLs,1) = ',' THEN LEFT(@ImageURLs,(LEN(@ImageURLs))-1) ELSE @ImageURLs END


				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				@SKU+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [ItemNumber],
				'Replacement TV Stand for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Television' AS [Auction Title],
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode](@SKU,@Condition) AS [Quantity],
				@Length AS [Length],
				@Height AS [Height],
				@Width AS [Width],
				@Weight AS [Weight],
				@PartNumber+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [MPN],

				'Replacement TV Stand for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Television.  DOES NOT INCLUDE SCREWS OR INSTALLATION HARDWARE.  The screws are typically supplied with the Television and replacements can be found at your local hardware store. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.' AS [Short Description],
				'Replacement TV Stand for ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Television.  DOES NOT INCLUDE SCREWS OR INSTALLATION HARDWARE.  The screws are typically supplied with the Television and replacements can be found at your local hardware store. This listing is for a USED item and may have minor cosmetic blemishes and imperfections.' AS [Description],
				@Manufacturer AS [Manufacturer],
				@Manufacturer AS [Brand],
				'Used' AS [Condition],
				'1 Year' AS [Warranty],
				@UnitCostUSED AS [Seller Cost],
				IsNull(@CeilingPrice,'89.99') AS [Buy It Now Price],
				IsNULL(CEILING(@CeilingPrice*2)-0.01,'89.99') AS [Retail Price],
				@ImageURLs AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'' AS [Labels],
				'TV Stand' AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				@SKU+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'ModelSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				@CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				@FloorPrice AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				@Manufacturer AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				@OriginallySuppliedWith AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				@AlsoCompatibleWith AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM [Remotes].[dbo].[fn_SplitItem](@ModelList)

			  FETCH NEXT FROM sku_cursor INTO @SKU 
		END 

		CLOSE sku_cursor  
		DEALLOCATE sku_cursor 
		---------------------------------------------------------------------------

		PRINT 'TV Stands - Model Specific USED Completed at '+CAST(GETDATE() AS NVARCHAR(50))

		
		--------------POWER ADAPTERS, CABLES, AND ONE CONNECT - MODEL SPECIFIC - NEW CONDITION----------------------
		SET @Condition = 'NEW'

		DECLARE sku_cursor CURSOR FOR 
		SELECT SKUD.[SKU]
		FROM #TempSKUData AS SKUD
		WHERE SKUD.[SKU] IS NOT NULL
		AND SKUD.[CategoryID] IN ('1305','1401','1201','1202','1203','1204','1205','1206','1207','1301','1302','1303','1304',
		'1502','1601','1701','1801','1901','2101','2102','2103','2104','2105','2106','2107','2201','2202','2203','2204','2205','2301','2001')
		AND 
		((SKUD.[AlsoCompatibleWith] IS NOT NULL AND SKUD.[AlsoCompatibleWith] != '')
		OR (SKUD.[OriginallySuppliedWith] IS NOT NULL AND SKUD.[OriginallySuppliedWith] != ''))

		OPEN sku_cursor  
		FETCH NEXT FROM sku_cursor INTO @SKU  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
				
				PRINT 'Processing SKU: '+@SKU 

				--Put a cursor here for all Remote Control SKU's with CN Quantity
				SET @Condition = 'NEW'
				SET @Manufacturer = (SELECT LTRIM(RTRIM([Manufacturer])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @PartNumber = (SELECT LTRIM(RTRIM([PartNumber])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Category = (SELECT [CategoryID] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CategoryName = (SELECT SKUD.[CategoryName] FROM #TempSKUData AS SKUD
				 WHERE SKUD.[SKU] = @SKU)

				SET @OriginallySuppliedWith = (SELECT [OriginallySuppliedWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @AlsoCompatibleWith = (SELECT [AlsoCompatibleWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ModelList = (IsNull(@OriginallySuppliedWith,'')+','+IsNull(@AlsoCompatibleWith,''))
				SET @FloorPrice = (SELECT LTRIM(RTRIM(IsNull([FloorPrice], IsNull([CeilingPrice],'289.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CeilingPrice = (SELECT LTRIM(RTRIM(IsNull([CeilingPrice],'289.99'))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ImageURLs = IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = @SKU 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'')


				SET @Length = (SELECT CAST(LTRIM(RTRIM(IsNull([Length],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Width = (SELECT CAST(LTRIM(RTRIM(IsNull([Width],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Height = (SELECT CAST(LTRIM(RTRIM(IsNull([Height],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Weight = (SELECT CAST(LTRIM(RTRIM(IsNull([WeightOz],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostCN = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostCN],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostNEW = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCost],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostUSED = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				

				--Take off Extra Comma
				SET @ImageURLs = CASE WHEN RIGHT(@ImageURLs,1) = ',' THEN LEFT(@ImageURLs,(LEN(@ImageURLs))-1) ELSE @ImageURLs END


				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				@SKU+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [ItemNumber],
		
				(CASE 
				WHEN @Category = '1401' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV One Connect Box for Television (No Cable)')
				WHEN @Category = '1305' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' TV One Connect Cable for Television'
				WHEN @Category = '1201' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN @Category = '1202' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN @Category = '1203' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1204' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN @Category = '1205' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1206' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1207' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1301' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Cable Cord'
				WHEN @Category = '1302' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Audio Video Cable A/V Cord'
				WHEN @Category = '1303' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Specialty Cable Cord'
				WHEN @Category = '1304' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cable Cord'
				ELSE
				@Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' ' + @CategoryName
				END
				)
				AS [Auction Title],
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode](@SKU,@Condition) AS [Quantity],
				@Length AS [Length],
				@Height AS [Height],
				@Width AS [Width],
				@Weight AS [Weight],
				@PartNumber+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [MPN],

				(CASE 
				WHEN @Category = '1401' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV One Connect Box for Television (No Cable)')
				WHEN @Category = '1305' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' TV One Connect Cable for Television'
				WHEN @Category = '1201' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN @Category = '1202' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN @Category = '1203' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1204' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN @Category = '1205' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1206' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1207' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1301' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Cable Cord'
				WHEN @Category = '1302' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Audio Video Cable A/V Cord'
				WHEN @Category = '1303' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Specialty Cable Cord'
				WHEN @Category = '1304' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cable Cord'
				ELSE
				@Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' ' + @CategoryName
				END
				)
				AS [Short Description],
		
				(CASE 
				WHEN @Category = '1401' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV One Connect Box for Television (No Cable)')
				WHEN @Category = '1305' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' TV One Connect Cable for Television'
				WHEN @Category = '1201' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN @Category = '1202' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN @Category = '1203' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1204' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN @Category = '1205' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1206' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1207' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1301' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Cable Cord'
				WHEN @Category = '1302' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Audio Video Cable A/V Cord'
				WHEN @Category = '1303' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Specialty Cable Cord'
				WHEN @Category = '1304' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cable Cord'
				ELSE
				@Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' ' + @CategoryName
				END
				)
				AS [Description],
		
				@Manufacturer AS [Manufacturer],
				@Manufacturer AS [Brand],
				'New' AS [Condition],
				'90 Days' AS [Warranty],
				@UnitCostNEW AS [Seller Cost],
				IsNull(@CeilingPrice,'289.99') AS [Buy It Now Price],
				IsNULL(CEILING(@CeilingPrice*2)-0.01,'289.99') AS [Retail Price],
				@ImageURLs AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'Walmart Marketplace' AS [Labels],
				(CASE
				WHEN @Category = '1401' THEN 'Media Boxes - One Connect'
				WHEN @Category = '1305' THEN 'Cables - One Connect'
				WHEN @Category = '1201' THEN 'Power Adapter - TV'
				WHEN @Category = '1202' THEN 'Power Adapter - Laptop'
				WHEN @Category = '1203' THEN 'Power Adapter - Tablet'
				WHEN @Category = '1204' THEN 'Power Adapter - Cell Phone'
				WHEN @Category = '1205' THEN 'Power Adapter - Appliance'
				WHEN @Category = '1206' THEN 'Power Adapter - Monitor'
				WHEN @Category = '1207' THEN 'Power Adapter - Other'
				WHEN @Category = '1301' THEN 'Cables - Power'
				WHEN @Category = '1302' THEN 'Cables - Audio Video'
				WHEN @Category = '1303' THEN 'Cables - Specialty'
				WHEN @Category = '1304' THEN 'Cables - Other'
				ELSE '' END) AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				@SKU+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'ModelSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				@CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				@FloorPrice AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				@Manufacturer AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				@OriginallySuppliedWith AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				@AlsoCompatibleWith AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM [Remotes].[dbo].[fn_SplitItem](@ModelList)

			  FETCH NEXT FROM sku_cursor INTO @SKU 
		END 

		CLOSE sku_cursor  
		DEALLOCATE sku_cursor 
		---------------------------------------------------------------------------

		PRINT 'POWER ADAPTERS, CABLES, AND ONE CONNECT - Model Specific NEW Completed at '+CAST(GETDATE() AS NVARCHAR(50))
		
		--------------POWER ADAPTERS, CABLES, AND ONE CONNECT - MODEL SPECIFIC - USED CONDITION----------------------
		SET @Condition = 'USED'

		DECLARE sku_cursor CURSOR FOR 
		SELECT SKUD.[SKU]
		FROM #TempSKUData AS SKUD
		WHERE SKUD.[SKU] IS NOT NULL
		AND SKUD.[CategoryID] IN ('1305','1401','1201','1202','1203','1204','1205','1206','1207','1301','1302','1303','1304',
		'1502','1601','1701','1801','1901','2101','2102','2103','2104','2105','2106','2107','2201','2202','2203','2204','2205','2301','2001')
		AND 
		((SKUD.[AlsoCompatibleWith] IS NOT NULL AND SKUD.[AlsoCompatibleWith] != '')
		OR (SKUD.[OriginallySuppliedWith] IS NOT NULL AND SKUD.[OriginallySuppliedWith] != ''))

		OPEN sku_cursor  
		FETCH NEXT FROM sku_cursor INTO @SKU  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
 
				PRINT 'Processing SKU: '+@SKU 

				--Put a cursor here for all Remote Control SKU's with CN Quantity
				SET @Condition = 'USED'
				SET @Manufacturer = (SELECT LTRIM(RTRIM([Manufacturer])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @PartNumber = (SELECT LTRIM(RTRIM([PartNumber])) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Category = (SELECT [CategoryID] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CategoryName = (SELECT SKUD.[CategoryName] FROM #TempSKUData AS SKUD
				 WHERE SKUD.[SKU] = @SKU)

				SET @OriginallySuppliedWith = (SELECT [OriginallySuppliedWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @AlsoCompatibleWith = (SELECT [AlsoCompatibleWith] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ModelList = (IsNull(@OriginallySuppliedWith,'')+','+IsNull(@AlsoCompatibleWith,''))
				SET @FloorPrice = (SELECT LTRIM(RTRIM(IsNull([FloorPriceUSED], IsNull([CeilingPriceUSED],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @CeilingPrice = (SELECT LTRIM(RTRIM(IsNull([CeilingPriceUSED],'89.99'))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @ImageURLs = IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = @SKU 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				) ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'')

				SET @Length = (SELECT CAST(LTRIM(RTRIM(IsNull([Length],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Width = (SELECT CAST(LTRIM(RTRIM(IsNull([Width],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Height = (SELECT CAST(LTRIM(RTRIM(IsNull([Height],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @Weight = (SELECT CAST(LTRIM(RTRIM(IsNull([WeightOz],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostCN = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostCN],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostNEW = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCost],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				SET @UnitCostUSED = (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = @SKU)
				


				--Take off Extra Comma
				SET @ImageURLs = CASE WHEN RIGHT(@ImageURLs,1) = ',' THEN LEFT(@ImageURLs,(LEN(@ImageURLs))-1) ELSE @ImageURLs END


				INSERT INTO #TempTable ([ID] ,[Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])


				SELECT DISTINCT
				'' AS [ID],
				@SKU+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [ItemNumber],
		
				(CASE 
				WHEN @Category = '1401' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV One Connect Box for Television (No Cable)')
				WHEN @Category = '1305' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' TV One Connect Cable for Television'
				WHEN @Category = '1201' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN @Category = '1202' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN @Category = '1203' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1204' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN @Category = '1205' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1206' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1207' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1301' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Cable Cord'
				WHEN @Category = '1302' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Audio Video Cable A/V Cord'
				WHEN @Category = '1303' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Specialty Cable Cord'
				WHEN @Category = '1304' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cable Cord'
				ELSE
				@Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' ' + @CategoryName
				END
				)
				AS [Auction Title],
				'AVAILABLE' AS [Quantity Update Type],
				[Remotes].[dbo].[fn_GetQtyByScanCode](@SKU,@Condition) AS [Quantity],
				@Length AS [Length],
				@Height AS [Height],
				@Width AS [Width],
				@Weight AS [Weight],
				@PartNumber+'-'+LTRIM(RTRIM([Item]))+'-'+@Condition AS [MPN],

				(CASE 
				WHEN @Category = '1401' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV One Connect Box for Television (No Cable)')
				WHEN @Category = '1305' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' TV One Connect Cable for Television'
				WHEN @Category = '1201' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN @Category = '1202' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN @Category = '1203' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1204' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN @Category = '1205' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1206' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1207' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1301' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Cable Cord'
				WHEN @Category = '1302' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Audio Video Cable A/V Cord'
				WHEN @Category = '1303' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Specialty Cable Cord'
				WHEN @Category = '1304' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cable Cord'
				ELSE
				@Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' ' + @CategoryName
				END
				)
				AS [Short Description],
		
				(CASE 
				WHEN @Category = '1401' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV One Connect Box for Television (No Cable)')
				WHEN @Category = '1305' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' TV One Connect Cable for Television'
				WHEN @Category = '1201' THEN 
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item]) + ' TV Power Adapter Cable Cord Box (Television Adaptor)')
				WHEN @Category = '1202' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Laptop Power Adapter Cable Cord Box Adaptor (Notebook)'
				WHEN @Category = '1203' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Tablet Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1204' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cell Phone Power Adapter Cable Cord Box Adaptor (Telephone)'
				WHEN @Category = '1205' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Appliance Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1206' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Monitor Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1207' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Adapter Cable Cord Box Adaptor'
				WHEN @Category = '1301' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Power Cable Cord'
				WHEN @Category = '1302' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Audio Video Cable A/V Cord'
				WHEN @Category = '1303' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Specialty Cable Cord'
				WHEN @Category = '1304' THEN
				'Original ' + @Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' Cable Cord'
				ELSE
				@Manufacturer + ' ' + LTRIM(RTRIM([Item])) + ' ' + @CategoryName
				END
				)
				AS [Description],
		
				@Manufacturer AS [Manufacturer],
				@Manufacturer AS [Brand],
				'Used' AS [Condition],
				'30 Days' AS [Warranty],
				@UnitCostUSED AS [Seller Cost],
				IsNull(@CeilingPrice,'289.99') AS [Buy It Now Price],
				IsNULL(CEILING(@CeilingPrice*2)-0.01,'289.99') AS [Retail Price],
				@ImageURLs AS [Picture URLs],
				'' AS [Description Template Name],
				'' AS [Posting Template Name],
				'' AS [Schedule Name],
				'' AS [eBay Category List],
				'' AS [eBay Store Category Name],
				'' AS [Labels],
				(CASE
				WHEN @Category = '1401' THEN 'Media Boxes - One Connect'
				WHEN @Category = '1305' THEN 'Cables - One Connect'
				WHEN @Category = '1201' THEN 'Power Adapter - TV'
				WHEN @Category = '1202' THEN 'Power Adapter - Laptop'
				WHEN @Category = '1203' THEN 'Power Adapter - Tablet'
				WHEN @Category = '1204' THEN 'Power Adapter - Cell Phone'
				WHEN @Category = '1205' THEN 'Power Adapter - Appliance'
				WHEN @Category = '1206' THEN 'Power Adapter - Monitor'
				WHEN @Category = '1207' THEN 'Power Adapter - Other'
				WHEN @Category = '1301' THEN 'Cables - Power'
				WHEN @Category = '1302' THEN 'Cables - Audio Video'
				WHEN @Category = '1303' THEN 'Cables - Specialty'
				WHEN @Category = '1304' THEN 'Cables - Other'
				ELSE 'Other' END) AS [Classification],
				'BoughtsSKU' AS [Attribute1Name],
				@SKU+'-'+@Condition AS [Attribute1Value],
				'MarketplaceUPC' AS [Attribute2Name],
				'' AS [Attribute2Value],
				'ListingType' AS [Attribute3Name],
				'ModelSpecific' AS [Attribute3Value],
				'BoughtsCategory' AS [Attribute4Name],
				@CategoryName AS [Attribute4Value],
				'FloorPrice' AS [Attribute5Name],
				@FloorPrice AS [Attribute5Value],
				'CompatibleBrand' AS [Attribute6Name],
				@Manufacturer AS [Attribute6Value],
				'OriginallySuppliedWith' AS [Attribute7Name],
				@OriginallySuppliedWith AS [Attribute7Value],
				'AlsoCompatibleWith' AS [Attribute8Name],
				@AlsoCompatibleWith AS [Attribute8Value],
				'' AS [Attribute9Name],
				'' AS [Attribute9Value],
				'' AS [Attribute10Name],
				'' AS [Attribute10Value],
				'' AS [Attribute11Name],
				'' AS [Attribute11Value],
				'' AS [Attribute12Name],
				'' AS [Attribute12Value],
				'' AS [Attribute13Name],
				'' AS [Attribute13Value],
				'' AS [Attribute14Name],
				'' AS [Attribute14Value],
				'' AS [Attribute15Name],
				'' AS [Attribute15Value]

				FROM [Remotes].[dbo].[fn_SplitItem](@ModelList)

			  FETCH NEXT FROM sku_cursor INTO @SKU 
		END 


		CLOSE sku_cursor  
		DEALLOCATE sku_cursor 
		---------------------------------------------------------------------------

		PRINT 'POWER ADAPTERS, CABLES, AND ONE CONNECT - Model Specific USED Completed at '+CAST(GETDATE() AS NVARCHAR(50))
		


		DELETE FROM #TempTable WHERE [Inventory Number] IS NULL OR [Inventory Number] = '';
		--DELETE FROM #TempTable WHERE [Inventory Number] LIKE '%New%' AND [Quantity] = 0;
		--DELETE FROM #TempTable WHERE [Inventory Number] LIKE '%Used%' AND [Quantity] = 0;


		--DELETES DUPLICATES CAUSED BY OVERLAPPING MODELS in AlsoCompatibleWith and OriginallySuppliedWith
		WITH CTE AS(
		   SELECT [Inventory Number],
			   RN = ROW_NUMBER()OVER(PARTITION BY [Inventory Number] ORDER BY [Inventory Number])
		   FROM #TempTable
		)
		DELETE FROM CTE WHERE RN > 1


		PRINT 'TempTable Cleanup Completed at '+CAST(GETDATE() AS NVARCHAR(50))

		--Insert into ChannelAdvisorCore
		--We create this table to see what is in the new full feed vs what exists in ChannelAdvisor Table
		--We do this in order to find which items are no longer in the feed so we can mark them for removal from ChannelAdvisor
		IF OBJECT_ID('[Remotes].[dbo].[ChannelAdvisorCore]') IS NOT NULL
		DROP TABLE [Remotes].[dbo].[ChannelAdvisorCore]

		CREATE TABLE [Remotes].[dbo].[ChannelAdvisorCore]([Inventory Number] NVARCHAR(MAX), [Title] NVARCHAR(MAX), [BoughtsSKU] NVARCHAR(MAX))

		INSERT INTO [Remotes].[dbo].[ChannelAdvisorCore]([Inventory Number], [Title], [BoughtsSKU])
		SELECT TMP.[Inventory Number], TMP.[Auction Title], TMP.[Attribute1Value] FROM #TempTable AS TMP
		WHERE TMP.[Inventory Number] IS NOT NULL
		ORDER BY TMP.[Inventory Number] ASC

		--We test if ChannelAdvisorCore Table has more than 20k records to prevent us marking 
		--everything for deletion in case the table is empty signaling an error in processing the feed into the table.
		IF ((SELECT COUNT(*) FROM [Remotes].[dbo].[ChannelAdvisorCore]) > 20000)
		BEGIN

			UPDATE CA
			SET [MarkedForDeletion] = 0, [MarkedForDeletionStamp] = NULL
			FROM [Remotes].[dbo].[ChannelAdvisor] AS CA
			WHERE [MarkedForDeletion] IS NULL

			UPDATE CA
			SET [MarkedForDeletion] = 1, [MarkedForDeletionStamp] = GETDATE()
			FROM [Remotes].[dbo].[ChannelAdvisor] AS CA
			LEFT OUTER JOIN [Remotes].[dbo].[ChannelAdvisorCore] AS CAC ON (CA.[Inventory Number] = CAC.[Inventory Number])
			WHERE CAC.[Inventory Number] IS NULL
			AND [MarkedForDeletionStamp] IS NULL

		
			UPDATE U
			SET U.[Inventory Number] = 'Removed-'+U.[Inventory Number] 
			FROM [Remotes].[dbo].[UPC] AS U
			LEFT OUTER JOIN [Remotes].[dbo].[ChannelAdvisorCore] AS CAC ON (U.[Inventory Number] = CAC.[Inventory Number])
			WHERE CAC.[Inventory Number] IS NULL
			AND U.[Inventory Number] NOT LIKE '%Removed%'

		END

		PRINT 'ChannelAdvisor Core UPDATE at '+CAST(GETDATE() AS NVARCHAR(50))

		SELECT * FROM #TempTable



       --Insert into ChannelAdvisorDB only if it doesn't exist
		INSERT INTO [Remotes].[dbo].[ChannelAdvisor] ([Inventory Number] ,[Auction Title] ,[Quantity Update Type] ,[Quantity] ,[Length] ,[Height] ,[Width] ,[Weight] , [MPN] ,[Short Description] ,[Description] 
				,[Manufacturer] ,[Brand] ,[Condition] ,[Warranty] ,[Seller Cost] ,[Buy It Now Price] ,[Retail Price] ,[Picture URLs] ,[Description Template Name] 
				,[Posting Template Name] ,[Schedule Name] ,[eBay Category List] ,[eBay Store Category Name] ,[Labels] ,[Classification] ,[Attribute1Name] ,[Attribute1Value] 
				,[Attribute2Name] ,[Attribute2Value] ,[Attribute3Name] ,[Attribute3Value] ,[Attribute4Name] ,[Attribute4Value] ,[Attribute5Name] ,[Attribute5Value]
				 ,[Attribute6Name] ,[Attribute6Value] ,[Attribute7Name] ,[Attribute7Value] ,[Attribute8Name] ,[Attribute8Value],[Attribute9Name] ,[Attribute9Value] 
				 ,[Attribute10Name] ,[Attribute10Value] ,[Attribute11Name] ,[Attribute11Value] ,[Attribute12Name] ,[Attribute12Value],[Attribute13Name] ,[Attribute13Value] 
				 ,[Attribute14Name] ,[Attribute14Value] ,[Attribute15Name] ,[Attribute15Value])
		SELECT DISTINCT TMP.[Inventory Number] ,TMP.[Auction Title] ,TMP.[Quantity Update Type] ,TMP.[Quantity] ,TMP.[Length] ,TMP.[Height] ,TMP.[Width] ,TMP.[Weight] ,TMP.[MPN] ,TMP.[Short Description] ,TMP.[Description] 
				,TMP.[Manufacturer] ,TMP.[Brand] ,TMP.[Condition] ,TMP.[Warranty] ,TMP.[Seller Cost] ,TMP.[Buy It Now Price] ,TMP.[Retail Price] ,TMP.[Picture URLs] ,TMP.[Description Template Name] 
				,TMP.[Posting Template Name] ,TMP.[Schedule Name] ,TMP.[eBay Category List] ,TMP.[eBay Store Category Name] ,TMP.[Labels] ,TMP.[Classification] ,TMP.[Attribute1Name] ,TMP.[Attribute1Value] 
				,TMP.[Attribute2Name] ,TMP.[Attribute2Value] ,TMP.[Attribute3Name] ,TMP.[Attribute3Value] ,TMP.[Attribute4Name] ,TMP.[Attribute4Value] ,TMP.[Attribute5Name] ,TMP.[Attribute5Value]
				 ,TMP.[Attribute6Name] ,TMP.[Attribute6Value] ,TMP.[Attribute7Name] ,TMP.[Attribute7Value] ,TMP.[Attribute8Name] ,TMP.[Attribute8Value],TMP.[Attribute9Name] ,TMP.[Attribute9Value] 
				 ,TMP.[Attribute10Name] ,TMP.[Attribute10Value] ,TMP.[Attribute11Name] ,TMP.[Attribute11Value] ,TMP.[Attribute12Name] ,TMP.[Attribute12Value],TMP.[Attribute13Name] ,TMP.[Attribute13Value] 
				 ,TMP.[Attribute14Name] ,TMP.[Attribute14Value] ,TMP.[Attribute15Name] ,TMP.[Attribute15Value]
				 FROM #TempTable AS TMP
				 LEFT OUTER JOIN [Remotes].[dbo].[ChannelAdvisor] AS CA ON (TMP.[Inventory Number] = CA.[Inventory Number])
				 WHERE 
				 TMP.[Inventory Number] IS NOT NULL
				 AND CA.[Inventory Number] IS NULL
				 ORDER BY [Inventory Number] ASC


		PRINT 'ChannelAdvisor Main Table Updated at '+CAST(GETDATE() AS NVARCHAR(50))
				 


		-------------BEGIN ADDING UPCS TO NEWLY ADDED PRODUCTS IN CHANNELADVISOR------------
		IF OBJECT_ID('[Remotes].[dbo].[TempCA]') IS NOT NULL
		DROP TABLE [Remotes].[dbo].[TempCA]

		IF OBJECT_ID('[Remotes].[dbo].[TempUPC]') IS NOT NULL
		DROP TABLE [Remotes].[dbo].[TempUPC]

		--TEMP ChannelAdvisorTable for UPC Mapping - ALL RECORDS FROM CA WITHOUT UPC
		CREATE TABLE [Remotes].[dbo].[TempCA] ([Row] INT,[ID] INT, [Inventory Number] NVARCHAR(MAX)
				,[Auction Title] NVARCHAR(MAX)
				,[Attribute2Name] NVARCHAR(MAX)
				,[Attribute2Value] NVARCHAR(MAX))

		INSERT INTO [Remotes].[dbo].[TempCA]
		SELECT  
				ROW_NUMBER() OVER(ORDER BY [Inventory Number] ASC) AS Row#
				,[ID]
				,[Inventory Number]
				,[Auction Title]
				,[Attribute2Name]
				,[Attribute2Value]
			FROM [Remotes].[dbo].[ChannelAdvisor]
			WHERE [Attribute2Value] = '' OR [Attribute2Value] IS NULL
			ORDER BY [ID] ASC

 
		--TEMP UPC TABLE - ALL RECORDS FROM UPC WITHOUT INVENTORYNUMBER
		CREATE TABLE [Remotes].[dbo].[TempUPC] ([Row] INT, [ID] INT, [UPC] NVARCHAR(MAX), [Inventory Number] NVARCHAR(MAX))

		INSERT INTO [Remotes].[dbo].[TempUPC]
		SELECT  
				ROW_NUMBER() OVER(ORDER BY [Inventory Number] ASC) AS Row#
				,[ID]
				,[UPC]
				,[Inventory Number]
		FROM [Remotes].[dbo].[UPC]
		WHERE [Inventory Number] = '' OR [Inventory Number] IS NULL
		ORDER BY [ID] ASC

		--UPDATE TEMP UPC Table
		UPDATE U SET U.[Inventory Number] = CA.[Inventory Number]
		FROM [Remotes].[dbo].[TempUPC] AS U
		LEFT OUTER JOIN [Remotes].[dbo].[TempCA] AS CA ON (U.[Row] = CA.[Row])
		WHERE CA.[Row] IS NOT NULL

		--UPDATE REAL UPC TABLE
		UPDATE RU SET RU.[Inventory Number] = TU.[Inventory Number]
		FROM [Remotes].[dbo].[UPC] AS RU
		LEFT OUTER JOIN [Remotes].[dbo].[TempUPC] AS TU ON (RU.[UPC] = TU.[UPC])
		WHERE RU.[Inventory Number] IS NULL

		--UPDATE REAL CA TABLE from REAL UPC TABLE
		UPDATE CA SET CA.[Attribute2Value] = (SELECT TOP(1) [UPC] FROM [Remotes].[dbo].[UPC] WHERE [Inventory Number] = CA.[Inventory Number])
		FROM [Remotes].[dbo].[ChannelAdvisor] AS CA


		PRINT 'UPCs Added at '+CAST(GETDATE() AS NVARCHAR(50))

		-------------THIS COMPLETES ADDING UPCS TO NEWLY ADDED PRODUCTS IN CHANNELADVISOR------------


		--UPDATE IMAGES TO CDN HTTPS
	    UPDATE [Remotes].[dbo].[ChannelAdvisor]
	    SET  [Picture URLs] = REPLACE([Picture URLs],'http://remotespict.mitechnologiesinc.com','https://d2tmwtn0gh4496.cloudfront.net')
      
		PRINT 'Images Updated at '+CAST(GETDATE() AS NVARCHAR(50))
		PRINT 'Starting Feed... '+CAST(GETDATE() AS NVARCHAR(50))

		DROP TABLE IF EXISTS [Remotes].[dbo].[ChannelAdvisorTemp]
		DROP TABLE IF EXISTS [Remotes].[dbo].[ChannelAdvisorTempCL]

		---FINAL SELECT FOR FEED
		CREATE TABLE [Remotes].[dbo].[ChannelAdvisorTemp] ([Inventory Number] nvarchar(max),[Auction Title] nvarchar(max)
		,[Quantity Update Type] nvarchar(max),[Quantity] nvarchar(max)
		,[Length] nvarchar(max),[Height] nvarchar(max),[Width] nvarchar(max),[Weight] nvarchar(max)
		,[MPN] nvarchar(max),[Short Description] nvarchar(max),[Description] nvarchar(max)
		,[Manufacturer] nvarchar(max),[Brand] nvarchar(max),[Condition] nvarchar(max),[Warranty] nvarchar(max)
		,[Seller Cost] nvarchar(max),[Buy It Now Price] nvarchar(max),[Retail Price] nvarchar(max)
		,[Picture URLs] nvarchar(max),[Description Template Name] nvarchar(max)
		,[Posting Template Name] nvarchar(max),[Schedule Name] nvarchar(max),[eBay Category List] nvarchar(max)
		,[eBay Store Category Name] nvarchar(max),[Labels] nvarchar(max),[Classification] nvarchar(max)
		,[Attribute1Name] nvarchar(max),[Attribute1Value] nvarchar(max),[Attribute2Name] nvarchar(max)
		,[Attribute2Value] nvarchar(max),[Attribute3Name] nvarchar(max),[Attribute3Value] nvarchar(max)
		,[Attribute4Name] nvarchar(max),[Attribute4Value] nvarchar(max),[Attribute5Name] nvarchar(max)
		,[Attribute5Value] nvarchar(max),[Attribute6Name] nvarchar(max),[Attribute6Value] nvarchar(max)
		,[Attribute7Name] nvarchar(max),[Attribute7Value] nvarchar(max),[Attribute8Name] nvarchar(max)
		,[Attribute8Value] nvarchar(max),[Attribute9Name] nvarchar(max),[Attribute9Value] nvarchar(max)
		,[Attribute10Name] nvarchar(max),[Attribute10Value] nvarchar(max),[Attribute11Name] nvarchar(max)
		,[Attribute11Value] nvarchar(max),[Attribute12Name] nvarchar(max),[Attribute12Value] nvarchar(max)
		,[Attribute13Name] nvarchar(max),[Attribute13Value] nvarchar(max),[Attribute14Name] nvarchar(max)
		,[Attribute14Value] nvarchar(max),[Attribute15Name] nvarchar(max),[Attribute15Value] nvarchar(max)
		,[Attribute16Name] nvarchar(max),[Attribute16Value] nvarchar(max),[Attribute17Name] nvarchar(max)
		,[Attribute17Value] nvarchar(max),[Attribute18Name] nvarchar(max),[Attribute18Value] nvarchar(max)
		,[Attribute19Name] nvarchar(max),[Attribute19Value] nvarchar(max),[Attribute20Name] nvarchar(max)
		,[Attribute20Value] nvarchar(max),[Attribute21Name] nvarchar(max),[Attribute21Value] nvarchar(max)
		,[Attribute22Name] nvarchar(max),[Attribute22Value] nvarchar(max),[Attribute23Name] nvarchar(max)
		,[Attribute23Value] nvarchar(max),[Attribute24Name] nvarchar(max),[Attribute24Value] nvarchar(max)
		,[Attribute25Name] nvarchar(max),[Attribute25Value] nvarchar(max))

		INSERT INTO [Remotes].[dbo].[ChannelAdvisorTemp]
		SELECT  
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Inventory Number] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Inventory Number], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Auction Title] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Auction Title], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Quantity Update Type] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Quantity Update Type], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Quantity] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Quantity], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Length] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Length], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Height] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Height], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Width] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Width], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Weight] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Weight], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([MPN] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [MPN], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Short Description] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Short Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Description] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Manufacturer] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Manufacturer], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Brand] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Brand], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Condition] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Condition], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Warranty] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Warranty], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Seller Cost] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Seller Cost], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Buy It Now Price] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Buy It Now Price], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Retail Price],'-0.01','89.99') ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Retail Price], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Picture URLs] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Picture URLs],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Description Template Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Description Template Name],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Posting Template Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Posting Template Name],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Schedule Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Schedule Name],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([eBay Category List] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [eBay Category List],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([eBay Store Category Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [eBay Store Category Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Labels] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Labels], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Classification] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Classification], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute1Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute1Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute1Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute1Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute2Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute2Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute2Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute2Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute3Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute3Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute3Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute3Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute4Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute4Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute4Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute4Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute5Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute5Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute5Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute5Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute6Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute6Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute6Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute6Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute7Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute7Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute7Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute7Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute8Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute8Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Value],
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute9Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute9Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute9Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute9Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute10Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute10Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute10Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute10Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute11Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute11Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute11Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute11Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute12Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute12Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute12Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute12Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute13Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute13Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute13Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute13Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute14Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute14Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute14Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute14Value], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute15Name] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute15Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE([Attribute15Value] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute15Value],
		'""' AS [Attribute16Name], 
		'""' AS [Attribute16Value],
		'""' AS [Attribute17Name], 
		'""' AS [Attribute17Value],
		'""' AS [Attribute18Name], 
		'""' AS [Attribute18Value],
		'""' AS [Attribute19Name], 
		'""' AS [Attribute19Value],
		'""' AS [Attribute20Name], 
		'""' AS [Attribute20Value],
		'""' AS [Attribute21Name], 
		'""' AS [Attribute21Value],
		'""' AS [Attribute22Name], 
		'""' AS [Attribute22Value],
		'""' AS [Attribute23Name], 
		'""' AS [Attribute23Value],
		'""' AS [Attribute24Name], 
		'""' AS [Attribute24Value],
		'""' AS [Attribute25Name], 
		'""' AS [Attribute25Value]

		FROM [Remotes].[dbo].[ChannelAdvisor]  WITH (NOLOCK)
		WHERE [MarkedForDeletion] = 0  OR [MarkedForDeletion] IS NULL
		--WHERE [Quantity] > 0
		ORDER BY [ID] ASC


		--Create CleanLaunchTemp Table
		CREATE TABLE [Remotes].[dbo].[ChannelAdvisorTempCL] ([Inventory Number] nvarchar(max),[Auction Title] nvarchar(max)
		,[Quantity Update Type] nvarchar(max),[Quantity] nvarchar(max)
		,[Length] nvarchar(max),[Height] nvarchar(max),[Width] nvarchar(max),[Weight] nvarchar(max)
		,[MPN] nvarchar(max),[Short Description] nvarchar(max),[Description] nvarchar(max)
		,[Manufacturer] nvarchar(max),[Brand] nvarchar(max),[Condition] nvarchar(max),[Warranty] nvarchar(max)
		,[Seller Cost] nvarchar(max),[Buy It Now Price] nvarchar(max),[Retail Price] nvarchar(max)
		,[Picture URLs] nvarchar(max),[Description Template Name] nvarchar(max)
		,[Posting Template Name] nvarchar(max),[Schedule Name] nvarchar(max),[eBay Category List] nvarchar(max)
		,[eBay Store Category Name] nvarchar(max),[Labels] nvarchar(max),[Classification] nvarchar(max)
		,[Attribute1Name] nvarchar(max),[Attribute1Value] nvarchar(max),[Attribute2Name] nvarchar(max)
		,[Attribute2Value] nvarchar(max),[Attribute3Name] nvarchar(max),[Attribute3Value] nvarchar(max)
		,[Attribute4Name] nvarchar(max),[Attribute4Value] nvarchar(max),[Attribute5Name] nvarchar(max)
		,[Attribute5Value] nvarchar(max),[Attribute6Name] nvarchar(max),[Attribute6Value] nvarchar(max)
		,[Attribute7Name] nvarchar(max),[Attribute7Value] nvarchar(max),[Attribute8Name] nvarchar(max)
		,[Attribute8Value] nvarchar(max),[Attribute9Name] nvarchar(max),[Attribute9Value] nvarchar(max)
		,[Attribute10Name] nvarchar(max),[Attribute10Value] nvarchar(max),[Attribute11Name] nvarchar(max)
		,[Attribute11Value] nvarchar(max),[Attribute12Name] nvarchar(max),[Attribute12Value] nvarchar(max)
		,[Attribute13Name] nvarchar(max),[Attribute13Value] nvarchar(max),[Attribute14Name] nvarchar(max)
		,[Attribute14Value] nvarchar(max),[Attribute15Name] nvarchar(max),[Attribute15Value] nvarchar(max)
		,[Attribute16Name] nvarchar(max),[Attribute16Value] nvarchar(max),[Attribute17Name] nvarchar(max)
		,[Attribute17Value] nvarchar(max),[Attribute18Name] nvarchar(max),[Attribute18Value] nvarchar(max)
		,[Attribute19Name] nvarchar(max),[Attribute19Value] nvarchar(max),[Attribute20Name] nvarchar(max)
		,[Attribute20Value] nvarchar(max),[Attribute21Name] nvarchar(max),[Attribute21Value] nvarchar(max)
		,[Attribute22Name] nvarchar(max),[Attribute22Value] nvarchar(max),[Attribute23Name] nvarchar(max)
		,[Attribute23Value] nvarchar(max),[Attribute24Name] nvarchar(max),[Attribute24Value] nvarchar(max)
		,[Attribute25Name] nvarchar(max),[Attribute25Value] nvarchar(max))



		--Add CleanLaunch Items - NEW
		INSERT INTO [Remotes].[dbo].[ChannelAdvisorTempCL]
		SELECT  
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[SKU]+'-'+CAST(CL.[ID] AS NVARCHAR(MAX))+'-NEW' ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Inventory Number], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonTitle] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Auction Title], 
		'"Available"' AS [Quantity Update Type], 
		'"' + CAST([Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'NEW') AS NVARCHAR(MAX)) + '"' AS [Quantity], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[Length],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Length], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[Height],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Height], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[Width],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Width], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[WeightOz],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Weight], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CL.[ID] AS NVARCHAR(MAX))+'-'+CL.[PartNumber] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [MPN], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[MobileDescription] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Short Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[FullDescription] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Brand] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Manufacturer], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Brand] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Brand], 
		'"New"' AS [Condition], 
		'"6 Months"' AS [Warranty], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(SKUD.[UnitCost] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Seller Cost], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CeilingPrice] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Buy It Now Price], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CL.[CeilingPrice]*1.4 AS Decimal(10,2)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Retail Price], 
		'"' + IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				)   ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') + '"' AS [Picture URLs],
		'""' AS [Description Template Name],
		'""' AS [Posting Template Name],
		'""' AS [Schedule Name],
		'""' AS [eBay Category List],
		'""' AS [eBay Store Category Name], 
		'"All Inventory, Walmart Marketplace, Amazon Marketplace - US"' AS [Labels], 
		'"'+(CASE WHEN SKUD.[CategoryID] = '' THEN '' ELSE 'Remote Control' END)+'"' AS [Classification], 
		'"BoughtsSKU"' AS [Attribute1Name], 
		'"' + CL.[SKU] + '-NEW"' AS [Attribute1Value], 
		'"MarketplaceUPC"' AS [Attribute2Name], 
		'"' + CAST(CL.[UPC] AS NVARCHAR(MAX)) + '"' AS [Attribute2Value], 
		'"ListingType"' AS [Attribute3Name], 
		'"CleanLaunch"' AS [Attribute3Value], 
		'"BoughtsCategory"' AS [Attribute4Name], 
		'"' + CAT.[CategoryName] + '"' AS [Attribute4Value], 
		'"FloorPrice"' AS [Attribute5Name], 
		'"' + CAST(CL.[FloorPrice] AS NVARCHAR(MAX)) + '"' AS [Attribute5Value], 
		'"CompatibleBrand"' AS [Attribute6Name], 
		'"' + CL.[Brand] + '"' AS [Attribute6Value], 
		'"ASIN"' AS [Attribute7Name], 
		'"' + CL.[ASIN] + '"' AS [Attribute7Value], 
		'"Bullet1"' AS [Attribute8Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet1] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Value],
		'"Bullet2"' AS [Attribute9Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet2] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute9Value], 
		'"Bullet3"' AS [Attribute10Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet3] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute10Value], 
		'"Bullet4"' AS [Attribute11Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet4] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute11Value], 
		'"Bullet5"' AS [Attribute12Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet5] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute12Value], 
		'"AmazonCategory"' AS [Attribute13Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonCategory] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute13Value], 
		'"AmazonProductType"' AS [Attribute14Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonProductType] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute14Value], 
		'"AmazonProductSubtype"' AS [Attribute15Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonProductSubtype] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute15Value],
		'"CustomField1"' AS [Attribute16Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField1] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute16Value],
		'"CustomField2"' AS [Attribute17Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField2] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute17Value],
		'"CustomField3"' AS [Attribute18Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField3] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute18Value],
		'"CustomField4"' AS [Attribute19Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField4] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute19Value],
		'"CustomField5"' AS [Attribute20Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField5] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute20Value],
		'"AmazonShipTemplate"' AS [Attribute21Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonShipTemplate] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute21Value],
		'""' AS [Attribute22Name], 
		'""' AS [Attribute22Value],
		'""' AS [Attribute23Name], 
		'""' AS [Attribute23Value],
		'""' AS [Attribute24Name], 
		'""' AS [Attribute24Value],
		'""' AS [Attribute25Name], 
		'""' AS [Attribute25Value] 

		FROM [Remotes].[dbo].[CleanLaunch] AS CL  WITH (NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD ON (CL.[SKU] = SKUD.[SKU])
		LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT ON (SKUD.[CategoryID] = CAT.[CategoryID])
		WHERE CL.[Condition] = 'New' AND  [Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'NEW') > 0
		ORDER BY CL.[ID] ASC


		--Add CleanLaunch Items - CN
		INSERT INTO [Remotes].[dbo].[ChannelAdvisorTempCL]
		SELECT  
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[SKU]+'-'+CAST(CL.[ID] AS NVARCHAR(MAX))+'-CN' ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Inventory Number], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonTitle] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Auction Title], 
		'"Available"' AS [Quantity Update Type], 
		'"' + CAST([Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'CN') AS NVARCHAR(MAX)) + '"' AS [Quantity], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[Length],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Length], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[Height],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Height], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[Width],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Width], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[WeightOz],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Weight], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CL.[ID] AS NVARCHAR(MAX))+'-'+CL.[PartNumber] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [MPN], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[MobileDescription] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Short Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[FullDescription] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Brand] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Manufacturer], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Brand] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Brand], 
		'"New"' AS [Condition], 
		'"6 Months"' AS [Warranty], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(SKUD.[UnitCost] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Seller Cost], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CeilingPrice] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Buy It Now Price], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CL.[CeilingPrice]*1.4 AS Decimal(10,2)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Retail Price], 
		'"' + IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				)   ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') + '"' AS [Picture URLs],
		'""' AS [Description Template Name],
		'""' AS [Posting Template Name],
		'""' AS [Schedule Name],
		'""' AS [eBay Category List],
		'""' AS [eBay Store Category Name], 
		'"All Inventory, Walmart Marketplace, Amazon Marketplace - US"' AS [Labels], 
		'"'+(CASE WHEN SKUD.[CategoryID] = '' THEN '' ELSE 'Remote Control' END)+'"' AS [Classification], 
		'"BoughtsSKU"' AS [Attribute1Name], 
		'"' + CL.[SKU] + '-NEW"' AS [Attribute1Value], 
		'"MarketplaceUPC"' AS [Attribute2Name], 
		'"' + CAST(CL.[UPC] AS NVARCHAR(MAX)) + '"' AS [Attribute2Value], 
		'"ListingType"' AS [Attribute3Name], 
		'"CleanLaunch"' AS [Attribute3Value], 
		'"BoughtsCategory"' AS [Attribute4Name], 
		'"' + CAT.[CategoryName] + '"' AS [Attribute4Value], 
		'"FloorPrice"' AS [Attribute5Name], 
		'"' + CAST(CL.[FloorPrice] AS NVARCHAR(MAX)) + '"' AS [Attribute5Value], 
		'"CompatibleBrand"' AS [Attribute6Name], 
		'"' + CL.[Brand] + '"' AS [Attribute6Value], 
		'"ASIN"' AS [Attribute7Name], 
		'"' + CL.[ASIN] + '"' AS [Attribute7Value], 
		'"Bullet1"' AS [Attribute8Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet1] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Value],
		'"Bullet2"' AS [Attribute9Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet2] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute9Value], 
		'"Bullet3"' AS [Attribute10Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet3] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute10Value], 
		'"Bullet4"' AS [Attribute11Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet4] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute11Value], 
		'"Bullet5"' AS [Attribute12Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet5] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute12Value], 
		'"AmazonCategory"' AS [Attribute13Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonCategory] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute13Value], 
		'"AmazonProductType"' AS [Attribute14Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonProductType] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute14Value], 
		'"AmazonProductSubtype"' AS [Attribute15Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonProductSubtype] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute15Value],
		'"CustomField1"' AS [Attribute16Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField1] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute16Value],
		'"CustomField2"' AS [Attribute17Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField2] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute17Value],
		'"CustomField3"' AS [Attribute18Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField3] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute18Value],
		'"CustomField4"' AS [Attribute19Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField4] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute19Value],
		'"CustomField5"' AS [Attribute20Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField5] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute20Value],
		'"AmazonShipTemplate"' AS [Attribute21Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonShipTemplate] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute21Value],
		'""' AS [Attribute22Name], 
		'""' AS [Attribute22Value],
		'""' AS [Attribute23Name], 
		'""' AS [Attribute23Value],
		'""' AS [Attribute24Name], 
		'""' AS [Attribute24Value],
		'""' AS [Attribute25Name], 
		'""' AS [Attribute25Value] 

		FROM [Remotes].[dbo].[CleanLaunch] AS CL  WITH (NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD ON (CL.[SKU] = SKUD.[SKU])
		LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT ON (SKUD.[CategoryID] = CAT.[CategoryID])
		WHERE CL.[Condition] = 'CN' AND [Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'CN') > 0
		ORDER BY CL.[ID] ASC


		--Add CleanLaunch Items - USED
		INSERT INTO [Remotes].[dbo].[ChannelAdvisorTempCL]
		SELECT  
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[SKU]+'-'+CAST(CL.[ID] AS NVARCHAR(MAX))+'-USED' ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Inventory Number], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonTitle] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Auction Title], 
		'"Available"' AS [Quantity Update Type], 
		'"' + CAST([Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'USED') AS NVARCHAR(MAX)) + '"' AS [Quantity], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[Length],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Length], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[Height],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Height], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[Width],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Width], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(IsNull(SKUD.[WeightOz],0) AS NVARCHAR(MAX)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Weight], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CL.[ID] AS NVARCHAR(MAX))+'-'+CL.[PartNumber] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [MPN], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[MobileDescription] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Short Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[FullDescription] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Description], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Brand] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Manufacturer], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Brand] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Brand], 
		'"Used"' AS [Condition], 
		'"6 Months"' AS [Warranty], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(SKUD.[UnitCost] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Seller Cost], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CeilingPrice] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Buy It Now Price], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CAST(CL.[CeilingPrice]*1.4 AS Decimal(10,2)) ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Retail Price], 
		'"' + IsNull((SELECT stuff((SELECT ', ' + cast([Url] as varchar(max)) FROM [Remotes].[dbo].[Image] WHERE [SKU] = SKUD.[SKU] 
				AND 
				(
				RIGHT([name],'6') LIKE '%'+'01.jpg'
				OR RIGHT([name],'6') LIKE '%'+'02.jpg'
				OR RIGHT([name],'6') LIKE '%'+'03.jpg'
				OR RIGHT([name],'6') LIKE '%'+'04.jpg'
				OR RIGHT([name],'6') LIKE '%'+'05.jpg'
				OR RIGHT([name],'6') LIKE '%'+'06.jpg'
				)   ORDER BY [Url] ASC
				FOR XML PATH('')), 1, 2, '')),'') + '"' AS [Picture URLs],
		'""' AS [Description Template Name],
		'""' AS [Posting Template Name],
		'""' AS [Schedule Name],
		'""' AS [eBay Category List],
		'""' AS [eBay Store Category Name], 
		'"All Inventory, -Walmart Marketplace, Amazon Marketplace - US"' AS [Labels], 
		'"'+(CASE WHEN SKUD.[CategoryID] = '' THEN '' ELSE 'Remote Control' END)+'"' AS [Classification], 
		'"BoughtsSKU"' AS [Attribute1Name], 
		'"' + CL.[SKU] + '-NEW"' AS [Attribute1Value], 
		'"MarketplaceUPC"' AS [Attribute2Name], 
		'"' + CAST(CL.[UPC] AS NVARCHAR(MAX)) + '"' AS [Attribute2Value], 
		'"ListingType"' AS [Attribute3Name], 
		'"CleanLaunch"' AS [Attribute3Value], 
		'"BoughtsCategory"' AS [Attribute4Name], 
		'"' + CAT.[CategoryName] + '"' AS [Attribute4Value], 
		'"FloorPrice"' AS [Attribute5Name], 
		'"' + CAST(CL.[FloorPrice] AS NVARCHAR(MAX)) + '"' AS [Attribute5Value], 
		'"CompatibleBrand"' AS [Attribute6Name], 
		'"' + CL.[Brand] + '"' AS [Attribute6Value], 
		'"ASIN"' AS [Attribute7Name], 
		'"' + CL.[ASIN] + '"' AS [Attribute7Value], 
		'"Bullet1"' AS [Attribute8Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet1] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute8Value],
		'"Bullet2"' AS [Attribute9Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet2] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute9Value], 
		'"Bullet3"' AS [Attribute10Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet3] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute10Value], 
		'"Bullet4"' AS [Attribute11Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet4] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute11Value], 
		'"Bullet5"' AS [Attribute12Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[Bullet5] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute12Value], 
		'"AmazonCategory"' AS [Attribute13Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonCategory] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute13Value], 
		'"AmazonProductType"' AS [Attribute14Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonProductType] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute14Value], 
		'"AmazonProductSubtype"' AS [Attribute15Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonProductSubtype] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute15Value],
		'"CustomField1"' AS [Attribute16Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField1] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute16Value],
		'"CustomField2"' AS [Attribute17Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField2] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute17Value],
		'"CustomField3"' AS [Attribute18Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField3] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute18Value],
		'"CustomField4"' AS [Attribute19Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField4] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute19Value],
		'"CustomField5"' AS [Attribute20Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[CustomField5] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute20Value],
		'"AmazonShipTemplate"' AS [Attribute21Name], 
		'"' + REPLACE(REPLACE(REPLACE(REPLACE(CL.[AmazonShipTemplate] ,CHAR(9),'') ,CHAR(10),'') ,CHAR(11),'') ,CHAR(13),'') + '"' AS [Attribute21Value],
		'""' AS [Attribute22Name], 
		'""' AS [Attribute22Value],
		'""' AS [Attribute23Name], 
		'""' AS [Attribute23Value],
		'""' AS [Attribute24Name], 
		'""' AS [Attribute24Value],
		'""' AS [Attribute25Name], 
		'""' AS [Attribute25Value] 

		FROM [Remotes].[dbo].[CleanLaunch] AS CL  WITH (NOLOCK)
		LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD ON (CL.[SKU] = SKUD.[SKU])
		LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT ON (SKUD.[CategoryID] = CAT.[CategoryID])
		WHERE CL.[Condition] = 'Used' AND [Remotes].[dbo].[fn_GetQtyByScanCode](CL.[SKU],'USED') > 0
		ORDER BY CL.[ID] ASC



		

		--SELECT * FROM [Remotes].[dbo].[ChannelAdvisorTemp] UNION ALL SELECT * FROM [Remotes].[dbo].[ChannelAdvisorTempCL]

		DECLARE @selectstatement NVARCHAR(3000)
		DECLARE @cmd NVARCHAR(3000)

		--START SELECT STATEMENT --We have to join CL becasue of DetectAndDrop
		SET @selectstatement = 'SELECT * FROM [Remotes].[dbo].[ChannelAdvisorTemp] UNION ALL SELECT * FROM [Remotes].[dbo].[ChannelAdvisorTempCL]'
		--END SELECT STATEMENT


		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\BSQLShares\ChannelAdvisor\ca-body.csv" -SBSQL -Usa -PZ91bM473 -c -C ACP -t"," -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\BSQLShares\ChannelAdvisor\cafeed.bat"'



		--SELECT * FROM [Remotes].[dbo].[ChannelAdvisorTempCL]

		--START SELECT STATEMENT CLEANLAUNCH
		SET @selectstatement = 'SELECT * FROM [Remotes].[dbo].[ChannelAdvisorTempCL]'
		--END SELECT STATEMENT


		SET @cmd = 'bcp "' + @selectstatement + '" queryout "C:\BSQLShares\ChannelAdvisor\ca-body.csv" -SBSQL -Usa -PZ91bM473 -c -C ACP -t"," -r"\n"'
		EXEC master..xp_cmdshell @cmd
		EXEC master..xp_cmdshell '"C:\BSQLShares\ChannelAdvisor\cafeedCL.bat"'



END
go

