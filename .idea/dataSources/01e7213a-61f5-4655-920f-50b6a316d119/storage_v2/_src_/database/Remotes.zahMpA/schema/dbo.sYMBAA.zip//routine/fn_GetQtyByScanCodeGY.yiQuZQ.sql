-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 8-26-2018
-- Description:	Get Qty by ScanCode GERMANY
-- =============================================
CREATE FUNCTION [dbo].[fn_GetQtyByScanCodeGY] 
(
	-- Add the parameters for the function here
	@pSKU nvarchar(10), @pScanCode nvarchar(20)
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = IsNull((
	SELECT SUM(BS.[StockQty]) FROM [Remotes].[dbo].[BinStock] AS BS WITH(NOLOCK)
	LEFT OUTER JOIN [Remotes].[dbo].[BinMaster] AS BM WITH(NOLOCK) ON (BS.[BinID] = BM.[BinID])
	WHERE BS.[SKU] = @pSKU 
	AND BS.[ScanCode] = @pScanCode
	AND BM.[WarehouseID] = 'GY'
	),0)
	-- Return the result of the function
	RETURN @Result 

END
go

