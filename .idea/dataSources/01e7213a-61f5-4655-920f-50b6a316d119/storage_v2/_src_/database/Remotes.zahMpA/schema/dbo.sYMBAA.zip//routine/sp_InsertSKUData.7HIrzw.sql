-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-03-25
-- Description:	Insert SKUData and Create automatic SKU 
-- =============================================
CREATE PROCEDURE [dbo].[sp_InsertSKUData]
	@Manufacturer		NVARCHAR(50),
	@PartNumber			NVARCHAR(50),
	@CompatibilityList	NVARCHAR(max),
	@AlternatePN		NVARCHAR(max),
	@ResearchComplete	BIT,
	@Length				INT,
	@Width				INT,
	@Height				INT,
	@WeightOz			INT,
	@FloorPrice			DECIMAL(10,2),
	@CeilingPrice		DECIMAL(10,2),
	@CategoryID			INT
AS
BEGIN
	DECLARE @COUNT	INT,
			@SKU	NVARCHAR(50)
	
	SET @COUNT = ISNULL((SELECT CAST((MAX(SUBSTRING(LTRIM(RTRIM(SKU)),5,LEN(SKU)-1))) AS INT) + 1 FROM [Remotes].[dbo].[SKUData]),1)
	SET NOCOUNT ON;

	SET @SKU = 'RMTC' + RIGHT('00000' + CONVERT(NVARCHAR,@COUNT),5)
		
	INSERT INTO [Remotes].[dbo].[SKUData] ( SKU, Manufacturer, PartNumber, CompatibilityList, AlternatePN, ResearchComplete, Length, Width, Height, WeightOz, FloorPrice, CeilingPrice, CategoryID )
	VALUES ( @SKU, @Manufacturer, @PartNumber, @CompatibilityList, @AlternatePN, @ResearchComplete, @Length, @Width, @Height, @WeightOz, @FloorPrice, @CeilingPrice, @CategoryID )

	SELECT @SKU

END
go

