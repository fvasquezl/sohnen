-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Catalog_2_SKU]
(
	@pCatalog varchar(20)
)
RETURNS int	
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar Int;
	DECLARE @temp Varchar(20);
	DECLARE @brand varchar(10);
	DECLARE @skuo int;
	DECLARE @skug int;
	SET @ResultVar = 0;

	IF CHARINDEX('-',@pCatalog) > 0
		BEGIN
			SET @temp = SUBSTRING ( @pCatalog ,0, CHARINDEX('-',@pCatalog) );
			SET @brand = SUBSTRING ( @pCatalog , CHARINDEX('-',@pCatalog)+1,10 );
			
			
			
			--Philips Bare
			IF @brand = 'BOP'
			BEGIN
				SELECT @skuo = a.BareSKUPH FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
				
				IF @skuo = '-'
				BEGIN
					SELECT @skuo = a.BareSKUOS FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
				END
			END
			
			--Osram Bare
			IF @brand = 'BOO'
			BEGIN
				SELECT @skuo = a.BareSKUOS FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
				
				IF @skuo = '-'
				BEGIN
					SELECT @skuo = a.BareSKUPH FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
				END
			END

			--Phoenix Bare
			IF @brand = 'BOX'
			BEGIN
				SELECT @skuo = a.BareSKUPX FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;			
			END

			--Ushio Bare
			IF @brand = 'BOU'
			BEGIN
				SELECT @skuo = a.BareSKUUSH FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
			END

			--Generic Bare
			IF @brand = 'BG'
			BEGIN
				SELECT @skuo = a.BareSKU FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
			END

			--Philips with Housing
			IF @brand = 'OP'
			BEGIN
				SELECT @skuo = a.EncSKUPH FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
			END

			--OSRAM with Housing
			IF @brand = 'OO'
			BEGIN
				SELECT @skuo = a.EncSKUOS FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
			END

			--Phoenix with Housing
			IF @brand = 'OX'
			BEGIN
				SELECT @skuo = a.EncSKUPX FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
			END
			
			--Ushio with Housing
			IF @brand = 'OU'
			BEGIN
				SELECT @skuo = a.EncSKUUSH FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
			END

			--Generic with Housing
			IF @brand = 'G'
			BEGIN
				SELECT @skuo = a.EncSKU FROM [MITDB].[dbo].[ProjectorData] a WHERE a.CatalogID = @temp;
				
				
			END
			
			
			SET @ResultVar = @skuo;
		END
	ELSE
		BEGIN
			-- Verify if exist in PRoduct Catalog
			IF  Inventory.dbo.fn_IfProductExist(cast(@pCatalog as int)) = 1
			BEGIN
				SET @ResultVar = @pCatalog;
			END
		END
	

	-- Return the result of the function
	RETURN @ResultVar;

END
go

