-- =============================================
-- Author:		Hubet Cardenas Isla
-- Create date: 2017-10-18
-- Description:	Get Lamp Kit Global Stock by SKU
-- =============================================
CREATE FUNCTION [dbo].[fn_GetLampKitGlobalSKU]
(
	-- Add the parameters for the function here
	@pSKU INT
)
RETURNS VARCHAR(8000)
AS
BEGIN
	DECLARE @ResultVar1 DECIMAL(18,6) = 0.000000, @ResultVar2 DECIMAL(18,6) = 0.000000;
	DECLARE @iResultVar1 INT = 0, @iResultVar2 INT = 0;
	DECLARE @lampsku INT = 0, @kitsku INT = 0;
	DECLARE @Result VARCHAR(8000) = ''
	
	SET @lampsku =  (SELECT [Inventory].[dbo].[fn_get_lampsku](@pSKU))
	SET @ResultVar1 = (SELECT [Inventory].[dbo].[fn_Get_Global_Stock](@lampsku))
	SET @kitsku = (SELECT [Inventory].[dbo].[fn_get_kitsku](@pSKU))
	SET @ResultVar2 = (SELECT [Inventory].[dbo].[fn_Get_Global_Stock](@kitsku))

	SET @iResultVar1 = CONVERT(INT, @ResultVar1)
	SET @iResultVar2 = CONVERT(INT, @ResultVar2)

	IF @lampsku > 0
	   AND @iResultVar1 > 0
	   AND @kitsku > 0
	   AND @iResultVar2 > 0
	BEGIN
		SET @Result =         CONVERT(VARCHAR, @lampsku)
					  + '-' + CONVERT(VARCHAR, @iResultVar1)
					  + ',' + CONVERT(VARCHAR, @kitsku)
					  + '-' + CONVERT(VARCHAR, @iResultVar2)
	END

	RETURN @Result;
END
--108862
--109058
--SELECT [Inventory].[dbo].[fn_GetLampKitGlobalSKU](108862)
--SELECT [Inventory].[dbo].[fn_GetLampKitGlobalSKU](109058)
go

