

CREATE PROCEDURE [dbo].[SuppliersUpdateTEST]

AS 
BEGIN

-- Delete all the SKUs that have been deleted from ERP.
DELETE FROM Inventory.dbo.Suppliers
WHERE ProductCatalogID NOT IN (Select ID FROM Inventory.dbo.ProductCatalog )

   
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INSERT MISSING SKUS - ALL CATEGORIES
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE @pSupplierID INT

DECLARE supplier_cursor CURSOR FOR   
SELECT SupplierID
FROM [Inventory].[dbo].[SupplierInfo]
ORDER BY SupplierId;

OPEN supplier_cursor  
  
FETCH NEXT FROM supplier_cursor   
INTO @pSupplierID
  
WHILE @@FETCH_STATUS = 0  
BEGIN    
	INSERT INTO Inventory.dbo.Suppliers
	(ProductCatalogId, SupplierID, UnitCost, Enabled)
	(Select ID, @pSupplierID, '0', '1' FROM Inventory.dbo.ProductCatalog
	 WHERE ID NOT IN (Select ProductCatalogID FROM Inventory.dbo.Suppliers WHERE SupplierID = @pSupplierID))

   -- Get the next supplier  
    FETCH NEXT FROM supplier_cursor   
    INTO @pSupplierID

END
CLOSE supplier_cursor;  
DEALLOCATE supplier_cursor;  
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------

---DELETE DUPLICATES
DELETE FROM [Inventory].[dbo].[Suppliers] 
WHERE (SELECT count(S2.ProductCatalogId) FROM [Inventory].[dbo].[Suppliers] AS S2 WHERE S2.[SupplierID] = Suppliers.[SupplierID] AND S2.[ProductCatalogID] = Suppliers.[ProductCatalogId]) > 1


END


go

