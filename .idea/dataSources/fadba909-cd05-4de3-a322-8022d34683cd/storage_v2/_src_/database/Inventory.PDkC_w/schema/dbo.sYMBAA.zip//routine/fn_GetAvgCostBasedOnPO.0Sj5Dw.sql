-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-05-13
-- Description:	Get Avg Cost PO
-- =============================================
CREATE FUNCTION fn_GetAvgCostBasedOnPO
(	
	@SKU	INT,
	@DATE	NVARCHAR(10)
)
RETURNS @Result TABLE (
	SKU		INT,
	AvgCost DECIMAL(13,2)
)
AS
BEGIN

	SET @DATE = CONVERT(NVARCHAR,CONVERT(DATE,@DATE),112)
	
	DECLARE @Global_Stock	INT,
			@NEW_STOCK		INT,
			@QtyReceived	INT,
			@UnitCost		DECIMAL(13,2),
			@Seq			INT,
			@SUM			INT,
			@COUNT			DECIMAL(13,2)

	DECLARE @tmpPO_DATA TABLE (PODate DATE, QtyReceived INT, UnitCost DECIMAL(13,4), Seq INT)

	SET @Global_Stock = ISNULL((
							SELECT Global_Stock 
							FROM Inventory.dbo.BinMovement 
							WHERE SKU = @SKU AND CONVERT(NVARCHAR,Activity_Date,112) = @DATE
						), 0)
	
	INSERT INTO @tmpPO_DATA (PODate, QtyReceived, UnitCost, Seq)
	SELECT PODate, QtyReceived, UnitCost, ROW_NUMBER() OVER(ORDER BY PODate DESC) AS Row
	FROM Inventory.dbo.PurchaseOrderData (NOLOCK)
	WHERE SKU = @SKU AND CONVERT(NVARCHAR,PODate,112) <= @DATE AND QtyReceived > 0

	SET @NEW_STOCK = @Global_Stock
	SET @SUM = 0
	SET @COUNT = 0

	WHILE(@NEW_STOCK > 0)
	BEGIN
		SET @QtyReceived = 0
		SET @UnitCost = 0
		SET @Seq = 0

		SELECT TOP 1 @QtyReceived = QtyReceived, @UnitCost = UnitCost, @Seq = Seq
		FROM @tmpPO_DATA
		ORDER BY Seq

		IF(ISNULL(@QtyReceived,0) = 0)
		BEGIN
			SET @QtyReceived = @NEW_STOCK
			SET @UnitCost = (SELECT TOP 1 UnitCost FROM Inventory.dbo.PurchaseOrderData (NOLOCK) WHERE SKU = @SKU AND QtyReceived > 0 ORDER BY PODate DESC)
		END

		IF((@QtyReceived - @NEW_STOCK) < 0)
		BEGIN
			SET @NEW_STOCK = @NEW_STOCK - @QtyReceived
			SET @SUM = @SUM + (@QtyReceived * @UnitCost)
		END
		ELSE
		BEGIN
			SET @SUM = @SUM + (@NEW_STOCK * @UnitCost)
			SET @NEW_STOCK = 0
		END

		DELETE FROM @tmpPO_DATA WHERE Seq = @Seq
	END
	
	INSERT INTO @Result (SKU, AvgCost) VALUES ( @SKU, CASE WHEN CONVERT(DECIMAL(13,2),@Global_Stock) > 0 THEN @SUM / CONVERT(DECIMAL(13,2),@Global_Stock) ELSE 0 END )

	RETURN
END
go

