-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-08-03
-- Description:	Get Sold by Month
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSKUTopSellbyMonth]
	@DATE1		NVARCHAR(8),
	@DATE2		NVARCHAR(8),
	@CATEGORY	NVARCHAR(50),
	@SEARCH		NVARCHAR(150)
AS
BEGIN
	DECLARE @SQL			NVARCHAR(4000),
			@CURSOR_DAYS	CURSOR,
			@SKU			INT
    SET NOCOUNT ON;
	SET ANSI_WARNINGS OFF;
	SET ANSI_WARNINGS ON;

	CREATE TABLE #tmpReturnUpSell (SKU INT, QtyOrdered INT, Name NVARCHAR(500), CategoryID INT, CategoryName NVARCHAR(500), ManufacturerPN NVARCHAR(500))
	
	CREATE TABLE #tmpTopSell ( SKU INT, QuantityOrdered INT, Name NVARCHAR(500), CategoryID INT, Seq INT, ManufacturerPN NVARCHAR(500))
	
	INSERT INTO #tmpTopSell (SKU, QuantityOrdered, Name, CategoryID, Seq, ManufacturerPN)
	SELECT OD.SKU, SUM(OD.QuantityOrdered), PC.Name, PC.CategoryID, 0, PC.ManufacturerPN
	FROM OrderManager.dbo.[Order Details] OD WITH(NOLOCK)
	LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	ON CONVERT(NVARCHAR,PC.ID) = OD.SKU
	INNER JOIN OrderManager.dbo.Orders O WITH(NOLOCK)
	ON O.OrderNumber = OD.OrderNumber AND O.Cancelled = 0
	WHERE CONVERT(NVARCHAR,OD.DetailDate,112) BETWEEN @DATE1 AND @DATE2 AND
	OD.Adjustment = 0 AND PC.CategoryID IN (5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,10,11,12,13,62,20,21,22,23,64,14,24,59,60,69,70, 36 ,101,105,109,123,128,133,138,143, 158) --/*-*/--
	GROUP BY OD.SKU, PC.Name, PC.CategoryID, PC.ManufacturerPN
	ORDER BY SUM(OD.QuantityOrdered) DESC
	
	IF(ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' OR ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' OR ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' OR ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' 
		OR ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' OR ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' OR ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' 
		OR ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' OR ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector')
	BEGIN
		SET @SQL = ' INSERT INTO #tmpTopSell (SKU, QuantityOrdered, Name, CategoryID, Seq, ManufacturerPN)
					SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 1, PC.ManufacturerPN
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '

		SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
								--WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								ELSE '0' END)

		SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.Name, PC.CategoryID, PC.ManufacturerPN '
		--PRINT(@SQL)
		EXEC(@SQL)
		
		--START V2
		SET @SQL = ' INSERT INTO #tmpTopSell (SKU, QuantityOrdered, Name, CategoryID, Seq, ManufacturerPN)
					SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 2, PC.ManufacturerPN
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC  WITH(NOLOCK)
					ON PC.ID = AD.SubSKU WHERE TTS.Seq = 1 AND PC.CategoryID IN ( '

		SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
								--WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								ELSE '0' END)

		SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.Name, PC.CategoryID, PC.ManufacturerPN '

		EXEC(@SQL)
		--END V2
	END
	--END FIRST
	IF (ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector')
	BEGIN
		SET @SQL = ' INSERT INTO #tmpTopSell (SKU, QuantityOrdered, Name, CategoryID, Seq, ManufacturerPN)
					SELECT AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 3, PC.ManufacturerPN
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD WITH(NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '
		
		SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' THEN '69' WHEN ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '70' ELSE '0' END)

		SET @SQL = @SQL + ' ) GROUP BY AD.SubSKU, PC.Name, PC.CategoryID, PC.ManufacturerPN '

		EXEC(@SQL)
	END
	
	SET @SQL = ' INSERT INTO #tmpReturnUpSell (SKU, QtyOrdered, Name, CategoryID, CategoryName, ManufacturerPN) 
				SELECT '
	SET @SQL = @SQL + (CASE WHEN ISNULL(@SEARCH,'') = 'TOP' THEN ' TOP 10 ' ELSE '' END)+' TBL.SKU, TBL.QtyOrdered, TBL.Name, TBL.CategoryID, TBL.CategoryName, TBL.ManufacturerPN
				FROM (
					SELECT TTS.SKU, SUM(TTS.QuantityOrdered) AS QtyOrdered, TTS.Name, TTS.CategoryID, C.Name AS CategoryName, TTS.ManufacturerPN
					FROM #tmpTopSell TTS
					LEFT OUTER JOIN Inventory.dbo.Categories C WITH(NOLOCK)
					ON C.ID = TTS.CategoryID
					WHERE TTS.CategoryID IN ( '
	
	SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'

								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps with Housing - FP' THEN '20,21,22,23,64'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps with Housing - TV' THEN '10,11,12,13,62'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps with Housing - FP' THEN '24'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps with Housing - TV' THEN '14'

								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' THEN '69'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '70'

								WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								WHEN ISNULL(@CATEGORY,'') = 'Mexican Handcrafted' THEN '158'
								ELSE '0' END)

	SET @SQL = @SQL + ' ) '
	IF(LEN(ISNULL(@SEARCH,'')) > 3)
	BEGIN
		SET @SQL = @SQL + ' AND (TTS.SKU LIKE ''%'+@SEARCH+'%'' OR TTS.Name LIKE ''%'+@SEARCH+'%'' OR TTS.ManufacturerPN LIKE ''%'+@SEARCH+'%'') '
	END

	SET @SQL = @SQL + ' GROUP BY TTS.SKU, TTS.Name, TTS.CategoryID, C.Name, TTS.ManufacturerPN
					) TBL
					ORDER BY TBL.QtyOrdered DESC '
	
	EXEC(@SQL)
	
	SELECT A.SKU, A.QtyOrdered AS QtySold_R, A.Name AS Description, A.CategoryName AS Category, ManufacturerPN
	FROM #tmpReturnUpSell A
	ORDER BY A.QtyOrdered DESC, A.SKU

END
go

