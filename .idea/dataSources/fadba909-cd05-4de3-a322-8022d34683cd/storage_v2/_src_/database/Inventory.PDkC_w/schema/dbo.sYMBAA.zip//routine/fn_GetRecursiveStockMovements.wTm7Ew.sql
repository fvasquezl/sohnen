-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 10-25-2015
-- Description:	Get Stock Movements and Sales Recursively by Multiple Layers
-- =============================================
CREATE FUNCTION [dbo].[fn_GetRecursiveStockMovements]
(	
	-- Add the parameters for the function here
	@pSKU int, 
	@pDateBack int

)


RETURNS @Results TABLE ([SKU] INT, [Name] NVARCHAR(MAX), [SoldQty] INT, [SoldQtyFBA] INT, [RemovedQty] INT, [PendingFBA] INT, [MissedOpportunities] INT, [Days] INT)
AS
BEGIN 


  DECLARE @SubSKU AS NVARCHAR(MAX)
  DECLARE @MainSold AS INT
  DECLARE @MainSoldFBA AS INT
  DECLARE @CurrentSold AS INT
  DECLARE @CurrentSoldFBA AS INT
  DECLARE @TotalSold AS INT
  DECLARE @MainRemoved AS INT
  DECLARE @CurrentRemoved AS INT
  DECLARE @TotalRemoved AS INT
  DECLARE @MainPendingFBA AS INT
  DECLARE @MainMissedOpportunities AS INT
  DECLARE @CurrentMissedOpportunities AS INT
  DECLARE @CurrentPendingFBA AS INT
  DECLARE @ResultTable AS TABLE ([SKU] NVARCHAR(MAX), [SoldQty] INT, [SoldQtyFBA] INT, [RemovedQty] INT, [PendingFBA] INT, [MissedOpportunities] INT, [Days] INT)
  
  --SET @pSKU = '154066'
  --SET @pDateBack = '30'

  SET @CurrentSold = '0'
  SET @TotalSold = '0'

------------------------------------------------------MAIN LAYER SECTION------------------------------------------------------------------------
				--NON FBA CARTS
  				  SELECT @MainSold = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
				  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
				  WHERE 
				  O.[OrderNumber] IS NOT NULL
				  AND O.[Cancelled] = 0
				  AND O.[CartID] != '53' --Exclude FBA Carts
				  AND OD.[Adjustment] = 0
				  AND OD.[SKU] = CAST(@pSKU AS NVARCHAR(MAX))
				  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

				--FBA CARTS
  				  SELECT @MainSoldFBA = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
				  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
				  WHERE 
				  O.[OrderNumber] IS NOT NULL
				  AND O.[Cancelled] = 0
				  AND O.[CartID] = '53' --Only FBA Carts
				  AND OD.[Adjustment] = 0
				  AND OD.[SKU] = CAST(@pSKU AS NVARCHAR(MAX))
				  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

				--REMOVED
				  SELECT @MainRemoved = IsNull(SUM(BH.[Qty]),0)
				  FROM [Inventory].[dbo].[Bins_History] AS BH (NOLOCK)
				  WHERE 
				  BH.[Flow] = '2' 
				  AND BH.[Stamp] BETWEEN GETDATE()-@pDateBack AND GETDATE() 
				  AND BH.[ScanCode] NOT LIKE 'TRN%'
				  AND BH.[Product_Catalog_ID] = CAST(@pSKU AS NVARCHAR(MAX))

				--PENDING FBA USA ALL ACCOUNTS
				  SELECT @MainPendingFBA = 0
				  --IsNull(SUM(AZFBAO.[OrderQty]),0)
				  --FROM [Inventory].[dbo].[AmazonFBAOrders] AS AZFBAO (NOLOCK)
				  --LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ (NOLOCK) ON (AZFBAO.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'US')
				  --WHERE AZ.[ProductCatalogID] = CAST(@pSKU AS NVARCHAR(MAX))
				  --AND AZFBAO.[Completed] = 'No'

				--MISSED OPPORTUNTIES
				  SELECT @MainMissedOpportunities = IsNull(SUM(MO.[Quantity]),0)
				  FROM [Inventory].[dbo].[MissedOpportunities] AS MO (NOLOCK)
				  WHERE CAST(MO.[SKU] AS NVARCHAR(MAX)) = CAST(@pSKU AS NVARCHAR(MAX))
				  AND MO.[DateRequested] BETWEEN GETDATE()-@pDateBack AND GETDATE()


			  	  INSERT INTO @ResultTable ([SKU],[SoldQty],[SoldQtyFBA],[RemovedQty],[PendingFBA],[MissedOpportunities],[Days]) VALUES (@pSKU, IsNull(@MainSold,0), IsNull(@MainSoldFBA,0), IsNull(@MainRemoved,0),@MainPendingFBA, @MainMissedOpportunities, @pDateBack)
------------------------------------------------------MAIN LAYER SECTION------------------------------------------------------------------------

	DECLARE GetSubSKU_Cursor CURSOR
	FOR
  
	SELECT DISTINCT CAST(AD.[ProductCatalogID] AS NVARCHAR(MAX)) FROM [Inventory].[dbo].[AssemblyDetails] AS AD (NOLOCK)
	WHERE AD.[SubSKU] = @pSKU
  
	OPEN GetSubSKU_Cursor
	FETCH NEXT FROM GetSubSKU_Cursor INTO @SubSKU

		WHILE @@FETCH_STATUS = 0
			BEGIN


				  
------------------------------------------------------1st LAYER SECTION------------------------------------------------------------------------
				  --NON FBA CARTS
				  SELECT @CurrentSold = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
				  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
				  WHERE 
				  O.[OrderNumber] IS NOT NULL
				  AND O.[Cancelled] = 0
				  AND O.[CartID] != '53' --Exclude FBA Carts
				  AND OD.[Adjustment] = 0
				  AND OD.[SKU] = @SubSKU
				  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

				 --FBA CARTS
				  SELECT @CurrentSoldFBA = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
				  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
				  WHERE 
				  O.[OrderNumber] IS NOT NULL
				  AND O.[Cancelled] = 0
				  AND O.[CartID] = '53' --Only FBA Carts
				  AND OD.[Adjustment] = 0
				  AND OD.[SKU] = @SubSKU
				  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

				  --PENDINGFBA
				  SELECT @CurrentPendingFBA = 0 
				  --IsNull(SUM(AZFBAO.[OrderQty]),0)
				  --FROM [Inventory].[dbo].[AmazonFBAOrders] AS AZFBAO (NOLOCK)
				  --LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ (NOLOCK) ON (AZFBAO.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'US')
				  --WHERE AZ.[ProductCatalogID] = @SubSKU
				  --AND AZFBAO.[Completed] = 'No'

				  --MISSED OPPORTUNTIES
				  SELECT @CurrentMissedOpportunities = IsNull(SUM(MO.[Quantity]),0)
				  FROM [Inventory].[dbo].[MissedOpportunities] AS MO (NOLOCK)
				  WHERE CAST(MO.[SKU] AS NVARCHAR(MAX)) = CAST(@SubSKU AS NVARCHAR(MAX))
				  AND MO.[DateRequested] BETWEEN GETDATE()-@pDateBack AND GETDATE()


				  INSERT INTO @ResultTable ([SKU],[SoldQty],[SoldQtyFBA],[PendingFBA],[MissedOpportunities],[Days]) VALUES (@SubSKU, IsNull(@CurrentSold,0), IsNull(@CurrentSoldFBA,0), @CurrentPendingFBA, @CurrentMissedOpportunities, @pDateBack)
------------------------------------------------------1st LAYER SECTION------------------------------------------------------------------------	  
							

							DECLARE @SubSKU2 NVARCHAR(MAX)
							DECLARE GetSubSKU2_Cursor CURSOR
							FOR
  
							SELECT CAST(AD.[ProductCatalogID] AS NVARCHAR(MAX)) FROM [Inventory].[dbo].[AssemblyDetails] AS AD (NOLOCK)
							WHERE AD.[SubSKU] = @SubSKU
  
							OPEN GetSubSKU2_Cursor
							FETCH NEXT FROM GetSubSKU2_Cursor INTO @SubSKU2

								WHILE @@FETCH_STATUS = 0
									BEGIN

------------------------------------------------------2nd LAYER SECTION------------------------------------------------------------------------
										  --NON FBA CARTS
										  SELECT @CurrentSold = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
										  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
										  WHERE 
										  O.[OrderNumber] IS NOT NULL
										  AND O.[Cancelled] = 0
										  AND O.[CartID] != '53' --Exclude FBA Carts
										  AND OD.[Adjustment] = 0
										  AND OD.[SKU] = @SubSKU2
										  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

										 --FBA CARTS
										  SELECT @CurrentSoldFBA = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
										  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
										  WHERE 
										  O.[OrderNumber] IS NOT NULL
										  AND O.[Cancelled] = 0
										  AND O.[CartID] = '53' --Only FBA Carts
										  AND OD.[Adjustment] = 0
										  AND OD.[SKU] = @SubSKU2
										  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()


										  --PENDINGFBA
										  SELECT @CurrentPendingFBA = 0
										  --IsNull(SUM(AZFBAO.[OrderQty]),0)
										  --FROM [Inventory].[dbo].[AmazonFBAOrders] AS AZFBAO (NOLOCK)
										  --LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ (NOLOCK) ON (AZFBAO.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'US')
										  --WHERE AZ.[ProductCatalogID] = @SubSKU2
										  --AND AZFBAO.[Completed] = 'No'

										  --MISSED OPPORTUNTIES
										  SELECT @CurrentMissedOpportunities = IsNull(SUM(MO.[Quantity]),0)
										  FROM [Inventory].[dbo].[MissedOpportunities] AS MO (NOLOCK)
										  WHERE CAST(MO.[SKU] AS NVARCHAR(MAX)) = CAST(@SubSKU2 AS NVARCHAR(MAX))
										  AND MO.[DateRequested] BETWEEN GETDATE()-@pDateBack AND GETDATE()
										 
										  INSERT INTO @ResultTable ([SKU],[SoldQty],[SoldQtyFBA],[PendingFBA],[MissedOpportunities],[Days]) VALUES (@SubSKU, IsNull(@CurrentSold,0), IsNull(@CurrentSoldFBA,0), @CurrentPendingFBA, @CurrentMissedOpportunities, @pDateBack)
------------------------------------------------------2nd LAYER SECTION------------------------------------------------------------------------	  


																		DECLARE @SubSKU3 NVARCHAR(MAX)
																		DECLARE GetSubSKU3_Cursor CURSOR
																		FOR
  
																		SELECT CAST(AD.[ProductCatalogID] AS NVARCHAR(MAX)) FROM [Inventory].[dbo].[AssemblyDetails] AS AD (NOLOCK)
																		WHERE AD.[SubSKU] = @SubSKU2
  
																		OPEN GetSubSKU3_Cursor
																		FETCH NEXT FROM GetSubSKU3_Cursor INTO @SubSKU3

																			WHILE @@FETCH_STATUS = 0
																				BEGIN

------------------------------------------------------3rd LAYER SECTION------------------------------------------------------------------------
																					  --NON FBA CARTS
																					  SELECT @CurrentSold = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
																					  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
																					  WHERE 
																					  O.[OrderNumber] IS NOT NULL
																					  AND O.[Cancelled] = 0
																					  AND O.[CartID] != '53' --Exclude FBA Carts
																					  AND OD.[Adjustment] = 0
																					  AND OD.[SKU] = @SubSKU3
																					  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

																					 --FBA CARTS
																					  SELECT @CurrentSoldFBA = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
																					  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
																					  WHERE 
																					  O.[OrderNumber] IS NOT NULL
																					  AND O.[Cancelled] = 0
																					  AND O.[CartID] = '53' --Only FBA Carts
																					  AND OD.[Adjustment] = 0
																					  AND OD.[SKU] = @SubSKU3
																					  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

																					  --PENDINGFBA
																					  SELECT @CurrentPendingFBA = 0
																					  --IsNull(SUM(AZFBAO.[OrderQty]),0)
																					  --FROM [Inventory].[dbo].[AmazonFBAOrders] AS AZFBAO (NOLOCK)
																					  --LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ (NOLOCK) ON (AZFBAO.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'US')
																					  --WHERE AZ.[ProductCatalogID] = @SubSKU3
																					  --AND AZFBAO.[Completed] = 'No'

											  										  --MISSED OPPORTUNTIES
																					  SELECT @CurrentMissedOpportunities = IsNull(SUM(MO.[Quantity]),0)
																					  FROM [Inventory].[dbo].[MissedOpportunities] AS MO (NOLOCK)
																					  WHERE CAST(MO.[SKU] AS NVARCHAR(MAX)) = CAST(@SubSKU3 AS NVARCHAR(MAX))
																					  AND MO.[DateRequested] BETWEEN GETDATE()-@pDateBack AND GETDATE()


																					  INSERT INTO @ResultTable ([SKU],[SoldQty],[SoldQtyFBA],[PendingFBA],[MissedOpportunities],[Days]) VALUES (@SubSKU, IsNull(@CurrentSold,0), IsNull(@CurrentSoldFBA,0), @CurrentPendingFBA, @CurrentMissedOpportunities, @pDateBack)
	  ------------------------------------------------------3rd LAYER SECTION------------------------------------------------------------------------



																									DECLARE @SubSKU4 NVARCHAR(MAX)
																									DECLARE GetSubSKU4_Cursor CURSOR
																									FOR
  
																									SELECT CAST(AD.[ProductCatalogID] AS NVARCHAR(MAX)) FROM [Inventory].[dbo].[AssemblyDetails] AS AD (NOLOCK)
																									WHERE AD.[SubSKU] = @SubSKU3
  
																									OPEN GetSubSKU4_Cursor
																									FETCH NEXT FROM GetSubSKU4_Cursor INTO @SubSKU4

																										WHILE @@FETCH_STATUS = 0
																											BEGIN

------------------------------------------------------4th LAYER SECTION------------------------------------------------------------------------
																												  --NON FBA CARTS
																												  SELECT @CurrentSold = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
																												  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
																												  WHERE 
																												  O.[OrderNumber] IS NOT NULL
																												  AND O.[Cancelled] = 0
																												  AND O.[CartID] != '53' --Exclude FBA Carts
																												  AND OD.[Adjustment] = 0
																												  AND OD.[SKU] = @SubSKU4
																												  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

																												 --FBA CARTS
																												  SELECT @CurrentSoldFBA = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
																												  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
																												  WHERE 
																												  O.[OrderNumber] IS NOT NULL
																												  AND O.[Cancelled] = 0
																												  AND O.[CartID] = '53' --Only FBA Carts
																												  AND OD.[Adjustment] = 0
																												  AND OD.[SKU] = @SubSKU4
																												  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

																												  --PENDINGFBA
																												  SELECT @CurrentPendingFBA = 0
																												  --IsNull(SUM(AZFBAO.[OrderQty]),0)
																												  --FROM [Inventory].[dbo].[AmazonFBAOrders] AS AZFBAO (NOLOCK)
																												  --LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ (NOLOCK) ON (AZFBAO.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'US')
																												  --WHERE AZ.[ProductCatalogID] = @SubSKU4
																												  --AND AZFBAO.[Completed] = 'No'

											  																	  --MISSED OPPORTUNTIES
																												  SELECT @CurrentMissedOpportunities = IsNull(SUM(MO.[Quantity]),0)
																												  FROM [Inventory].[dbo].[MissedOpportunities] AS MO (NOLOCK)
																												  WHERE CAST(MO.[SKU] AS NVARCHAR(MAX)) = CAST(@SubSKU4 AS NVARCHAR(MAX))
																												  AND MO.[DateRequested] BETWEEN GETDATE()-@pDateBack AND GETDATE()


																												  INSERT INTO @ResultTable ([SKU],[SoldQty],[SoldQtyFBA],[PendingFBA],[MissedOpportunities],[Days]) VALUES (@SubSKU, IsNull(@CurrentSold,0), IsNull(@CurrentSoldFBA,0), @CurrentPendingFBA, @CurrentMissedOpportunities, @pDateBack)
------------------------------------------------------4th LAYER SECTION------------------------------------------------------------------------	  




																									DECLARE @SubSKU5 NVARCHAR(MAX)
																									DECLARE GetSubSKU5_Cursor CURSOR
																									FOR
  
																									SELECT CAST(AD.[ProductCatalogID] AS NVARCHAR(MAX)) FROM [Inventory].[dbo].[AssemblyDetails] AS AD (NOLOCK)
																									WHERE AD.[SubSKU] = @SubSKU4
  
																									OPEN GetSubSKU5_Cursor
																									FETCH NEXT FROM GetSubSKU5_Cursor INTO @SubSKU5

																										WHILE @@FETCH_STATUS = 0
																											BEGIN

------------------------------------------------------5th LAYER SECTION------------------------------------------------------------------------
																												  --NON FBA CARTS
																												  SELECT @CurrentSold = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
																												  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
																												  WHERE 
																												  O.[OrderNumber] IS NOT NULL
																												  AND O.[Cancelled] = 0
																												  AND O.[CartID] != '53' --Exclude FBA Carts
																												  AND OD.[Adjustment] = 0
																												  AND OD.[SKU] = @SubSKU5
																												  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()

																												 --FBA CARTS
																												  SELECT @CurrentSoldFBA = SUM(IsNull(OD.[QuantityOrdered],0)) FROM [OrderManager].[dbo].[Order Details] AS OD (NOLOCK)
																												  LEFT OUTER JOIN [OrderManager].[dbo].[Orders] AS O (NOLOCK) ON (OD.[OrderNumber] = O.[OrderNumber])
																												  WHERE 
																												  O.[OrderNumber] IS NOT NULL
																												  AND O.[Cancelled] = 0
																												  AND O.[CartID] = '53' --Only FBA Carts
																												  AND OD.[Adjustment] = 0
																												  AND OD.[SKU] = @SubSKU5
																												  AND OD.[DetailDate] BETWEEN GETDATE()-@pDateBack AND GETDATE()


																												  --PENDINGFBA
																												  SELECT @CurrentPendingFBA = 0
																												  --IsNull(SUM(AZFBAO.[OrderQty]),0)
																												  --FROM [Inventory].[dbo].[AmazonFBAOrders] AS AZFBAO (NOLOCK)
																												  --LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ (NOLOCK) ON (AZFBAO.[ASIN] = AZ.[ASIN] AND AZ.[CountryCode] = 'US')
																												  --WHERE AZ.[ProductCatalogID] = @SubSKU5
																												  --AND AZFBAO.[Completed] = 'No'

											  																	  --MISSED OPPORTUNTIES
																												  SELECT @CurrentMissedOpportunities = IsNull(SUM(MO.[Quantity]),0)
																												  FROM [Inventory].[dbo].[MissedOpportunities] AS MO (NOLOCK)
																												  WHERE CAST(MO.[SKU] AS NVARCHAR(MAX)) = CAST(@SubSKU5 AS NVARCHAR(MAX))
																												  AND MO.[DateRequested] BETWEEN GETDATE()-@pDateBack AND GETDATE()


																												  INSERT INTO @ResultTable ([SKU],[SoldQty],[SoldQtyFBA],[PendingFBA],[MissedOpportunities],[Days]) VALUES (@SubSKU, IsNull(@CurrentSold,0), IsNull(@CurrentSoldFBA,0), @CurrentPendingFBA, @CurrentMissedOpportunities, @pDateBack)
------------------------------------------------------5th LAYER SECTION------------------------------------------------------------------------	  


																												FETCH NEXT FROM GetSubSKU5_Cursor INTO @SubSKU5

																											END 
																									CLOSE GetSubSKU5_Cursor;
																									DEALLOCATE GetSubSKU5_Cursor;




																												FETCH NEXT FROM GetSubSKU4_Cursor INTO @SubSKU4

																											END 
																									CLOSE GetSubSKU4_Cursor;
																									DEALLOCATE GetSubSKU4_Cursor;








																					FETCH NEXT FROM GetSubSKU3_Cursor INTO @SubSKU3

																				END 
																		CLOSE GetSubSKU3_Cursor;
																		DEALLOCATE GetSubSKU3_Cursor;








										FETCH NEXT FROM GetSubSKU2_Cursor INTO @SubSKU2

									END 
							CLOSE GetSubSKU2_Cursor;
							DEALLOCATE GetSubSKU2_Cursor;




				FETCH NEXT FROM GetSubSKU_Cursor INTO @SubSKU

			END 
	CLOSE GetSubSKU_Cursor;
	DEALLOCATE GetSubSKU_Cursor;

		--PURGE DUPLICATES FROM @ResultsTable
		;WITH cte AS (
		SELECT [SKU], [SoldQty], [SoldQtyFBA], [RemovedQty], [PendingFBA], [MissedOpportunities], [Days],
			row_number() OVER(PARTITION BY [SKU], [SoldQty], [SoldQtyFBA], [RemovedQty], [PendingFBA], [MissedOpportunities], [Days] ORDER BY [SKU]) AS [rn]
		FROM @ResultTable
		)
		DELETE cte WHERE [rn] > 1





	
	--Show Movement Grid Detailed
	INSERT INTO @Results
	SELECT RT.[SKU], PC.[Name], RT.[SoldQty], RT.[SoldQtyFBA], IsNull(RT.[RemovedQty],0), IsNull(RT.[PendingFBA],0), IsNull(RT.[MissedOpportunities],0), RT.[Days] FROM @ResultTable AS RT
	LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC (NOLOCK) ON (RT.[SKU] = CAST(PC.[ID] AS NVARCHAR(MAX)))
	WHERE RT.[SoldQty] != '0' OR RT.[SoldQtyFBA] != '0' OR RT.[PendingFBA] != '0' OR RT.[MissedOpportunities] != '0' OR (RT.[RemovedQty] != '0' AND RT.[RemovedQty] IS NOT NULL)
	

	---USES:
	--Inventory Analytics Summary
	--EXECUTE [Inventory].[dbo].[sp_GetInventoryAnalyticsSummary] '153015'

	---Inventory Analytics Details
	--SELECT	[SKU],
	--		[Name],
	--		[SoldQty],
	--		[SoldQtyFBA],
	--		[RemovedQty],
	--		[PendingFBA],
	--		[MissedOpportunities],
	--		[Days]		
	--FROM [Inventory].[dbo].fn_GetRecursiveStockMovements('153015','30')



	RETURN;

END


go

