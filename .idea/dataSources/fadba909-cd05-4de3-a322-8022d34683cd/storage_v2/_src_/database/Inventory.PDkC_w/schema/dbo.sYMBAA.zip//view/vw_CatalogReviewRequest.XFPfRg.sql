
-- ==========================================================================================
-- Author:		Santos Escobar
-- Create date: 2016-09-14
-- Description:	Retrieves an order list that have been sent automated e-mails 
--				requesting customer reviews.
-- ==========================================================================================

CREATE VIEW vw_CatalogReviewRequest
AS
	SELECT 
		O.OrderNumber, O.SourceOrderID, O.Name CustomerName, CONVERT(DATE, O.OrderDate) AS OrderDate, 
		CONVERT(DATE, OD.DateShipped) AS DateShipped, N.Keywords, REPLACE(REPLACE(N.Completed, '1', 'Sent'), '0', 'Rejected') [Request]
	FROM OrderManager.dbo.Orders O (NOLOCK)
		INNER JOIN OrderManager.dbo.[Order Details] OD (NOLOCK) ON O.OrderNumber = OD.OrderNumber AND OD.Adjustment = 0
		INNER JOIN OrderManager.dbo.Notes N (NOLOCK) ON O.OrderNumber = N.NumericKey
		-- LEFT OUTER JOIN OrderManager.dbo.Tracking T (NOLOCK) ON O.OrderNumber = T.NumericKey -- Some orders don't have any tracking entries.
	WHERE 
		N.[Event] = 'Review Request'
	GROUP BY 
		O.OrderNumber, O.SourceOrderID, O.Name, O.OrderDate, OD.DateShipped, N.Keywords,N.Completed

	/*
		SELECT * FROM Inventory.dbo.vw_CatalogReviewRequest ORDER BY DateShipped DESC, OrderNumber DESC

		SELECT DateShipped, COUNT(Request) AS Request
		FROM Inventory.dbo.vw_CatalogReviewRequest
		WHERE DateShipped >= getdate() - 100
		GROUP BY DateShipped, Request
		ORDER BY DateShipped DESC

	*/
go

