-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_project_virtual_inventory]
	@pSubSKU int
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE @SKU int;

    DECLARE requires_cursor CURSOR FOR 
				SELECT distinct ProductCatalogId
					FROM AssemblyDetails
					WHERE (SubSKU = @pSubSKU)
						and (ApprovedBy > 0)
						and (Isrequired = 1)
						
			OPEN requires_cursor;

			FETCH NEXT FROM requires_cursor 
			INTO @SKU
			
			WHILE @@FETCH_STATUS = 0
			BEGIN
				   
					exec inventory.dbo.Set_Vitual_Inventory @SKU;
				
					FETCH NEXT FROM requires_cursor 
					INTO @SKU;
					
			END

			CLOSE requires_cursor;
			DEALLOCATE requires_cursor;
			
			
END
go

