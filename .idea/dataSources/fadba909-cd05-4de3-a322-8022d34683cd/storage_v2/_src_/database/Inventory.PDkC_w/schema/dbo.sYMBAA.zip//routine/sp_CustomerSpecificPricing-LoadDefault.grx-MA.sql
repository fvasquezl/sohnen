CREATE PROCEDURE [dbo].[sp_CustomerSpecificPricing-LoadDefault]
AS 
BEGIN

DECLARE @CustomerID AS NVARCHAR(MAX)

--Delete all non-existent SKU's from CustomerSpecificPricing
DELETE FROM [Inventory].[dbo].[CustomerSpecificPricing] WHERE [ProductCatalogID] NOT IN (SELECT ID FROM [Inventory].[dbo].[ProductCatalog])
--Delete all non-existent Customers from CustomerSpecificPricing
DELETE FROM [Inventory].[dbo].[CustomerSpecificPricing] WHERE CustomerID NOT IN (SELECT DISTINCT CustomerID FROM [Inventory].[dbo].[Users] WHERE CustomerID > 0)
--Delete all non-existent Customers from CustomerSpecificPricingManagement
DELETE FROM [Inventory].[dbo].[CustomerSpecificPricingManagement] WHERE CustomerID NOT IN (SELECT DISTINCT CustomerID FROM [Inventory].[dbo].[Users] WHERE CustomerID > 0)

DECLARE CustomerID_cursor CURSOR
FOR
--Select all Customers with CustomerID Greater Than 0
Select DISTINCT CUST.[CustomerID] FROM [Inventory].[dbo].[Users] AS CUST
WHERE CUST.[CustomerID] > 0

OPEN CustomerID_cursor
FETCH NEXT FROM CustomerID_cursor INTO @CustomerID

WHILE @@FETCH_STATUS = 0
BEGIN

  INSERT INTO [Inventory].[dbo].[CustomerSpecificPricing] ([ProductCatalogID],[CustomerID],[SalePrice],[DSEconomyPrice],[DS2ndDayPrice],[DS1DayPrice],[Rebate],[Active],[Autoprice],[DateAdded],[UseLiveRates])
  SELECT PC.[ID] AS [ProductCatalogID]
      ,@CustomerID AS [CustomerID]
      ,CAST(CEILING((IsNull(PC.[PriceFloor],999)*1.3)+20) AS Decimal(10,2)) AS [SalePrice]
      ,'12.00' AS [DSEconomyPrice]
      ,'25.00' AS [DS2ndDayPrice]
      ,'39.00' AS [DS1DayPrice]
      ,'0.00' AS [Rebate]
      ,'0' AS [Active]
	  ,'1' AS [Autoprice]
	  ,CURRENT_TIMESTAMP AS [DateAdded]
	  ,'0' AS [UseLiveRates]
  FROM [Inventory].[dbo].[ProductCatalog] AS PC
  WHERE PC.[ID] NOT IN (SELECT [ProductCatalogID] FROM [Inventory].[dbo].[CustomerSpecificPricing] WHERE CustomerID = @CustomerID)
  AND PC.[CategoryID] IN ('5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','29','30','36','59','60','61','62','63','64','82', '83', '84', '85', '87', '88', '89', '90', '91', '93', '94', '95', '96', '97', '98', '99', '100', '101', '102', '103', '104', '105', '106', '107', '108', '109', '110', '111', '112', '113', '114', '115', '116', '117', '118', '119', '120', '121', '122', '123', '124', '125', '126', '127', '128', '129', '130', '131', '132', '133', '134', '135', '136', '137', '138', '139', '140', '141', '142', '143', '144', '145')




  INSERT INTO [Inventory].[dbo].[CustomerSpecificPricingManagement] ([CategoryID],[CustomerID],[CostPlusPercent],[AddAmount],[IsActive],[DSEconomyDefault],[DS2ndDayDefault],[DS1DayDefault])
  SELECT DISTINCT 
      PC.[CategoryID] AS [CategoryID]
	  ,@CustomerID AS [CustomerID]
      ,'50.0' AS [CostPlusPercent]
      ,'10.00' AS [AddAmount]
      ,'1' AS [IsActive]
	  ,(CASE 
	  --RPTV Bare Lamps
	  WHEN PC.[CategoryID] IN ('5','6','7','8','9','61') THEN '7.00'
	  --RPTV Lamp w/Housing
	  WHEN PC.[CategoryID] IN ('10','11','12','13','14','62') THEN '10.00'
	  --FP Lamp w/Housing
	  WHEN PC.[CategoryID] IN ('15','16','17','18','19','63') THEN '7.00'
	  --FP Lamp w/Housing
	  WHEN PC.[CategoryID] IN ('20','21','22','23','24','64') THEN '8.00'
	  --Specialty Lighting
	  WHEN PC.[CategoryID] IN ('82', '83', '84', '85', '87', '88', '89', '90', '91', '93', '94', '95', '96', '97', '98', '99', '100', '101', '102', '103', '104', '105', '106', '107', '108', '109', '110', '111', '112', '113', '114', '115', '116', '117', '118', '119', '120', '121', '122', '123', '124', '125', '126', '127', '128', '129', '130', '131', '132', '133', '134', '135', '136', '137', '138', '139', '140', '141', '142', '143', '144', '145') THEN '6.00'

	  --Everything Else
	  ELSE '16.00' END) AS [DSEconomyDefault]
	  ,(CASE 
	  --RPTV Bare Lamps
	  WHEN PC.[CategoryID] IN ('5','6','7','8','9','61') THEN '22.00'
	  --RPTV Lamp w/Housing
	  WHEN PC.[CategoryID] IN ('10','11','12','13','14','62') THEN '26.00'
	  --FP Lamp w/Housing
	  WHEN PC.[CategoryID] IN ('15','16','17','18','19','63') THEN '22.00'
	  --FP Lamp w/Housing
	  WHEN PC.[CategoryID] IN ('20','21','22','23','24','64') THEN '22.00'
	  --Specialty Lighting
	  WHEN PC.[CategoryID] IN ('82', '83', '84', '85', '87', '88', '89', '90', '91', '93', '94', '95', '96', '97', '98', '99', '100', '101', '102', '103', '104', '105', '106', '107', '108', '109', '110', '111', '112', '113', '114', '115', '116', '117', '118', '119', '120', '121', '122', '123', '124', '125', '126', '127', '128', '129', '130', '131', '132', '133', '134', '135', '136', '137', '138', '139', '140', '141', '142', '143', '144', '145') THEN '20.00'
	  --Everything Else
	  ELSE '29.00' END) AS [DS2ndDayDefault]
	  ,(CASE 
	  --RPTV Bare Lamps
	  WHEN PC.[CategoryID] IN ('5','6','7','8','9','61') THEN '32.00'
	  --RPTV Lamp w/Housing
	  WHEN PC.[CategoryID] IN ('10','11','12','13','14','62') THEN '36.00'
	  --FP Lamp w/Housing
	  WHEN PC.[CategoryID] IN ('15','16','17','18','19','63') THEN '32.00'
	  --FP Lamp w/Housing
	  WHEN PC.[CategoryID] IN ('20','21','22','23','24','64') THEN '32.00'
	  --Specialty Lighting
	  WHEN PC.[CategoryID] IN ('82', '83', '84', '85', '87', '88', '89', '90', '91', '93', '94', '95', '96', '97', '98', '99', '100', '101', '102', '103', '104', '105', '106', '107', '108', '109', '110', '111', '112', '113', '114', '115', '116', '117', '118', '119', '120', '121', '122', '123', '124', '125', '126', '127', '128', '129', '130', '131', '132', '133', '134', '135', '136', '137', '138', '139', '140', '141', '142', '143', '144', '145') THEN '32.00'
	  --Everything Else
	  ELSE '49.00' END) AS [DS1DayDefault]
  FROM [Inventory].[dbo].[Categories] AS CAT
  LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (CAT.ID = PC.[CategoryID])
  LEFT OUTER JOIN [Inventory].[dbo].[CustomerSpecificPricing] AS CSP ON (PC.[ID] = CSP.[ProductCatalogID])
  WHERE CSP.[CustomerID] = @CustomerID
  AND PC.[CategoryID] NOT IN (SELECT [CategoryID] FROM [Inventory].[dbo].[CustomerSpecificPricingManagement] WHERE [CustomerID] = @CustomerID)
  ORDER BY PC.[CategoryID] ASC

  PRINT @CustomerID
  
FETCH NEXT FROM CustomerID_cursor INTO @CustomerID

END

CLOSE CustomerID_cursor
DEALLOCATE CustomerID_cursor

END
go

