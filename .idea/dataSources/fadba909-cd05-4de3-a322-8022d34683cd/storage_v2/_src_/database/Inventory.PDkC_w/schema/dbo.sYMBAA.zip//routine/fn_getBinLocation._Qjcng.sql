
CREATE FUNCTION [dbo].[fn_getBinLocation](@pSKU nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @listStr VARCHAR(MAX)
	DECLARE @returnstring VARCHAR(MAX)
	SELECT @listStr = COALESCE(@listStr+'-','') + BC.Bin_Id
	FROM [Inventory].[dbo].[Bin_Content] AS BC WITH(NOLOCK) WHERE CONVERT(NVARCHAR,BC.ProductCatalog_Id) = @pSKU
	AND Bin_Id IN (SELECT Bin_Id FROM Inventory.dbo.Bins WITH(NOLOCK) WHERE WarehouseID IN ('MX','US'))

	SET @returnstring = @listStr
	
	RETURN @returnstring
END



go

