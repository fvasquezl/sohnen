CREATE VIEW [dbo]._dta_mv_179 WITH SCHEMABINDING AS SELECT  [dbo].[Compatibility].[Manufacturer] as _col_1,  [dbo].[Compatibility].[PartNumber] as _col_2,  count_big(*) as _col_3 FROM  [dbo].[Compatibility]  GROUP BY  [dbo].[Compatibility].[Manufacturer],  [dbo].[Compatibility].[PartNumber]
go

