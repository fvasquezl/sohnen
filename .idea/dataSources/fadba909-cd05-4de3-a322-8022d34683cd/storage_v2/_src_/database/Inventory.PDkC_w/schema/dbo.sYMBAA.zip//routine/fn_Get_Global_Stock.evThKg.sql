-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Get_Global_Stock] (@ProductId INT)
RETURNS decimal(18,6)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar decimal(18,6);

	-- Add the T-SQL statements to compute the return value here
	SET @ResultVar =  (SELECT [globalStock]
						 FROM [Inventory].[dbo].[Global_Stocks] WITH(NOLOCK)
						WHERE [ProductCatalogId] = @productId);

	-- Return the result of the function
	if @ResultVar is null
	Begin
		SET @ResultVar = 0;
	End

	RETURN @ResultVar;

END
go

