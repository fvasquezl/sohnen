CREATE VIEW dbo.OrderSalesData
AS
SELECT        o.OrderDate, o.OrderNumber, trk.PickupDate AS DateShipped, ISNULL(o.Company, '') AS CompanyName, o.Name, sc.CartName, od.SKU, od.Product, 
                         od.ItemNumber AS LineItem, od.PricePerUnit, od.QuantityShipped, od.QuantityReturned, ISNULL(CAST
                             ((SELECT        TOP (1) PricePerUnit
                                 FROM            OrderManager.dbo.[Order Details]
                                 WHERE        (SKU = 'Shipping') AND (OrderNumber = od.OrderNumber)) AS VARCHAR), '-') AS ShippingPrice, ISNULL(CAST
                             ((SELECT        TOP (1) PricePerUnit
                                 FROM            OrderManager.dbo.[Order Details] AS [Order Details_5]
                                 WHERE        (SKU LIKE 'Sales tax 1') AND (OrderNumber = od.OrderNumber)) AS VARCHAR), '-') AS SalesTax, ISNULL(CAST
                             ((SELECT        TOP (1) PricePerUnit
                                 FROM            OrderManager.dbo.[Order Details] AS [Order Details_4]
                                 WHERE        (SKU LIKE 'Sales Tax 3') AND (OrderNumber = od.OrderNumber)) AS VARCHAR), '-') AS SalesTaxAdjustment, ISNULL(CAST
                             ((SELECT        TOP (1) PricePerUnit
                                 FROM            OrderManager.dbo.[Order Details] AS [Order Details_3]
                                 WHERE        (SKU LIKE 'Discount') AND (OrderNumber = od.OrderNumber)) AS VARCHAR), '-') AS Discount, ISNULL(CAST
                             ((SELECT        TOP (1) PricePerUnit
                                 FROM            OrderManager.dbo.[Order Details] AS [Order Details_2]
                                 WHERE        (SKU LIKE 'Coupon') AND (OrderNumber = od.OrderNumber)) AS VARCHAR), '-') AS Coupon, ISNULL(CAST
                             ((SELECT        TOP (1) PricePerUnit
                                 FROM            OrderManager.dbo.[Order Details] AS [Order Details_1]
                                 WHERE        (SKU LIKE 'Surcharge') AND (OrderNumber = od.OrderNumber)) AS VARCHAR), '-') AS Surcharge, o.GrandTotal AS OrderTotal, o.OrderStatus, 
                         ISNULL(pm.Method, '-') AS PayMethod, trk.PickupDate
FROM            OrderManager.dbo.[Order Details] AS od LEFT OUTER JOIN
                         OrderManager.dbo.Orders AS o ON od.OrderNumber = o.OrderNumber LEFT OUTER JOIN
                         OrderManager.dbo.Tracking AS trk ON o.OrderNumber = trk.OrderNum LEFT OUTER JOIN
                         OrderManager.dbo.ShoppingCarts AS sc ON o.CartID = sc.ID LEFT OUTER JOIN
                         OrderManager.dbo.PaymentMethods AS pm ON o.PayType = pm.ID
WHERE        (od.Adjustment = '0')
go

