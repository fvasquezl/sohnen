-- =============================================
-- Author:		Hubet Cárdenas-Isla
-- Create date: 2017-12-19
-- Description:	Amazon Sales Summary by SKU
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonSalesSummaryBySKU] 
	-- Add the parameters for the stored procedure here
	@pOption NVARCHAR(50)
	,@pDateStart datetime = NULL
	,@pDateEnd datetime = NULL
AS
	DECLARE @sMessage NVARCHAR(4000) = 'Non valid option'
		   ,@dDateStart datetime = NULL
		   ,@dDateEnd datetime = NULL
	
	SET @dDateStart = GETDATE() - 7
	SET @dDateEnd = GETDATE()

	IF ISNULL(@pDateStart, '') = ''
	BEGIN
		SET @pDateStart = GETDATE() - 7 
	END

	IF ISNULL(@pDateEnd, '') = ''
	BEGIN
		SET @pDateEnd = GETDATE()
	END
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @pOption = 'NONAURABEAM'
	BEGIN
		--TMP_MarketplaceMapping
		--TMP_AmazonAPI_OrderDetails  
		--DROP TABLE #TMP_AmazonAPI_OrderDetails  
		CREATE TABLE #TMP_AmazonAPI_OrderDetails([AmazonOrderId] NVARCHAR(50)
												,[SellerSKU] NVARCHAR(50)
												,[QuantityOrdered] INT)

		CREATE NONCLUSTERED INDEX ix_AmazonAPI_OrderDetails_A ON #TMP_AmazonAPI_OrderDetails ([AmazonOrderId]);
		CREATE CLUSTERED INDEX ix_AmazonAPI_OrderDetails_B ON #TMP_AmazonAPI_OrderDetails ([SellerSKU]);

		INSERT INTO #TMP_AmazonAPI_OrderDetails
		SELECT [AmazonOrderId]
			   ,[SellerSKU]
			   ,SUM([QuantityOrdered]) [QuantityOrdered]
		  FROM (SELECT [AmazonOrderId]
					   ,LEFT([SellerSKU],8) [SellerSKU]
					   ,[QuantityOrdered]
				  FROM [Remotes].[dbo].[AmazonAPI_OrderDetails] WITH(NOLOCK)
				 WHERE [Title] NOT LIKE '%Aurabeam%') [AmazonAPI_OrderDetails]
		 GROUP BY [AmazonOrderId]
				 ,[SellerSKU]

		--TMP_MarketplaceMapping
		--DROP TABLE #TMP_MarketplaceMapping  
		CREATE TABLE #TMP_MarketplaceMapping([MerchantSKU] NVARCHAR(50)
											,[SKU] NVARCHAR(50))  
		CREATE NONCLUSTERED INDEX ix_MarketplaceMapping_A ON #TMP_MarketplaceMapping ([MerchantSKU]);
		CREATE CLUSTERED INDEX ix_MarketplaceMapping_B ON #TMP_MarketplaceMapping ([SKU]);

		INSERT INTO #TMP_MarketplaceMapping
		SELECT REPLACE(LEFT(MM.[MerchantSKU],9),'RMTC','SKU') [MerchantSKU]
			   ,[SKU]
		  FROM [Remotes].[dbo].[MarketplaceMapping] AS MM WITH(NOLOCK)   

		--Amazon Sales Summary by SKU  (NON AURABEAM)
		SELECT MAIN.[SKU]
			   ,MAIN.[Manufacturer]
			   ,MAIN.[PartNumber]
			   ,MAIN.[QtySold]
			   --,MAIN.[Qty]
			   ,MAIN.[DailyAvg7DT]
			   ,MAIN.[DaysInvBO7DT]
		  FROM (SELECT SKUD.[SKU]
					   ,SKUD.[Manufacturer]
					   ,SKUD.[PartNumber]
					   /*,(SELECT [QtySold]
						  FROM [Remotes].[dbo].[fn_GetAmazonSalesQtyByDate](SKUD.[SKU],GETDATE()-1,GETDATE())) AS [QtySold]*/
					   ,(SELECT SUM(OD.[QuantityOrdered]) 
						   FROM #TMP_AmazonAPI_OrderDetails AS OD
 						   LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_Orders] AS O WITH(NOLOCK)
							    ON OD.[AmazonOrderId] = O.[AmazonOrderId]
						  WHERE OD.[SellerSKU] IN (SELECT [MerchantSKU]
													 FROM #TMP_MarketplaceMapping AS MM 
												    WHERE [SKU] = SKUD.[SKU])
						    AND O.[StampInsert] BETWEEN @pDateStart AND @pDateEnd) AS [QtySold]
					   --,INV.[QuantityMXNew] AS [Qty]
					   
					   /*,NULLIF((SELECT [QtySold]/7 FROM [Remotes].[dbo].[fn_GetAmazonSalesQtyByDate](SKUD.[SKU],GETDATE()-7,GETDATE())),0) AS [DailyAvg-7DT]*/
					   ,NULLIF((SELECT SUM(OD.[QuantityOrdered])/7 
						  FROM #TMP_AmazonAPI_OrderDetails AS OD
						  LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_Orders] AS O WITH(NOLOCK)
							   ON OD.[AmazonOrderId] = O.[AmazonOrderId]
						 WHERE OD.[SellerSKU] IN (SELECT [MerchantSKU]
													FROM #TMP_MarketplaceMapping AS MM 
												   WHERE [SKU] = SKUD.[SKU])
						   AND O.[StampInsert] BETWEEN @dDateStart AND @dDateEnd),0) AS [DailyAvg7DT]

					   /*,(INV.[QuantityMXNew] / NULLIF((SELECT [QtySold]/7 FROM [Remotes].[dbo].[fn_GetAmazonSalesQtyByDate](SKUD.[SKU],GETDATE()-7,GETDATE())),0)) AS [DaysInv-BO7DT] */
					   ,(INV.[QuantityMXNew] / NULLIF((SELECT SUM(OD.[QuantityOrdered])/7 
						  FROM #TMP_AmazonAPI_OrderDetails AS OD
						  LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_Orders] AS O WITH(NOLOCK)
							   ON OD.[AmazonOrderId] = O.[AmazonOrderId]
						 WHERE OD.[SellerSKU] IN (SELECT [MerchantSKU]
													FROM #TMP_MarketplaceMapping AS MM 
												   WHERE [SKU] = SKUD.[SKU])
						   AND O.[StampInsert] BETWEEN @dDateStart AND @dDateEnd),0)) AS [DaysInvBO7DT]
				  FROM [Remotes].[dbo].[SKUData] AS SKUD
				  LEFT OUTER JOIN [Remotes].[dbo].[MarketplaceMapping] AS MM ON (SKUD.[SKU] = MM.[SKU])
				  LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_OrderDetails] AS OD ON (MM.[MerchantSKU] = OD.[SellerSKU])
				  --LEFT OUTER JOIN [Remotes].[dbo].[Inventory] AS INV ON (SKUD.[SKU] = INV.[SKU])
				 GROUP BY SKUD.[SKU]
						 ,SKUD.[Manufacturer]
						 ,SKUD.[PartNumber])MAIN
						 --,INV.[QuantityMXNew])
						 
	     ORDER BY MAIN.[QtySold] DESC
				 --,MAIN.[SKU]
	END
	ELSE IF @pOption = 'AURABEAM'
	BEGIN
		--TMP_MarketplaceMapping
		--TMP_AmazonAPI_OrderDetails  
		--DROP TABLE #TMP_AmazonAPI_OrderDetails_Aurabeam  
		CREATE TABLE #TMP_AmazonAPI_OrderDetails_Aurabeam([AmazonOrderId] NVARCHAR(50)
												,[SellerSKU] NVARCHAR(50)
												,[QuantityOrdered] INT)

		CREATE NONCLUSTERED INDEX ix_AmazonAPI_OrderDetails_Aurabeam_A ON #TMP_AmazonAPI_OrderDetails_Aurabeam ([AmazonOrderId]);
		CREATE CLUSTERED INDEX ix_AmazonAPI_OrderDetails_Aurabeam_B ON #TMP_AmazonAPI_OrderDetails_Aurabeam ([SellerSKU]);

		INSERT INTO #TMP_AmazonAPI_OrderDetails_Aurabeam
		SELECT [AmazonOrderId]
			   ,[SellerSKU]
			   ,SUM([QuantityOrdered]) [QuantityOrdered]
		  FROM (SELECT [AmazonOrderId]
					   ,LEFT([SellerSKU],8) [SellerSKU]
					   ,[QuantityOrdered]
				  FROM [Remotes].[dbo].[AmazonAPI_OrderDetails] WITH(NOLOCK)
				 WHERE [Title] LIKE '%Aurabeam%') [AmazonAPI_OrderDetails]
		 GROUP BY [AmazonOrderId]
				 ,[SellerSKU]

		--TMP_MarketplaceMapping
		--DROP TABLE #TMP_MarketplaceMapping_Aurabeam  
		CREATE TABLE #TMP_MarketplaceMapping_Aurabeam([MerchantSKU] NVARCHAR(50)
											,[SKU] NVARCHAR(50))  
		CREATE NONCLUSTERED INDEX ix_MarketplaceMapping_Aurabeam_A ON #TMP_MarketplaceMapping_Aurabeam ([MerchantSKU]);
		CREATE CLUSTERED INDEX ix_MarketplaceMapping_Aurabeam_B ON #TMP_MarketplaceMapping_Aurabeam ([SKU]);

		INSERT INTO #TMP_MarketplaceMapping_Aurabeam
		SELECT REPLACE(LEFT(MM.[MerchantSKU],9),'RMTC','SKU') [MerchantSKU]
			   ,[SKU]
		  FROM [Remotes].[dbo].[MarketplaceMapping] AS MM WITH(NOLOCK)

		--Amazon Sales Summary by SKU (AURABEAM)
		SELECT MAIN.[SKU]
			   ,MAIN.[Manufacturer]
			   ,MAIN.[PartNumber]
			   ,MAIN.[QtySold]
			   --,MAIN.[Qty]
			   ,MAIN.[DailyAvg7DT]
			   ,MAIN.[DaysInvBO7DT]
		  FROM (SELECT SKUD.[SKU]
					   ,SKUD.[Manufacturer]
					   ,SKUD.[PartNumber]
					   /*,(SELECT [QtySold]
						  FROM [Remotes].[dbo].[fn_GetAmazonSalesQtyByDate_Aurabeam](SKUD.[SKU],GETDATE()-1,GETDATE())) AS [QtySold]*/
					   ,(SELECT SUM(OD.[QuantityOrdered]) 
						   FROM #TMP_AmazonAPI_OrderDetails_Aurabeam AS OD
						   LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_Orders] AS O WITH(NOLOCK)
							    ON OD.[AmazonOrderId] = O.[AmazonOrderId]
						  WHERE OD.[SellerSKU] IN (SELECT [MerchantSKU]
													 FROM #TMP_MarketplaceMapping_Aurabeam AS MM 
												    WHERE [SKU] = SKUD.[SKU])
						    AND O.[StampInsert] BETWEEN @pDateStart AND @pDateEnd) AS [QtySold]
					   --,INV.[QuantityCN] AS [Qty]
					   ,/*NULLIF((SELECT [QtySold]/7
								 FROM [Remotes].[dbo].[fn_GetAmazonSalesQtyByDate_Aurabeam](SKUD.[SKU],GETDATE()-7,GETDATE())),0) AS [DailyAvg-7DT]*/
						NULLIF((SELECT SUM(OD.[QuantityOrdered])/7 
						  FROM #TMP_AmazonAPI_OrderDetails_Aurabeam AS OD
						  LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_Orders] AS O WITH(NOLOCK)
							   ON OD.[AmazonOrderId] = O.[AmazonOrderId]
						 WHERE OD.[SellerSKU] IN (SELECT [MerchantSKU]
													FROM #TMP_MarketplaceMapping_Aurabeam AS MM 
												   WHERE [SKU] = SKUD.[SKU])
						   AND O.[StampInsert] BETWEEN @dDateStart AND @dDateEnd),0) AS [DailyAvg7DT]
					   /*,(INV.[QuantityCN] / NULLIF((SELECT [QtySold]/7
													 FROM [Remotes].[dbo].[fn_GetAmazonSalesQtyByDate_Aurabeam](SKUD.[SKU],GETDATE()-7,GETDATE())),0)) AS [DaysInv-BO7DT]*/
					   ,(INV.[QuantityCN] / NULLIF((SELECT SUM(OD.[QuantityOrdered])/7 
						  FROM #TMP_AmazonAPI_OrderDetails_Aurabeam AS OD
						  LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_Orders] AS O WITH(NOLOCK)
							   ON OD.[AmazonOrderId] = O.[AmazonOrderId]
						 WHERE OD.[SellerSKU] IN (SELECT [MerchantSKU]
													FROM #TMP_MarketplaceMapping_Aurabeam AS MM 
												   WHERE [SKU] = SKUD.[SKU])
						   AND O.[StampInsert] BETWEEN @dDateStart AND @dDateEnd),0)) AS [DaysInvBO7DT]
				  FROM [Remotes].[dbo].[SKUData] AS SKUD
				  LEFT OUTER JOIN [Remotes].[dbo].[MarketplaceMapping] AS MM ON (SKUD.[SKU] = MM.[SKU])
				  LEFT OUTER JOIN [Remotes].[dbo].[AmazonAPI_OrderDetails] AS OD ON (MM.[MerchantSKU] = OD.[SellerSKU])
				  --LEFT OUTER JOIN [Remotes].[dbo].[Inventory] AS INV ON (SKUD.[SKU] = INV.[SKU])
				 GROUP BY SKUD.[SKU]
						 ,SKUD.[Manufacturer]
						 ,SKUD.[PartNumber])MAIN
						 --,INV.[QuantityCN])MAIN
	     ORDER BY MAIN.[QtySold] DESC
				 --,MAIN.[SKU]
	END
	ELSE
	BEGIN
		SELECT @sMessage
	END
END
/*
 EXEC [Remotes].[dbo].[sp_AmazonSalesSummaryBySKU] @pOption = 'NONAURABEAM', @pDateStart = '2017-12-18', @pDateEnd = '2017-12-19' 
 EXEC [Remotes].[dbo].[sp_AmazonSalesSummaryBySKU] @pOption = 'AURABEAM', @pDateStart = '2017-12-18', @pDateEnd = '2017-12-19'  
*/
go

