-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 2-28-2018
-- Description:	Shipping Rate Calculator
-- =============================================
CREATE PROCEDURE [dbo].[sp_ShippingRateCalculator] 
	-- Add the parameters for the stored procedure here
	@pLength decimal(10,2), 
	@pWidth decimal(10,2),
	@pHeight decimal(10,2),
	@pWeightLBS decimal(10,2)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
		--Amazon Declarations
		DECLARE @AmazonPackageType NVARCHAR(20)
		DECLARE @AmazonShippableWeightLBS INT
		DECLARE @AmazonDimWeightLBS INT
		DECLARE @AmazonDimFactor INT

		--UPS Declarations
		DECLARE @UPSPackageType NVARCHAR(20)
		DECLARE @UPSGroundDimFactor INT
		DECLARE @UPSAirDimFactor INT
		DECLARE @UPSGroundShippableWeightLBS INT
		DECLARE @UPSAirShippableWeightLBS INT
		DECLARE @UPSGroundDimWeightLBS INT
		DECLARE @UPSAirDimWeightLBS INT
		DECLARE @UPSResiGroundSurcharge Decimal(10,2)
		DECLARE @UPSResiAirSurcharge Decimal(10,2)
		DECLARE @UPSGroundResi Decimal(10,2)
		DECLARE @UPS3DayResi Decimal(10,2)
		DECLARE @UPS2DayResi Decimal(10,2)
		DECLARE @UPSNextDaySaverResi Decimal(10,2)
		DECLARE @UPSNextDayResi Decimal(10,2)


		--Package Declarations
		DECLARE @PackageLength Decimal(10,2)
		DECLARE @PackageWidth Decimal(10,2)
		DECLARE @PackageHeight Decimal(10,2)
		DECLARE @PackageWeightLBS Decimal(10,2)
		DECLARE @GirthLength INT

		--Package Calculated Declarations
		DECLARE @LongestSideDetected INT
		DECLARE @MedianSideDetected INT
		DECLARE @ShortestSideDetected INT

		--SUBA Declarations
		DECLARE @SUBASS Decimal(10,2)
		DECLARE @SUBALS Decimal(10,2)
		DECLARE @SUBALSIncrement Decimal(10,2)
		DECLARE @SUBASO Decimal(10,2)
		DECLARE @SUBASOIncrement Decimal(10,2)
		DECLARE @SUBAMO Decimal(10,2)
		DECLARE @SUBAMOIncrement Decimal(10,2)
		DECLARE @SUBALO Decimal(10,2)
		DECLARE @SUBALOIncrement Decimal(10,2)
		DECLARE @SUBASH Decimal(10,2)
		DECLARE @SUBASHIncrement Decimal(10,2)
		DECLARE @AmazonSUBAFulfillmentCost Decimal(10,2)

		--SUBL Declarations
		DECLARE @SUBLSL Decimal(10,2)
		DECLARE @SUBLSLIncrement Decimal(10,2)
		DECLARE @AmazonSUBLFulfillmentCost Decimal(10,2)

		--SUSA Declarations
		DECLARE @SUSASS Decimal(10,2)
		DECLARE @SUSALS Decimal(10,2)
		DECLARE @SUSALSIncrement Decimal(10,2)
		DECLARE @SUSASO Decimal(10,2)
		DECLARE @SUSASOIncrement Decimal(10,2)
		DECLARE @SUSAMO Decimal(10,2)
		DECLARE @SUSAMOIncrement Decimal(10,2)
		DECLARE @SUSALO Decimal(10,2)
		DECLARE @SUSALOIncrement Decimal(10,2)
		DECLARE @SUSASH Decimal(10,2)
		DECLARE @SUSASHIncrement Decimal(10,2)
		DECLARE @AmazonSUSAFulfillmentCost Decimal(10,2)


		--SUBASUSA Declarations
		DECLARE @SUBASUSASS Decimal(10,2)
		DECLARE @SUBASUSALS Decimal(10,2)
		DECLARE @SUBASUSALSIncrement Decimal(10,2)
		DECLARE @SUBASUSASO Decimal(10,2)
		DECLARE @SUBASUSASOIncrement Decimal(10,2)
		DECLARE @SUBASUSAMO Decimal(10,2)
		DECLARE @SUBASUSAMOIncrement Decimal(10,2)
		DECLARE @SUBASUSALO Decimal(10,2)
		DECLARE @SUBASUSALOIncrement Decimal(10,2)
		DECLARE @SUBASUSASH Decimal(10,2)
		DECLARE @SUBASUSASHIncrement Decimal(10,2)
		DECLARE @AmazonSUBASUSAFulfillmentCost Decimal(10,2)



		--SET SUBA RATES:
		SET @SUBASS = '3.76'
		SET @SUBALS = '4.77'
		SET @SUBALSIncrement = '1.27'
		SET @SUBASO = '12.37'
		SET @SUBASOIncrement = '0.44'
		SET @SUBAMO = '16.50'
		SET @SUBAMOIncrement = '0.38'
		SET @SUBALO = '45.00'
		SET @SUBALOIncrement = '0.77'
		SET @SUBASH = '138.02'
		SET @SUBASHIncrement = '0.92'

		--SET SUBL RATES:
		SET @SUBLSL = '2.09'
		SET @SUBLSLIncrement = '0.11'

		--SET SUSA RATES:
		SET @SUSASS = '4.92'
		SET @SUSALS = '6.11'
		SET @SUSALSIncrement = '0.78'
		SET @SUSASO = '10.75'
		SET @SUSASOIncrement = '0.42'
		SET @SUSAMO = '13.51'
		SET @SUSAMOIncrement = '0.37'
		SET @SUSALO = '45.00'
		SET @SUSALOIncrement = '0.65'
		SET @SUSASH = '138.02'
		SET @SUSASHIncrement = '0.92'

		--SET SUBA+SUSA RATES:
		SET @SUBASUSASS = '0'
		SET @SUBASUSALS = '0'
		SET @SUBASUSALSIncrement = '0'
		SET @SUBASUSASO = '8.93'
		SET @SUBASUSASOIncrement = '0.30'
		SET @SUBASUSAMO = '11.59'
		SET @SUBASUSAMOIncrement = '0.26'
		SET @SUBASUSALO = '45.00'
		SET @SUBASUSALOIncrement = '0.56'
		SET @SUBASUSASH = '138.02'
		SET @SUBASUSASHIncrement = '0.92'



		--Dim Factors and Surcharges
		SET @AmazonDimFactor = '139'
		SET @UPSGroundDimFactor = '194'
		SET @UPSAirDimFactor = '139'
		SET @UPSResiGroundSurcharge = '2.16'
		SET @UPSResiAirSurcharge = '2.49'


		----------Package Details----------
		-------REPLACE WITH PARAMETERS-------
		SET @PackageLength = @pLength
		SET @PackageWidth = @pWidth
		SET @PackageHeight = @pHeight
		SET @PackageWeightLBS = @pWeightLBS
		-------------------------------------
		-------------------------------------
		-------------------------------------


		--Get Relative Data
		DECLARE @tempLongestSideDetected TABLE (a DECIMAL(10,1))
		INSERT INTO @tempLongestSideDetected VALUES(ROUND(@PackageLength,0))
		INSERT INTO @tempLongestSideDetected VALUES(ROUND(@PackageWidth,0))
		INSERT INTO @tempLongestSideDetected VALUES(ROUND(@PackageHeight,0))
		SET @LongestSideDetected = (SELECT MAX(a) FROM @tempLongestSideDetected)
		SET @MedianSideDetected = IsNULL((SELECT (a) FROM @tempLongestSideDetected WHERE a != (SELECT MAX(a) FROM @tempLongestSideDetected) AND a != (SELECT MIN(a) FROM @tempLongestSideDetected)),(SELECT MIN(a) FROM @tempLongestSideDetected))
		SET @ShortestSideDetected = (SELECT MIN(a) FROM @tempLongestSideDetected)
		SET @GirthLength = (((@ShortestSideDetected+@MedianSideDetected)*2)+@LongestSideDetected)


		--Get Amazon Calculations
		SET @AmazonDimWeightLBS = CEILING(((ROUND(@PackageHeight,0)*ROUND(@PackageWidth,0)*ROUND(@PackageLength,0))/133))
		SET @AmazonShippableWeightLBS = CEILING((CASE WHEN @AmazonDimWeightLBS > @PackageWeightLBS THEN @AmazonDimWeightLBS
											ELSE @PackageWeightLBS
											END))

		SET @AmazonPackageType = CASE 
								WHEN @LongestSideDetected <= 16 AND @MedianSideDetected <= 9 AND @ShortestSideDetected <=  4 AND @AmazonShippableWeightLBS <= 1 THEN 'SmallAndLight'
								
								WHEN @LongestSideDetected <= 15 AND @MedianSideDetected <= 12 AND @ShortestSideDetected <= 0.75 AND @AmazonShippableWeightLBS <= 0.75 THEN 'SmallStandard'

								WHEN @LongestSideDetected <= 18 AND @MedianSideDetected <= 14 AND @ShortestSideDetected <= 8 AND @AmazonShippableWeightLBS <= 20 THEN 'LargeStandard'
						
								WHEN (@LongestSideDetected > 18 OR @MedianSideDetected > 14 OR @ShortestSideDetected > 8) 
										AND @LongestSideDetected <= 60 
										AND @MedianSideDetected <= 30 
										AND @GirthLength <= 130 
										AND @AmazonShippableWeightLBS <= 20 THEN 'SmallOversize'
							
								WHEN (@LongestSideDetected > 60 OR @MedianSideDetected > 30 OR @AmazonShippableWeightLBS > 20) 
										AND @LongestSideDetected <= 108 
										AND @GirthLength <= 130 
										AND @AmazonShippableWeightLBS <= 150 THEN 'MediumOversize'
						
								WHEN (@LongestSideDetected > 60 OR @MedianSideDetected > 30 OR @AmazonShippableWeightLBS > 70 OR @GirthLength > 130) 
										AND @LongestSideDetected <= 108 
										AND @GirthLength <= 165 
										AND @AmazonShippableWeightLBS <= 150 THEN 'LargeOversize'

								WHEN @LongestSideDetected > 108 OR @GirthLength > 165 OR @AmazonShippableWeightLBS > 150
										 THEN 'SpecialHandling'

								ELSE 'ERROR' END

		--Get UPS Calculations
		SET @UPSPackageType = (CASE WHEN @GirthLength > 130 OR @LongestSideDetected > 96 THEN 'Large Package'
									WHEN @GirthLength <= 130 AND @LongestSideDetected <= 96 THEN 'Standard Package'
									ELSE 'ERROR' END)

		SET @UPSGroundDimWeightLBS = CEILING(((ROUND(@PackageHeight,1)*ROUND(@PackageWidth,1)*ROUND(@PackageLength,1))/@UPSGroundDimFactor))
		SET @UPSAirDimWeightLBS = CEILING(((ROUND(@PackageHeight,1)*ROUND(@PackageWidth,1)*ROUND(@PackageLength,1))/@UPSAirDimFactor))
		SET @UPSGroundShippableWeightLBS = CEILING((CASE WHEN @UPSGroundDimWeightLBS > @PackageWeightLBS THEN @UPSGroundDimWeightLBS
											ELSE @PackageWeightLBS
											END))

		SET @UPSAirShippableWeightLBS = CEILING((CASE WHEN @UPSAirDimWeightLBS > @PackageWeightLBS THEN @UPSAirDimWeightLBS
											ELSE @PackageWeightLBS
											END))



		--SUBA Cost Calculations
		SET @AmazonSUBAFulfillmentCost = CASE WHEN @AmazonPackageType = 'SmallStandard' THEN @SUBASS
												WHEN @AmazonPackageType = 'LargeStandard' THEN (@SUBALS+((@AmazonShippableWeightLBS-2)*@SUBALSIncrement))
												WHEN @AmazonPackageType = 'SmallOversize' THEN (@SUBASO+((@AmazonShippableWeightLBS-2)*@SUBASOIncrement))
												WHEN @AmazonPackageType = 'MediumOversize' THEN (@SUBAMO+((@AmazonShippableWeightLBS-2)*@SUBAMOIncrement))
												WHEN @AmazonPackageType = 'LargeOversize' AND @AmazonShippableWeightLBS <= 90 THEN (@SUBALO+((@AmazonShippableWeightLBS)*@SUBALOIncrement))
												WHEN @AmazonPackageType = 'LargeOversize' AND @AmazonShippableWeightLBS > 90 THEN (@SUBALO+((90-2)*@SUBALOIncrement))
												WHEN @AmazonPackageType = 'SpecialHandling' THEN (@SUBASH+((@AmazonShippableWeightLBS-2)*@SUBASHIncrement))
												ELSE '0' END

		--SUBL Cost Calculations
		SET @AmazonSUBLFulfillmentCost = CASE WHEN @AmazonPackageType = 'SmallAndLight' THEN @SUBLSL+((CEILING((@PackageWeightLBS/0.0625)-1)*@SUBLSLIncrement))
												ELSE '0' END


		--SUSA Cost Calculations
		SET @AmazonSUSAFulfillmentCost = CASE WHEN @AmazonPackageType = 'SmallStandard' THEN @SUSASS
												WHEN @AmazonPackageType = 'LargeStandard' THEN (@SUSALS+((@AmazonShippableWeightLBS-2)*@SUSALSIncrement))
												WHEN @AmazonPackageType = 'SmallOversize' THEN (@SUSASO+((@AmazonShippableWeightLBS-2)*@SUSASOIncrement))
												WHEN @AmazonPackageType = 'MediumOversize' THEN (@SUSAMO+((@AmazonShippableWeightLBS-2)*@SUSAMOIncrement))
												WHEN @AmazonPackageType = 'LargeOversize' AND @AmazonShippableWeightLBS <= 90 THEN (@SUSALO+((@AmazonShippableWeightLBS-2)*@SUSALOIncrement))
												WHEN @AmazonPackageType = 'LargeOversize' AND @AmazonShippableWeightLBS > 90 THEN (@SUSALO+((90-2)*@SUSALOIncrement))
												WHEN @AmazonPackageType = 'SpecialHandling' THEN (@SUSASH+((@AmazonShippableWeightLBS-2)*@SUSASHIncrement))
												ELSE '0' END

		--SUBA+SUSA Cost Calculations
		SET @AmazonSUBASUSAFulfillmentCost = CASE WHEN @AmazonPackageType = 'SmallStandard' THEN @SUBASUSASS
												WHEN @AmazonPackageType = 'LargeStandard' THEN (@SUBASUSALS+((@AmazonShippableWeightLBS-2)*@SUBASUSALSIncrement))
												WHEN @AmazonPackageType = 'SmallOversize' THEN (@SUBASUSASO+((@AmazonShippableWeightLBS-2)*@SUBASUSASOIncrement))
												WHEN @AmazonPackageType = 'MediumOversize' THEN (@SUBASUSAMO+((@AmazonShippableWeightLBS-2)*@SUBASUSAMOIncrement))
												WHEN @AmazonPackageType = 'LargeOversize' AND @AmazonShippableWeightLBS <= 90 THEN @SUBASUSALO
												WHEN @AmazonPackageType = 'LargeOversize' AND @AmazonShippableWeightLBS > 90 THEN (@SUBASUSALO+((@AmazonShippableWeightLBS-90)*@SUBASUSALOIncrement))
												WHEN @AmazonPackageType = 'SpecialHandling' THEN (@SUBASUSASH+((@AmazonShippableWeightLBS-2)*@SUBASUSASHIncrement))
												ELSE '0' END



		--UPS Cost Calculations
		SET @UPSGroundResi = (SELECT [CostAvg] FROM [Inventory].[dbo].[ShippingRates] WHERE [Service] = 'UPSGroundCommercial' AND [WeightLBS] = @UPSGroundShippableWeightLBS)+@UPSResiGroundSurcharge
		SET @UPS3DayResi = (SELECT [CostAvg] FROM [Inventory].[dbo].[ShippingRates] WHERE [Service] = 'UPS3DayResidential' AND [WeightLBS] = @UPSAirShippableWeightLBS)
		SET @UPS2DayResi = (SELECT [CostAvg] FROM [Inventory].[dbo].[ShippingRates] WHERE [Service] = 'UPS2DayResidential' AND [WeightLBS] = @UPSAirShippableWeightLBS)
		SET @UPSNextDaySaverResi = (SELECT [CostAvg] FROM [Inventory].[dbo].[ShippingRates] WHERE [Service] = 'UPSNextDaySaverResidential' AND [WeightLBS] = @UPSAirShippableWeightLBS)
		SET @UPSNextDayResi = (SELECT [CostAvg] FROM [Inventory].[dbo].[ShippingRates] WHERE [Service] = 'UPSNextDay' AND [WeightLBS] =  @UPSAirShippableWeightLBS)


		DECLARE @TBLRESULT TABLE (TITLE NVARCHAR(100), RESULT NVARCHAR(20), SEQ INT IDENTITY(1,1))



		PRINT '--------------PACKAGE INFO---------------'
		PRINT 'PackageLength: ' + CAST(@PackageLength AS NVARCHAR(20))
		PRINT 'PackageWidth: ' + CAST(@PackageWidth AS NVARCHAR(20))
		PRINT 'PackageHeight: ' + CAST(@PackageHeight AS NVARCHAR(20))
		PRINT 'PackageWeightLBS: ' + CAST(@PackageWeightLBS AS NVARCHAR(20))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('PackageLength:', CAST(@PackageLength AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('PackageWidth:', CAST(@PackageWidth AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('PackageHeight:', CAST(@PackageHeight AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('PackageWeightLBS:', CAST(@PackageWeightLBS AS NVARCHAR(20)))
		PRINT '--------------PACKAGE INFO---------------'
		PRINT ''
		PRINT '--------------CALCULATED PACKAGE INFO---------------'
		PRINT 'LongestSideDetected: ' + CAST(@LongestSideDetected AS NVARCHAR(20))
		PRINT 'MedianSideDetected: ' + CAST(@MedianSideDetected AS NVARCHAR(20))
		PRINT 'ShortestSideDetected: ' + CAST(@ShortestSideDetected AS NVARCHAR(20))
		PRINT 'GirthLength: ' + CAST(@GirthLength AS NVARCHAR(20))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('LongestSideDetected:', CAST(@LongestSideDetected AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('MedianSideDetected:', CAST(@MedianSideDetected AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('ShortestSideDetected:', CAST(@ShortestSideDetected AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('GirthLength:', CAST(@GirthLength AS NVARCHAR(20)))
		PRINT '--------------CALCULATED PACKAGE INFO---------------'
		PRINT ''
		PRINT '--------------AMAZON RELATED INFO---------------'
		PRINT 'AmazonPackageType: ' + CAST(@AmazonPackageType AS NVARCHAR(20))
		PRINT 'AmazonDimWeightLBS: ' + CAST(@AmazonDimWeightLBS AS NVARCHAR(20))
		PRINT 'AmazonShippableWeight: ' + CAST(@AmazonShippableWeightLBS AS NVARCHAR(20))
		PRINT 'AmazonDimFactor:' + CAST(@AmazonDimFactor AS NVARCHAR(20))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('AmazonPackageType:', CAST(@AmazonPackageType AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('AmazonDimWeightLBS:', CAST(@AmazonDimWeightLBS AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('AmazonShippableWeight:', CAST(@AmazonShippableWeightLBS AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('AmazonDimFactor:', CAST(@AmazonDimFactor AS NVARCHAR(20)))
		PRINT '--------------AMAZON RELATED INFO---------------'
		PRINT ''
		PRINT '--------------AMAZON RATES---------------'
		PRINT 'AmazonSUBLFulfilmentCost: '+ CAST(@AmazonSUBLFulfillmentCost AS NVARCHAR(20))
		PRINT 'AmazonSUBAFulfillmentCost: '+ CAST(@AmazonSUBAFulfillmentCost AS NVARCHAR(20))
		PRINT 'AmazonSUSAFulfillmentCost: '+ CAST(@AmazonSUSAFulfillmentCost AS NVARCHAR(20))
		PRINT 'AmazonSUBA+SUSAFulfillmentCost: '+ CAST(@AmazonSUBASUSAFulfillmentCost AS NVARCHAR(20))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('AmazonSUBLFulfillmentCost:', CAST(@AmazonSUBLFulfillmentCost AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('AmazonSUBAFulfillmentCost:', CAST(@AmazonSUBAFulfillmentCost AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('AmazonSUSAFulfillmentCost:', CAST(@AmazonSUSAFulfillmentCost AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('AmazonSUBA+SUSAFulfillmentCost:', CAST(@AmazonSUBASUSAFulfillmentCost AS NVARCHAR(20)))
		PRINT '--------------AMAZON RATES---------------'
		PRINT ''
		PRINT '--------------UPS RELATED INFO---------------'
		PRINT 'UPSPackageType: ' + CAST(@UPSPackageType AS NVARCHAR(20))
		PRINT 'UPSGroundDimWeightLBS: ' + CAST(@UPSGroundDimWeightLBS AS NVARCHAR(20))
		PRINT 'UPSGroundShippableWeight: ' + CAST(@UPSGroundShippableWeightLBS AS NVARCHAR(20))
		PRINT 'UPSGroundDimFactor: ' + CAST(@UPSGroundDimFactor AS NVARCHAR(20))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSPackageType:', CAST(@UPSPackageType AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSGroundDimWeightLBS:', CAST(@UPSGroundDimWeightLBS AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSGroundShippableWeight:', CAST(@UPSGroundShippableWeightLBS AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSGroundDimFactor:', CAST(@UPSGroundDimFactor AS NVARCHAR(20)))
		PRINT ''
		PRINT 'UPSAirDimWeightLBS: ' + CAST(@UPSAirDimWeightLBS AS NVARCHAR(20))
		PRINT 'UPSAirShippableWeight: ' + CAST(@UPSAirShippableWeightLBS AS NVARCHAR(20))
		PRINT 'UPSAirDimFactor: ' + CAST(@UPSAirDimFactor AS NVARCHAR(20)) 
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSAirDimWeightLBS:', CAST(@UPSAirDimWeightLBS AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSAirShippableWeight:', CAST(@UPSAirShippableWeightLBS AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSAirDimFactor:', CAST(@UPSAirDimFactor AS NVARCHAR(20)))
		PRINT '--------------UPS RELATED INFO---------------'
		PRINT ''
		PRINT '--------------UPS RATES---------------'
		PRINT 'UPSGroundResidentialCost: '+ CAST(@UPSGroundResi AS NVARCHAR(20))
		PRINT 'UPS3DayResidentialCost: '+ CAST(@UPS3DayResi AS NVARCHAR(20))
		PRINT 'UPS2DayResidentialCost: '+ CAST(@UPS2DayResi AS NVARCHAR(20))
		PRINT 'UPSNextDaySaverResidentialCost: '+ CAST(@UPSNextDaySaverResi AS NVARCHAR(20))
		PRINT 'UPSNextDayResidentialCost: '+ CAST(@UPSNextDayResi AS NVARCHAR(20))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSGroundResidentialCost:', CAST(@UPSGroundResi AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPS3DayResidentialCost:', CAST(@UPS3DayResi AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPS2DayResidentialCost:', CAST(@UPS2DayResi AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSNextDaySaverResidentialCost: ', CAST(@UPSNextDaySaverResi AS NVARCHAR(20)))
		INSERT INTO @TBLRESULT (TITLE, RESULT) VALUES ('UPSNextDayResidentialCost:', CAST(@UPSNextDayResi AS NVARCHAR(20)))
		PRINT '--------------UPS RATES---------------'

		SELECT Title, RESULT
		FROM @TBLRESULT
		ORDER BY SEQ ASC
END
go

