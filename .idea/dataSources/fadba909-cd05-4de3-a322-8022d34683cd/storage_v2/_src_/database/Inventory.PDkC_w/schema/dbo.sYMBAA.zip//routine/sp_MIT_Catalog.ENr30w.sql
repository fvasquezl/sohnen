-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_MIT_Catalog]
	
	@pItemsByPage int
	,@pPage int
	,@pLutemaPrice real
	,@pGenericPrice real
	,@pLutemaWarranty varchar(250)
	,@pGenericWarranty varchar(250)
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT a.Brand
			, a.Partnumber, a.PartNumberV2, a.PartNumberV3
			, a.CatalogID
			, cast(a.catalogid as varchar) + '-O' as LutemaID 
			, @pLutemaPrice as LutemaPrice
			, @pLutemaWarranty as LutemaWarranty

			, cast(a.catalogid as varchar) + '-G' as LutemaID 
			, @pGenericPrice as GenericPRice
			, @pGenericWarranty as GenericWarranty
			 FROM MITDB.dbo.ProjectorData a ;


END
go

