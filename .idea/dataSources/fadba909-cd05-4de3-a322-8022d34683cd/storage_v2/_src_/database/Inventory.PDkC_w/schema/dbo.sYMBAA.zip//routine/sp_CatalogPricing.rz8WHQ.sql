-- =============================================
-- Author:		Ankit Gulati
-- Create date: 1-31-2014
-- Description:	Update prices in the CatalogPricing table 
-- with the calculate formula.
-- =============================================
CREATE PROCEDURE [dbo].[sp_CatalogPricing]
AS 
BEGIN
Declare @MITSKU	      AS Varchar(10)
Declare @EncSKU	      AS Varchar(10)
Declare @EncSKUPH     AS Varchar(10)
Declare @BareSKU	  AS Varchar(10)
Declare @BareSKUPH	  AS Varchar(10)
Declare @UnitCost    AS Float
Declare @SalePrice    AS Float

-- Update PHILIPS Lamp Encloures
UPDATE cp
SET EncSKUPHPrice = ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](pd.[ID]) + 13) * 1.6
FROM [Inventory].[dbo].[CatalogPricing] cp
LEFT JOIN MITDB.dbo.ProjectorData pd
ON cp.CatalogID = pd.CatalogID
LEFT JOIN Inventory.dbo.ProductCatalog pc
ON pd.EncSKUPH = pc.ID

-- Update PHILIPS Lamp Bare
UPDATE cp
SET [BareSKUPHPrice] = ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](pd.[ID]) + 13) * 1.6
FROM [Inventory].[dbo].[CatalogPricing] cp
LEFT JOIN MITDB.dbo.ProjectorData pd
ON cp.CatalogID = pd.CatalogID
LEFT JOIN Inventory.dbo.ProductCatalog pc
ON pd.BareSKUPH = pc.ID

-- Update OSRAM Lamp Bare
UPDATE cp
SET [BareSKUOSPrice] = ([Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](pd.[ID]) + 13) * 1.6
FROM [Inventory].[dbo].[CatalogPricing] cp
LEFT JOIN MITDB.dbo.ProjectorData pd
ON cp.CatalogID = pd.CatalogID
LEFT JOIN Inventory.dbo.ProductCatalog pc
ON pd.BareSKUOS = pc.ID

SET @SalePrice = 0

--Enclosure GENERIC
DECLARE FPGeneric_cursor CURSOR
FOR
-- FP Generic - Select the Lowest Cost among all the suppliers.
Select ProductCatalogId, MIN( CASE WHEN [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ProductCatalogId)=0 OR [Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](ProductCatalogId) IS NULL THEN 500 Else UnitCost END) AS Cost
FROM Inventory.dbo.Suppliers sp
WHERE SupplierID <> '11'
GROUP BY ProductCatalogId

OPEN FPGeneric_cursor
FETCH NEXT FROM FPGeneric_cursor INTO @MITSKU, @UnitCost

WHILE @@FETCH_STATUS = 0
BEGIN
	-- Formula to set the Sale Price
	SET @SalePrice   = CEILING ((@UnitCost + 13) * 1.6 )
		
	-- Update the CatalogPricing table with Sale PRICE
	UPDATE [Inventory].[dbo].[CatalogPricing] 
	SET [EncSKUPrice] = @SalePrice
	WHERE CatalogID IN ( Select CatalogID FROM MITDB.dbo.ProjectorData WHERE EncSKU = @MITSKU)
	
FETCH NEXT FROM FPGeneric_cursor INTO @MITSKU, @UnitCost

END

CLOSE FPGeneric_cursor
DEALLOCATE FPGeneric_cursor

END
go

