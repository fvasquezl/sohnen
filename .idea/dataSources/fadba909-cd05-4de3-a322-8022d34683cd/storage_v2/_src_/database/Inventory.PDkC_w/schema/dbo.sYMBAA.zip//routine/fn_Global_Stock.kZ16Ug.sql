-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Global_Stock]()
	RETURNS @GlobalStock TABLE (ProductCatalogId int, ProductName varchar(254), qty real )
AS
BEGIN

	INSERT INTO @GlobalStock (ProductCatalogId, ProductName) 
		SELECT id, name FROM ProductCatalog ORDER BY ID;
		
	RETURN;
END
go

