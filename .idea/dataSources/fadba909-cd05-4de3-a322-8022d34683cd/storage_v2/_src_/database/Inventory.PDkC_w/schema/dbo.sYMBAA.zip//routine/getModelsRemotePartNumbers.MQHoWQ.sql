
CREATE FUNCTION [dbo].[getModelsRemotePartNumbers](@PartNumber nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @myString nVarchar(max);
	DECLARE @Model nVarchar(max);
	DECLARE @AltModel nVarchar(max);
	
	SET @myString = '';
	DECLARE model_cursor CURSOR 
	FOR 
	SELECT Model FROM [Inventory].[dbo].[CompatibilityDetails] cd where cd.PartNumber = @PartNumber;
	OPEN model_cursor; 
	FETCH NEXT FROM model_cursor INTO @Model;
	
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		SET @myString = @myString + @Model + ', '
		
			DECLARE altmodel_cursor CURSOR 
			FOR 
			SELECT AlternativeModel FROM [Inventory].[dbo].[CompatibilityAlternativeModels] cam where cam.OriginalModel = @Model;
			OPEN altmodel_cursor; 
			FETCH NEXT FROM altmodel_cursor INTO @AltModel;
			WHILE @@FETCH_STATUS = 0 
			BEGIN
				SET @myString = @myString + @AltModel + ', '
				FETCH NEXT FROM altmodel_cursor INTO @AltModel;
			END
			CLOSE altmodel_cursor 
			DEALLOCATE altmodel_cursor
						
	FETCH NEXT FROM model_cursor INTO @Model;
	END
	
	CLOSE model_cursor 
	
	DEALLOCATE model_cursor 
	
	
	IF @myString  <> '' 
	BEGIN
		SET @myString = LEFT(@myString, LEN(@myString)-1 )
	End
	
	
  RETURN @myString
  
END



go

