-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-27-2016
-- Description:	Get Lowest Price BOM List ONLY IF IsREQUIRED is marked
-- =============================================
CREATE FUNCTION [dbo].[fn_GetLowestPriceForBOM]
(
	-- Add the parameters for the function here
	@pSKU int
)
RETURNS @Result TABLE (SKU INT,SubSKU INT, SubSKUQtyRequired DECIMAL(10,4), UnitCost DECIMAL(10,4), TotalCost DECIMAL(10,4))
AS
BEGIN
	

	BEGIN
	INSERT INTO @Result (SKU, SubSKU, SubSKUQtyRequired, UnitCost, TotalCost)
	SELECT PC.[ID]
		,AD.[SubSKU]
		,AD.[SubSKUQTYRequired]
		,[Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](AD.[SubSKU]) AS [UnitCost]
		,AD.[SubSKUQTYRequired]*[Inventory].[dbo].[fn_GetLowestPriceFromSuppliersTable](AD.[SubSKU]) AS [TotalCost]
	FROM [Inventory].[dbo].[ProductCatalog] AS PC
	LEFT OUTER JOIN [Inventory].[dbo].[AssemblyDetails] AS AD ON (PC.[ID] = AD.[ProductCatalogID])
	WHERE AD.[IsRequired] = '1' AND AD.[SubSKUQTYRequired] > 0
	AND PC.[ID] = @pSKU

	 
	 END


	RETURN;

END
go

