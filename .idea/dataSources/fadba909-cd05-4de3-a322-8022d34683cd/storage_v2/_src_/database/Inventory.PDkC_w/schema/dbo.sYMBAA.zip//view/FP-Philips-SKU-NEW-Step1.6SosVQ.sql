CREATE VIEW dbo.[FP-Philips-SKU-NEW]
AS
SELECT DISTINCT 
                         PD.Brand, PD.PartNumber, PD.PartNumberV2, PD.PartNumberV3, PD.EncSKUPH AS 'ModuleSKU', CAST(GSPHM.GlobalStock AS int) AS 'ModulePrebuilt', 
                         CAST(GSPHM.TotalStock AS int) AS 'ModuleBuildability', PD.BareSKUPH AS 'BulbSKU', CAST(GSPHB.TotalStock AS int) AS 'BulbQOH',
                             (SELECT        ASSY2.SubSKU
                               FROM            dbo.AssemblyDetails AS ASSY2 LEFT OUTER JOIN
                                                         dbo.ProductCatalog AS PC2 ON ASSY2.SubSKU = PC2.ID
                               WHERE        (ASSY2.ProductCatalogID = PD.EncSKUPH) AND (PC2.CategoryID = '60')) AS 'KitSKU'
FROM            MITDB.dbo.ProjectorData AS PD LEFT OUTER JOIN
                         dbo.ProductCatalog AS PC ON PD.EncSKUPH = PC.ID LEFT OUTER JOIN
                         dbo.AssemblyDetails AS ASSY ON PD.EncSKUPH = ASSY.ProductCatalogID LEFT OUTER JOIN
                         dbo.Global_Stocks AS GSPHM ON PD.EncSKUPH = GSPHM.ProductCatalogId LEFT OUTER JOIN
                         dbo.Global_Stocks AS GSPHB ON PD.BareSKUPH = GSPHB.ProductCatalogId
WHERE        (PC.CategoryID = '20') AND (PD.EncSKUPH <> '-')
go

