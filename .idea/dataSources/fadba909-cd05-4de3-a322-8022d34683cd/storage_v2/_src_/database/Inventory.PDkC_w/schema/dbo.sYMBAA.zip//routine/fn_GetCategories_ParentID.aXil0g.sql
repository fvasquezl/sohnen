-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetCategories_ParentID]
(
	@pProductCatalogID varchar(255)
 
)
RETURNS integer
AS
BEGIN
	
	DECLARE @lresult int;
	DECLARE @lsku int;

	SET @lresult = -1;
	
	IF isnumeric(@pProductCatalogID) = 1
	BEGIN
		
			Select @lresult =  PC.CategoryId from ProductCatalog AS PC
			where PC.ID = @pProductCatalogID ;
	
		
			IF  not ((@lresult  is null) or (@lresult = -1))
			BEGIN
				

				Select @lresult =  CAT.ParentId from Categories AS CAT
				where CAT.ID = @lresult ;

				IF  (@lresult  is null)
				BEGIN
					SET @lresult = -1;
				END
			END
			ELSE
			BEGIN
				SET @lresult = -1;
			END
		
	END

	
	RETURN (@lresult)
END
go

