
-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-03-30
-- Description:	Get FLEX Alternative Highest Stock and Price
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetAlternativePriceStockHighestFLEX]
	@pSKU INT
AS
BEGIN
	SET NOCOUNT ON;

	
		UPDATE PC SET 
			PC.[TotalStock] = CAST(GS.[TotalStock] AS INT),
			PC.[ShipSKUFBA] = @pSKU,
			PC.[TMPFloorCeilingFBA] = NULL
		FROM [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK)
		LEFT OUTER JOIN [Inventory].[dbo].[Global_stocks] AS GS ON (PC.[ID] = GS.[ProductCatalogID])
		WHERE PC.ID = @pSKU
	

END
go

