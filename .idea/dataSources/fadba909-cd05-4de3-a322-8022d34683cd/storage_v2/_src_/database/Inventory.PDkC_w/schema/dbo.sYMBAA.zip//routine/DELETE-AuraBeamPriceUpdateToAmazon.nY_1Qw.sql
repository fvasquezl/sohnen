-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 5-21-2016
-- Description:	Update Aurabeam Price for Business and Regular
-- =============================================
CREATE PROCEDURE [dbo].[AuraBeamPriceUpdateToAmazon] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	--CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED
	IF (EXISTS (SELECT * 
					 FROM INFORMATION_SCHEMA.TABLES 
					 WHERE TABLE_CATALOG = 'Inventory' 
					 AND  TABLE_NAME = 'tmpAurabeamPriceFeed'))
	BEGIN
		DROP TABLE [Inventory].[dbo].[tmpAurabeamPriceFeed]
	END
	--END CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED

	CREATE TABLE [Inventory].[dbo].[tmpAurabeamPriceFeed] ([SKU] NVARCHAR(MAX), [ASIN] NVARCHAR(MAX), [SellingPrice] Decimal(10,2), [Quantity] INT, [CountryCode] NVARCHAR(MAX))



	---FLEX USA---
	INSERT INTO [Inventory].[dbo].[tmpAurabeamPriceFeed]
	SELECT AZMSKU.[DARTFBMSKU]+'FLX' AS 'SKU', 
	AZMSKU.[ASIN] AS 'ASIN',
	CAST((Case When (PC.DumpFBA = 'True' AND Convert(date,PC.DumpFBAEndDate) > Convert(date,GETDATE())) THEN (PC.PriceFloorFBA*0.60) 
	ELSE AZ.[BuyBoxPrice] END) AS Decimal(10,2)) AS 'SellingPrice', 
	IsNull(CAST((CASE WHEN PC.[AlwaysInStock] = '1' THEN '400' ELSE (GS.[TotalStock]*0.8) END) AS INT),0) AS 'Quantity',
	'US' AS 'CountryCode'
	FROM [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU 
	LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ ON (AZMSKU.[ASIN] = AZ.[ASIN]) 
	LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (AZ.[ProductCatalogID] = PC.[ID]) 
	LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PC.[ID] = GS.[ProductCatalogID])
	Where AZ.[FLXActive] = 1 AND AZ.CountryCode = 'US' AND AZ.[BrandMentioned] LIKE '%Aurabeam%'
	AND  AZMSKU.[DARTFBMSKU] != ''
	AND AZ.[BuyBoxPrice] IS NOT NULL

	-----------CANADA--------------
	---FBA CANADA---
	INSERT INTO [Inventory].[dbo].[tmpAurabeamPriceFeed]
	SELECT 
	AZFBA.[MerchantSKU] AS 'SKU',
	AZFBA.[ASIN] AS 'ASIN',
	CAST((Case When (PC.DumpFBA = 'True' AND Convert(date,PC.DumpFBAEndDate) > Convert(date,GETDATE())) THEN (PC.PriceFloorFBA*0.60)+6 
	ELSE AZ.[BuyBoxPrice]+6 END) AS Decimal(10,2)) AS 'SellingPrice', 
	IsNull(AZFBA.[FBAQty],0) AS 'Quantity',
	'CA' AS 'CountryCode'
	FROM [Inventory].[dbo].[AmazonFBA] AS AZFBA 
	LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ ON (AZFBA.[ASIN] = AZ.[ASIN]) 
	LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (AZ.[ProductCatalogId] = PC.[ID])
	Where AZFBA.Channel = 'Dart' AND AZ.CountryCode = 'CA' AND AZ.[BrandMentioned] LIKE '%Aurabeam%' AND AZFBA.[MerchantSKU] != ''
	AND AZ.[BuyBoxPrice] IS NOT NULL

	---FBM CANADA---
	INSERT INTO [Inventory].[dbo].[tmpAurabeamPriceFeed]
	SELECT 
	OMAliasSKU.[AliasSKU] AS 'SKU', 
	AZMSKU.[ASIN] AS 'ASIN',
	Cast((
	Case When PC.DumpFBM = 'True' AND Convert(date,PC.DumpFBMEndDate) > Convert(date,GETDATE()) THEN (IsNull(PC.PriceFloor,250)*0.60) 
	When AZ.BrandMentioned = 'AuraBeam' THEN AZ.BuyBoxPrice+8  
	ELSE IsNull(PC.PriceFloor+8,250) END) AS Decimal(10,2)) AS 'SellingPrice', 
	IsNull(CAST((CASE WHEN PC.[AlwaysInStock] = '1' THEN '400' ELSE (GS.[TotalStock]*0.8) END) AS INT),0) AS 'Quantity', 
	'CA' AS 'CountryCode'
	FROM [OrderManager].[dbo].[AliasSKUs] AS OMAliasSKU 
	LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (OMAliasSKU.[ParentSKU] = PC.[ID]) 
	LEFT OUTER JOIN [Inventory].[dbo].[AmazonMerchantSKU] AS AZMSKU ON (OMAliasSKU.[AliasSKU] = AZMSKU.[DARTFBMSKU]) 
	LEFT OUTER JOIN [Inventory].[dbo].[Amazon] AS AZ ON (AZMSKU.[ASIN] = AZ.[ASIN]) 
	LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PC.[ID] = GS.[ProductCatalogID])
	Where OMAliasSKU.[Description] like 'ExclusiveBulbs' AND AZ.CountryCode = 'CA' AND AZ.[BrandMentioned] LIKE '%Aurabeam%'
	AND OMAliasSKU.[AliasSKU] != ''
	AND AZ.[BuyBoxPrice] IS NOT NULL

	-----------CANADA END----------


	DELETE FROM [Inventory].[dbo].[History_AurabeamPriceFeed] WHERE [Stamp] < GETDATE()-30

	---FEED START USA---
	INSERT INTO [Inventory].[dbo].[History_AurabeamPriceFeed]
	SELECT 
	tmpABPF.[SKU] AS [sku],
	tmpABPF.[SellingPrice] AS [price],
	'10' AS [minimum-seller-allowed-price],
	'4999' AS [maximum-seller-allowed-price],
	--tmpABPF.[Quantity] AS [quantity],  -this was changing fbm to fba
	'' AS [quantity],
	'' AS [leadtime-to-ship],
	CAST((tmpABPF.[SellingPrice]*.99) AS DECIMAL(10,2)) AS [business-price],
	'FIXED' AS [quantity-price-type],
	'2' AS [quantity-lower-bound1],
	CAST((tmpABPF.[SellingPrice]*.98) AS DECIMAL(10,2)) AS [quantity-price1],
	'3' AS [quantity-lower-bound2],
	CAST((tmpABPF.[SellingPrice]*.97) AS DECIMAL(10,2)) AS [quantity-price2],
	'6' AS [quantity-lower-bound3],
	CAST((tmpABPF.[SellingPrice]*.96) AS DECIMAL(10,2)) AS [quantity-price3],
	'10' AS [quantity-lower-bound4],
	CAST((tmpABPF.[SellingPrice]*.94) AS DECIMAL(10,2)) AS [quantity-price4],
	'20' AS [quantity-lower-bound5],
	CAST((tmpABPF.[SellingPrice]*.90) AS DECIMAL(10,2)) AS [quantity-price5]
	--History Section
	,GETDATE() AS [Stamp]
	,tmpABPF.[CountryCode] AS [CountryCode]
	--End History
	FROM [Inventory].[dbo].[tmpAurabeamPriceFeed] AS tmpABPF
	WHERE tmpABPF.[CountryCode] = 'US'


	DECLARE @selectstatementupdatepricing AS NVARCHAR(MAX)
	DECLARE @cmdupdatepricing AS VARCHAR(2000)

	SET @selectstatementupdatepricing = 'SELECT tmpABPF.[SKU] AS [sku],	tmpABPF.[SellingPrice] AS [price], ''10'' AS [minimum-seller-allowed-price], ''4999'' AS [maximum-seller-allowed-price], '''' AS [quantity], '''' AS [leadtime-to-ship], CAST((tmpABPF.[SellingPrice]*.99) AS DECIMAL(10,2)) AS [business-price], ''FIXED'' AS [quantity-price-type], ''2'' AS [quantity-lower-bound1],	CAST((tmpABPF.[SellingPrice]*.98) AS DECIMAL(10,2)) AS [quantity-price1], ''3'' AS [quantity-lower-bound2], CAST((tmpABPF.[SellingPrice]*.97) AS DECIMAL(10,2)) AS [quantity-price2], ''6'' AS [quantity-lower-bound3], CAST((tmpABPF.[SellingPrice]*.96) AS DECIMAL(10,2)) AS [quantity-price3], ''10'' AS [quantity-lower-bound4], CAST((tmpABPF.[SellingPrice]*.94) AS DECIMAL(10,2)) AS [quantity-price4], ''20'' AS [quantity-lower-bound5], CAST((tmpABPF.[SellingPrice]*.90) AS DECIMAL(10,2)) AS [quantity-price5] FROM [Inventory].[dbo].[tmpAurabeamPriceFeed] AS tmpABPF WHERE tmpABPF.[CountryCode] = ''US'''

	SET @cmdupdatepricing = 'bcp "' + @selectstatementupdatepricing + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbs\ebbody-aurabeamprice.txt" -SMITSQL -Usa -PZ91bM473 -T -c -t \t'
	EXEC master..xp_cmdshell @cmdupdatepricing
	EXEC master..xp_CMDShell 'c:\sharedb\AmazonAPI\ExclusiveBulbs\ebsendaurabeamprice.bat'

	---FEED END USA---



	---FEED START CANADA---
	SELECT tmpABPF.[SKU] AS [sku],
	tmpABPF.[SellingPrice] AS [price],
	'10' AS [minimum-seller-allowed-price],
	'4999' AS [maximum-seller-allowed-price],
	tmpABPF.[Quantity] AS [quantity],
	'1' AS [leadtime-to-ship]
	FROM [Inventory].[dbo].[tmpAurabeamPriceFeed] AS tmpABPF
	WHERE tmpABPF.[CountryCode] = 'CA'


	DECLARE @selectstatementupdatepricingca AS NVARCHAR(MAX)
	DECLARE @cmdupdatepricingca AS VARCHAR(2000)

	SET @selectstatementupdatepricingca = 'SELECT tmpABPF.[SKU] AS [sku], tmpABPF.[SellingPrice] AS [price], ''10'' AS [minimum-seller-allowed-price], ''4999'' AS [maximum-seller-allowed-price], '''' AS [quantity], '''' AS [leadtime-to-ship] FROM [Inventory].[dbo].[tmpAurabeamPriceFeed] AS tmpABPF WHERE tmpABPF.[CountryCode] = ''CA'''

	SET @cmdupdatepricingca = 'bcp "' + @selectstatementupdatepricingca + '" queryout "C:\sharedb\AmazonAPI\ExclusiveBulbsCA\ebbodyca-aurabeamprice.txt" -SMITSQL -Usa -PZ91bM473 -T -c -t \t'
	EXEC master..xp_cmdshell @cmdupdatepricingca
	EXEC master..xp_CMDShell 'c:\sharedb\AmazonAPI\ExclusiveBulbsCA\ebsendaurabeampriceca.bat'

	---FEED END CANADA---



	--CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED
	IF (EXISTS (SELECT * 
					 FROM INFORMATION_SCHEMA.TABLES 
					 WHERE TABLE_CATALOG = 'Inventory' 
					 AND  TABLE_NAME = 'tmpAurabeamPriceFeed'))
	BEGIN
		DROP TABLE [Inventory].[dbo].[tmpAurabeamPriceFeed]
	END
	--END CHECK IF TEMP TABLE EXISTS OR NOT.. IF EXISTS DROP.. IF NOT PROCEED

END
go

