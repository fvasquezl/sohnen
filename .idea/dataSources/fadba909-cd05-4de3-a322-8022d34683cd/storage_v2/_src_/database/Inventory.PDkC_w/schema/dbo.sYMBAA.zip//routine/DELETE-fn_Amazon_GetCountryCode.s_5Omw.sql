-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Amazon_GetCountryCode]
(
	@asin varchar(15)
)
RETURNS varchar(15)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(15);

	SET @resultvar = '';
	-- Add the T-SQL statements to compute the return value here
	SET @ResultVar = (SELECT top 1 CountryCode From Amazon WHERE ASIN = @asin);

	-- Return the result of the function
	RETURN @ResultVar

END
go

