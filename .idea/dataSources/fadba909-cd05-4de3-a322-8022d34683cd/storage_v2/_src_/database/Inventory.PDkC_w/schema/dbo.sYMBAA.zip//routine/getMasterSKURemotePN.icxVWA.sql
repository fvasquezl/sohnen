


CREATE FUNCTION [dbo].[getMasterSKURemotePN](@SKU nVarChar(50))
RETURNS nvarChar(max)
AS
BEGIN
	DECLARE @PartNumber nVarchar(max);
		
	SET @PartNumber = '';
	DECLARE model_cursor CURSOR 
	FOR 
	SELECT PartNumber FROM [Inventory].[dbo].[Compatibility] WHERE ProductCatalogID = @SKU AND Comments LIKE '%Master%';
	OPEN model_cursor; 
	FETCH NEXT FROM model_cursor INTO @PartNumber;
	
	CLOSE model_cursor 
	
	DEALLOCATE model_cursor 
	
RETURN @PartNumber
  
END



go

