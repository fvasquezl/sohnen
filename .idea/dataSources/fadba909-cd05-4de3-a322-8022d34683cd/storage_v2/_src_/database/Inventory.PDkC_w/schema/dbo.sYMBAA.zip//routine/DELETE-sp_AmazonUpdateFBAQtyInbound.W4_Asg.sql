-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-07-17
-- Description:	Update Amazon FBA Qty and Inbound
-- =============================================
CREATE PROCEDURE [dbo].[sp_AmazonUpdateFBAQtyInbound]
AS
BEGIN
	DECLARE @CURSOR_Inventory	CURSOR,
			@MITSKU				INT,
			@MerchantSKU		NVARCHAR(50),
			@ASIN				NVARCHAR(50), 
			@FNSKU				NVARCHAR(50),
			@Title				NVARCHAR(4000),
			@FBAQty				INT,
			@FBAInboundQty		INT,
			@COUNT				INT = 0
	SET NOCOUNT ON;

    SET @CURSOR_Inventory = CURSOR FOR 

	SELECT FBA.sku, FBA.fnsku, FBA.asin, FBA.product_name, FBA.afn_fulfillable_quantity, FBA.afn_inbound_receiving_quantity, A.ProductCatalogId
	FROM AmazonExclusiveBulbs.dbo.InventoryFBAManage FBA WITH(NOLOCK) 
	LEFT OUTER JOIN Inventory.dbo.Amazon A WITH(NOLOCK) 
	ON A.ASIN = FBA.asin AND A.CountryCode = 'US'
	LEFT OUTER JOIN Inventory.dbo.AmazonFBA AF WITH(NOLOCK)
	ON AF.ASIN = FBA.asin AND AF.Channel = 'Dart' AND AF.MerchantSKU = FBA.sku AND AF.FNSKU = FBA.fnsku AND AF.MITSKU = A.ProductCatalogId
	--WHERE ISNULL(FBA.afn_fulfillable_quantity,0) <> ISNULL(AF.FBAQty,0) OR ISNULL(FBA.afn_inbound_receiving_quantity,0) <> ISNULL(AF.FBAInboundQty,0)
	WHERE A.ProductCatalogId IS NOT NULL
	GROUP BY FBA.sku, FBA.fnsku, FBA.asin, FBA.product_name, FBA.afn_fulfillable_quantity, FBA.afn_inbound_receiving_quantity, A.ProductCatalogId

	OPEN @CURSOR_Inventory
	FETCH NEXT FROM @CURSOR_Inventory 
	INTO @MerchantSKU, @FNSKU, @ASIN, @Title, @FBAQty, @FBAInboundQty, @MITSKU

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF(ISNULL((SELECT COUNT(*) FROM Inventory.dbo.AmazonFBA WITH(NOLOCK) WHERE MerchantSKU = @MerchantSKU AND ASIN = @ASIN AND FNSKU = @FNSKU AND MITSKU = @MITSKU),0) > 0)
		BEGIN
			UPDATE Inventory.dbo.AmazonFBA SET FBAQty = @FBAQty, FBAInboundQty = @FBAInboundQty, EnteredTime = GETDATE() WHERE MerchantSKU = @MerchantSKU AND ASIN = @ASIN AND FNSKU = @FNSKU AND MITSKU = @MITSKU		
		END
		ELSE
		BEGIN
			INSERT INTO Inventory.dbo.AmazonFBA (MITSKU,MerchantSKU,ASIN,FNSKU,Title,Channel,FBAQty,FBAInboundQty,IsChecked,EnteredTime) VALUES (@MITSKU,@MerchantSKU,@ASIN,@FNSKU,@Title,'Dart',@FBAQty,@FBAInboundQty,0,GETDATE())
			--PRINT(@MITSKU)
			--PRINT(@MerchantSKU)
			--PRINT(@ASIN)
			--PRINT(@FNSKU)
		END
		--SET @COUNT = @COUNT + 1
		--PRINT(@COUNT)
		NEXT_FETCH:
		FETCH NEXT FROM @CURSOR_Inventory
		INTO @MerchantSKU, @FNSKU, @ASIN, @Title, @FBAQty, @FBAInboundQty, @MITSKU
	END
	CLOSE      @CURSOR_Inventory
	DEALLOCATE @CURSOR_Inventory
END
go

