
CREATE VIEW [dbo].[QTY_SOLD_IN_OM_LAST_6_MONTHS]
AS
SELECT     SKU, SUM(QuantityOrdered) AS SOLD
FROM         OrderManager.dbo.[Order Details]
WHERE     (DATEADD(MM, - 6, GETDATE()) < DetailDate)
GROUP BY SKU

go

