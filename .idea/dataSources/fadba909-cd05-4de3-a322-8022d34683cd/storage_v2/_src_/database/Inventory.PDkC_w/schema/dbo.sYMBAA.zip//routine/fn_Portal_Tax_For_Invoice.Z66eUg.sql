-- =============================================
-- Author:		Luis Bautista
-- Create date: Jun-20 2014
-- Description: Return the taxes
-- =============================================
CREATE FUNCTION [dbo].[fn_Portal_Tax_For_Invoice]
(
	@pClient_id int, @pSubTotal decimal(14,3), @pFlag1 varchar(20), @pFlag2 varchar(20)
)
RETURNS 
@invoice TABLE 
(
	Tax decimal(14,3)
	, ShippingCost decimal(14,3)
	, ShippingDays integer
	, GrandTotal decimal(14,3)
)
AS
BEGIN
	DECLARE @tax decimal(14,3);
	DECLARE @days integer;
	DECLARe @ShippingCost decimal(14,3);
	DECLARe @ShippingDays decimal(14,3);
	DECLARe @GrandTotal decimal(14,3);
	
	SET @tax = @pSubTotal * 0.10;
	SET @ShippingCost = @pSubTotal * 0.05;
	SET @ShippingDays = 3;
	SET @GrandTotal = @pSubTotal + @tax + @ShippingCost;
	
	-- Fill the table variable with the rows for your result set
	INSERT INTO @invoice (tax , shippingcost, ShippingDays, GrandTotal)
				values (@tax, @ShippingCost, @ShippingDays, @GrandTotal );
	RETURN 
END
go

