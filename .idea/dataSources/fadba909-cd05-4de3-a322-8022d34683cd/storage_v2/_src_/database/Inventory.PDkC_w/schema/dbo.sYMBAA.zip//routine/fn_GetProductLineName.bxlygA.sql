-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_GetProductLineName
(
	@ProductLineID as int
)
RETURNS varchar (100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ProductLineName as varchar(100)

	-- Add the T-SQL statements to compute the return value here
	SELECT @ProductLineName = name FROM ProductLines WHERE ID = @ProductLineID

	-- Return the result of the function
	RETURN @ProductLineName

END
go

