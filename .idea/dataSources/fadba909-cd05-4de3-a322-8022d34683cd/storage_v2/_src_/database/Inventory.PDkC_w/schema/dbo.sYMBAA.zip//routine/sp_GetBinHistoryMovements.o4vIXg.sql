-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-05-13
-- Description:	Get Bin History
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetBinHistoryMovements]
AS
BEGIN
	DECLARE @CURSOR_DAYS	CURSOR,
			@CURSOR_SKUS	CURSOR,
			@NEW_DATE		DATE,
			@INITIAL_DATE	DATE,
			@FINAL_DATE		DATE,
			@SKU			INT,
			@DATES			DATE,
			@LAST_QTY		INT,
			@NEW_QTY		INT
	SET NOCOUNT ON;
		
	
	CREATE TABLE #tmpDays (Dates DATE)
	CREATE NONCLUSTERED INDEX IDX_tmpDays ON #tmpDays ( Dates )

	SET @INITIAL_DATE = GETDATE()
	SET @NEW_DATE = CONVERT(DATE,'2011-01-01')--DATEADD(YEAR,-6,@INITIAL_DATE)
	SET @FINAL_DATE = GETDATE()
	SET @INITIAL_DATE = @NEW_DATE

	CREATE TABLE #tmpSKUHistory (SKU INT, id INT, TransactionId INT, mydate DATE, Bin_Id NVARCHAR(6), Reason NVARCHAR(20), inputs INT, outputs INT, globalqty INT, username NVARCHAR(150), comments NVARCHAR(250))
	CREATE NONCLUSTERED INDEX IDX_tmpSKUHistory ON #tmpSKUHistory ( SKU, id )
	
	WHILE(@NEW_DATE <= @FINAL_DATE)
	BEGIN
		INSERT INTO #tmpDays (Dates) VALUES (@NEW_DATE)
		SET @NEW_DATE = DATEADD(DD,1,@NEW_DATE)
	END
	
	SET @CURSOR_SKUS = CURSOR FOR 

	SELECT ID FROM Inventory.dbo.ProductCatalog WITH(NOLOCK) ORDER BY ID DESC
	OPEN @CURSOR_SKUS 
		FETCH NEXT FROM @CURSOR_SKUS 
		INTO @SKU
	   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			PRINT(@SKU)

			DELETE FROM #tmpSKUHistory
			
			INSERT INTO #tmpSKUHistory (id, TransactionId, mydate, Bin_Id, Reason, inputs, outputs, globalqty, username, comments)
			EXEC Inventory.dbo.sp_Bins_History @SKU, @INITIAL_DATE, @FINAL_DATE

			UPDATE #tmpSKUHistory SET SKU = @SKU

			SET @NEW_QTY = 0
			SET @LAST_QTY = 0

			SET @CURSOR_DAYS = CURSOR FOR 

			SELECT Dates FROM #tmpDays

			OPEN @CURSOR_DAYS 
				FETCH NEXT FROM @CURSOR_DAYS 
				INTO @DATES
	   
				WHILE (@@FETCH_STATUS = 0)
				BEGIN
					SET @NEW_QTY = NULL

					SET @NEW_QTY = (SELECT globalqty FROM #tmpSKUHistory WHERE mydate = @DATES AND SKU = @SKU AND TransactionId = (SELECT MAX(TransactionId) FROM #tmpSKUHistory WHERE mydate = @DATES AND SKU = @SKU))
			
					IF(@NEW_QTY IS NULL)
					BEGIN
						SET @NEW_QTY = @LAST_QTY
					END

					IF((SELECT COUNT(*) FROM Inventory.dbo.BinMovement WITH(NOLOCK) WHERE SKU = @SKU AND Activity_Date = @DATES) > 0)
					BEGIN
						UPDATE Inventory.dbo.BinMovement SET Global_Stock = @NEW_QTY WHERE SKU = @SKU AND Activity_Date = @DATES
					END
					ELSE
					BEGIN
						INSERT INTO Inventory.dbo.BinMovement (SKU,Activity_Date,Global_Stock) VALUES (@SKU,@DATES,@NEW_QTY)
					END

					SET @LAST_QTY = @NEW_QTY

					NEXT_FETCH2:
					FETCH NEXT FROM @CURSOR_DAYS
					INTO @DATES
				END
			CLOSE      @CURSOR_DAYS
			DEALLOCATE @CURSOR_DAYS
			
			NEXT_FETCH:
			FETCH NEXT FROM @CURSOR_SKUS
			INTO @SKU
		END
	CLOSE      @CURSOR_SKUS
	DEALLOCATE @CURSOR_SKUS
END
go

