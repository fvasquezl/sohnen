-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-03-29
-- Description:	Valid Counter
-- =============================================
CREATE TRIGGER [dbo].[tr_ValidCounterbyTR]
   ON  [Inventory].[dbo].[Bin_Content]
   AFTER INSERT, UPDATE
AS 
BEGIN
	DECLARE @ID			INT,
			@Counter	INT,
			@SKU		INT
	SET NOCOUNT ON;

    SELECT @ID = ID, @Counter = Counter, @SKU = ProductCatalog_Id
	FROM inserted

	IF(ISNULL(@Counter,0)<=0)
	BEGIN
		DELETE FROM Inventory.dbo.Bin_Content WHERE Id = @ID
	END

	BEGIN TRY
		INSERT INTO Inventory.dbo.BinSKUMovement (Bin_Id, SKU, Counter_Stock) 
		SELECT Bin_Id, ProductCatalog_Id, [Counter] FROM inserted

		INSERT INTO Inventory.[dbo].[BinTotalMovement] (SKU, Global_Stock) 
		SELECT BC.ProductCatalog_Id, SUM(BC.Counter) 
		FROM Inventory.dbo.Bin_Content BC WITH(NOLOCK) 
		INNER JOIN Inventory.dbo.Bins B WITH(NOLOCK)
		ON B.Bin_Id = BC.Bin_Id AND B.WarehouseID <> 'DF'
		WHERE ProductCatalog_Id = @SKU
		--AND SUBSTRING(Bin_id,1,2) NOT IN ('DF','RC','TM') 
		GROUP BY ProductCatalog_Id
	END TRY
	BEGIN CATCH
		PRINT('error')
	END CATCH

END
go

