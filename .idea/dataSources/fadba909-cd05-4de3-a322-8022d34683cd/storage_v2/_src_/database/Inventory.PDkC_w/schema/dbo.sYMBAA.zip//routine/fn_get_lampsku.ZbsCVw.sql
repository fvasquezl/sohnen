-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-02-23
-- Description:	Get Lamp for Assembly
-- =============================================
CREATE FUNCTION [dbo].[fn_get_lampsku]
(	
	@pSKU INT
)
RETURNS INT
AS
BEGIN
	DECLARE @ResultVar INT

	SET @ResultVar  = (SELECT TOP 1 ZASSY.[SubSKU]
						 FROM [Inventory].[dbo].[AssemblyDetails] ZASSY WITH(NOLOCK)
                         LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] ZPC WITH(NOLOCK)
						              ON (ZASSY.[ProductCatalogID] = ZPC.[ID])
                         LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] QPC WITH(NOLOCK)
						              ON (ZASSY.[SubSKU] = QPC.[ID])
                        WHERE --(QPC.[CategoryID] NOT IN (59,60)) 
						      QPC.[CategoryID] IN (SELECT [ID]
											       FROM [Inventory].[dbo].[Categories] WITH(NOLOCK)
												  WHERE [Name] LIKE '%Bare')
						  AND (ZASSY.[ProductCatalogID] = @pSKU) 
                       )
	RETURN @ResultVar
END
go

