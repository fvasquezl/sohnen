-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_MegaAnalitic]
	 @productLine int, @d1 date, @d2 date
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @tin real;
	DECLARE @tout real;
	DECLARE @titems integer;
	DECLARE @tdelta integer;
	


	SET @tdelta = DATEDIFF(day, @d1, @d2);
	
	DECLARE @analitic table (
					
						ProductCatalogId int,
						Name varchar(250),
						Current_Stock Real,
						Inbounds Real,
						PercentIn Real,
						CumulativeIn	Real,
						AvgDIn Real,
						
						Outbounds Real,
						PercentOut Real,
						CumulativeOut Real,
						AVgDOut Real,
						
						AVGStock Real,
						Lean	Real,
						Provision Real,
						tins real,
						touts real,
						nitems integer,
						delta int
						);
						
	DECLARE @result table (
					
						ProductCatalogId int,
						Name varchar(250),
						Current_Stock Real,
						Inbounds Real,
						PercentIn Real,
						AccIn	Real,
						AvgDIn Real,
						
						Outbounds Real,
						PercentOut Real,
						AccOut Real,
						AVgDOut Real,
						
						AVGStock Real,
						Lean	Real,
						Provision Real,
						tins real,
						touts real,
						nitems integer,
						delta int
						);
						
		INSERT INTO @analitic (ProductCatalogId ,Name ,Current_stock)
					SELECT id, name, inventory.dbo.fn_GetProductStock(id) as current_stock
					FROM ProductCatalog
					WHERE ProductLineId = @productLine;
					
	
		
		UPDATE @analitic SET Inbounds = inventory.dbo.fn_Total_Inbounds(ProductCatalogId, @d1, @d2);
		UPDATE @analitic SET Outbounds = inventory.dbo.fn_Total_Outbounds(ProductCatalogId, @d1, @d2);
		
		SET @tin = (SELECT sum(Inbounds) FROM @analitic );
		SET @tout = (SELECT sum(Outbounds) FROM @analitic );
		SET @titems = (SELECT count(ProductCatalogId) FROM @analitic );
		
		UPDATE @analitic SET PercentIn =  round(Inbounds / @tin * 100,3),
							 PercentOut = round(Outbounds / @tout * 100,3),
							 AvgDIn = Inbounds / @tdelta,
							 AvgDOut = Outbounds / @tdelta,
							 tins = @tin,
							 touts = @tout,
							 nitems = @titems,
							 delta = @tdelta;
		
		
		
		
		INSERT INTO @result  SELECT * FROM @analitic ORDER BY PercentOut DESC;
		
		SELECT * FROM @result;
	
						
END
go

