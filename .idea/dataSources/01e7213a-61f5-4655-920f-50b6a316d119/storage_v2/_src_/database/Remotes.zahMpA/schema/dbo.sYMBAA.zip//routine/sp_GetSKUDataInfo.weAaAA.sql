-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2019-05-06
-- Description:	<Get all SKU information with short qty info(US and EU)>
--EXEC Remotes.dbo.[sp_GetSKUDataInfo] '', 0, '', 0, 0, 2
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSKUDataInfo]
	@compatibility		NVARCHAR(MAX),
	@hasInventory		BIT,
	@Manufacturer		NVARCHAR(150),
	@Category			INT,
	@ResearchComplete	INT,
	@HaveCNVariant		INT
AS
BEGIN
	DECLARE @SQL NVARCHAR(MAX)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	--------------
	-- Temp Table, store final table.
	--------------
	CREATE TABLE #TMP_SKUDATA_WITH_CATEGORY(
											 [ID] int IDENTITY(1,1) PRIMARY KEY
											,[SKU] NVARCHAR(50)
											,[Manufacturer] NVARCHAR(50)
											,[PartNumber] NVARCHAR(250)
											,[Categories] NVARCHAR(50)
											,[WeightOz] decimal(10,2)
											,[FloorPrice] decimal (10,2)
											,[CeilingPrice] decimal (10,2)
											,[UnitCost] decimal (10,2)
											,[FloorPriceCN] decimal (10,2)
											,[CeilingPriceCN] decimal (10,2)
											,[UnitCostCN] decimal (10,2)
											,[FloorPriceUSED] decimal (10,2)
											,[CeilingPriceUSED] decimal (10,2)
											,[UnitCostUSED] decimal (10,2)											
											,[HaveCNVariant] bit
											,[Qty] NVARCHAR(50)
											,[QtyGBT] NVARCHAR(50)												
											,[NImages] int
											,[ResearchComplete] BIT
											,[CategoryID] INT)

	CREATE NONCLUSTERED INDEX ix_SKUDATA_SKU ON #TMP_SKUDATA_WITH_CATEGORY([ID]);

	-----------------
	--- Fill TEMP table with SKU DATA plus Category Names
	--- Filter information by Compatibility if exists. 
	-----------------

	IF(@compatibility ='')
		INSERT INTO #TMP_SKUDATA_WITH_CATEGORY
			SELECT SKUD.SKU, SKUD.Manufacturer, SKUD.PartNumber,CAT.CategoryName, SKUD.WeightOz, SKUD.FloorPrice, SKUD.CeilingPrice,
					SKUD.UnitCost, SKUD.FloorPriceCN, SKUD.CeilingPriceCN, SKUD.UnitCostCN, SKUD.FloorPriceUSED, SKUD.CeilingPriceUSED, 
					SKUD.UnitCostUSED,SKUD.HaveCNVariant,

			stuff((SELECT CHAR(10) + CHAR(10) + cast([ScanCode] as varchar(max))+': '+cast([Qty] as varchar(max))
			  FROM [Remotes].[dbo].[fn_GetQtyPerScanCode] (SKUD.[SKU]) FOR XML PATH('')), 1, 2, '') AS [Qty],

			stuff((SELECT CHAR(10) + CHAR(10) + cast([ScanCode] as varchar(max))+': '+cast([Qty] as varchar(max))
			  FROM [Remotes].[dbo].[fn_GetQtyPerScanCodeByGBT] (SKUD.[SKU]) FOR XML PATH('')), 1, 2, '') AS [QtyGBT],


			(SELECT COUNT (SKU) FROM [Remotes].[dbo].[Image] Image WHERE SKU = SKUD.[SKU] ) AS [NImages], [ResearchComplete], SKUD.[CategoryID]


			FROM SKUData AS SKUD WITH(NOLOCK)
			INNER JOIN Categories AS CAT WITH(NOLOCK) ON (SKUD.[CategoryID] = CAT.CategoryID);
	ELSE
		INSERT INTO #TMP_SKUDATA_WITH_CATEGORY
			SELECT SKUD.SKU, SKUD.Manufacturer, SKUD.PartNumber,CAT.CategoryName, SKUD.WeightOz, SKUD.FloorPrice, SKUD.CeilingPrice,
					SKUD.UnitCost, SKUD.FloorPriceCN, SKUD.CeilingPriceCN, SKUD.UnitCostCN, SKUD.FloorPriceUSED, SKUD.CeilingPriceUSED, 
					SKUD.UnitCostUSED, SKUD.HaveCNVariant,

			stuff((SELECT CHAR(10) + CHAR(10) + cast([ScanCode] as varchar(max))+': '+cast([Qty] as varchar(max))
			  FROM [Remotes].[dbo].[fn_GetQtyPerScanCode] (SKUD.[SKU]) FOR XML PATH('')), 1, 2, '') AS [Qty],

			stuff((SELECT CHAR(10) + CHAR(10) + cast([ScanCode] as varchar(max))+': '+cast([Qty] as varchar(max))
			  FROM [Remotes].[dbo].[fn_GetQtyPerScanCodeByGBT] (SKUD.[SKU]) FOR XML PATH('')), 1, 2, '') AS [QtyGBT],

			(SELECT COUNT (SKU) FROM [Remotes].[dbo].[Image] Image WHERE SKU = SKUD.[SKU] ) AS [NImages], [ResearchComplete], SKUD.[CategoryID]

			FROM SKUData AS SKUD WITH(NOLOCK)
			INNER JOIN Categories AS CAT WITH(NOLOCK) ON (SKUD.[CategoryID] = CAT.CategoryID)
			WHERE AlsoCompatibleWith LIKE '%'+@compatibility+'%' OR OriginallySuppliedWith LIKE '%'+@compatibility+'%';	

	-- Return Data.
	SET @SQL = '	SELECT SKU, Manufacturer, PartNumber,Categories, WeightOz, FloorPrice, CeilingPrice, UnitCost, FloorPriceCN, CeilingPriceCN, UnitCostCN, 
			FloorPriceUSED, CeilingPriceUSED, UnitCostUSED, HaveCNVariant, CAST(IsNull(Qty,'''') AS NVARCHAR(50)) AS [Qty], CAST(IsNull(QtyGBT,'''') AS NVARCHAR(50)) AS [QtyGBT], [NImages],
			''$'' + CONVERT(NVARCHAR,FloorPrice) + '' - $'' + CONVERT(NVARCHAR,CeilingPrice) + '' - $'' + CONVERT(NVARCHAR,UnitCost) AS NewPrices,
			''$'' + CONVERT(NVARCHAR,FloorPriceCN) + '' - $'' + CONVERT(NVARCHAR,CeilingPriceCN) + '' - $'' + CONVERT(NVARCHAR,UnitCostCN) AS CNPrices,
			''$'' + CONVERT(NVARCHAR,FloorPriceUSED) + '' - $'' + CONVERT(NVARCHAR,CeilingPriceUSED) + '' - $'' + CONVERT(NVARCHAR,UnitCostUSED) AS UsedPrices
		FROM #TMP_SKUDATA_WITH_CATEGORY
		WHERE Manufacturer LIKE ''%'+@Manufacturer+'%'' '

		IF(ISNULL(@hasInventory,0) = 1)
		BEGIN
			SET @SQL = @SQL + ' AND CAST(ISNULL(Qty,'''') AS NVARCHAR(50)) <> '''' '
		END

		IF(ISNULL(@Category,0) > 0)
		BEGIN
			SET @SQL = @SQL + ' AND ISNULL([CategoryID],0) = ' + CONVERT(NVARCHAR,@Category)
		END

		IF(ISNULL(@ResearchComplete,0) = 1)
		BEGIN
			SET @SQL = @SQL + ' AND ISNULL([ResearchComplete],0) = 1 '
		END
		IF(ISNULL(@ResearchComplete,0) = 2)
		BEGIN
			SET @SQL = @SQL + ' AND ISNULL([ResearchComplete],0) = 0 '
		END

		IF(ISNULL(@HaveCNVariant,0) = 1)
		BEGIN
			SET @SQL = @SQL + ' AND ISNULL([HaveCNVariant],0) = 1 AND (CAST(IsNull(Qty,'''') AS NVARCHAR(50)) LIKE ''%CN%'' OR CAST(IsNull(QtyGBT,'''') AS NVARCHAR(50)) LIKE ''%CN%'')'
		END
		IF(ISNULL(@HaveCNVariant,0) = 2)
		BEGIN
			SET @SQL = @SQL + ' AND ISNULL([HaveCNVariant],0) = 0 AND (CAST(IsNull(Qty,'''') AS NVARCHAR(50)) NOT LIKE ''%CN%'' OR CAST(IsNull(QtyGBT,'''') AS NVARCHAR(50)) NOT LIKE ''%CN%'')'
		END



	SET @SQL = @SQL + ' ORDER BY SKU '

	EXECUTE(@SQL)
/*
	--BEGIN
		SELECT SKU, Manufacturer, PartNumber,Categories, WeightOz, FloorPrice, CeilingPrice, UnitCost, FloorPriceCN, CeilingPriceCN, UnitCostCN, 
			FloorPriceUSED, CeilingPriceUSED, UnitCostUSED,HaveCNVariant, CAST(IsNull(Qty,'') AS NVARCHAR(50)) AS [Qty], CAST(IsNull(QtyGBT,'') AS NVARCHAR(50)) AS [QtyGBT], [NImages]
		FROM #TMP_SKUDATA_WITH_CATEGORY
		WHERE Manufacturer LIKE @Manufacturer
		ORDER BY SKU
	--END
*/
END
go

