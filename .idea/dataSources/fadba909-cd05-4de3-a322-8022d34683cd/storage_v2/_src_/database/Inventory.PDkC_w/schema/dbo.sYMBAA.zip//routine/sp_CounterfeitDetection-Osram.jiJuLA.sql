-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <6-5-2015>
-- Description:	<Counterfeit Detection Report for OSRAM>
-- =============================================
CREATE PROCEDURE [dbo].[sp_CounterfeitDetection-Osram]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
			DECLARE @xml NVARCHAR(MAX)
			DECLARE @body NVARCHAR(MAX)
			DECLARE @date VARCHAR(12)
			DECLARE @subtext VARCHAR(50)
			DECLARE @subject VARCHAR(62)
			DECLARE @recipients VARCHAR(255)
			DECLARE @datestart date

			SET @datestart = DATEADD(DD, -10, GETDATE())


----------------------USA START----------------------
			SET @xml =CAST(( 
			SELECT DISTINCT AZD.[Title] AS 'td',''
				  ,AZD.[Brand] AS 'td',''
				  ,AZD.[Manufacturer] AS 'td',''
				  ,LOFFER.[LandedPrice] AS 'td',''
				  ,CAT.[CategoryName] AS 'td',''
				  ,(CASE WHEN AZD.[Brand] LIKE '%OSRAM%' THEN '<center><strong>X</strong></center>' ELSE '' END) AS 'td',''
				  ,(CASE WHEN (AZD.[Title] LIKE '%OSRAM%') AND (AZD.[Title] NOT LIKE '%FOR OSRAM%') THEN '<center><strong>X</strong></center>' ELSE '' END) AS 'td',''
				  ,(CASE WHEN (AZD.[Feature_A] LIKE '%OSRAM%' OR AZD.[Feature_B] LIKE '%OSRAM%' OR AZD.[Feature_C] LIKE '%OSRAM%' OR AZD.[Feature_D] LIKE '%OSRAM%' OR AZD.[Feature_E] LIKE '%OSRAM%') THEN '<center><strong>X</strong></center>' ELSE '' END) AS 'td',''
				  ,LOFFER.[EnteredDate] AS 'td',''
				  ,IsNull(AZ.[MITSalesRank],99999) AS 'td',''
				  ,Case
				  When AZ.[CountryCode] = 'US' Then 'http://www.amazon.com/gp/offer-listing/' + AZ.[ASIN] + '/ref=dp_olp_new?ie=UTF8&condition=new'	  
				  End
				  AS  'td'
			  FROM [MiTech].[amz].[Amazon] AS AZ
			  LEFT OUTER JOIN [MiTech].[amzAPI].[ASINDetails] AS AZD ON (AZ.[ASIN] = AZD.[ASIN])
			  LEFT OUTER JOIN [Inventory].[dbo].[ProductCatalog] AS PC ON (AZ.[ProductSKU] = PC.[ID])
			  LEFT OUTER JOIN [Inventory].[dbo].[Categories] AS CAT ON (PC.CategoryID = CAT.ID)
			  LEFT OUTER JOIN [MiTech].[amzAPI].[GetLowestOfferListingsForASIN] AS LOFFER ON (AZ.[ASIN] = LOFFER.[ASIN])

			  WHERE 
			  CAT.ID IN ('5','10','15','20') 
			  AND ((AZD.[Brand] LIKE '%OSRAM%') OR (AZD.[Manufacturer] LIKE '%OSRAM%') OR (AZD.[Feature_A] LIKE '%OSRAM%') OR (AZD.[Feature_B] LIKE '%OSRAM%')
			  OR (AZD.[Feature_C] LIKE '%OSRAM%') OR (AZD.[Feature_D] LIKE '%OSRAM%') OR (AZD.[Feature_E] LIKE '%OSRAM%') OR ((AZD.[Title] LIKE '%OSRAM%') AND (AZD.[Title] NOT LIKE '%FOR OSRAM%')))
			  AND AZ.[CountryCode] = 'US'
			  AND AZD.[Brand] NOT LIKE '%Lutema%'
			  AND AZD.[Manufacturer] NOT LIKE '%Lutema%'
			  AND AZD.[Brand] NOT LIKE '%Aurabeam%'
			  AND AZD.[Manufacturer] NOT LIKE '%Aurabeam%'
			  AND AZD.[Brand] NOT LIKE '%Sparc%'
			  AND AZD.[Manufacturer] NOT LIKE '%Sparc%'
			  AND AZD.[Brand] NOT LIKE '%MI Technologies%'
			  AND AZD.[Manufacturer] NOT LIKE '%MI Technologies%'
			  AND LOFFER.[LandedPrice] < (PC.PriceFloorFBA)
			  AND LOFFER.[LandedPrice] > 0
			  AND LOFFER.[LandedPrice] IS NOT NULL 
			  AND LOFFER.[LandedPrice] < 998
			  and LOFFER.[EnteredDate] IS NOT NULL AND LOFFER.[EnteredDate] > Getdate()-30
			  AND AZ.[IsActive] = 1
			  Order by IsNull(AZ.[MITSalesRank],99999) ASC 

			   FOR XML PATH('tr'), ELEMENTS 
			) AS NVARCHAR(MAX))

			/** FIX HTML **/
			 SET @xml = replace(@xml, '&amp;', '&')
			 SET @xml = replace(@xml, '&lt;' , '<')
			 SET @xml = replace(@xml, '&gt;' , '>')
			/** FIX HTML END**/

			SET @subtext = 'Automated OSRAM Counterfeit Detection USA - '
			SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
			SET @subject = @subtext + @date
			SET @recipients = 'amir.tafreshi@mitechnologiesinc.com;jovan.rodriguez@mitechnologiesinc.com;ivan.martinez@mitechnologiesinc.com.mx'
			SET @body ='<html><center><H1>Automated OSRAM Counterfeit Detection USA - <br>' + @date + '</H1><br><br></Center>Ladies and Gentlemen,<br>MI Technologies AutoBot has detected potential counterfeit products in the marketplace.  Please review below listings that are subject to potential counterfeit or false advertisement. <br><br><Center><body bgcolor=yellow><table border = 2><tr>
			<th>Title</th>
			<th>Brand</th>
			<th>Manufacturer</th>
			<th>Price</th>
			<th>Category</th>
			<th>BrandMatch</th>
			<th>TitleMatch</th>
			<th>BulletMatch</th>
			<th>DateChecked</th>
			<th>Link</th>
			</tr>' 
			SET @body = @body + @xml +'</center></table><br><br>Thanks,<br>AutoBot by MI Technologies, Inc</body></html>'


			If @body is not null BEGIN

			EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',

			@recipients = @recipients,
			@subject = @subject,
			@body = @body,
			@body_format ='HTML'

			END




END
go

