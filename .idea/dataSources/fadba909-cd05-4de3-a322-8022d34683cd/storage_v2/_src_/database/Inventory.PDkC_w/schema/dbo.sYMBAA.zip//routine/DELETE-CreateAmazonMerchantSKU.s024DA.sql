

--This procedure is created to generate random Merchant SKU for Amazon channel.

CREATE PROCEDURE [dbo].[CreateAmazonMerchantSKU]

AS 
BEGIN
Declare @ASIN	    AS Varchar(10)
Declare @RandomFBA  AS nVarchar(25)
Declare @RandomFBM  AS nVarchar(25)
Declare @RandomMFP  AS nVarchar(25)
Declare @RandomFBACA  AS nVarchar(25)
Declare @RandomFBMCA  AS nVarchar(25)
Declare @RandomFBAUK  AS nVarchar(25)
Declare @RandomFBMUK  AS nVarchar(25)

Declare @MyID nvarchar(max)

INSERT INTO Inventory.dbo.AmazonMerchantSKU
([ASIN])
SELECT A.[ASIN] FROM Inventory.dbo.Amazon A WITH(NOLOCK)
LEFT OUTER JOIN Inventory.dbo.AmazonMerchantSKU M WITH(NOLOCK)
ON A.[ASIN] = M.[ASIN]
 WHERE M.[ASIN] IS NULL-- NOT IN (Select [ASIN] FROM Inventory.dbo.AmazonMerchantSKU WITH(NOLOCK))
--AND CountryCode = 'US' 
AND ChannelName = 'Amazon'
GROUP BY A.[ASIN]
--UPDATE Inventory.dbo.Amazon  SET ChannelName = 'Amazon' WHERE [ASIN] = 'B00FWNI1WO'

-- Delete all the SKUs that have been deleted from ERP.
DELETE FROM Inventory.dbo.AmazonMerchantSKU
WHERE [ASIN] NOT IN (Select [ASIN] FROM Inventory.dbo.Amazon WITH(NOLOCK))

PRINT('3')
DECLARE CreateSKU_cursor CURSOR
FOR
--Select all of ASINs that are NULL
SELECT [ASIN] FROM Inventory.dbo.AmazonMerchantSKU WITH(NOLOCK)
WHERE DARTFBMSKU IS NULL


OPEN CreateSKU_cursor
FETCH NEXT FROM CreateSKU_cursor INTO @ASIN

WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT(@ASIN)
	---- Set Low Price Distributor (LPD) FBM SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,5)) + 'L' + CONVERT(varchar(5), RIGHT(@MyID,3)) + 'PD'
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET LPDFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	
	---- SET Smart Marketplace (SMP)FBM SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,3)) + 'SMP' + CONVERT(varchar(5), RIGHT(@MyID,5)) 
	--SET @RandomFBA = 'AF' + @RandomFBM 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET [SMARTMARKETPLACEFBASKU] = @RandomFBA, [SMARTMARKETPLACEFBMSKU] = @RandomFBM WHERE [ASIN] = @ASIN	
		
	---- Set WORLD LAMPS FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = 'W' + CONVERT(varchar(5), LEFT(@MyID,3)) + 'L' + CONVERT(varchar(5), RIGHT(@MyID,3)) 
	--SET @RandomFBA = 'WA' + CONVERT(varchar(5), LEFT(@MyID,3)) + 'L' + CONVERT(varchar(5), RIGHT(@MyID,3)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET WORLDLAMPSFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET WORLDLAMPSFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set Linc Stuff FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,4)) + 'LST' + CONVERT(varchar(5), RIGHT(@MyID,3)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,4)) + 'LST' + CONVERT(varchar(5), RIGHT(@MyID,3))  + 'BA'
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET LINCSTUFFFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET LINCSTUFFFBASKU = @RandomFBM + 'BA' WHERE [ASIN] = @ASIN
	
	
	---- Set Glow Good FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,6)) + 'GLO' + CONVERT(varchar(4), RIGHT(@MyID,2)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET GLOGOODSFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET GLOGOODSFBASKU = 'AF' + @RandomFBM WHERE [ASIN] = @ASIN
	
	---- Set Shop Jiv FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,2)) + 'JIV' + CONVERT(varchar(5), RIGHT(@MyID,5)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,2)) + 'JVFBA' + CONVERT(varchar(5), RIGHT(@MyID,5)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET SHOPJIVFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET SHOPJIVFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set Foco Focus FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,4)) + 'FO' + CONVERT(varchar(6), RIGHT(@MyID,6)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,4)) + 'FOA' + CONVERT(varchar(6), RIGHT(@MyID,6)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET FOCOFOCUSFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET FOCOFOCUSFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set SHOE IT UP FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,5)) + 'SU' + CONVERT(varchar(5), RIGHT(@MyID,5)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,5)) + 'ASU' + CONVERT(varchar(5), RIGHT(@MyID,5)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET SHOEITUPFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET SHOEITUPFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set Glowing Globe FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,2)) + 'GG' + CONVERT(varchar(7), RIGHT(@MyID,7)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,2)) + 'BAGG' + CONVERT(varchar(7), RIGHT(@MyID,7)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET GLOWINGGLOBESFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET GLOWINGGLOBESFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set Glowing Globe FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,2)) + 'GG' + CONVERT(varchar(7), RIGHT(@MyID,7)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,2)) + 'BAGG' + CONVERT(varchar(7), RIGHT(@MyID,7)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET GLOWINGGLOBESFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET GLOWINGGLOBESFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set EYE COMMERCE FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,2)) + 'E' + CONVERT(varchar(8), RIGHT(@MyID,8)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,2)) + 'EA' + CONVERT(varchar(8), RIGHT(@MyID,8)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET EYECOMMERCEFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET EYECOMMERCEFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set ELEMENTARY VISION FBM & FBA SKU
	SET @MyID = newid();
	SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,5)) + 'EVM' + CONVERT(varchar(8), RIGHT(@MyID,3)) 
	SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,5)) + 'EVA' + CONVERT(varchar(8), RIGHT(@MyID,3)) 
	
	UPDATE Inventory.dbo.AmazonMerchantSKU SET ELEMENTARYVISIONFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	UPDATE Inventory.dbo.AmazonMerchantSKU SET ELEMENTARYVISIONFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set GRADE SCHOOL VISION FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,2)) + 'GSM' + CONVERT(varchar(8), RIGHT(@MyID,7)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,2)) + 'GSA' + CONVERT(varchar(8), RIGHT(@MyID,7)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET GRADESCHOOLVISIONFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET GRADESCHOOLVISIONFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	
	---- Set FLOJOSOJOS FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,5)) + 'JOSM' + CONVERT(varchar(8), RIGHT(@MyID,3)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,5)) + 'JSOA' + CONVERT(varchar(8), RIGHT(@MyID,3)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET FLOJOSOJOSFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET FLOJOSOJOSFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	
	---- Set SCHOOL LAMP FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(5), LEFT(@MyID,4)) + 'SLM' + CONVERT(varchar(8), RIGHT(@MyID,3)) 
	--SET @RandomFBA = CONVERT(varchar(5), LEFT(@MyID,4)) + 'SLA' + CONVERT(varchar(8), RIGHT(@MyID,3)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET SCHOOLLAMPFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET SCHOOLLAMPFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set Bargain X FBM & FBA SKU
	--SET @MyID = newid();
	--SET @RandomFBM = 'BX' + CONVERT(varchar(5), LEFT(@MyID,5)) + CONVERT(varchar(3), RIGHT(@MyID,3)) 
	--SET @RandomFBA = 'FBABX' + CONVERT(varchar(5), LEFT(@MyID,5)) + CONVERT(varchar(3), RIGHT(@MyID,3)) 
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET BARGAINXFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET BARGAINXFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	---- Set THE TRAIL account SKU
	--SET @MyID = newid();
	--SET @RandomFBM = CONVERT(varchar(3), LEFT(@MyID,3)) + 'TR' + CONVERT(varchar(4), RIGHT(@MyID,4)) 
	--SET @RandomFBA = 'A' + @RandomFBM + 'L'
	
	--UPDATE Inventory.dbo.AmazonMerchantSKU SET TRAILFBMSKU = @RandomFBM, TRAILFBASKU = @RandomFBA WHERE [ASIN] = @ASIN
	
	-- Set DART account SKU
	SET @MyID = newid();
	SET @RandomFBM = CONVERT(varchar(3), LEFT(@MyID,3)) + 'D' + CONVERT(varchar(4), RIGHT(@MyID,4))  + 'T' 
	SET @RandomFBA = @RandomFBM + 'FBA'
	SET @RandomMFP = @RandomFBM + 'MFP'
	SET @RandomFBMCA = @RandomFBM + 'CA'
	SET @RandomFBACA = @RandomFBM + 'FBACA'
	SET @RandomFBMUK = @RandomFBM + 'EU'
	SET @RandomFBAUK = @RandomFBM + 'FBAEU'
	
	UPDATE Inventory.dbo.AmazonMerchantSKU SET 
	DARTFBMSKU = @RandomFBM, 
	DARTFBASKU = @RandomFBA, 
	DARTMFPSKU = @RandomMFP, 
	DARTFBMSKUCA = @RandomFBMCA, 
	DARTFBASKUCA = @RandomFBACA,
	DARTFBMSKUUK = @RandomFBMUK, 
	DARTFBASKUUK = @RandomFBAUK 
	WHERE [ASIN] = @ASIN
	

	---- Set GTRL X FBM & FBA SKU
	SET @MyID = newid();
	SET @RandomFBM = CONVERT(varchar(2), LEFT(@MyID,2)) + 'GTRL'+ CONVERT(varchar(4), RIGHT(@MyID,4)) + 'MFN'
	SET @RandomFBA = CONVERT(varchar(2), LEFT(@MyID,2)) + 'GTRL' + CONVERT(varchar(4), RIGHT(@MyID,4)) + 'AZF'
	
	UPDATE Inventory.dbo.AmazonMerchantSKU SET GTRLFBMSKU = @RandomFBM WHERE [ASIN] = @ASIN
	UPDATE Inventory.dbo.AmazonMerchantSKU SET GTRLFBASKU = @RandomFBA WHERE [ASIN] = @ASIN



FETCH NEXT FROM CreateSKU_cursor INTO @ASIN

END

CLOSE CreateSKU_cursor
DEALLOCATE CreateSKU_cursor

END

--EXECUTE [dbo].[CreateAmazonMerchantSKU]

go

