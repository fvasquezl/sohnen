-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-17-2018
-- Description:	ChannelAdvisor Field Updates
-- =============================================
CREATE PROCEDURE [dbo].[sp_ChannelAdvisorFieldUpdates] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	  --UPDATE DIMS AND WEIGHT
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] 
	  SET [Length] = IsNull((SELECT [Length] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9)),0),
	  [Height] = IsNull((SELECT [Height] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9)),0),
	  [Width] = IsNull((SELECT [Width] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9)),0),
	  [Weight] = IsNull((SELECT [WeightOZ] FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9)),0)

	  --UPDATE MPN
	  UPDATE CA SET [MPN] = 
	  (CASE 
	  WHEN RIGHT([Inventory Number],3) = 'SED' THEN [PartNumber]+'-USED' 
	  WHEN RIGHT([Inventory Number],3) = 'NEW' THEN [PartNumber]+'-NEW' 
	  WHEN RIGHT([Inventory Number],3) = '-CN' THEN [PartNumber]+'-CN' 
	  WHEN RIGHT([Inventory Number],3) = '-NC' THEN [PartNumber]+'-NC' 
	  ELSE '' END)
	  FROM [Remotes].[dbo].[ChannelAdvisor] AS CA
	  LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD ON (LEFT(CA.[Attribute1Value],9) = SKUD.[SKU])
	  WHERE [Attribute3Value] = 'PartNumberSpecific'


	  UPDATE CA SET [MPN] = 
	  REPLACE([Inventory Number],SKUD.[SKU],SKUD.[PartNumber])
	  FROM [Remotes].[dbo].[ChannelAdvisor] AS CA
	  LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD ON (LEFT(CA.[Attribute1Value],9) = SKUD.[SKU])
	  WHERE [Attribute3Value] = 'ModelSpecific'


	  --UPDATE WEBDESCRIPTION
	  UPDATE CA SET 
					CA.[Short Description] = CA.[Short Description]+'. '+SKUD.[WebDescription],
					CA.[Description] = CA.[Description]+'. '+SKUD.[WebDescription]

	  FROM [Remotes].[dbo].[ChannelAdvisor] AS CA
	  LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD ON (LEFT(CA.[Attribute1Value],9) = SKUD.[SKU])
	  WHERE CA.[Short Description] NOT LIKE '%'+SKUD.[WebDescription]+'%'
	  AND CA.[Description] NOT LIKE '%'+SKUD.[WebDescription]+'%'

	  --FIX WEBDESCRIPTION PUNCTUATION
	  UPDATE CA SET 
					CA.[Short Description] = REPLACE(CA.[Short Description],'. .','.'),
					CA.[Description] = REPLACE(CA.[Description],'. .','.')
	  FROM [Remotes].[dbo].[ChannelAdvisor] AS CA
	  LEFT OUTER JOIN [Remotes].[dbo].[SKUData] AS SKUD ON (LEFT(CA.[Attribute1Value],9) = SKUD.[SKU])
	  

	  --UPDATE CONDITION TO NORMALIZE LowerCase
	  UPDATE [Remotes].[dbo].[ChannelAdvisor]  SET [Condition] = UPPER(LEFT([Condition],1))+LOWER(SUBSTRING([Condition],2,LEN([Condition])))
	  	  

	  --UPDATE QUANTITY
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Quantity] =
	  IsNULL((CASE 
	  WHEN (RIGHT([Attribute1Value],3) = 'NEW') THEN [Remotes].[dbo].[fn_GetQtyByScanCode](LEFT([Attribute1Value],9),'New')
	  WHEN (RIGHT([Attribute1Value],3) = 'SED') THEN [Remotes].[dbo].[fn_GetQtyByScanCode](LEFT([Attribute1Value],9),'Used')
	  WHEN (RIGHT([Attribute1Value],3) = '-CN') THEN [Remotes].[dbo].[fn_GetQtyByScanCode](LEFT([Attribute1Value],9),'CN')
	  WHEN (RIGHT([Attribute1Value],3) = '-NC') THEN [Remotes].[dbo].[fn_GetQtyByScanCode](LEFT([Attribute1Value],9),'NC')
	  ELSE '0' END),'0')

	  --UPDATE SELLER COST
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Seller Cost] = 
  
	  CASE 
	  WHEN [Classification] = 'Remotes' AND (RIGHT([Attribute1Value],3) = 'NEW') THEN
	  (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCost],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
	  WHEN [Classification] = 'Remotes' AND (RIGHT([Attribute1Value],3) = 'SED') THEN
	  (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
	  WHEN [Classification] = 'Remotes' AND (RIGHT([Attribute1Value],3) = '-CN') THEN
	  (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostCN],0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
	  WHEN [Classification] = 'Remotes' AND (RIGHT([Attribute1Value],3) = '-NC') THEN
	  (SELECT CAST(LTRIM(RTRIM(IsNull([UnitCostUSED]*0.75,0))) AS NVARCHAR(MAX)) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
	  ELSE '0' END


	  --UPDATE FLOORPRICE, CEILINGPRICE, BINPRICE, RETAIL PRICE
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Attribute5Name] = 'FloorPrice'
	  
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Attribute5Value] = (CASE 
						WHEN [Condition] = 'Used' THEN (SELECT LTRIM(RTRIM(IsNull([FloorPriceUSED], IsNull([CeilingPriceUSED],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
	  					WHEN RIGHT([Inventory Number],2) = 'CN' THEN (SELECT LTRIM(RTRIM(IsNull([FloorPriceCN], IsNull([CeilingPriceCN],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
						WHEN RIGHT([Inventory Number],2) = 'NC' THEN (SELECT LTRIM(RTRIM(IsNull([FloorPriceUSED]*0.75, IsNull([CeilingPriceUSED]*0.75,'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
						ELSE (SELECT LTRIM(RTRIM(IsNull([FloorPrice], IsNull([CeilingPrice],'89.99')))) FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9)) END)

	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Buy It Now Price] = (CASE 
					  WHEN [Condition] = 'Used' THEN (SELECT IsNull([CeilingPriceUSED],'89.99') FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
					  WHEN RIGHT([Inventory Number],2) = 'CN' THEN (SELECT IsNull([CeilingPriceCN],'89.99') FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
					  WHEN RIGHT([Inventory Number],2) = 'NC' THEN (SELECT IsNull([CeilingPriceUSED]*0.75,'89.99') FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
					  ELSE (SELECT IsNull([CeilingPrice],'89.99') FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9)) END)


	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Retail Price] = (CASE 
					  WHEN [Condition] = 'Used' THEN (SELECT IsNULL(CEILING([CeilingPriceUSED]*2)-0.01,'89.99') FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
					  WHEN RIGHT([Inventory Number],2) = 'CN' THEN (SELECT IsNULL(CEILING([CeilingPriceCN]*2)-0.01,'89.99') FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
					  WHEN RIGHT([Inventory Number],2) = 'NC' THEN (SELECT IsNULL(CEILING([CeilingPriceUSED]*2)-0.01,'89.99') FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9))
					  ELSE (SELECT IsNULL(CEILING([CeilingPrice]*2)-0.01,'89.99') FROM [Remotes].[dbo].[SKUData] WHERE [SKU] = LEFT([Attribute1Value],9)) END)


	  --UPDATE CATEGORY NAME
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Attribute4Value] = (SELECT CAT.[CategoryName] FROM [Remotes].[dbo].[SKUData] AS SKUD 
	  LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT ON (SKUD.[CategoryID] = CAT.[CategoryID]) 
	  WHERE SKUD.[SKU] = LEFT([Attribute1Value],9))

	  --UPDATE COMPATIBILITY LISTS
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Attribute6Name] = 'CompatibleBrand'
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Attribute6Value] = IsNull((SELECT SKUD.[Manufacturer] FROM [Remotes].[dbo].[SKUData] AS SKUD WHERE SKUD.[SKU] = LEFT([Attribute1Value],9)),'')
	  

	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Attribute7Name] = 'OriginallySuppliedWith'
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Attribute7Value] = 
	  (CASE 
	  WHEN [Attribute3Value] = 'PartNumberSpecific' 
	  THEN IsNull((SELECT SKUD.[OriginallySuppliedWith] FROM [Remotes].[dbo].[SKUData] AS SKUD WHERE SKUD.[SKU] = LEFT([Attribute1Value],9)),'')
	  WHEN [Attribute3Value] = 'ModelSpecific' THEN SUBSTRING([Inventory Number], CHARINDEX('-', [Inventory Number]) + 1, LEN([Inventory Number])) 
	  ELSE [Attribute3Value] END)
	  
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Attribute8Name] = 'AlsoCompatibleWith'
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Attribute8Value] = 
	  (CASE 
	  WHEN [Attribute3Value] = 'PartNumberSpecific' THEN
	  IsNull((SELECT SKUD.[AlsoCompatibleWith] FROM [Remotes].[dbo].[SKUData] AS SKUD WHERE SKUD.[SKU] = LEFT([Attribute1Value],9)),'')
	  WHEN [Attribute3Value] = 'ModelSpecific' THEN '' 
	  ELSE [Attribute3Value] END)

	  



	  --UPDATE LABEL
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Labels] = (CASE WHEN RIGHT([Inventory Number],3) = 'NEW' OR RIGHT([Inventory Number],3) = '-CN' 
																			THEN 'Walmart Marketplace, Amazon Marketplace - US, Sears Marketplace, Rakuten.com Shopping'

																	WHEN RIGHT([Inventory Number],4) = 'USED'
																			THEN 'All Inventory, Amazon Marketplace - US, Sears Marketplace, Rakuten.com Shopping, -Walmart Marketplace'
																	
																	WHEN RIGHT([Inventory Number],3) = '-NC' 
																			THEN 'All Inventory, -Walmart Marketplace, -Amazon Marketplace - US, -Sears Marketplace, -Rakuten.com Shopping'
																	
																	ELSE 'All Inventory, -Walmart Marketplace, -Amazon Marketplace - US, -Sears Marketplace, -Rakuten.com Shopping' END)

	  --UPDATE IMAGES
	  UPDATE [Remotes].[dbo].[ChannelAdvisor]
	  SET  [Picture URLs] = 
  
	  CASE 
	  WHEN [Classification] = 'Remote Control' AND RIGHT([Inventory Number],2) != 'CN' AND RIGHT([Inventory Number],2) != 'NC' AND ([Condition] = 'New' OR [Condition] = 'Used') THEN
	  IsNull((SELECT stuff((SELECT ', ' + cast(IMG.[Url] as varchar(max)) FROM [Remotes].[dbo].[Image] AS IMG WHERE IMG.[SKU] = LEFT([Attribute1Value],9)
					AND 
					(
					RIGHT([name],'6') LIKE '%'+'01.jpg'
					OR RIGHT([name],'6') LIKE '%'+'02.jpg'
					OR RIGHT([name],'6') LIKE '%'+'03.jpg'
					OR RIGHT([name],'6') LIKE '%'+'04.jpg'
					OR RIGHT([name],'6') LIKE '%'+'05.jpg'
					OR RIGHT([name],'6') LIKE '%'+'06.jpg'
					) ORDER BY IMG.[Url] ASC
					FOR XML PATH('')), 1, 2, '')),'')

	  WHEN [Classification] = 'Remote Control' AND RIGHT([Inventory Number],2) = 'CN' THEN
	  IsNull((SELECT stuff((SELECT ', ' + cast(IMG.[Url] as varchar(max)) FROM [Remotes].[dbo].[Image] AS IMG WHERE IMG.[SKU] = LEFT([Attribute1Value],9)
					AND 
					(
					RIGHT([name],'6') LIKE '%'+'07.jpg'
					OR RIGHT([name],'6') LIKE '%'+'08.jpg'
					OR RIGHT([name],'6') LIKE '%'+'09.jpg'
					OR RIGHT([name],'6') LIKE '%'+'10.jpg'
					OR RIGHT([name],'6') LIKE '%'+'11.jpg'
					OR RIGHT([name],'6') LIKE '%'+'12.jpg'
					) ORDER BY IMG.[Url] ASC
					FOR XML PATH('')), 1, 2, '')),'')

	  WHEN [Classification] = 'Remote Control' AND RIGHT([Inventory Number],2) = 'NC' THEN
	  'http://remotespict.mitechnologiesinc.com/NOCOVER/nc.jpg,'+IsNull((SELECT stuff((SELECT ', ' + cast(IMG.[Url] as varchar(max)) FROM [Remotes].[dbo].[Image] AS IMG WHERE IMG.[SKU] = LEFT([Attribute1Value],9)
					AND 
					(
					RIGHT([name],'6') LIKE '%'+'01.jpg'
					OR RIGHT([name],'6') LIKE '%'+'02.jpg'
					OR RIGHT([name],'6') LIKE '%'+'03.jpg'
					) ORDER BY IMG.[Url] ASC
					FOR XML PATH('')), 1, 2, '')),'')

	  ELSE  IsNull((SELECT stuff((SELECT ', ' + cast(IMG.[Url] as varchar(max)) FROM [Remotes].[dbo].[Image] AS IMG WHERE IMG.[SKU] = LEFT([Attribute1Value],9)
					AND 
					(
					RIGHT([name],'6') LIKE '%'+'01.jpg'
					OR RIGHT([name],'6') LIKE '%'+'02.jpg'
					OR RIGHT([name],'6') LIKE '%'+'03.jpg'
					OR RIGHT([name],'6') LIKE '%'+'04.jpg'
					OR RIGHT([name],'6') LIKE '%'+'05.jpg'
					OR RIGHT([name],'6') LIKE '%'+'06.jpg'
					)  ORDER BY IMG.[Url] ASC
					FOR XML PATH('')), 1, 2, '')),'')

	  
	  END


	  UPDATE [Remotes].[dbo].[ChannelAdvisor]
	  SET  [Picture URLs] = REPLACE([Picture URLs],'http://remotespict.mitechnologiesinc.com','https://d2tmwtn0gh4496.cloudfront.net')
      
	  --CLEAN IMAGES
	  UPDATE [Remotes].[dbo].[ChannelAdvisor] SET [Picture URLs] = CASE WHEN RIGHT([Picture URLs],1) = ',' THEN LEFT([Picture URLs],(LEN([Picture URLs]))-1) ELSE [Picture URLs] END   



	  -------------------------------------------------------
	  --------------------EU Fields Start--------------------
	  -------------------------------------------------------
	 
	 --Model Specific 
	  UPDATE CA
	  SET  CA.[Attribute10Name] = 'GermanTitle',
	  CA.[Attribute10Value] = 
	  (CASE 
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz TV Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Fernseher'
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original TV Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Fernseher'

	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' CD Player'
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' CD Player'


	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' DVD Player'
	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' DVD Player'


	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Blu-Ray Player'
	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Blu-Ray Player'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Receiver/Stereoanlage (Surroundsystem)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Receiver/Stereoanlage (Surroundsystem)'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Receiver/Stereoanlage (Surroundsystem)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Receiver/Stereoanlage (Surroundsystem)'

	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Lautsprecher Heimkino System Musik Spieler'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Lautsprecher Heimkino System Musik Spieler'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Klimaanlage/Klimagerät/Air Conditioner'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Klimaanlage/Klimagerät/Air Conditioner'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')
	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')


	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box für Fernseher (ohne Kabel)'
	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box für Fernseher (ohne Kabel)'
		
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Verbindungskabel/Kabel für Fernseher'
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Verbindungskabel/Kabel für Fernseher'
				
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Laptop/Notebook Ladekabel inkl. Netzteil Stromkabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Laptop/Notebook Ladekabel inkl. Netzteil Stromkabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Tablet Ladekabel inkl. Netzteil Stromkabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Tablet Ladekabel inkl. Netzteil Stromkabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Handy/Telefon Ladekabel inkl. Netzteil Stromkabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Handy/Telefon Ladekabel inkl. Netzteil Stromkabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Stromkabel/Netzteil Stromanschlusskabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Stromkabel/Netzteil Stromanschlusskabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Bildschirm/Monitor Netzteil Stromkabel/Anschlusskabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Bildschirm/Monitor Netzteil Stromkabel/Anschlusskabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Netzteil inkl. Stromkabel Stromadapter'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Netzteil inkl. Stromkabel Stromadapter'

	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Stromkabel/Stromanschluss Netzkabel'
	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Stromkabel/Stromanschluss Netzkabel'

	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' AV Kabel Audio Video Anschlusskabel'
	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' AV Kabel Audio Video Anschlusskabel'

	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Spezialkabel'
	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Spezialkabel'

	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Kabel'
	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Kabel'


	  ELSE '' END),

	  CA.[Attribute11Name] = 'FrenchTitle',
	  CA.[Attribute11Value] = 
	  (CASE 
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande TV de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Télévision'
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande TV Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Télévision'
	  
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Lecteur CD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Lecteur CD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Lecteur DVD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Lecteur DVD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Lecteur Blu-Ray'
	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Lecteur Blu-Ray'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Récepteur/Stéréo (Système Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Récepteur/Stéréo (Système Surround)'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Récepteur/Stéréo (Système Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Récepteur/Stéréo (Système Surround)'

	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Haut-parleur Home Cinema Système Lecteurs de Musique'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Haut-parleur Home Cinema Système Lecteurs de Musique'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Investissement Climatique/Climatiseur'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Investissement Climatique/Climatiseur'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')
	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')


	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box pour Téléviseurs (sans câble)'
	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box pour Téléviseurs (sans câble)'
		
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Connexion TV One Connect pour Téléviseurs'
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Connexion TV One Connect pour Téléviseurs'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Recharge pour Ordinateur Portatif/Portable d*alimentation'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Recharge pour Ordinateur Portatif/Portable d*alimentation'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble de charge pour Tablette/Adaptateur Secteur'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble de charge pour Tablette/Adaptateur Secteur'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Charge pour Téléphone Portable/Adaptateur d*alimentation'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Charge pour Téléphone Portable/Adaptateur d*alimentation'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble d*alimentation/Adaptateur'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble d*alimentation/Adaptateur'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble d*alimentation pour écran/Moniteur'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble d*alimentation pour écran/Moniteur'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Bloc d*alimentation avec câble d*alimentation Adaptateur secteur'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Bloc d*alimentation avec câble d*alimentation Adaptateur secteur'

	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cordon d*alimentation'
	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cordon d*alimentation'

	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble AV Connexion Vidéo y Audio'
	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble AV Connexion Vidéo y Audio'

	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câbles Spéciaux'
	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câbles Spéciaux'

	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble'
	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Câble'


	  ELSE '' END),

	  CA.[Attribute12Name] = 'SpanishTitle',
	  CA.[Attribute12Value] = 
	  (CASE 
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Televisión/TV'
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Televisión/TV'

	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de CD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de CD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de DVD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de DVD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de Blu-Ray'
	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de Blu-Ray'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Barra/Sistema de Sonido'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Barra/Sistema de Sonido'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Receptor de Audio/Estéreo (sistema de sonido)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Receptor de Audio/Estéreo (sistema de sonido)'

	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Sistema de Teatro/Altavoz'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Sistema de Teatro/Altavoz'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Aire Acondicionado'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Aire Acondicionado'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')
	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')


	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Caja para Televisión/TV (sin Cable)'
	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Caja para Televisión/TV (sin Cable)'
		
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable de One Connect Cable para Televisión/TV'
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable de One Connect Cable para Televisión/TV'
			
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Laptop'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Laptop'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Tableta'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Tableta'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Teléfono Móvil/Cellular'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Teléfono Móvil/Cellular'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente/Fuente de Alimentación'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente/Fuente de Alimentación'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Monitor de Computadora'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Monitor de Computadora'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente/Fuente de Alimentación'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente/Fuente de Alimentación'

	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable de Alimentación'
	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable de Alimentación'

	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable de Audio y Video'
	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable de Audio y Video'

	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable Especial'
	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable Especial'

	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable'
	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cable'


	  ELSE '' END),

	  CA.[Attribute13Name] = 'ItalianTitle',
	  CA.[Attribute13Value] = 
	  (CASE 
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' televisione'
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' televisione'

	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore CD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore CD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore DVD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore DVD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore Blu-Ray'
	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore Blu-Ray'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Soundbar (Sistema Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Soundbar (Sistema Surround)'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Ricevitore Audio (Sistema Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Ricevitore Audio (Sistema Surround)'

	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Sistema Home Theater (Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Sistema Home Theater (Surround)'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Aria Condizionata/Condizionatore'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')+' Aria Condizionata/Condizionatore'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')
	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','')


	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect per TV (senza cavo)'
	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect per TV (senza cavo)'
		
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Cavo di Collegamento per TV'
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Cavo di Collegamento per TV'
				
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Laptop'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Laptop'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Tablet'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Tablet'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Cellulare'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Cellulare'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Schermo/Computer'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Schermo/Computer'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione'

	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cavo di Alimentazione'
	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cavo di Alimentazione'

	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cavo di Audio Video'
	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cavo di Audio Video'

	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cavo Speciale'
	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cavo Speciale'

	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cavo'
	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[Attribute7Value],'-USED',''),'-NEW',''),'-CN','') + ' Cavo'


	  ELSE '' END),

	  CA.[Attribute14Name] = 'PriceFloorEU',
	  CA.[Attribute14Value] =
	  (SELECT (CASE	WHEN RIGHT(CA.[Attribute1Value],3) = 'NEW'THEN SKUD.[FloorPriceEU]
					WHEN RIGHT(CA.[Attribute1Value],3) = '-CN'THEN SKUD.[FloorPriceEUCN] 
					WHEN RIGHT(CA.[Attribute1Value],3) = 'SED'THEN SKUD.[FloorPriceEUUSED]
					ELSE SKUD.[FloorPriceEU] END) 
	  FROM [Remotes].[dbo].[SKUDATA] AS SKUD WHERE SKUD.[SKU] = LEFT(CA.[Attribute1Value],9)),

	  CA.[Attribute15Name] = 'PriceCeilingEU',
	  CA.[Attribute15Value] = 
	  (SELECT (CASE	WHEN RIGHT(CA.[Attribute1Value],3) = 'NEW'THEN SKUD.[CeilingPriceEU]
					WHEN RIGHT(CA.[Attribute1Value],3) = '-CN'THEN SKUD.[CeilingPriceEUCN] 
					WHEN RIGHT(CA.[Attribute1Value],3) = 'SED'THEN SKUD.[CeilingPriceEUUSED]
					ELSE SKUD.[CeilingPriceEU] END) 
	  FROM [Remotes].[dbo].[SKUDATA] AS SKUD WHERE SKUD.[SKU] = LEFT(CA.[Attribute1Value],9))

	  FROM [Remotes].[dbo].[ChannelAdvisor] AS CA
	  WHERE CA.[Attribute3Value] != 'PartNumberSpecific'
	  

	  ---------------------
	  	 --PartNumber Specific 
	  UPDATE CA
	  SET  CA.[Attribute10Name] = 'GermanTitle',
	  CA.[Attribute10Value] = 
	  (CASE 
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz TV Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Fernseher'
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original TV Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Fernseher'

	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' CD Player'
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' CD Player'


	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' DVD Player'
	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' DVD Player'


	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Blu-Ray Player'
	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Blu-Ray Player'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Receiver/Stereoanlage (Surroundsystem)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Receiver/Stereoanlage (Surroundsystem)'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Receiver/Stereoanlage (Surroundsystem)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Receiver/Stereoanlage (Surroundsystem)'

	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Lautsprecher Heimkino System Musik Spieler'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Lautsprecher Heimkino System Musik Spieler'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Klimaanlage/Klimagerät/Air Conditioner'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Klimaanlage/Klimagerät/Air Conditioner'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Ersatz Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')
	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')

	  
	 WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box für Fernseher (ohne Kabel)'
	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box für Fernseher (ohne Kabel)'
		
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Verbindungskabel/Kabel für Fernseher'
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Verbindungskabel/Kabel für Fernseher'
				
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Laptop/Notebook Ladekabel inkl. Netzteil Stromkabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Laptop/Notebook Ladekabel inkl. Netzteil Stromkabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Tablet Ladekabel inkl. Netzteil Stromkabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Tablet Ladekabel inkl. Netzteil Stromkabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Handy/Telefon Ladekabel inkl. Netzteil Stromkabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Handy/Telefon Ladekabel inkl. Netzteil Stromkabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Stromkabel/Netzteil Stromanschlusskabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Stromkabel/Netzteil Stromanschlusskabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Bildschirm/Monitor Netzteil Stromkabel/Anschlusskabel'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Bildschirm/Monitor Netzteil Stromkabel/Anschlusskabel'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Netzteil inkl. Stromkabel Stromadapter'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Netzteil inkl. Stromkabel Stromadapter'

	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Stromkabel/Stromanschluss Netzkabel'
	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Stromkabel/Stromanschluss Netzkabel'

	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' AV Kabel Audio Video Anschlusskabel'
	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' AV Kabel Audio Video Anschlusskabel'

	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Spezialkabel'
	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Spezialkabel'

	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Kabel'
	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Kabel'


	  ELSE '' END),

	  CA.[Attribute11Name] = 'FrenchTitle',
	  CA.[Attribute11Value] = 
	  	  (CASE 
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande TV de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Télévision'
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande TV originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Télévision'
	  
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Lecteur CD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Lecteur CD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Lecteur DVD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Lecteur DVD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Lecteur Blu-Ray'
	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Lecteur Blu-Ray'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Récepteur/Stéréo (Système Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Récepteur/Stéréo (Système Surround)'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Récepteur/Stéréo (Système Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Original Fernbedienung für '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Récepteur/Stéréo (Système Surround)'

	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Haut-parleur Home Cinema Système Lecteurs de Musique'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Haut-parleur Home Cinema Système Lecteurs de Musique'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Investissement Climatique/Climatiseur'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Investissement Climatique/Climatiseur'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Télécommande de remplacement pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')
	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Télécommande Originale pour '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')


	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box pour Téléviseurs (sans câble)'
	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box pour Téléviseurs (sans câble)'
		
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Connexion TV One Connect pour Téléviseurs'
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Connexion TV One Connect pour Téléviseurs'
			
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Recharge pour Ordinateur Portatif/Portable d*alimentation'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Recharge pour Ordinateur Portatif/Portable d*alimentation'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble de charge pour Tablette/Adaptateur Secteur'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble de charge pour Tablette/Adaptateur Secteur'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Charge pour Téléphone Portable/Adaptateur d*alimentation'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble de Charge pour Téléphone Portable/Adaptateur d*alimentation'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble d*alimentation/Adaptateur'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble d*alimentation/Adaptateur'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble d*alimentation pour écran/Moniteur'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble d*alimentation pour écran/Moniteur'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Ersatz ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Bloc d*alimentation avec câble d*alimentation Adaptateur secteur'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Bloc d*alimentation avec câble d*alimentation Adaptateur secteur'

	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cordon d*alimentation'
	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cordon d*alimentation'

	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble AV Connexion Vidéo y Audio'
	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble AV Connexion Vidéo y Audio'

	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câbles Spéciaux'
	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câbles Spéciaux'

	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Remplacement ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble'
	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Câble'


	  ELSE '' END),

	  CA.[Attribute12Name] = 'SpanishTitle',
	  CA.[Attribute12Value] = 
	   (CASE 
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Televisión/TV'
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Televisión/TV'

	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de CD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de CD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de DVD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de DVD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de Blu-Ray'
	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Reproductor de Blu-Ray'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Barra/Sistema de Sonido'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Barra/Sistema de Sonido'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Receptor de Audio/Estéreo (sistema de sonido)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Receptor de Audio/Estéreo (sistema de sonido)'

	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Sistema de Teatro/Altavoz'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Sistema de Teatro/Altavoz'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Aire Acondicionado'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Aire Acondicionado'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Control Remoto Compatible para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')
	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Control Remoto Original para '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')

	  
	 WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Caja para Televisión/TV (sin Cable)'
	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Caja para Televisión/TV (sin Cable)'
		
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable de One Connect Cable para Televisión/TV'
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable de One Connect Cable para Televisión/TV'
				
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Laptop'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Laptop'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Tableta'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Tableta'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Teléfono Móvil/Cellular'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Teléfono Móvil/Cellular'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente/Fuente de Alimentación'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente/Fuente de Alimentación'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Monitor de Computadora'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente para Monitor de Computadora'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente/Fuente de Alimentación'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adaptador de Corriente/Fuente de Alimentación'

	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable de Alimentación'
	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable de Alimentación'

	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable de Audio y Video'
	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable de Audio y Video'

	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable Especial'
	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable Especial'

	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Compatible ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable'
	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Original ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cable'


	  ELSE '' END),

	  CA.[Attribute13Name] = 'ItalianTitle',
	  CA.[Attribute13Value] = 
	   (CASE 
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Televisione'
	  WHEN CA.[Attribute4Value] = 'Remote Control - TV' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale TV per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Televisione'

	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore CD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - CD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore CD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore DVD'
	  WHEN CA.[Attribute4Value] = 'Remote Control - DVD' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore DVD'


	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore Blu-Ray'
	  WHEN CA.[Attribute4Value] = 'Remote Control - BluRay' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Riproduttore Blu-Ray'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Soundbar (Sistema Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Sound Bar' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'OTelecomando Originale per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Soundbar (Sistema Surround)'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Ricevitore Audio (Sistema Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Audio Receiver' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Ricevitore Audio (Sistema Surround)'

	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Sistema Home Theater (Surround)'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Home Theater' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Sistema Home Theater (Surround)'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Aria Condizionata/Condizionatore'
	  WHEN CA.[Attribute4Value] = 'Remote Control - Air Conditioner' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')+' Aria Condizionata/Condizionatore'


	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	  'Telecomando Sostitutivo per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')
	  WHEN CA.[Attribute4Value] = 'Remote Control - Other' AND (RIGHT(CA.[Attribute1Value],3) = 'NEW' OR RIGHT(CA.[Attribute1Value],3) = 'SED') THEN
	  'Telecomando Originale per '+CA.[Attribute6Value]+' '+REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','')

	  
	 WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box per TV (senza cavo)'
	WHEN CA.[Attribute4Value] = 'Media Boxes - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Box per TV (senza cavo)'
		
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Cavo di Collegamento per TV'
	WHEN CA.[Attribute4Value] = 'Cables - One Connect' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' TV One Connect Cavo di Collegamento per TV'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Laptop'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Laptop' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Laptop'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Tablet'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Tablet' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Tablet'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Cellulare'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Cell Phone' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Cellulare'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Appliance' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Schermo/Computer'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Monitor' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione per Schermo/Computer'

	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione'
	WHEN CA.[Attribute4Value] = 'Power Adapter - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Adattatore di Alimentazione'

	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cavo di Alimentazione'
	WHEN CA.[Attribute4Value] = 'Cables - Power' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cavo di Alimentazione'

	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cavo di Audio Video'
	WHEN CA.[Attribute4Value] = 'Cables - Audio Video' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cavo di Audio Video'

	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cavo Speciale'
	WHEN CA.[Attribute4Value] = 'Cables - Specialty' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cavo Speciale'

	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = '-CN' THEN	
	'Sostitutivo ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cavo'
	WHEN CA.[Attribute4Value] = 'Cables - Other' AND RIGHT(CA.[Attribute1Value],3) = 'NEW' THEN	
	'Originale ' + CA.[Attribute6Value] + ' ' + REPLACE(REPLACE(REPLACE(CA.[MPN],'-USED',''),'-NEW',''),'-CN','') + ' Cavo'


	  ELSE '' END),

	  CA.[Attribute14Name] = 'PriceFloorEU',
	  CA.[Attribute14Value] =
	  (SELECT (CASE	WHEN RIGHT(CA.[Attribute1Value],3) = 'NEW'THEN SKUD.[FloorPriceEU]
					WHEN RIGHT(CA.[Attribute1Value],3) = '-CN'THEN SKUD.[FloorPriceEUCN] 
					WHEN RIGHT(CA.[Attribute1Value],3) = 'SED'THEN SKUD.[FloorPriceEUUSED]
					ELSE SKUD.[FloorPriceEU] END) 
	  FROM [Remotes].[dbo].[SKUDATA] AS SKUD WHERE SKUD.[SKU] = LEFT(CA.[Attribute1Value],9)),

	  CA.[Attribute15Name] = 'PriceCeilingEU',
	  CA.[Attribute15Value] = 
	  (SELECT (CASE	WHEN RIGHT(CA.[Attribute1Value],3) = 'NEW'THEN SKUD.[CeilingPriceEU]
					WHEN RIGHT(CA.[Attribute1Value],3) = '-CN'THEN SKUD.[CeilingPriceEUCN] 
					WHEN RIGHT(CA.[Attribute1Value],3) = 'SED'THEN SKUD.[CeilingPriceEUUSED]
					ELSE SKUD.[CeilingPriceEU] END) 
	  FROM [Remotes].[dbo].[SKUDATA] AS SKUD WHERE SKUD.[SKU] = LEFT(CA.[Attribute1Value],9))

	  FROM [Remotes].[dbo].[ChannelAdvisor] AS CA
	  WHERE CA.[Attribute3Value] = 'PartNumberSpecific'



	  
END
go

