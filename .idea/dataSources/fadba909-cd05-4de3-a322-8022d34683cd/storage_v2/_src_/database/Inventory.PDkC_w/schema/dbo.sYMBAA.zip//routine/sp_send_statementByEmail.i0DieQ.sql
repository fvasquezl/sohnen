-- =============================================
-- Author:		Araceli Sánchez
-- Create date: 2016-03-30
-- Description:	Scan By Hour and Between Dates version to linq
-- =============================================
CREATE PROCEDURE [dbo].[sp_send_statementByEmail]
	@SearchVal	NVARCHAR(200)
AS
BEGIN

	SELECT --TOP (@a)
	CUST.[CustomerID] ID, 
	CUST.[FullName] CUSTOMER, 
	CUST.[Company] COMPANY, 
	upper(CUST.[Address] + case when CUST.[Address2] is null then '' else '. ' + CUST.[Address2] end) as [ADDRESS], 
	(CUST.[CITY] + case when CUST.[State] is null then '' else ', ' + CUST.[State] end) as [CITY], CUST.[ZIP], 
	CUST.[COUNTRY], CUST.[EMAIL] 
	FROM [OrderManager].[dbo].[Customers] (NOLOCK) AS cust 
	WHERE 
	
	(
		(
		CustomerID IN (
			SELECT CustomerID from OrderManager.dbo.Orders WHERE Approved = '1' AND Cancelled = '0' AND BalanceDue > '1.00')
		) 
		AND
		(
			(@SearchVal IS NULL OR LEN(@SearchVal) = 0)
		OR
		(	CUST.[CustomerID] LIKE @SearchVal OR 
			CUST.FullName LIKE @SearchVal OR 
			CUST.Company LIKE @SearchVal OR 
			(CUST.[Address] + ' ' + ISNULL(CUST.[Address2],'')) LIKE @SearchVal OR 
			CUST.[CITY] LIKE @SearchVal OR 
			ISNULL(CUST.[State],'') LIKE @SearchVal OR 
			CUST.Country LIKE @SearchVal OR  
			CUST.[ZIP] LIKE @SearchVal OR 
			CUST.[EMAIL] LIKE @SearchVal 
		)
		)
	) 
	order by 
	CUST.[CustomerID]
END
go

