-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-05-20
-- Description:	Get Menus
-- =============================================
CREATE PROCEDURE sp_GetMenus
	@parent_menu_id NVARCHAR(5)
AS
DECLARE
	@CURSOR_MENU		CURSOR,
	@CURSOR_SUBMENU		CURSOR,
	@CURSOR_SUBMENU2	CURSOR,
	@CURSOR_SUBMENU3	CURSOR,
	@menu_id			NVARCHAR(5),
	@title_label		NVARCHAR(50), 
	@menu_url			NVARCHAR(100),
	@parent_id			NVARCHAR(5),
	@I					INT = 0,
	@NEXT_MENU			NVARCHAR(5),
	@CUR_menu_id		NVARCHAR(5),
	@CUR_title_label	NVARCHAR(50), 
	@CUR_menu_url		NVARCHAR(100),
	@CUR_parent_id		NVARCHAR(5),
	@CUR2_menu_id		NVARCHAR(5),
	@CUR2_title_label	NVARCHAR(50), 
	@CUR2_menu_url		NVARCHAR(100),
	@CUR2_parent_id		NVARCHAR(5),
	@CUR3_menu_id		NVARCHAR(5),
	@CUR3_title_label	NVARCHAR(50), 
	@CUR3_menu_url		NVARCHAR(100),
	@CUR3_parent_id		NVARCHAR(5)
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #tmpMenus (menu_id NVARCHAR(5), title_label NVARCHAR(50), menu_url NVARCHAR(100), parent_menu_id NVARCHAR(5), seq INT )
	CREATE CLUSTERED INDEX Idx1 ON #tmpMenus(menu_id,title_label,menu_url,seq)

	SET @I = 0

	SET @CURSOR_MENU = CURSOR FOR

    SELECT A.menu_id, A.title_label, A.menu_url, A.parent_menu_id
	FROM Inventory.dbo.menus A
	WHERE A.active = 1 AND ISNULL(A.parent_menu_id,'') = @parent_menu_id
	ORDER BY menu_seq ASC

	OPEN @CURSOR_MENU 
	FETCH NEXT FROM @CURSOR_MENU
	INTO @menu_id, @title_label, @menu_url, @parent_id
      
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		
		INSERT INTO #tmpMenus (menu_id,title_label,menu_url,parent_menu_id,seq) VALUES (@menu_id,@title_label,@menu_url,@parent_id,@I)
		SET @NEXT_MENU = @menu_id

		SET @I = @I + 1
		
		IF(ISNULL(@NEXT_MENU,'') <> '')
		BEGIN
			SET @CURSOR_SUBMENU = CURSOR FOR

			SELECT menu_id, title_label, menu_url, parent_menu_id
			FROM Inventory.dbo.menus 
			WHERE active = 1 AND ISNULL(parent_menu_id,'') = @NEXT_MENU

			OPEN @CURSOR_SUBMENU 
			FETCH NEXT FROM @CURSOR_SUBMENU
			INTO @CUR_menu_id, @CUR_title_label, @CUR_menu_url, @CUR_parent_id

			WHILE (@@FETCH_STATUS = 0)
			BEGIN
					
				INSERT INTO #tmpMenus (menu_id,title_label,menu_url,parent_menu_id,seq) VALUES (@CUR_menu_id,@CUR_title_label,@CUR_menu_url,@CUR_parent_id,@I)
				SET @NEXT_MENU = @CUR_menu_id

				SET @I = @I + 1

				IF(ISNULL(@NEXT_MENU,'') <> '')
				BEGIN
					SET @CURSOR_SUBMENU2 = CURSOR FOR

					SELECT menu_id, title_label, menu_url, parent_menu_id
					FROM Inventory.dbo.menus 
					WHERE active = 1 AND ISNULL(parent_menu_id,'') = @NEXT_MENU

					OPEN @CURSOR_SUBMENU2
					FETCH NEXT FROM @CURSOR_SUBMENU2
					INTO @CUR2_menu_id, @CUR2_title_label, @CUR2_menu_url, @CUR2_parent_id

					WHILE (@@FETCH_STATUS = 0)
					BEGIN
						
						INSERT INTO #tmpMenus (menu_id,title_label,menu_url,parent_menu_id,seq) VALUES (@CUR2_menu_id,@CUR2_title_label,@CUR2_menu_url,@CUR2_parent_id,@I)
						SET @NEXT_MENU = @CUR2_menu_id

						SET @I = @I + 1

						IF(ISNULL(@NEXT_MENU,'') <> '')
						BEGIN

							SET @CURSOR_SUBMENU3 = CURSOR FOR

							SELECT menu_id, title_label, menu_url, parent_menu_id
							FROM Inventory.dbo.menus 
							WHERE active = 1 AND ISNULL(parent_menu_id,'') = @NEXT_MENU

							OPEN @CURSOR_SUBMENU3
							FETCH NEXT FROM @CURSOR_SUBMENU3
							INTO @CUR3_menu_id, @CUR3_title_label, @CUR3_menu_url, @CUR3_parent_id

							WHILE (@@FETCH_STATUS = 0)
							BEGIN
								INSERT INTO #tmpMenus (menu_id,title_label,menu_url,parent_menu_id,seq) VALUES (@CUR3_menu_id,@CUR3_title_label,@CUR3_menu_url,@CUR3_parent_id,@I)
								SET @NEXT_MENU = @CUR3_menu_id

								SET @I = @I + 1

								NEXT_FETCH3:
								FETCH NEXT FROM @CURSOR_SUBMENU3
								INTO @CUR3_menu_id, @CUR3_title_label, @CUR3_menu_url, @CUR3_parent_id
							END
							CLOSE      @CURSOR_SUBMENU3
							DEALLOCATE @CURSOR_SUBMENU3
						END

						NEXT_FETCH2:
						FETCH NEXT FROM @CURSOR_SUBMENU2
						INTO @CUR2_menu_id, @CUR2_title_label, @CUR2_menu_url, @CUR2_parent_id
					END
					CLOSE      @CURSOR_SUBMENU2
					DEALLOCATE @CURSOR_SUBMENU2
				END

				NEXT_FETCH1:
				FETCH NEXT FROM @CURSOR_SUBMENU
				INTO @CUR_menu_id, @CUR_title_label, @CUR_menu_url, @CUR_parent_id
			END
			CLOSE      @CURSOR_SUBMENU
			DEALLOCATE @CURSOR_SUBMENU
		END

		NEXT_FETCH:
		FETCH NEXT FROM @CURSOR_MENU
		INTO @menu_id, @title_label, @menu_url, @parent_id
	END
	CLOSE      @CURSOR_MENU
	DEALLOCATE @CURSOR_MENU

	SELECT * FROM #tmpMenus
	ORDER BY seq ASC

END
go

