-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2019-05-02
-- Description:	Get VirtStock by Reflector Category
-- =============================================
CREATE PROCEDURE [sp_Update_VirtStock_Reflector]
AS
BEGIN
	DECLARE @CURSOR_REF		CURSOR,
			@MITSKU			INT,
			@VirtualStock	INT
	SET NOCOUNT ON;
	    	
	SET @CURSOR_REF = CURSOR FOR 

	SELECT ID FROM Inventory.dbo.ProductCatalog WITH(NOLOCK) 
	--Raw Materials - Lamp Reflector
	WHERE CategoryID = 70
	
	OPEN @CURSOR_REF 
	FETCH NEXT FROM @CURSOR_REF 
	INTO @MITSKU
	
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
	
		SET @VirtualStock = ISNULL((
			SELECT MIN(R.QtyStock)
			FROM (
				SELECT T.SubSKU, CONVERT(INT,(T.Counter / T.SubSKUQTYRequired)) AS QtyStock
				FROM (
					SELECT AD.SubSKU, AD.SubSKUQTYRequired, SUM(ISNULL(BC.Counter,0)) AS Counter
					FROM [Inventory].[dbo].[AssemblyDetails] AS AD WITH(NOLOCK)
					LEFT OUTER JOIN Inventory.dbo.Bin_Content BC WITH(NOLOCK)
					ON BC.ProductCatalog_Id = AD.SubSKU AND Inventory.dbo.fn_Get_Bin_WarehouseID(BC.Bin_Id) <> 'DF' 
					WHERE AD.ProductCatalogID = @MITSKU
					GROUP BY AD.SubSKU, AD.SubSKUQTYRequired
				) T
			) R
		),0)

		UPDATE Inventory.dbo.Global_Stocks WITH(UPDLOCK) SET VirtualStock = ISNULL(@VirtualStock,0) WHERE ProductCatalogId = @MITSKU

		PRINT @MITSKU
		PRINT @VirtualStock

		SET @VirtualStock = 0

		NEXT_FETCH:
		FETCH NEXT FROM @CURSOR_REF
		INTO @MITSKU
	END
	CLOSE      @CURSOR_REF
	DEALLOCATE @CURSOR_REF
END
go

