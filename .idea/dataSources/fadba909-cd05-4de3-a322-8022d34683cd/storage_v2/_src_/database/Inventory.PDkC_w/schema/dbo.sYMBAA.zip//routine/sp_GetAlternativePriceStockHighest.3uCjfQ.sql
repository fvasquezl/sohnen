
-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2018-10-30
-- Description:	Get FLEX Alternative Highest Stock
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetAlternativePriceStockHighest]
	@pSKU INT
AS
BEGIN
	DECLARE @tQOH			INT = 0,
			@CategoryID		INT,
			@AlwaysInStock	BIT = 0,
			@isLampsBare	BIT = 0,
			@ShipSKU		INT
	SET NOCOUNT ON;
	/*
		Create temporary tables to save the results obtained
		1.- #tmpResult: this table keeps all possible alternative skus by means of the SKU to search
		2.- #tmpSKU: this table saves the sku by sequence
	*/
	CREATE TABLE #tmpResult ([EncSKUPH] NVARCHAR(6), [EncSKUOS] NVARCHAR(6), [EncSKUNL] NVARCHAR(6), [EncSKUPX] NVARCHAR(6), [EncSKUUSH] NVARCHAR(6), [EncSKUOEM] NVARCHAR(6), [EncSKU] NVARCHAR(6))
	CREATE TABLE #tmpSKU (SKU INT, Seq INT)
	CREATE CLUSTERED INDEX IDX_tmpSKU ON #tmpSKU(SKU)

	/*
		Step 1: Data is searched for by SKU, such as:
			1.1 - CategoryID: the category of the SKU
			1.2 - tQOH: Total amount of Stock ( GlobalStock + VirtualStock = TotalStock)
			1.3 - AlwaysInStock: if the sku is always in stock
	*/
	SELECT @CategoryID = PC.CategoryID, @tQOH = CONVERT(INT,ISNULL(GS.TotalStock,0)), @AlwaysInStock = ISNULL(PC.AlwaysInStock,0)
	FROM Inventory.dbo.ProductCatalog PC WITH(NOLOCK)
	LEFT OUTER JOIN Inventory.dbo.Global_Stocks GS WITH(NOLOCK)
	ON GS.ProductCatalogId = PC.ID
	WHERE PC.ID = @pSKU

	/*
		Step 2: Verify if the SKU category is not enclosure
	*/
	IF(@CategoryID NOT IN (10,11,12,13,20,21,22,23,62,64,14,24))
	BEGIN
		SET @isLampsBare = 1
	END
	
	--Uncomment the bottom line to see the result of the first two steps
	--SELECT @pSKU AS SKU, @CategoryID AS CategoryID, @tQOH AS tQOH, @AlwaysInStock AS AlwaysInStock, @isLampsBare AS isLampsBare

	/*
		Step 3: If the results obtained meet the following conditions, go to the last step (Step 7)
			3.1 - If AlwaysInStock is true the tQOH gets 500 per default
	*/

	IF(ISNULL(@tQOH,0) > 0 OR @isLampsBare = 1 OR @AlwaysInStock = 1)
	BEGIN
		IF(@AlwaysInStock = 1)
		BEGIN
			SET @tQOH = 500
		END
	END
	ELSE
	BEGIN
		IF (@CategoryID NOT IN (24,14))
		BEGIN
			/*
				Step 4: Search all alternative SKUs for the searched SKU and they are inserted in the temporary table 
			*/
			INSERT INTO #tmpResult
			SELECT [EncSKUPH], [EncSKUOS], [EncSKUNL], [EncSKUPX], [EncSKUUSH], [EncSKUOEM], [EncSKU]
			FROM [MITDB].[dbo].[ProjectorData] AS PJD WITH(NOLOCK)
			WHERE PJD.[EncSKUPH] = @pSKU OR PJD.[EncSKUOS] = @pSKU OR PJD.[EncSKUNL] = @pSKU OR PJD.[EncSKUPX] = @pSKU OR PJD.[EncSKUUSH] = @pSKU OR PJD.[EncSKUOEM] = @pSKU OR PJD.[EncSKU] = @pSKU

			--Uncomment the bottom line to see the result of the 4 step
			--SELECT * FROM #tmpResult

			/*
				Step 5: The result is organized by sequence previously established
					5.1 - Seq 1: Philips
					5.2 - Seq 2: Osram
					5.3 - Seq 3: NL
					5.4 - Seq 4: Phoenix
					5.5 - Seq 5: Ushio
					5.6 - Seq 6: OEM
					5.7 - Seq 7: Generic
			*/
			INSERT INTO #tmpSKU 
			SELECT [EncSKUPH], 1
			FROM #tmpResult	WHERE [EncSKUPH] != '-' AND [EncSKUPH] IS NOT NULL AND [EncSKUPH] != @pSKU GROUP BY [EncSKUPH]

			INSERT INTO #tmpSKU 
			SELECT [EncSKUOS], 2
			FROM #tmpResult	WHERE [EncSKUOS] != '-' AND [EncSKUOS] IS NOT NULL AND [EncSKUOS] != @pSKU GROUP BY [EncSKUOS]

			INSERT INTO #tmpSKU 
			SELECT [EncSKUNL], 3
			FROM #tmpResult	WHERE [EncSKUNL] != '-' AND [EncSKUNL] IS NOT NULL AND [EncSKUNL] != @pSKU GROUP BY [EncSKUNL]

			INSERT INTO #tmpSKU 
			SELECT [EncSKUPX], 4
			FROM #tmpResult	WHERE [EncSKUPX] != '-' AND [EncSKUPX] IS NOT NULL AND [EncSKUPX] != @pSKU GROUP BY [EncSKUPX]

			INSERT INTO #tmpSKU 
			SELECT [EncSKUUSH], 5
			FROM #tmpResult	WHERE [EncSKUUSH] != '-' AND [EncSKUUSH] IS NOT NULL AND [EncSKUUSH] != @pSKU GROUP BY [EncSKUUSH]

			INSERT INTO #tmpSKU 
			SELECT [EncSKUOEM], 6
			FROM #tmpResult	WHERE [EncSKUOEM] != '-' AND [EncSKUOEM] IS NOT NULL AND [EncSKUOEM] != @pSKU GROUP BY [EncSKUOEM]

			INSERT INTO #tmpSKU 
			SELECT [EncSKU], 7
			FROM #tmpResult	WHERE [EncSKU] != '-' AND [EncSKU] IS NOT NULL AND [EncSKU] != @pSKU GROUP BY [EncSKU]

			--Uncomment the bottom line to see the result of the 5 step
			--SELECT T.SKU, T.Seq, C.Name FROM #tmpSKU T INNER JOIN Inventory.dbo.ProductCatalog PC WITH(NOLOCK) ON PC.ID = T.SKU LEFT OUTER JOIN Inventory.dbo.Categories C WITH(NOLOCK) ON C.ID = PC.CategoryID
	
			/*
				Step 6: Filter the SKUs with quantity in stock ordered by the established sequence and take the first line according to the result
			*/
			SELECT TOP 1 @ShipSKU = T.SKU, @tQOH = GS.TotalStock 
			FROM #tmpSKU T
			LEFT OUTER JOIN Inventory.dbo.Global_Stocks GS WITH(NOLOCK)
			ON GS.ProductCatalogId = T.SKU
			WHERE ISNULL(GS.TotalStock,0) > 0
			ORDER BY Seq ASC
		
			--Uncomment the bottom line to see all the result of the 6 step, if you want to see the full result uncomment the second line
			--SELECT @ShipSKU AS ShipSKU, @tQOH AS tQOH
			--SELECT T.SKU,GS.TotalStock FROM #tmpSKU T LEFT OUTER JOIN Inventory.dbo.Global_Stocks GS WITH(NOLOCK) ON GS.ProductCatalogId = T.SKU ORDER BY Seq ASC	
		END
	END

	/*
		Setp 7: Finally, the ProductCatalog table is updated with the result obtained
		If the @ShipSKU is NULL (meaning there was no other option with inventory) we will simply update with the original SKU.
	*/
	UPDATE [Inventory].[dbo].[ProductCatalog] SET [TotalStock] = @tQOH, ShipSKUFBA = ISNULL(@ShipSKU,@pSKU) WHERE ID = @pSKU

	--Uncomment the bottom line to see the update of the 7 step
	--SELECT @pSKU AS SKU, ISNULL(@ShipSKU,@pSKU) AS ShipSKU, @tQOH AS TotalQty

END
go

