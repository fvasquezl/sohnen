-- =============================================
-- Author:		Luis Bautista
-- Create date: Jul-01-2014
-- Description:	Get the bin Stock
-- =============================================
CREATE FUNCTION [dbo].[fn_Bins_SKU_Stock]
(
	@pSKU int
)
RETURNS int	
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar INT	

	SELECT  @ResultVar = sum(a.Counter) 
	FROM Inventory.dbo.Bin_Content a 
	WHERE a.ProductCatalog_Id = @pSKU
	Group By a.ProductCatalog_Id 
	order by  a.ProductCatalog_Id;
	
	
	RETURN @ResultVar;

END
go

