-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 6-22-2016
-- Description:	Get Alternative Highest Stock
-- =============================================
CREATE FUNCTION [dbo].[fn_GetAlternativeStockHighest] 
(
	-- Add the parameters for the function here
	@pSKU int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	-- Add the T-SQL statements to compute the return value here
    DECLARE @CategoryID AS INT
	DECLARE @CheckAlwaysInStock AS INT
	DECLARE @tmpSKUALTS AS TABLE ([SKU] INT, [tQOH] INT)

--TEST
--SET @pSKU = '107125'

(SELECT @CategoryID = [CategoryID] FROM [Inventory].[dbo].[ProductCatalog] WHERE [ID] = @pSKU)
(SELECT @CheckAlwaysInStock = [AlwaysInStock] FROM [Inventory].[dbo].[ProductCatalog] WHERE [ID] = @pSKU)

--IF ALWAYS IN STOCK
IF @CheckAlwaysInStock = 1
BEGIN
	INSERT INTO @tmpSKUALTS ([SKU],[tQOH])
	SELECT @pSKU, '500' FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE GS.[ProductCatalogId] = @pSKU
	GOTO ENDALL
END
--IF ORIGINAL
IF @CategoryID IN ('10','11','12','13','20','21','22','23','62','64','14','24')

BEGIN
	
	INSERT INTO @tmpSKUALTS ([SKU],[tQOH])
	SELECT PJD.[EncSKU], GS.[TotalStock] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PJD.[EncSKU] = GS.[ProductCatalogId])
	WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
	OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
	OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
	OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
	OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
	OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))

	INSERT INTO @tmpSKUALTS ([SKU],[tQOH])
	SELECT PJD.[EncSKUPH], GS.[TotalStock] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PJD.[EncSKUPH] = GS.[ProductCatalogId])
	WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
	OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
	OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
	OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
	OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
	OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))
	
	INSERT INTO @tmpSKUALTS ([SKU],[tQOH])
	SELECT PJD.[EncSKUOS], GS.[TotalStock] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PJD.[EncSKUOS] = GS.[ProductCatalogId])
	WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
	OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
	OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
	OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
	OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
	OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))
	
	INSERT INTO @tmpSKUALTS ([SKU],[tQOH])
	SELECT PJD.[EncSKUPX], GS.[TotalStock] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PJD.[EncSKUPX] = GS.[ProductCatalogId])
	WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
	OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
	OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
	OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
	OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
	OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))
	
	INSERT INTO @tmpSKUALTS ([SKU],[tQOH])
	SELECT PJD.[EncSKUUSH], GS.[TotalStock] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PJD.[EncSKUUSH] = GS.[ProductCatalogId])
	WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
	OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
	OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
	OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
	OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
	OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))

	INSERT INTO @tmpSKUALTS ([SKU],[tQOH])
	SELECT PJD.[EncSKUOEM], GS.[TotalStock] FROM [MITDB].[dbo].[ProjectorData] AS PJD
	LEFT OUTER JOIN [Inventory].[dbo].[Global_Stocks] AS GS ON (PJD.[EncSKUOEM] = GS.[ProductCatalogId])
	WHERE (PJD.[EncSKU] = @pSKU AND (PJD.[EncSKU] != '-' OR PJD.[EncSKU] IS NOT NULL))
	OR (PJD.[EncSKUPH] = @pSKU AND (PJD.[EncSKUPH] != '-' OR PJD.[EncSKUPH] IS NOT NULL))
	OR (PJD.[EncSKUOS] = @pSKU AND (PJD.[EncSKUOS] != '-' OR PJD.[EncSKUOS] IS NOT NULL))
	OR (PJD.[EncSKUPX] = @pSKU AND (PJD.[EncSKUPX] != '-' OR PJD.[EncSKUPX] IS NOT NULL))
	OR (PJD.[EncSKUUSH] = @pSKU AND (PJD.[EncSKUUSH] != '-' OR PJD.[EncSKUUSH] IS NOT NULL))
	OR (PJD.[EncSKUOEM] = @pSKU AND (PJD.[EncSKUOEM] != '-' OR PJD.[EncSKUOEM] IS NOT NULL))

END

/**
--IF GENERIC
IF @CategoryID IN ('14','24')
BEGIN
	INSERT INTO @tmpSKUALTS ([SKU],[tQOH])
	SELECT @pSKU, GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE GS.[ProductCatalogId] = @pSKU
END

**/
IF @CategoryID NOT IN ('10','11','12','13','20','21','22','23','62','64','14','24') AND @CheckAlwaysInStock != 1 
BEGIN
	INSERT INTO @tmpSKUALTS ([SKU],[tQOH])
	SELECT @pSKU, GS.[TotalStock] FROM [Inventory].[dbo].[Global_Stocks] AS GS WHERE GS.[ProductCatalogId] = @pSKU
END

ENDALL:
SELECT TOP(1) @Result = [tQOH] FROM @tmpSKUALTS WHERE [SKU] != '-' AND [SKU] IS NOT NULL AND [SKU] != 0 ORDER BY [tQOH] DESC

	-- Return the result of the function
	RETURN IsNULL(@Result,0)

END
go

