
-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2017-02-23
-- Description:	Get Alternative Highest Stock and Price
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetAlternativePriceStockHighest]
	@pSKU INT
AS
BEGIN
	

		
		UPDATE PC SET 
			PC.[TotalStock] = CAST(GS.[TotalStock] AS INT),
			PC.[TMPFloorCeilingFBA] = NULL
		FROM [Inventory].[dbo].[ProductCatalog] AS PC WITH(NOLOCK)
		LEFT OUTER JOIN [Inventory].[dbo].[Global_stocks] AS GS ON (PC.[ID] = GS.[ProductCatalogID])
		WHERE PC.ID = @pSKU

END
go

