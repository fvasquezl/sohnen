-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 11-21-2018
-- Description:	Missing Images Autobot
-- =============================================
CREATE PROCEDURE [dbo].[sp_Autobot_MissingImages]
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		DECLARE @xml NVARCHAR(MAX)
		DECLARE @body NVARCHAR(MAX)
		DECLARE @date VARCHAR(12)
		DECLARE @subtext VARCHAR(50)
		DECLARE @subject VARCHAR(62)
		DECLARE @recipients VARCHAR(255)
		DECLARE @imagesadded int
		DECLARE @imagesaddedskus int

		SET @imagesadded = (SELECT COUNT([ID]) AS [Total] FROM [Remotes].[dbo].[Image] WHERE [ImageExistsStamp] IS NULL)
		SET @imagesaddedskus = (SELECT DISTINCT COUNT([SKU]) AS [Total] FROM [Remotes].[dbo].[Image] WHERE [ImageExistsStamp] IS NULL)


		---START NEW/USED
		SET @xml =CAST(( 
		Select Distinct SKUD.[SKU] AS 'td',''
			,SKUD.[Manufacturer] AS 'td',''
			,SKUD.[PartNumber] AS 'td',''
			,[Remotes].[dbo].[fn_GetQtyByScanCode](SKUD.[SKU],'NEW') AS 'td',''
			,[Remotes].[dbo].[fn_GetQtyByScanCode](SKUD.[SKU],'USED') AS 'td',''
			,CAT.[CategoryName] AS 'td',''
			,CAT.[ImagesRequired] AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-001.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-002.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-003.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-004.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-005.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-006.jpg'),0,'No'),1,'Yes') AS 'td',''
	
		FROM [Remotes].[dbo].[SKUData] AS SKUD
		LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT ON (SKUD.[CategoryID] = CAT.[CategoryID])
		WHERE 
		--Check if category is sellable
		CAT.[Sellable] = 1
		AND
		--Check if we have New or Used in stock
		 ([Remotes].[dbo].[fn_GetQtyByScanCode](SKUD.[SKU],'NEW') + [Remotes].[dbo].[fn_GetQtyByScanCode](SKUD.[SKU],'USED')) > 0 
		AND
		--Check images 1-6 for new/used
		CAT.[ImagesRequired] > 
		(
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-001.jpg') AS INT) + 
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-002.jpg') AS INT) +
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-003.jpg') AS INT) +
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-004.jpg') AS INT) +
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-005.jpg') AS INT) +
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-006.jpg') AS INT) 
		) 
		

		ORDER BY CAT.[CategoryName] ASC, SKUD.[SKU] ASC FOR XML PATH('tr'), ELEMENTS 
		) AS NVARCHAR(MAX))

		/** FIX HTML **/
		 SET @xml = replace(@xml, '&amp;', '&')
		 SET @xml = replace(@xml, '&lt;' , '<')
		 SET @xml = replace(@xml, '&gt;' , '>')
		 /** FIX HTML END**/


		SET @subtext = 'ImagesMissing Report Original - '
		SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
		SET @subject = @subtext + @date
		SET @recipients = 'images@boughts.com'
		SET @body ='<html><center><H1>Images Missing Report Original - <br>' + @date + '</H1><br><br>
		We added '+CAST(@imagesadded AS NVARCHAR(MAX))+' images for '+CAST(@imagesaddedskus AS NVARCHAR(MAX))+' different SKUs today!
		<br>
		<br>
		<body bgcolor=yellow><table border = 2><tr>
		<th>SKU</th>
		<th>Manufacturer</th>
		<th>PartNumber</th>
		<th>QtyNew</th>
		<th>QtyUsed</th>
		<th>Category</th>
		<th>ImagesRequired</th>
		<th>Image1</th>
		<th>Image2</th>
		<th>Image3</th>
		<th>Image4</th>
		<th>Image5</th>
		<th>Image6</th>
		</tr>' 
		SET @body = @body + @xml +'</center></table><br><br>Thanks,<br>Autobot by Boughts</body></html>'

		If @body is not null BEGIN

		EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',
		@recipients = @recipients,
		@subject = @subject,
		@body = @body,
		@body_format ='HTML'

		END



		---START CN
		SET @xml =CAST(( 
		Select Distinct SKUD.[SKU] AS 'td',''
			,SKUD.[Manufacturer] AS 'td',''
			,SKUD.[PartNumber] AS 'td',''
			,[Remotes].[dbo].[fn_GetQtyByScanCode](SKUD.[SKU],'CN') AS 'td',''
			,CAT.[CategoryName] AS 'td',''
			,CAT.[ImagesRequired] AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-007.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-008.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-009.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-010.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-011.jpg'),0,'No'),1,'Yes') AS 'td',''
			,Replace(Replace([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-012.jpg'),0,'No'),1,'Yes') AS 'td',''
	
		FROM [Remotes].[dbo].[SKUData] AS SKUD
		LEFT OUTER JOIN [Remotes].[dbo].[Categories] AS CAT ON (SKUD.[CategoryID] = CAT.[CategoryID])
		WHERE 
		--Check if category is sellable
		CAT.[Sellable] = 1
		AND
		--Check if we have CN in stock
		 [Remotes].[dbo].[fn_GetQtyByScanCode](SKUD.[SKU],'CN') > 0 
		AND
		--Check images 1-6 for new/used
		CAT.[ImagesRequired] > 
		(
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-007.jpg') AS INT) + 
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-008.jpg') AS INT) +
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-009.jpg') AS INT) +
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-010.jpg') AS INT) +
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-011.jpg') AS INT) +
		CAST([Remotes].[dbo].[fn_CheckIfFileExists]('\\192.168.0.232\public\http\remotes\'+[SKU]+'\'+[SKU]+'-012.jpg') AS INT) 
		) 

		ORDER BY CAT.[CategoryName] ASC, SKUD.[SKU] ASC FOR XML PATH('tr'), ELEMENTS 
		) AS NVARCHAR(MAX))

		/** FIX HTML **/
		 SET @xml = replace(@xml, '&amp;', '&')
		 SET @xml = replace(@xml, '&lt;' , '<')
		 SET @xml = replace(@xml, '&gt;' , '>')
		 /** FIX HTML END**/


		SET @subtext = 'ImagesMissing Report CN - '
		SET @date = CONVERT(VARCHAR(12),GETDATE(),107)
		SET @subject = @subtext + @date
		SET @recipients = 'images@boughts.com'
		SET @body ='<html><center><H1>Images Missing Report CN - <br>' + @date + '</H1><br><br>
		We added '+CAST(@imagesadded AS NVARCHAR(MAX))+' images for '+CAST(@imagesaddedskus AS NVARCHAR(MAX))+' different SKUs today!
		<br>
		<br>
		<body bgcolor=yellow><table border = 2><tr>
		<th>SKU</th>
		<th>Manufacturer</th>
		<th>PartNumber</th>
		<th>QtyCN</th>
		<th>Category</th>
		<th>ImagesRequired</th>
		<th>Image7</th>
		<th>Image8</th>
		<th>Image9</th>
		<th>Image10</th>
		<th>Image11</th>
		<th>Image12</th>
		</tr>' 
		SET @body = @body + @xml +'</center></table><br><br>Thanks,<br>Autobot by Boughts</body></html>'

		If @body is not null BEGIN

		EXEC msdb.dbo.sp_send_dbmail @profile_name='Outgoing',
		@recipients = @recipients,
		@subject = @subject,
		@body = @body,
		@body_format ='HTML'

		END


END
go

