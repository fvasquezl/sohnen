-- =============================================
-- Author:		Luis Bautista
-- Create date: 2014-09-08
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_Get_Compatibility_SKU
(
	@pManufaturer varchar(50), @pPartNumber varchar(50)
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar int;

	SELECT @ResultVar = [ProductCatalogID] FROM [Inventory].[dbo].[Compatibility]  
			WHERE     (Manufacturer = @pManufaturer)
				AND  (PartNumber = @pPartNumber );

	IF @ResultVar is null
	BEGIN
		SET @ResultVar = 0;
	END

	-- Return the result of the function
	RETURN @ResultVar;

END
go

