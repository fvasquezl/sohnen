-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2015-06-03
-- Description:	Get Next Serial
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetMIT_NextLampSerial1]
	@NUMBER	INT,
	@BRAND	NVARCHAR(50)
AS
DECLARE
	@MITSerial	NVARCHAR(10),
	@SEQNUM		INT = 0
BEGIN
	SET NOCOUNT ON;
	SET @BRAND = (CASE WHEN ISNULL(@BRAND,'') <> '' THEN @BRAND ELSE 'M' END)

    -- Insert statements for procedure here
	SELECT @MITSerial = SUBSTRING(MITSerial_start,1,LEN(@BRAND)+3), @SEQNUM = seq_num + 1
	FROM Inventory.dbo.LampProductionSerial
	WHERE ID = (
		SELECT MAX(ID)
		FROM Inventory.dbo.LampProductionSerial
		WHERE MITSerial_start LIKE @BRAND + Inventory.dbo.fn_Year_Month_Day_Serial(DATEPART(YYYY,GETDATE()),DATEPART(MM,GETDATE()),DATEPART(DD,GETDATE())) + '%'
		AND status = 'P'
	)
	SET @MITSerial = (CASE WHEN ISNULL(@MITSerial,'') <> '' THEN @MITSerial 
						ELSE @BRAND + Inventory.dbo.fn_Year_Month_Day_Serial(DATEPART(YYYY,GETDATE()),DATEPART(MM,GETDATE()),DATEPART(DD,GETDATE()))
					END)

	--PRINT(ISNULL(@SEQNUM,0))

	SET @SEQNUM = (CASE WHEN ISNULL(@SEQNUM,0) <> 0 THEN @SEQNUM ELSE 1 END)

	--PRINT(@SEQNUM)

	SELECT @MITSerial + RIGHT('0000' + CONVERT(NVARCHAR,@SEQNUM),4), @MITSerial + RIGHT('0000' + CONVERT(NVARCHAR,(@SEQNUM + @NUMBER - 1)),4)
END
go

