

-- ============================================================================
-- Author:		Santos Escobar
-- Create date: 01/04/2015
-- Description:	Gets description and detail of a particuar order.
-- ============================================================================
CREATE PROCEDURE [dbo].[sp_GetOrderDetail] 
(
	@OrderNumber INT
)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT 
		A.Name
		, A.Company
		, A.Address
		, A.Country, (A.City + (CASE WHEN LTRIM(RTRIM(ISNULL(A.State,''))) <> '' THEN ' ' + A.State ELSE '' END) + (CASE WHEN LTRIM(RTRIM(ISNULL(A.Zip,''))) <> '' THEN ' ' + A.Zip ELSE '' END)) AS City
		, ISNULL(A.ShipName, '') [ShipName]
		, ISNULL(A.ShipCompany, '') [ShipCompany]
		, ISNULL(A.ShipAddress, '') [ShipAddress]
		, ISNULL(A.ShipCountry, '') [ShipCountry]
		, (A.ShipCity + (CASE WHEN LTRIM(RTRIM(ISNULL(A.ShipState,''))) <> '' THEN ' ' + A.ShipState ELSE '' END) + (CASE WHEN LTRIM(RTRIM(ISNULL(A.ShipZip,''))) <> '' THEN ' ' + A.ShipZip ELSE '' END)) AS ShipCity
		, CONVERT(NVARCHAR,A.OrderDate,106) AS OrderDate
		, CONVERT(NVARCHAR, A.OrderNumber) AS OrderNumber
		, A.Shipping
		, B.SKU, B.QuantityOrdered, B.Product, ISNULL(Inventory.dbo.fn_getBinLocation(B.SKU), '') Location, ISNULL(B.WebSKU, '')
	FROM OrderManager.dbo.Orders A 
		INNER JOIN OrderManager.dbo.[Order Details] B
	ON B.OrderNumber = A.OrderNumber
	WHERE 
		B.Adjustment = 0 AND A.OrderNumber = @OrderNumber
	ORDER BY A.NumItems
END

go

