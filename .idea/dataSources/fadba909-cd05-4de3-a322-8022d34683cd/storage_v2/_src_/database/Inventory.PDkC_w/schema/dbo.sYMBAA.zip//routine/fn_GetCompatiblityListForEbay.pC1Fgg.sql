-- =============================================
-- Author:		<Amir Tafreshi>
-- Create date: <1-21-2015>
-- Description:	<Based on Keoki's Cursor to get Compatibility from Manufacturer & PartNumber>
-- =============================================
CREATE FUNCTION [dbo].[fn_GetCompatiblityListForEbay] 
(
	
	@pManufaturer varchar(50), @pPartNumber varchar(50), @pQueryType as varchar(50)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @fCompatiblity NVARCHAR(MAX)


IF @pQueryType = 'PartNumberSpecific' GOTO ByPartNumber;
IF @pQueryType = 'ModelSpecific' GOTO ByModelNumber;
GOTO ENDALL

ByPartNumber:
BEGIN
	-- Add the T-SQL statements to compute the return value here
	---- Part Number Break down
						Declare @AltPN varchar(max), @AltPNx varchar(max), @AltMN varchar(max), @AltMNx varchar(max), @Model varchar(max), @ModelX varchar(max)

						DECLARE db_ALtPN CURSOR FOR  
						
								Select AlternativePN 
									From Inventory.dbo.CompatibilityAlternativePN 
									where PartNumber = @pPartNumber
									and OriginalManufacturer = @pManufaturer
									Group By AlternativePN
						/*	End*/
						
						Set @AltPNx = 'Part Numbers: '+ @pPartNumber +', ' 

						OPEN db_ALtPN   
						FETCH NEXT FROM db_ALtPN INTO @AltPN   

						WHILE @@FETCH_STATUS = 0   
						BEGIN   
							   If @AltPNx = 'Part Numbers: '+ @pPartNumber +', ' 
								   Begin
									   Set @AltPNx = @AltPNx + @AltPN
								   End 
							   Else
								   Begin
									   Set @AltPNx = @AltPNx + ', ' + @AltPN
								   End
								   
							   FETCH NEXT FROM db_ALtPN INTO @AltPN   
						END   
						CLOSE db_ALtPN   
						DEALLOCATE db_ALtPN
						
--- Alternate Model Numbers
						Set @ModelX = '-/-'
						DECLARE db_ALtMN CURSOR FOR  

--						Select Model, AlternativeModel 
--						from inventory.dbo.compatibilitydetails CD, Inventory.dbo.CompatibilityAlternativeMOdels CM
--						where CD.Model = CM.OriginalModel and CD.PartNumber = @pPartNumber and CD.OriginalManufacturer = @pManufaturer
--						Group By PartNumber, Model, AlternativeModel 

						Select CD.Model, IsNull(CM.AlternativeModel,CD.Model)
						From inventory.dbo.compatibilitydetails AS CD
						LEFT OUTER JOIN Inventory.dbo.CompatibilityAlternativeModels AS CM ON (CD.[OriginalManufacturer] = CM.[OriginalManufacturer] AND CD.[Model] = CM.[OriginalModel])
						where CD.PartNumber = @pPartNumber and CD.[OriginalManufacturer] = @pManufaturer
						Group By CD.PartNumber, CD.OriginalManufacturer, CD.Model, CM.OriginalModel, CM.AlternativeModel 

						Set @AltMNx = 'Model Numbers: '

						OPEN db_ALtMN   
						FETCH NEXT FROM db_ALtMN INTO @Model, @AltMN   


						WHILE @@FETCH_STATUS = 0   
						BEGIN   

						
							   If @AltMNx = 'Model Numbers: '
								   Begin
	       							   If @Model <> @ModelX
										  Begin
											   Set @AltMNx = @AltMNx + @Model +', '+ @AltMN
--												Set @AltMNx = @AltMNx + ', '+ @AltMN
										  End
									   Else
										  Begin
											Set @AltMNx = @AltMNx + @AltMN
										  End
								   End 
							   Else
								   Begin
	       							   If @Model <> @ModelX
										  Begin
											   Set @AltMNx = @AltMNx +', '+ @Model +', '+ @AltMN
--												Set @AltMNx = @AltMNx +', ' + @AltMN
										  End
									   Else
										  Begin
											   Set @AltMNx = @AltMNx + ', ' + @AltMN
										  End
								   End
						       
							   Set @ModelX = @Model
						       
							   FETCH NEXT FROM db_ALtMN INTO @model, @AltMN   
						END   

--Are there alternative Part or Model Numbers or not? 

						If @AltPNx = 'Part Numbers: '
							Begin
								Set @AltPNx = ''
							End
						If @AltMNx = 'Model Numbers: '
						    Begin
								Set @AltMNx = ''
							End
							
--Remove <br><br> if at begining or end  @Compatibility like ' <br><br> %' or @Compatibility like '% <br><br> '
						If @AltMNx = '' or @AltMNx is null 
						    Begin
							If @AltPNx = '' or @AltPNx is null 
								Begin
								-- No Alternative Partnumbers or Model Numbers.
									Set @fCompatiblity = ''
								End 
						    Else
								Begin
								--No Alternate Model Numbers
									Set @fCompatiblity = @AltPNx
								End						
							End
						Else 
						    Begin
							If @AltPNx = '' or @AltPNx is null 
								Begin
								--No Alternate Part numbers
									Set @fCompatiblity = @AltMNx
								End 
							Else
								Begin
								--Both part and model numbers exist
									Set @fCompatiblity = @AltPNx + ' <br><br> ' + @AltMNx
								End
							End
						    

						CLOSE db_ALtMN   
						DEALLOCATE db_ALtMN

END
GOTO ENDALL
------------------------------------------------------------------------------------------------------

ByModelNumber:

BEGIN
--- Model Numbers
						Set @ModelX = '-/-'
						DECLARE db_ALtMN CURSOR FOR  

--						Select Model, AlternativeModel 
--						from inventory.dbo.compatibilitydetails CD, Inventory.dbo.CompatibilityAlternativeMOdels CM
--						where CD.Model = CM.OriginalModel and CD.PartNumber = @pPartNumber and CD.OriginalManufacturer = @pManufaturer
--						Group By PartNumber, Model, AlternativeModel 

						Select CD.Model, IsNull(CM.AlternativeModel,CD.Model)
						From inventory.dbo.compatibilitydetails AS CD
						LEFT OUTER JOIN Inventory.dbo.CompatibilityAlternativeModels AS CM ON (CD.[OriginalManufacturer] = CM.[OriginalManufacturer] AND CD.[Model] = CM.[OriginalModel])
						where CD.PartNumber = @pPartNumber and CD.[OriginalManufacturer] = @pManufaturer
						Group By CD.PartNumber, CD.OriginalManufacturer, CD.Model, CM.OriginalModel, CM.AlternativeModel 

						Set @AltMNx = 'Model Numbers: '

						OPEN db_ALtMN   
						FETCH NEXT FROM db_ALtMN INTO @Model, @AltMN   

						WHILE @@FETCH_STATUS = 0   
						BEGIN   


							   If @AltMNx = 'Model Numbers: ' 
								   Begin
	       							   If @Model <> @ModelX
										  Begin
--											   Set @AltMNx = @AltMNx + @Model +', '+ @AltMN
												Set @AltMNx = @AltMNx + ', '+ @AltMN
										  End
									   Else
										  Begin
											Set @AltMNx = @AltMNx + @AltMN
										  End
								   End 
							   Else
								   Begin
	       							   If @Model <> @ModelX
										  Begin
--											   Set @AltMNx = @AltMNx +', '+ @Model +', '+ @AltMN
												Set @AltMNx = @AltMNx +', '+ @AltMN
										  End
									   Else
										  Begin
											   Set @AltMNx = @AltMNx + ', ' + @AltMN
										  End
								   End
						       
							   Set @ModelX = @Model
						       
							   FETCH NEXT FROM db_ALtMN INTO @model, @AltMN   
						END   

--Are there alternative Part or Model Numbers or not? 

						If @AltMNx = 'Model Numbers: '
						    Begin
								Set @AltMNx = ''
							End
							
--Remove <br><br> if at begining or end  @Compatibility like ' <br><br> %' or @Compatibility like '% <br><br> '
						If @AltMNx = '' or @AltMNx is null 
						    Begin
							
								--No Alternate Part numbers
									Set @fCompatiblity = @AltMNx
								End 
							Else
								Begin
								--Both part and model numbers exist
									Set @fCompatiblity = @AltMNx
						End
							
						    

						CLOSE db_ALtMN   
						DEALLOCATE db_ALtMN
END
GOTO ENDALL

ENDALL:
	-- Return the result of the function
	--Remove extra comma's from the compatibility list
	BEGIN
	IF RIGHT(@fCompatiblity ,2) = ', ' SET @fCompatiblity = LEFT(@fCompatiblity, LEN(@fCompatiblity) - 1) ELSE SET @fCompatiblity = REPLACE(REPLACE(@fCompatiblity,', <br>',' <br>'),',  <br>',' <br>')
	END

	--Clean up
	SET @fCompatiblity = REPLACE(@fCompatiblity,'Model Numbers: ,','Model Numbers: ')

	RETURN @fCompatiblity
	
END
go

