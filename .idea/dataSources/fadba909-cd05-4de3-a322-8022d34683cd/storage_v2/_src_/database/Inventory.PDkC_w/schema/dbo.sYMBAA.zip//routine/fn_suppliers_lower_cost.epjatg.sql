-- =============================================
-- Author:		Luis Bautista
-- Create date: 05-05-2014
-- Description:	Return the lower unit cost for a given SKU
-- =============================================
CREATE FUNCTION [dbo].[fn_suppliers_lower_cost]
(
	@pSKU int	
)
RETURNS decimal (12,2)
AS
BEGIN
	
	DECLARE @ResultVar decimal (12,2);

	
	SET @ResultVar = (SELECT min(a.UnitCost) FROM Suppliers a
				 WHERE a.ProductCatalogId = @pSKU);

	
	RETURN @ResultVar

END
go

