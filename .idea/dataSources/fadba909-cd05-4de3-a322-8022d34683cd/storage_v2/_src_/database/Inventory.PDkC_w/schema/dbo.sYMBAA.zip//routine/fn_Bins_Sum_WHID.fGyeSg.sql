-- =============================================
-- Author:		Luis Bautista
-- Create date: JUL 08 2014
-- Description:	Sum SKU by warehouse id
-- =============================================
CREATE FUNCTION [dbo].[fn_Bins_Sum_WHID]
(
	@pSKU int, @pWHID varchar(2)
)
RETURNS integer
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar int;
	DECLARE @serachfilter as varchar(20)

	SET @serachfilter = '%' + @pWHID + '%';
	
	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = SUM(a.Counter) 
				FROM Bin_Content  a
				WHERE (a.ProductCatalog_Id = @pSKU)
						AND (Inventory.dbo.fn_Get_Bin_WarehouseID(a.Bin_Id) like @serachfilter );

	IF @ResultVar is null
	BEGIN
		SET @ResultVar = 0;
	END
	-- Return the result of the function
	RETURN @ResultVar;

END
go

