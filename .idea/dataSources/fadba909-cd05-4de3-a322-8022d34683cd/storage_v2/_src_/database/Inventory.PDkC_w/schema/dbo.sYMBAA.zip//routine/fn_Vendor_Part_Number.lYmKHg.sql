-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Vendor_Part_Number]
(
	-- Add the parameters for the function here
	@sku  as integer
)
RETURNS varchar(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar as varchar(100)
	DECLARE @tempsku as varchar(100)
	SET @tempsku = CAST(@sku as varchar(100))
	
	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = SupplierSKU FROM OrderManager.dbo.InventorySuppliers
			WHERE (LocalSKU = @tempsku) AND (PrimarySupplier = 1)

	if @resultvar is null  --there is not a primary supplier
	begin
			SELECT @ResultVar = SupplierSKU FROM OrderManager.dbo.InventorySuppliers
			WHERE (LocalSKU = @tempsku) 
	end
	
	if @resultvar is null --- there is not any provider
	begin
		SET @ResultVar = 'Undefined'
	end

	-- Return the result of the function
	RETURN @ResultVar

END
go

