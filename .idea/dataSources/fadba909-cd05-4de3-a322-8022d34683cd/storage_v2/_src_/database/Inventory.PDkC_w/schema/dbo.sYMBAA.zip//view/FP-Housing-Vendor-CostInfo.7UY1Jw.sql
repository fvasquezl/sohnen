CREATE VIEW dbo.[FP-Housing-Vendor-CostInfo]
AS
SELECT        dbo.ProductCatalog.ID AS MITSKU, CAST(dbo.Global_Stocks.TotalStock AS INT) AS QOH, Suppliers_2.SupplierSKU AS MoldGateSKU, 
                         Suppliers_2.UnitCost AS MoldGateCost, Suppliers_1.SupplierSKU AS GrandBulbSKU, Suppliers_1.UnitCost AS GrandBulbCost, dbo.Suppliers.SupplierSKU AS MISKU,
                          dbo.Suppliers.UnitCost AS MICost, Suppliers_3.SupplierSKU AS SouthernTechSKU, Suppliers_3.UnitCost AS SouthernTechCost, 
                         Suppliers_4.SupplierSKU AS KWSKU, Suppliers_4.UnitCost AS KWCost, Suppliers_5.SupplierSKU AS LeaderSKU, Suppliers_5.UnitCost AS LeaderCost, 
                         Suppliers_6.SupplierSKU AS YitaSKU, Suppliers_6.UnitCost AS YitaCost, Suppliers_7.SupplierSKU AS FYVSKU, Suppliers_7.UnitCost AS FYVCost, 
                         Suppliers_8.SupplierSKU AS LampsChoiceSKU, Suppliers_8.UnitCost AS LampsChoiceCost, Suppliers_9.SupplierSKU AS OnlyLampSKU, 
                         Suppliers_9.UnitCost AS OnlyLampCost
FROM            dbo.ProductCatalog LEFT OUTER JOIN
                         dbo.Global_Stocks ON dbo.ProductCatalog.ID = dbo.Global_Stocks.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_3 ON dbo.ProductCatalog.ID = Suppliers_3.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_4 ON dbo.ProductCatalog.ID = Suppliers_4.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers ON dbo.ProductCatalog.ID = dbo.Suppliers.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_1 ON dbo.ProductCatalog.ID = Suppliers_1.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_2 ON dbo.ProductCatalog.ID = Suppliers_2.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_5 ON dbo.ProductCatalog.ID = Suppliers_5.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_6 ON dbo.ProductCatalog.ID = Suppliers_6.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_7 ON dbo.ProductCatalog.ID = Suppliers_7.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_8 ON dbo.ProductCatalog.ID = Suppliers_8.ProductCatalogId LEFT OUTER JOIN
                         dbo.Suppliers AS Suppliers_9 ON dbo.ProductCatalog.ID = Suppliers_9.ProductCatalogId
WHERE        (dbo.ProductCatalog.CategoryID = '60') AND (Suppliers_2.SupplierID = '12') AND (Suppliers_1.SupplierID = '11') AND (dbo.Suppliers.SupplierID = '14') AND 
                         (Suppliers_3.SupplierID = '13') AND (Suppliers_4.SupplierID = '15') AND (Suppliers_5.SupplierID = '16') AND (Suppliers_6.SupplierID = '17') AND 
                         (Suppliers_7.SupplierID = '18') AND (Suppliers_8.SupplierID = '20') AND (Suppliers_9.SupplierID = '21')
go

