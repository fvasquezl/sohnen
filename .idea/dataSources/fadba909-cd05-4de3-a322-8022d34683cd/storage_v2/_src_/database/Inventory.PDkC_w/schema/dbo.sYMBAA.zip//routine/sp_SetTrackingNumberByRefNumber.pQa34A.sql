
-- =============================================
-- Author:		Santos Escobar
-- Create date: 2016-01-22
-- Description:	Update tracking number to recently updaloaded orders
-- =============================================
CREATE PROCEDURE [dbo].[sp_SetTrackingNumberByRefNumber]
	@RefNumber			NVARCHAR(25),
	@TrackingNumber		NVARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE [Inventory].dbo.HistoryReferenceTracking SET TrackingNumber = @TrackingNumber WHERE ReferenceNumber = @RefNumber
END

go

