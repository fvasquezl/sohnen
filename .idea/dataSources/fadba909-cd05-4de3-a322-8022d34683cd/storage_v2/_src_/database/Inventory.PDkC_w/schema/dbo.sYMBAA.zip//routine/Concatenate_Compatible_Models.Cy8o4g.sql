
--This procedure is created to concatenate the different models that a product can be used for
-- to be posted is the title or description of a listing on ebay or othersites. 
-- This Prodedure uses a cursor to select all of the compatible
-- models and insert them into a single varchar.
----------------------------------------
--Updates:
--1. created by Keoki Rosa 03/27/2012
--2.
----------------------------------------
CREATE FUNCTION [dbo].[Concatenate_Compatible_Models] (@PartNumber as Varchar(25))
RETURNS nvarChar(max)

AS
BEGIN

Declare Cont_Cursor Cursor
	For
		Select a.Manufacturer, b.Model
			from Inventory.dbo.Compatibility A
			Inner Join Inventory.dbo.CompatibilityDetails B
			On A.PartNumber = B.PartNumber
			where B.PartNumber = @PartNumber
			Group by a.Manufacturer, b.Model
			Order by A.Manufacturer,  b.model
			
Open Cont_Cursor

Declare @ReturnValue as Varchar(500), @Manufacturer as Varchar(25), @model as Varchar(40), @cnt as Int
		
Fetch Next from Cont_Cursor into @Manufacturer, @model

Set @cnt = 1

While (@@FETCH_STATUS<> -1)
Begin
	If (@@FETCH_STATUS<> -2)
		If @cnt = 1
			Begin
				Set @ReturnValue = @Model
			End
		Else
			Begin
				Set @ReturnValue = @ReturnValue + ' , ' + @model 
			End
			
		Set @cnt = 2		
						
	Fetch Next from Cont_Cursor into @Manufacturer, @Model
END

CLOSE Cont_Cursor
DEALLOCATE Cont_Cursor

RETURN @ReturnValue

End
go

