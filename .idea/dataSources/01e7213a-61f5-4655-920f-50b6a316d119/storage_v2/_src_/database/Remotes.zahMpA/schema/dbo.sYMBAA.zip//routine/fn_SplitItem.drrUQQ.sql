CREATE FUNCTION SplitItem( @ItemIDs VARCHAR(MAX))
RETURNS @ItemTable TABLE ( Item VARCHAR(200) )
AS 
BEGIN
    DECLARE @Item VARCHAR(200)
    DECLARE @Index INT

    WHILE LEN(@ItemIDs) <> 0 
        BEGIN
            SET @Index = PATINDEX('%,%', @ItemIDs)
            IF @Index > 0 
                BEGIN
                    SET @Item = SUBSTRING(@ItemIDs, 1, @Index - 1) 
                    SET @ItemIDs = RIGHT(@ItemIDs, LEN(@ItemIDs) - @Index)
                    INSERT  INTO @ItemTable
                    VALUES  ( @Item )
                END
            ELSE 
                BEGIN
                    BREAK
                END
        END
    SET @Item = @ItemIDs 
    INSERT  INTO @ItemTable
    VALUES  ( @Item )

    RETURN
END
go

