-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 8-26-2018
-- Description:	Update/Add to Amazon_TransactionsDateRangeReports Table
-- =============================================
CREATE PROCEDURE sp_AmazonUpdate_Amazon_TransactionsDateRangeReports 
	-- Add the parameters for the stored procedure here
	@p1 int = 0, 
	@p2 int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    --PREP INSTRUCTIONS
	--Download Transaction Report - DateRangeReports
	--Open in Excel - Delete top 7 rows and save as EXCEL Workbook (.xlsx) 
	--Right Click on Database -> Tasks -> Import Data 
	--Choose Microsoft Excel
	--****This needs to be installed on local machine: https://www.microsoft.com/en-us/download/confirmation.aspx?id=23734
	--Next until Finish
	--Update the NEWTR tablename in this stored procedure

	--This query will insert items that do not already exist in the table.. meaning it will only inject new records

	INSERT INTO [Remotes].[dbo].[Amazon_TransactionsDateRangeReports]
	SELECT NEWTR.[date/time]
      ,NEWTR.[settlement id]
      ,NEWTR.[type]
      ,NEWTR.[order id]
      ,NEWTR.[sku]
      ,NEWTR.[description]
      ,NEWTR.[quantity]
      ,NEWTR.[marketplace]
      ,NEWTR.[fulfillment]
      ,NEWTR.[order city]
      ,NEWTR.[order state]
      ,NEWTR.[order postal]
      ,NEWTR.[product sales]
      ,NEWTR.[shipping credits]
      ,NEWTR.[gift wrap credits]
      ,NEWTR.[promotional rebates]
      ,NEWTR.[sales tax collected]
      ,NEWTR.[Marketplace Facilitator Tax]
      ,NEWTR.[selling fees]
      ,NEWTR.[fba fees]
      ,NEWTR.[other transaction fees]
      ,NEWTR.[other]
      ,NEWTR.[total]
	FROM [Remotes].[dbo].[2018Jan1-2018Jun8CustomTransact] AS NEWTR
	LEFT OUTER JOIN [Remotes].[dbo].[Amazon_TransactionsDateRangeReports] AS ALLTR ON 
	(NEWTR.[settlement id] = ALLTR.[settlement id] 
	AND NEWTR.[date/time] = ALLTR.[date/time]
	AND NEWTR.[total] = ALLTR.[Total])
	WHERE
	ALLTR.[settlement id] IS NULL
	AND ALLTR.[date/time] IS NULL
	AND ALLTR.[total] IS NULL



END
go

