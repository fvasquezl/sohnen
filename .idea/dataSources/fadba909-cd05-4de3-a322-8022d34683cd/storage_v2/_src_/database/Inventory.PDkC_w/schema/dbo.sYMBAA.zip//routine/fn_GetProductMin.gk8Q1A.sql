-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_GetProductMin
(
	-- Add the parameters for the function here
	@ProductCatalogID int
)
RETURNS numeric(12,2)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Qty numeric (12,2)

	-- Add the T-SQL statements to compute the return value here
	select @Qty =  a.InventoryMin from Inventory.dbo.ProductCatalog a
	where a.ID = @ProductCatalogID

	-- Return the result of the function
	RETURN (@qty)

END
go

