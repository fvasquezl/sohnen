-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_GetAccountName 
(
	-- Add the parameters for the function here
	@AccountID int
)
RETURNS varchar(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @AccountName as varchar(100)

	-- Add the T-SQL statements to compute the return value here
	select @AccountName =  a.name from Inventory.dbo.Accounts a
	where a.ID = @AccountId

return (@AccountName)

END
go

