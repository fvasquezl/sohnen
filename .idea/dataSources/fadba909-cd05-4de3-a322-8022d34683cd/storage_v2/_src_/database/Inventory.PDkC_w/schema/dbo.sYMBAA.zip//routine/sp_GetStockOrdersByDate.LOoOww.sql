
-- =============================================
-- Author:		Eduardo Gutierrez
-- Create date: 2016-05-17
-- Description:	Get Stock Qty and Order Qty by Date
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetStockOrdersByDate]
	@SKU		INT,
	@DATE1		NVARCHAR(8),
	@DATE2		NVARCHAR(8),
	@CATEGORY	NVARCHAR(50)
AS
BEGIN
	DECLARE @SQL NVARCHAR(4000),
			@CURSOR_DAYS	CURSOR,
			@INITIAL_DATE	DATE,
			@FINAL_DATE		DATE,
			@NEW_DATE		DATE,
			@DATES			DATE,
			@LAST_QTY		INT,
			@VLAST_QTY		INT,
			@NEW_QTY		INT,
			@VS_QTY			INT
	SET NOCOUNT ON;
	SET ANSI_WARNINGS OFF;
	SET ANSI_WARNINGS ON;

	--SET @NEW_DATE = CONVERT(DATETIME,@INITIAL_DATE) 
	SET @NEW_DATE = DATEADD(MONTH,-6,CONVERT(DATETIME,@DATE1))
	--SET @DATE1 = CONVERT(DATETIME,@INITIAL_DATE)
	SET @INITIAL_DATE = DATEADD(MONTH,-6,CONVERT(DATETIME,@DATE1))
	SET @FINAL_DATE = CONVERT(DATETIME,@DATE2)


    CREATE TABLE #tmpTopSellOrder ( SKU INT, SubSKU1 INT, SubSKU2 INT, SubSKU3 INT, QuantityOrdered INT, Name NVARCHAR(500), CategoryID INT, Seq INT )

	INSERT INTO #tmpTopSellOrder (SKU, QuantityOrdered, Name, CategoryID, Seq)
	SELECT OD.SKU, SUM(OD.QuantityOrdered), PC.Name, PC.CategoryID, 0
	FROM OrderManager.dbo.[Order Details] OD (NOLOCK)
	LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
	ON CONVERT(NVARCHAR,PC.ID) = OD.SKU
	INNER JOIN OrderManager.dbo.Orders O (NOLOCK)
	ON O.OrderNumber = OD.OrderNumber AND O.Cancelled = 0
	WHERE CONVERT(NVARCHAR,OD.DetailDate,112) BETWEEN @DATE1 AND @DATE2 AND
	--OD.OrderNumber IN (
	--	SELECT OrderNumber 
	--	FROM OrderManager.dbo.Orders (NOLOCK) WHERE CONVERT(NVARCHAR,OrderDate,112) BETWEEN @DATE1 AND @DATE2 --AND OrderStatus IN ('Shipped','Order Approved','Order Received','Payment Received','Pending Shipment')
	--) AND 
	OD.Adjustment = 0 AND PC.CategoryID IN (5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,10,11,12,13,62,20,21,22,23,64,14,24,59,60,69,70, 36 ,101,105,109,123,128,133,138,143,30, 158) --/*-*/--
	GROUP BY OD.SKU, PC.Name, PC.CategoryID
	ORDER BY SUM(OD.QuantityOrdered) DESC

	SET @SQL = ' INSERT INTO #tmpTopSellOrder (SKU, SubSKU1, QuantityOrdered, Name, CategoryID, Seq)
					SELECT TTS.SKU, AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 1
					FROM #tmpTopSellOrder TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
					ON AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '

	SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
							WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
							WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
							WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
							WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
							WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
							WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
							WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
							WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
							WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
							WHEN ISNULL(@CATEGORY,'') = 'TV Parts' THEN '30'
							WHEN ISNULL(@CATEGORY,'') = 'Mexican Handcrafted' THEN '158'
							ELSE '0' END)

	SET @SQL = @SQL + ' ) GROUP BY TTS.SKU, AD.SubSKU, PC.Name, PC.CategoryID '

	EXEC(@SQL)
	
	--START V2
	SET @SQL = ' INSERT INTO #tmpTopSellOrder (SKU, SubSKU1, SubSKU2, QuantityOrdered, Name, CategoryID, Seq)
					SELECT TTS.SKU, TTS.SubSKU1, AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 2
					FROM #tmpTopSellOrder TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
					ON AD.ProductCatalogID = TTS.SubSKU1
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
					ON PC.ID = AD.SubSKU WHERE TTS.Seq = 1 AND PC.CategoryID IN ( '

	SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - TV' THEN '5,6,7,8,61'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - FP' THEN '15,16,17,18,63'
								WHEN ISNULL(@CATEGORY,'') = 'Original Lamps Bare - Other' THEN '88,89,90,113,97,98,99,100,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - TV' THEN '9'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - FP' THEN '19'
								WHEN ISNULL(@CATEGORY,'') = 'Generic Lamps Bare - Other' THEN '91,114'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Rear Projection' THEN '59'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Housing Kits - Front Projection' THEN '60'
								WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' OR ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '5,6,7,8,61,15,16,17,18,63,88,89,90,113,97,98,99,100,9,19,91,114,101,105,109,123,128,133,138,143'
								WHEN ISNULL(@CATEGORY,'') = 'Toys' THEN '36'
								WHEN ISNULL(@CATEGORY,'') = 'TV Parts' THEN '30'
								WHEN ISNULL(@CATEGORY,'') = 'Mexican Handcrafted' THEN '158'
								ELSE '0' END)

	SET @SQL = @SQL + ' ) GROUP BY TTS.SKU, TTS.SubSKU1, AD.SubSKU, PC.Name, PC.CategoryID '

	EXEC(@SQL)
	--END V2

	SET @SQL = ' INSERT INTO #tmpTopSellOrder (SKU, SubSKU1, SubSKU2, SubSKU3, QuantityOrdered, Name, CategoryID, Seq)
					SELECT TTS.SKU, TTS.SubSKU1, TTS.SubSKU2, AD.SubSKU, SUM(TTS.QuantityOrdered), PC.Name, PC.CategoryID, 3
					FROM #tmpTopSellOrder TTS
					LEFT OUTER JOIN [Inventory].dbo.[AssemblyDetails] AD (NOLOCK)
					ON AD.ProductCatalogID = TTS.SubSKU2 OR AD.ProductCatalogID = TTS.SubSKU1 OR AD.ProductCatalogID = TTS.SKU
					LEFT OUTER JOIN Inventory.dbo.ProductCatalog PC (NOLOCK)
					ON PC.ID = AD.SubSKU WHERE PC.CategoryID IN ( '

	SET @SQL = @SQL + (CASE WHEN ISNULL(@CATEGORY,'') = 'Lamp Burner' THEN '69' WHEN ISNULL(@CATEGORY,'') = 'Lamp Reflector' THEN '70' ELSE '0' END)

	SET @SQL = @SQL + ' ) GROUP BY TTS.SKU, TTS.SubSKU1, TTS.SubSKU2, AD.SubSKU, PC.Name, PC.CategoryID '
	
	EXEC(@SQL)

	---------- Bin History ----------
	DECLARE @tmpDays TABLE (Dates DATE, Qty INT, vQty INT)

	WHILE(@NEW_DATE <= @FINAL_DATE)
	BEGIN
		INSERT INTO @tmpDays (Dates) VALUES (@NEW_DATE)
		SET @NEW_DATE = DATEADD(DD,1,@NEW_DATE)
	END

	DECLARE @tmpSKUHistory TABLE (
		SKU INT, Global_Stock INT, Virtual_Stock INT, Activity_Date DATE
	)

	--DECLARE @tmpSKUHistory TABLE (
	--	id INT, TransactionId INT, mydate DATE, Bin_Id NVARCHAR(6), Reason NVARCHAR(2000), inputs INT, outputs INT, globalqty INT, username NVARCHAR(250), comments NVARCHAR(2500)
	--)

	--INSERT INTO @tmpSKUHistory (id, TransactionId, mydate, Bin_Id, Reason, inputs, outputs, globalqty, username, comments)
	--EXEC Inventory.dbo.sp_Bins_History @SKU, @INITIAL_DATE, @FINAL_DATE
	INSERT INTO @tmpSKUHistory
	SELECT SKU, Global_Stock, Virtual_Stock, Activity_Date FROM Inventory.dbo.BinMovement WITH(NOLOCK) WHERE SKU = @SKU AND Activity_Date BETWEEN @INITIAL_DATE AND @FINAL_DATE
	SET @NEW_QTY = 0
	SET @VS_QTY = 0
	SET @LAST_QTY = 0
	SET @VLAST_QTY = 0

	SET @CURSOR_DAYS = CURSOR FOR 

	SELECT Dates FROM @tmpDays

	OPEN @CURSOR_DAYS 
		FETCH NEXT FROM @CURSOR_DAYS 
		INTO @DATES
	   
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @NEW_QTY = (SELECT Global_Stock FROM @tmpSKUHistory WHERE Activity_Date = @DATES AND SKU = @SKU)
			SET @VS_QTY = (SELECT Virtual_Stock FROM @tmpSKUHistory WHERE Activity_Date = @DATES AND SKU = @SKU)
			
			IF(@NEW_QTY IS NULL)
			BEGIN
				SET @NEW_QTY = @LAST_QTY
			END

			IF(@VS_QTY IS NULL)
			BEGIN
				SET @VS_QTY = @VLAST_QTY
			END

			UPDATE @tmpDays SET Qty = @NEW_QTY, vQty = @VS_QTY WHERE Dates = @DATES

			SET @LAST_QTY = @NEW_QTY

			SET @VLAST_QTY = @VS_QTY

			NEXT_FETCH:
			FETCH NEXT FROM @CURSOR_DAYS
			INTO @DATES
		END
	CLOSE      @CURSOR_DAYS
	DEALLOCATE @CURSOR_DAYS

	SELECT CONVERT(NVARCHAR,D.Dates,101) AS Dates, D.Qty, ISNULL(O.QuantityOrdered,0) AS QuantityOrdered, @SKU AS SKU, D.vQty
	FROM @tmpDays D
	LEFT OUTER JOIN (
		SELECT CONVERT(NVARCHAR,OD.DetailDate,101) AS OrderDate, SUM(OD.QuantityOrdered) AS QuantityOrdered
		FROM OrderManager.dbo.[Order Details] OD (NOLOCK)
		INNER JOIN OrderManager.dbo.Orders O (NOLOCK) 
		ON O.OrderNumber = OD.OrderNumber AND O.Cancelled = 0
		WHERE CONVERT(NVARCHAR,OD.DetailDate,112) BETWEEN @DATE1 AND @DATE2 AND
		--OD.OrderNumber IN (
		--SELECT OrderNumber 
		--	FROM OrderManager.dbo.Orders (NOLOCK) WHERE CONVERT(NVARCHAR,OrderDate,112) BETWEEN @DATE1 AND @DATE2 --AND OrderStatus IN('Shipped','Order Approved','Order Received','Payment Received','Pending Shipment')
		--) AND OD.Adjustment = 0 
		--AND 
		OD.SKU IN (
			SELECT CONVERT(NVARCHAR,SKU) FROM #tmpTopSellOrder WHERE SKU = @SKU OR SubSKU1 = @SKU OR SubSKU2 = @SKU OR SubSKU3 = @SKU
		)
		GROUP BY CONVERT(NVARCHAR,OD.DetailDate,101)
	) O
	ON O.OrderDate = CONVERT(NVARCHAR,Dates,101)
	WHERE CONVERT(NVARCHAR,Dates,112) BETWEEN @DATE1 AND @DATE2
	ORDER BY Dates ASC

END

go

