-- =============================================
-- Author:		Amir Tafreshi
-- Create date: 7-12-2016
-- Description:	ADSI Void Order Manager Tracking Information
-- Deletes Tracking Number related to given order
-- Updates Status in Orders Table to Pending Shipment or if Cancelled ignores
-- Updates Status of items in Order Details table to Pending Shipment or if Cancelled ignores
-- =============================================
CREATE PROCEDURE [dbo].[sp_ADSIVoidTracking] 
	-- Add the parameters for the stored procedure here
		@pOrderNumber AS INT,
		@pTrackingNumber AS NVARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	if exists(select 1 from [OrderManager].[dbo].[Tracking]  where [OrderNum] = @pOrderNumber AND [TrackingID] = @pTrackingNumber) 
	BEGIN
		 DELETE FROM [OrderManager].[dbo].[Tracking] WHERE [TrackingID] = @pTrackingNumber AND [OrderNum] = @pOrderNumber
		
		--Set Order as Shipped
		  UPDATE O SET O.[OrderStatus] = 'Pending Shipment', O.[OrderStatusChanged] = '1', O.[OrdStatDetail] = 'Tracking Voided by ADSI: '+CONVERT (NVARCHAR(10), GETDATE(),101) 
		  FROM [OrderManager].[dbo].[Orders] AS O
		  LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] AS TRK ON (O.[OrderNumber] = TRK.[NumericKey])
		  WHERE [OrderNumber] = @pOrderNumber 
		  --AND TRK.[TrackingID] IS NOT NULL --This makes it insure that there is no trackingnumbers before changing status of order
		  AND O.[OrderStatus] != 'Canceled' --Leaves Status if items are cancelled

		--Set Items as Shipped
		  UPDATE OD SET [Status] = 'Pending Shipment', [DateShipped] = NULL, [StatusChanged] = '1' 
		  FROM [OrderManager].[dbo].[Order Details] AS OD
		  LEFT OUTER JOIN [OrderManager].[dbo].[Tracking] AS TRK ON (OD.[OrderNumber] = TRK.[NumericKey])
		  WHERE [OrderNumber] = @pOrderNumber AND [Adjustment] = 0 
		  --AND TRK.[TrackingID] IS NOT NULL --This makes it insure that there is no trackingnumbers before changing status of items
		  AND (OD.[Status] != 'Canceled' OR OD.[Status] != 'Item Canceled')--Leaves Status if items are cancelled

		  PRINT 'Tracking '+@pTrackingNumber+'Voided Successfully.'
	END	  


END
go

