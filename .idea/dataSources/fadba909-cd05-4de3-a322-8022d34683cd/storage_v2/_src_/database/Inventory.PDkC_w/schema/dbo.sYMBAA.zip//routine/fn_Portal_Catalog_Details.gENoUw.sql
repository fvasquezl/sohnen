-- =============================================
-- Author:		Luis Bautista
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_Portal_Catalog_Details]
(	
	@pCatalog_ID int
)
RETURNS  @Details TABLE 
(
							  Id int 
							, CatalogId int
							, Manufacturer nvarchar(50)
							, Partnumber nvarchar(50)
							, Models_List varchar(1000)
							, PN_List  varchar(1000)
							, Economical_price decimal (12,2)
							, Premium_price decimal(12,2)
							, compare_URL varchar(255)
							, image1_url varchar(255)
							, image2_url varchar(255)
							, image3_url varchar(255)
							, image4_url varchar(255)
							, image5_url varchar(255)
							, tbn1_url varchar(255)
							, tbn2_url varchar(255)
							, tbn3_url varchar(255)
							, tbn4_url varchar(255)
							, tbn5_url varchar(255)
							
							, sku int
				
)
AS
BEGIN

	DECLARE  @lid int ;
	DECLARE  @CatalogId int;
	DECLARE  @Manufacturer varchar(50);
	DECLARE  @Partnumber varchar(50);
	DECLARE  @Models_List varchar(1000);
	DECLARE  @PN_List  varchar(1000);
	DECLARE  @Economical_price decimal (12,2);
	DECLARE  @Premium_price decimal(12,2);
	DECLARE  @compare_URL varchar(255);
	DECLARE  @image1_url varchar(255);
	DECLARE  @image2_url varchar(255);
	DECLARE  @image3_url varchar(255);
	DECLARE  @image4_url varchar(255);
	DECLARE  @image5_url varchar(255);
	DECLARE  @tbn1_url varchar(255);
	DECLARE  @tbn2_url varchar(255);
	DECLARE  @tbn3_url varchar(255);
	DECLARE  @tbn4_url varchar(255);
	DECLARE  @tbn5_url varchar(255);
				
				
	SELECT @lid  = a.id
			, @CatalogId = a.CatalogID
			, @Manufacturer = a.Brand
			, @Partnumber = a.PartNumber
			, @Models_List = a.Models_Slash
			, @PN_List = a.PN_List
			, @Economical_price  = a.PriceGeneric
			, @Premium_price = a.PricePremium
			, @compare_URL = 'https://www.discount-merchant.com/Compare.aspx?ProductID=109'
			, @image1_url = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/' + cast(sku as varchar) + '-1.jpg'
			, @image2_url  = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/' + cast(sku as varchar) + '-2.jpg'
			, @image3_url  = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/' + cast(sku as varchar) + '-3.jpg'
			, @image4_url  = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/' + cast(sku as varchar) + '-4.jpg'
			, @image5_url  = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/' + cast(sku as varchar) + '-5.jpg'
			, @tbn1_url = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/th/' + cast(sku as varchar) + '-1.jpg'
			, @tbn2_url  = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/th/' + cast(sku as varchar) + '-2.jpg'
			, @tbn3_url  = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/th/' + cast(sku as varchar) + '-3.jpg'
			, @tbn4_url  = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/th/' + cast(sku as varchar) + '-4.jpg'
			, @tbn5_url  = 'http://photos.mitechnologiesinc.com/' + cast(sku as varchar) + '/th/' + cast(sku as varchar) + '-5.jpg'
		 FROM Catalog_Pager a 
	WHERE a.CatalogId = 	@pCatalog_ID;
	
	
	insert into @Details(
	  Id, CatalogId , Manufacturer , Partnumber 
		, Models_List , PN_List , Economical_price 
		, Premium_price , compare_URL
		, image1_url , image2_url , image3_url
		, image4_url , image5_url 
		, tbn1_url, tbn2_url , tbn3_url
		, tbn4_url, tbn5_url
	) values (
	@lid ,
	  @CatalogId ,
	  @Manufacturer ,
	  @Partnumber,
	  @Models_List ,
	  @PN_List  ,
	  @Economical_price ,
	  @Premium_price,
	  @compare_URL,
	  @image1_url ,
	  @image2_url ,
	  @image3_url ,
	  @image4_url ,
	  @image5_url 
	  , @tbn1_url, @tbn2_url , @tbn3_url
		, @tbn4_url, @tbn5_url
	);
	
	RETURN ;
END

go

