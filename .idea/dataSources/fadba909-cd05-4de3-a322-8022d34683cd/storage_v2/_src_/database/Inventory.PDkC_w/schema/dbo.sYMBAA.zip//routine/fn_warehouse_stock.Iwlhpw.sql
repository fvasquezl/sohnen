-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION fn_warehouse_stock
(
	-- Add the parameters for the function here
	@pwh int, @psku int
)
RETURNS decimal(18,2)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar decimal(18,2);

	-- Add the T-SQL statements to compute the return value here
	SET @ResultVar = (SELECT Quantity FROM inventory WHERE (ProductCatalogID = @psku) AND (AccountID = @pwh));

	-- Return the result of the function
	RETURN @ResultVar

END
go

